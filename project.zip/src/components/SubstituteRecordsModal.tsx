import { ChevronLeft, Plus, UserCheck } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { db } from '../db/database';
import type {
  AcademicYear,
  ClassSession,
  Course,
  Organization,
} from '../db/types';
import { formatSlashDate, formatSlashDateWithWeekday, toDateKey } from '../utils/date';
import {
  formatDurationSummary,
  getSessionDurationMinutes,
  isSessionCancelled,
  resolveSessionDisplay,
} from '../utils/sessionDisplay';
import { useBackLayer } from '../utils/backNavigation';
import { useLiveQuery } from '../utils/useLiveQuery';
import { SessionDetailModal } from './SessionDetailModal';
import { SessionFormModal } from './SessionFormModal';
import {
  CancelledBadge,
  SessionMenuButton,
  SessionQuickActionsHost,
  useSessionQuickActions,
} from './SessionQuickActions';
import { SubstituteBadge } from './SubstituteBadge';

interface SubstituteRecordsModalProps {
  open: boolean;
  onClose: () => void;
}

function formatMonthLabel(monthKey: string): string {
  const [year, month] = monthKey.split('-');
  if (!year || !month) return monthKey;
  return `${year} 年 ${Number.parseInt(month, 10)} 月`;
}

export function pickCurrentAcademicYearId(years: AcademicYear[]): string {
  if (years.length === 0) return '';
  const todayKey = toDateKey(new Date());
  const currentNonArchived = years.find(
    (y) => !y.archived && y.startDate <= todayKey && todayKey <= y.endDate
  );
  if (currentNonArchived) return currentNonArchived.id;
  const firstNonArchived = years.find((y) => !y.archived);
  return firstNonArchived?.id ?? years[0].id;
}

export function getSubstituteSessionsForYear(
  sessions: ClassSession[],
  year: AcademicYear | undefined,
  courseMap: Map<string, Course>
): ClassSession[] {
  const subSessions = sessions.filter((s) => s.kind === 'substitute');
  if (!year) return subSessions;
  return subSessions.filter((s) => {
    const course = s.courseId ? courseMap.get(s.courseId) : undefined;
    if (course && course.academicYearId) {
      return course.academicYearId === year.id;
    }
    return s.date >= year.startDate && s.date <= year.endDate;
  });
}

export function SubstituteRecordsModal({
  open,
  onClose,
}: SubstituteRecordsModalProps) {
  const academicYears = useLiveQuery(
    async (): Promise<AcademicYear[]> =>
      open ? db.academicYears.orderBy('startDate').reverse().toArray() : [],
    [open]
  );
  const organizations = useLiveQuery(
    async (): Promise<Organization[]> =>
      open ? db.organizations.orderBy('createdAt').toArray() : [],
    [open]
  );
  const courses = useLiveQuery(
    async (): Promise<Course[]> => (open ? db.courses.toArray() : []),
    [open]
  );
  const allSessions = useLiveQuery(
    async (): Promise<ClassSession[]> => (open ? db.sessions.toArray() : []),
    [open]
  );

  const [selectedYearId, setSelectedYearId] = useState('');
  const [selectedMonth, setSelectedMonth] = useState<string>('all');
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [createOpen, setCreateOpen] = useState(false);

  const { openSessionMenu, quickActionsProps } = useSessionQuickActions({
    courses: courses ?? [],
    organizations: organizations ?? [],
    onSessionDeleted: (deletedId) => {
      if (activeSessionId === deletedId) {
        setActiveSessionId(null);
      }
    },
  });

  useEffect(() => {
    if (!open) return;
    setSelectedMonth('all');
    setActiveSessionId(null);
  }, [open]);

  useBackLayer({
    active: open,
    zLayer: 40,
    onBack: onClose,
  });

  useEffect(() => {
    if (!open || !academicYears || academicYears.length === 0) return;
    if (!selectedYearId || !academicYears.some((y) => y.id === selectedYearId)) {
      setSelectedYearId(pickCurrentAcademicYearId(academicYears));
    }
  }, [open, academicYears, selectedYearId]);

  const courseMap = useMemo(
    () => new Map((courses ?? []).map((c) => [c.id, c])),
    [courses]
  );
  const orgMap = useMemo(
    () => new Map((organizations ?? []).map((o) => [o.id, o])),
    [organizations]
  );
  const sessionMap = useMemo(
    () => new Map((allSessions ?? []).map((s) => [s.id, s])),
    [allSessions]
  );
  const selectedYear = useMemo(
    () => (academicYears ?? []).find((y) => y.id === selectedYearId),
    [academicYears, selectedYearId]
  );

  const yearSubSessions = useMemo(() => {
    const list = getSubstituteSessionsForYear(
      allSessions ?? [],
      selectedYear,
      courseMap
    );
    return list.sort((a, b) => {
      const dateDiff = b.date.localeCompare(a.date);
      if (dateDiff !== 0) return dateDiff;
      const timeDiff = b.startTime.localeCompare(a.startTime);
      if (timeDiff !== 0) return timeDiff;
      return b.createdAt - a.createdAt;
    });
  }, [allSessions, selectedYear, courseMap]);

  const availableMonths = useMemo(() => {
    const monthSet = new Set<string>();
    for (const s of yearSubSessions) {
      if (s.date && s.date.length >= 7) {
        monthSet.add(s.date.slice(0, 7));
      }
    }
    return Array.from(monthSet).sort((a, b) => b.localeCompare(a));
  }, [yearSubSessions]);

  useEffect(() => {
    if (selectedMonth !== 'all' && !availableMonths.includes(selectedMonth)) {
      setSelectedMonth('all');
    }
  }, [availableMonths, selectedMonth]);

  const visibleSessions = useMemo(() => {
    if (selectedMonth === 'all') return yearSubSessions;
    return yearSubSessions.filter((s) => s.date.startsWith(selectedMonth));
  }, [yearSubSessions, selectedMonth]);

  const summary = useMemo(() => {
    let activeCount = 0;
    let cancelledCount = 0;
    let totalMinutes = 0;
    for (const s of visibleSessions) {
      if (isSessionCancelled(s)) {
        cancelledCount += 1;
        continue;
      }
      activeCount += 1;
      totalMinutes += getSessionDurationMinutes(s);
    }
    return {
      activeCount,
      cancelledCount,
      totalMinutes,
    };
  }, [visibleSessions]);

  if (!open) {
    return null;
  }

  const activeSession = activeSessionId
    ? (sessionMap.get(activeSessionId) ?? null)
    : null;
  const activeResolved = activeSession
    ? resolveSessionDisplay(activeSession, courseMap, orgMap)
    : null;

  const isLoading =
    academicYears === undefined ||
    organizations === undefined ||
    courses === undefined ||
    allSessions === undefined;

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="substitute-records-title"
        className="fixed inset-0 z-40 flex flex-col bg-[var(--bg-canvas)] pb-[var(--kb-inset,0px)]"
      >
        <header className="sticky top-0 z-10 border-b border-violet-200/70 bg-white/95 backdrop-blur-md">
          <div className="mx-auto flex h-12 w-full max-w-2xl items-center justify-between gap-2 px-2">
            <button
              type="button"
              onClick={onClose}
              className="flex min-h-[44px] shrink-0 items-center gap-1 rounded-xl px-2.5 text-sm font-medium text-zinc-700 transition-colors hover:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
            >
              <ChevronLeft size={18} aria-hidden="true" />
              <span>返回</span>
            </button>

            <h2
              id="substitute-records-title"
              className="truncate text-base font-semibold text-zinc-900"
            >
              代課／臨時紀錄
            </h2>

            <button
              type="button"
              onClick={() => setCreateOpen(true)}
              className="flex min-h-[44px] shrink-0 items-center gap-1 rounded-xl px-2.5 text-xs font-semibold text-amber-900 transition-colors hover:bg-amber-50 whitespace-nowrap"
            >
              <Plus size={15} aria-hidden="true" />
              <span>臨時代課</span>
            </button>
          </div>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
          <div className="mx-auto w-full max-w-2xl space-y-4 px-4 py-4 pb-[calc(2rem+env(safe-area-inset-bottom)+var(--kb-inset,0px))]">
            {/* 學年選擇與統計摘要 */}
            <div className="space-y-3 rounded-2xl border border-zinc-200 bg-white p-4">
              <div>
                <label
                  htmlFor="substitute-year-select"
                  className="block text-xs font-medium text-zinc-500"
                >
                  檢視學年
                </label>
                <select
                  id="substitute-year-select"
                  value={selectedYearId}
                  onChange={(e) => {
                    setSelectedYearId(e.target.value);
                    setSelectedMonth('all');
                  }}
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base font-semibold text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                >
                  {(academicYears ?? []).map((y) => (
                    <option key={y.id} value={y.id}>
                      {y.name}
                      {y.archived ? '（已歸檔）' : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 divide-x divide-zinc-100 rounded-xl border border-amber-200/80 bg-[#FEF9E7]">
                <div className="px-3.5 py-3">
                  <p className="text-xs font-medium text-amber-900/80">
                    累計堂數
                  </p>
                  <p className="mt-1 text-xl font-bold text-zinc-900 tabular-nums">
                    {summary.activeCount}{' '}
                    <span className="text-xs font-medium text-zinc-600">堂</span>
                  </p>
                </div>
                <div className="px-3.5 py-3">
                  <p className="text-xs font-medium text-amber-900/80">
                    總時數
                  </p>
                  <p className="mt-1 text-xl font-bold text-zinc-900 tabular-nums">
                    {formatDurationSummary(summary.totalMinutes)}
                  </p>
                </div>
              </div>

              {summary.cancelledCount > 0 && (
                <p className="text-xs text-zinc-500 tabular-nums">
                  另含 {summary.cancelledCount} 堂已取消紀錄（不計入累計堂數與時數）。
                </p>
              )}
            </div>

            {/* 月份篩選 */}
            {availableMonths.length > 0 && (
              <div
                role="tablist"
                aria-label="依月份篩選代課紀錄"
                className="flex items-center gap-1.5 overflow-x-auto pb-0.5"
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={selectedMonth === 'all'}
                  onClick={() => setSelectedMonth('all')}
                  className={`flex min-h-[44px] shrink-0 items-center justify-center rounded-xl border px-3.5 text-xs font-medium transition-colors whitespace-nowrap ${
                    selectedMonth === 'all'
                      ? 'border-violet-600 bg-[#CDB8FF] font-semibold text-zinc-900'
                      : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                  }`}
                >
                  全部月份
                </button>
                {availableMonths.map((monthKey) => {
                  const active = selectedMonth === monthKey;
                  return (
                    <button
                      key={monthKey}
                      type="button"
                      role="tab"
                      aria-selected={active}
                      onClick={() => setSelectedMonth(monthKey)}
                      className={`flex min-h-[44px] shrink-0 items-center justify-center rounded-xl border px-3.5 text-xs font-medium transition-colors whitespace-nowrap tabular-nums ${
                        active
                          ? 'border-violet-600 bg-[#CDB8FF] font-semibold text-zinc-900'
                          : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                      }`}
                    >
                      {formatMonthLabel(monthKey)}
                    </button>
                  );
                })}
              </div>
            )}

            {/* 代課場次列表 */}
            {isLoading ? (
              <div className="rounded-2xl border border-zinc-200 bg-white p-8 text-center text-sm text-zinc-500">
                載入中…
              </div>
            ) : visibleSessions.length === 0 ? (
              <div className="rounded-2xl border border-zinc-200 bg-white px-5 py-8 text-center">
                <UserCheck
                  size={24}
                  aria-hidden="true"
                  className="mx-auto text-zinc-400"
                />
                <p className="mt-2.5 text-sm font-medium text-zinc-800">
                  {selectedMonth === 'all'
                    ? '本學年尚無代課／臨時紀錄'
                    : '此月份沒有代課／臨時紀錄'}
                </p>
                <p className="mt-1 text-xs text-zinc-500">
                  點右上角「+ 臨時代課」，或從「今天」「週課表」頁面的新增按鈕建立。
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {visibleSessions.map((session) => {
                  const resolved = resolveSessionDisplay(
                    session,
                    courseMap,
                    orgMap
                  );
                  const isCancelled = isSessionCancelled(session);
                  const durationMins = getSessionDurationMinutes(session);

                  return (
                    <div
                      key={session.id}
                      className={`flex min-h-[72px] w-full items-center gap-1 rounded-2xl border transition-colors ${
                        isCancelled
                          ? 'border-zinc-200/80 bg-zinc-50/60'
                          : 'border-zinc-200 bg-white'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => setActiveSessionId(session.id)}
                        className="min-w-0 flex-1 rounded-l-2xl py-3 pl-4 pr-1 text-left transition-colors hover:bg-zinc-50/80 active:bg-zinc-100/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
                      >
                        <div className="min-w-0 space-y-1">
                          <div className="flex items-center gap-2">
                            <span
                              aria-hidden="true"
                              style={{ backgroundColor: resolved.color }}
                              className={`h-3.5 w-3.5 shrink-0 rounded-sm ring-1 ring-inset ring-black/15 ${
                                isCancelled ? 'opacity-45' : ''
                              }`}
                            />
                            <span
                              className={`truncate text-base font-semibold ${
                                isCancelled
                                  ? 'text-zinc-400 line-through'
                                  : 'text-zinc-900'
                              }`}
                            >
                              {resolved.title}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-1.5 pl-[22px] text-xs text-zinc-500">
                            <span>{resolved.orgName}</span>
                            <SubstituteBadge />
                            {resolved.substituteFor && (
                              <span
                                className={
                                  isCancelled ? 'text-zinc-400' : 'text-zinc-700'
                                }
                              >
                                （代 {resolved.substituteFor}）
                              </span>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 pl-[22px] text-xs tabular-nums">
                            <span
                              className={`font-medium ${
                                isCancelled
                                  ? 'text-zinc-400 line-through'
                                  : 'text-zinc-800'
                              }`}
                            >
                              {formatSlashDateWithWeekday(session.date)}{' '}
                              {session.startTime}–{session.endTime}
                            </span>
                            {durationMins > 0 && (
                              <span className="text-zinc-500">
                                （{durationMins} 分）
                              </span>
                            )}
                            {isCancelled && (
                              <>
                                <CancelledBadge />
                                {session.cancelReason && (
                                  <span className="text-zinc-500">
                                    {session.cancelReason}
                                  </span>
                                )}
                              </>
                            )}
                            {session.originalDate && session.originalStartTime && (
                              <span
                                className={`font-medium ${
                                  isCancelled
                                    ? 'text-zinc-400'
                                    : 'text-violet-700'
                                }`}
                              >
                                · 調課（原定 {formatSlashDate(session.originalDate)}{' '}
                                {session.originalStartTime}）
                              </span>
                            )}
                          </div>

                          {session.progress?.trim() && (
                            <p
                              className={`truncate pl-[22px] text-xs ${
                                isCancelled ? 'text-zinc-400' : 'text-zinc-600'
                              }`}
                            >
                              進度：{session.progress.trim()}
                            </p>
                          )}
                        </div>
                      </button>

                      <SessionMenuButton
                        onClick={() => openSessionMenu(session)}
                        ariaLabel={`更多操作：${resolved.title}`}
                        className="mr-1.5"
                      />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      <SessionDetailModal
        session={activeSession}
        course={activeResolved?.course}
        organization={activeResolved?.organization}
        allCourses={courses ?? []}
        allOrganizations={organizations ?? []}
        onClose={() => setActiveSessionId(null)}
      />

      <SessionFormModal
        open={createOpen}
        session={null}
        courses={courses ?? []}
        organizations={organizations ?? []}
        defaultMode="substitute"
        defaultDate={toDateKey(new Date())}
        onClose={() => setCreateOpen(false)}
      />
      <SessionQuickActionsHost {...quickActionsProps} />
    </>
  );
}
