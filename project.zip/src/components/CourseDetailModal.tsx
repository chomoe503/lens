import {
  CalendarPlus,
  Check,
  CheckSquare,
  ChevronRight,
  Pencil,
  Pin,
  PinOff,
  Plus,
  Repeat,
  Trash2,
  X,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type PointerEvent } from 'react';
import { db } from '../db/database';
import { deleteMultipleSessions } from '../db/repositories';
import type {
  AcademicYear,
  ClassSession,
  Course,
  CourseNote,
  Exam,
  Homework,
  HomeworkStatus,
  Organization,
  StoredImage,
  TaskItem,
} from '../db/types';
import {
  formatSlashDate,
  formatSlashDateWithWeekday,
  formatTimestamp,
  WEEKDAY_LABELS,
} from '../utils/date';
import { createId } from '../utils/id';
import { useBackLayer } from '../utils/backNavigation';
import { isSessionCancelled, isSubstituteSession } from '../utils/sessionDisplay';
import { pushUndoAction } from '../utils/undoStore';
import { useLiveQuery } from '../utils/useLiveQuery';
import { BatchGenerateSessionsModal } from './BatchGenerateSessionsModal';
import { ConfirmDialog } from './ConfirmDialog';
import { ExamFormModal } from './ExamFormModal';
import { HOMEWORK_STATUS_OPTIONS, HomeworkFormModal } from './HomeworkFormModal';
import { ThumbnailStrip } from './PhotoGallerySection';
import { SessionDetailModal } from './SessionDetailModal';
import { SessionFormModal } from './SessionFormModal';
import {
  CancelledBadge,
  SessionMenuButton,
  SessionQuickActionsHost,
  useSessionQuickActions,
} from './SessionQuickActions';
import { SubstituteBadge } from './SubstituteBadge';
import { TaskFormModal } from './TaskFormModal';
import { TaskRowItem } from './TaskRowItem';

export type CourseTabId = 'history' | 'exams' | 'homeworks' | 'notes';

interface CourseDetailModalProps {
  open: boolean;
  course: Course | null;
  organization?: Organization;
  academicYear?: AcademicYear;
  allCourses: Course[];
  allOrganizations: Organization[];
  initialTab?: CourseTabId;
  highlightItemId?: string | null;
  onClose: () => void;
  onEditCourse: (course: Course) => void;
}
type HomeworkFilter = 'all' | HomeworkStatus;

const COURSE_TABS: Array<{ id: CourseTabId; label: string }> = [
  { id: 'history', label: '歷史' },
  { id: 'exams', label: '考試' },
  { id: 'homeworks', label: '作業' },
  { id: 'notes', label: '備註' },
];

const HOMEWORK_FILTERS: Array<{ value: HomeworkFilter; label: string }> = [
  { value: 'all', label: '全部' },
  { value: 'uncollected', label: '未收' },
  { value: 'collected', label: '收齊' },
  { value: 'graded', label: '已批改' },
];

interface TimelineRowProps {
  session: ClassSession;
  orgMap: Map<string, Organization>;
  selectionMode: boolean;
  selected: boolean;
  onTap: (session: ClassSession) => void;
  onLongPress: (session: ClassSession) => void;
  onOpenMenu: (session: ClassSession) => void;
}

function TimelineRow({
  session,
  orgMap,
  selectionMode,
  selected,
  onTap,
  onLongPress,
  onOpenMenu,
}: TimelineRowProps) {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const startPosRef = useRef<{ x: number; y: number } | null>(null);
  const longPressFiredRef = useRef(false);

  const clearTimer = () => {
    if (timerRef.current !== null) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  const handlePointerDown = (e: PointerEvent<HTMLDivElement>) => {
    if (selectionMode) return;
    longPressFiredRef.current = false;
    startPosRef.current = { x: e.clientX, y: e.clientY };
    clearTimer();
    timerRef.current = setTimeout(() => {
      longPressFiredRef.current = true;
      onLongPress(session);
    }, 450);
  };

  const handlePointerMove = (e: PointerEvent<HTMLDivElement>) => {
    if (!startPosRef.current || timerRef.current === null) return;
    if (
      Math.abs(e.clientX - startPosRef.current.x) > 10 ||
      Math.abs(e.clientY - startPosRef.current.y) > 10
    ) {
      clearTimer();
    }
  };

  const handlePointerUpOrCancel = () => {
    clearTimer();
    startPosRef.current = null;
  };

  const isCancelled = isSessionCancelled(session);

  return (
    <div
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUpOrCancel}
      onPointerCancel={handlePointerUpOrCancel}
      onContextMenu={(e) => {
        if (!selectionMode) {
          e.preventDefault();
          onLongPress(session);
        }
      }}
      className="relative pl-6"
    >
      {/* 時間軸連接線與節點 */}
      <span
        aria-hidden="true"
        className="absolute bottom-0 left-[9px] top-0 w-px bg-zinc-200"
      />
      <span
        aria-hidden="true"
        className={`absolute left-[5px] top-5 h-2.5 w-2.5 rounded-full ring-2 ring-white ${
          isCancelled ? 'bg-zinc-400' : 'bg-violet-500'
        }`}
      />

      <div
        className={`flex min-h-[64px] w-full items-center gap-1 rounded-2xl border transition-colors ${
          selected
            ? 'border-violet-600 bg-[#F2ECFF]/70'
            : isCancelled
              ? 'border-zinc-200/80 bg-zinc-50/60'
              : 'border-zinc-200 bg-white'
        }`}
      >
        <button
          type="button"
          onClick={() => {
            if (longPressFiredRef.current) {
              longPressFiredRef.current = false;
              return;
            }
            onTap(session);
          }}
          className="flex min-w-0 flex-1 items-center gap-3 rounded-l-2xl py-3 pl-3.5 pr-1 text-left transition-colors hover:bg-zinc-50/80 active:bg-zinc-100/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
        >
          {selectionMode && (
            <span
              aria-hidden="true"
              className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${
                selected
                  ? 'border-violet-700 bg-violet-700 text-white'
                  : 'border-zinc-300 bg-white'
              }`}
            >
              {selected && <Check size={14} strokeWidth={2.5} />}
            </span>
          )}

          <div className="min-w-0 flex-1 space-y-1">
            {isSubstituteSession(session) && (
              <div>
                <p
                  className={`truncate text-base font-semibold ${
                    isCancelled ? 'text-zinc-400 line-through' : 'text-zinc-900'
                  }`}
                >
                  {session.title}
                </p>
                <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-zinc-500">
                  <span>
                    {(session.organizationId
                      ? orgMap.get(session.organizationId)?.name
                      : undefined) ?? '未指定單位'}
                  </span>
                  <SubstituteBadge />
                  {session.substituteFor?.trim() && (
                    <span className={isCancelled ? 'text-zinc-400' : 'text-zinc-700'}>
                      （代 {session.substituteFor.trim()}）
                    </span>
                  )}
                </div>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs tabular-nums">
              <span
                className={`font-semibold ${
                  isCancelled ? 'text-zinc-400 line-through' : 'text-zinc-900'
                }`}
              >
                {formatSlashDateWithWeekday(session.date)} {session.startTime}–
                {session.endTime}
              </span>
              {session.periodLabel && (
                <span className={isCancelled ? 'text-zinc-400' : 'text-zinc-500'}>
                  · {session.periodLabel}
                </span>
              )}
              {isCancelled && (
                <>
                  <CancelledBadge />
                  {session.cancelReason && (
                    <span className="text-zinc-500">{session.cancelReason}</span>
                  )}
                </>
              )}
              {session.kind === 'makeup' && (
                <span
                  className={`font-medium ${
                    isCancelled ? 'text-zinc-400' : 'text-violet-700'
                  }`}
                >
                  · 補課
                </span>
              )}
              {session.kind === 'extra' && (
                <span
                  className={`font-medium ${
                    isCancelled ? 'text-zinc-400' : 'text-violet-700'
                  }`}
                >
                  · 加課
                </span>
              )}
            </div>

            {session.originalDate && session.originalStartTime && (
              <p
                className={`text-xs font-medium tabular-nums ${
                  isCancelled ? 'text-zinc-400' : 'text-violet-700'
                }`}
              >
                調課：原定 {formatSlashDate(session.originalDate)}{' '}
                {session.originalStartTime}
              </p>
            )}

            <p
              className={`text-sm ${
                isCancelled
                  ? 'text-zinc-400'
                  : session.progress?.trim()
                    ? 'text-zinc-800'
                    : 'text-xs text-zinc-400'
              }`}
            >
              {session.progress?.trim()
                ? `進度：${session.progress.trim()}`
                : '尚未填寫上課進度'}
            </p>
          </div>
        </button>

        {!selectionMode && (
          <SessionMenuButton
            onClick={() => onOpenMenu(session)}
            ariaLabel={`更多操作：${formatSlashDate(session.date)} ${session.startTime}`}
            className="mr-1.5"
          />
        )}
      </div>
    </div>
  );
}

export function CourseDetailModal({
  open,
  course,
  organization,
  academicYear,
  allCourses,
  allOrganizations,
  initialTab = 'history',
  highlightItemId = null,
  onClose,
  onEditCourse,
}: CourseDetailModalProps) {
  const courseSessions = useLiveQuery(async (): Promise<ClassSession[]> => {
    if (!open || !course) return [];
    const rows = await db.sessions.where('courseId').equals(course.id).toArray();
    // 新的在上（依日期與時間降冪排序）
    return rows.sort((a, b) => {
      const dateDiff = b.date.localeCompare(a.date);
      if (dateDiff !== 0) return dateDiff;
      const timeDiff = b.startTime.localeCompare(a.startTime);
      if (timeDiff !== 0) return timeDiff;
      return b.createdAt - a.createdAt;
    });
  }, [open, course?.id]);

  const courseExams = useLiveQuery(async (): Promise<Exam[]> => {
    if (!open || !course) return [];
    const rows = await db.exams.where('courseId').equals(course.id).toArray();
    return rows.sort((a, b) => {
      const dateDiff = b.date.localeCompare(a.date);
      if (dateDiff !== 0) return dateDiff;
      return b.createdAt - a.createdAt;
    });
  }, [open, course?.id]);

  const courseExamImages = useLiveQuery(async (): Promise<StoredImage[]> => {
    if (!open || !course) return [];
    const rows = await db.images.where('courseId').equals(course.id).toArray();
    return rows
      .filter((img) => Boolean(img.examId))
      .sort((a, b) => a.createdAt - b.createdAt);
  }, [open, course?.id]);

  const courseHomeworks = useLiveQuery(async (): Promise<Homework[]> => {
    if (!open || !course) return [];
    const rows = await db.homeworks.where('courseId').equals(course.id).toArray();
    return rows.sort((a, b) => {
      const assignedDiff = b.assignedDate.localeCompare(a.assignedDate);
      if (assignedDiff !== 0) return assignedDiff;
      return b.createdAt - a.createdAt;
    });
  }, [open, course?.id]);

  const courseNotes = useLiveQuery(async (): Promise<CourseNote[]> => {
    if (!open || !course) return [];
    const rows = await db.courseNotes
      .where('courseId')
      .equals(course.id)
      .toArray();
    return rows.sort((a, b) => {
      const pinDiff = Number(b.pinned) - Number(a.pinned);
      if (pinDiff !== 0) return pinDiff;
      return b.updatedAt - a.updatedAt;
    });
  }, [open, course?.id]);

  const courseTasks = useLiveQuery(async (): Promise<TaskItem[]> => {
    if (!open || !course || course.isSystem) return [];
    const rows = await db.tasks.where('courseId').equals(course.id).toArray();
    return rows.sort((a, b) => {
      const doneDiff = Number(a.done) - Number(b.done);
      if (doneDiff !== 0) return doneDiff;
      return b.createdAt - a.createdAt;
    });
  }, [open, course?.id, course?.isSystem]);

  const [activeTab, setActiveTab] = useState<CourseTabId>('history');
  const [homeworkFilter, setHomeworkFilter] = useState<HomeworkFilter>('all');

  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [createSessionOpen, setCreateSessionOpen] = useState(false);
  const [batchModalOpen, setBatchModalOpen] = useState(false);

  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [multiDeleteConfirmOpen, setMultiDeleteConfirmOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Exams & Homeworks modal state
  const [examModalOpen, setExamModalOpen] = useState(false);
  const [editingExam, setEditingExam] = useState<Exam | null>(null);
  const [homeworkModalOpen, setHomeworkModalOpen] = useState(false);
  const [editingHomework, setEditingHomework] = useState<Homework | null>(null);

  // Tasks modal state
  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskItem | null>(null);

  // Notes state
  const [newNoteText, setNewNoteText] = useState('');
  const [isSavingNote, setIsSavingNote] = useState(false);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editingNoteText, setEditingNoteText] = useState('');
  const [deleteNoteTarget, setDeleteNoteTarget] = useState<CourseNote | null>(null);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);

  const { openSessionMenu, quickActionsProps } = useSessionQuickActions({
    courses: allCourses,
    organizations: allOrganizations,
    onSessionDeleted: (deletedId) => {
      if (activeSessionId === deletedId) {
        setActiveSessionId(null);
      }
      setSelectedIds((prev) => prev.filter((id) => id !== deletedId));
    },
  });

  useEffect(() => {
    if (!open) return;
    setActiveTab(initialTab);
    setHomeworkFilter('all');
    setActiveSessionId(null);
    setSelectionMode(false);
    setSelectedIds([]);
    setMultiDeleteConfirmOpen(false);
    setNewNoteText('');
    setEditingNoteId(null);
    setDeleteNoteTarget(null);
    setDiscardConfirmOpen(false);
  }, [open, course?.id, initialTab]);

  const hasUnsavedNoteDraft =
    newNoteText.trim() !== '' || editingNoteId !== null;

  const handleRequestClose = () => {
    if (isSavingNote || isDeleting) return;
    if (hasUnsavedNoteDraft) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: open && course !== null,
    zLayer: 40,
    onBack: handleRequestClose,
  });

  const filteredSessions = courseSessions ?? [];

  const filteredHomeworks = useMemo(() => {
    const list = courseHomeworks ?? [];
    if (homeworkFilter === 'all') return list;
    return list.filter((hw) => hw.status === homeworkFilter);
  }, [courseHomeworks, homeworkFilter]);

  const examImagesMap = useMemo(() => {
    const map = new Map<string, StoredImage[]>();
    for (const img of courseExamImages ?? []) {
      if (!img.examId) continue;
      const arr = map.get(img.examId) ?? [];
      arr.push(img);
      map.set(img.examId, arr);
    }
    return map;
  }, [courseExamImages]);

  const orgMap = useMemo(() => {
    const map = new Map<string, Organization>();
    for (const o of allOrganizations) map.set(o.id, o);
    return map;
  }, [allOrganizations]);

  const activeSession = useMemo(() => {
    if (!activeSessionId || !courseSessions) return null;
    return courseSessions.find((s) => s.id === activeSessionId) ?? null;
  }, [activeSessionId, courseSessions]);

  if (!open || !course) {
    return null;
  }

  const regularSlots = course.regularSlots ?? [];

  const handleTapSession = (session: ClassSession) => {
    if (selectionMode) {
      setSelectedIds((prev) =>
        prev.includes(session.id)
          ? prev.filter((id) => id !== session.id)
          : [...prev, session.id]
      );
      return;
    }
    setActiveSessionId(session.id);
  };

  const handleLongPressSession = (session: ClassSession) => {
    setSelectionMode(true);
    setSelectedIds((prev) =>
      prev.includes(session.id) ? prev : [...prev, session.id]
    );
  };

  const handleConfirmMultiDelete = async () => {
    if (selectedIds.length === 0) return;
    setIsDeleting(true);
    try {
      const count = selectedIds.length;
      const backup = await deleteMultipleSessions(selectedIds);
      pushUndoAction(`已刪除 ${count} 堂場次`, backup);
      setMultiDeleteConfirmOpen(false);
      setSelectionMode(false);
      setSelectedIds([]);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleUpdateHomeworkStatus = async (
    hw: Homework,
    nextStatus: HomeworkStatus
  ) => {
    if (hw.status === nextStatus) return;
    await db.homeworks.update(hw.id, {
      status: nextStatus,
      updatedAt: Date.now(),
    });
  };

  const handleAddNote = async () => {
    const trimmed = newNoteText.trim();
    if (!trimmed) return;
    setIsSavingNote(true);
    try {
      const now = Date.now();
      await db.courseNotes.put({
        id: createId(),
        courseId: course.id,
        content: trimmed,
        pinned: false,
        createdAt: now,
        updatedAt: now,
      });
      setNewNoteText('');
    } finally {
      setIsSavingNote(false);
    }
  };

  const handleTogglePinNote = async (noteItem: CourseNote) => {
    await db.courseNotes.update(noteItem.id, {
      pinned: !noteItem.pinned,
      updatedAt: Date.now(),
    });
  };

  const handleSaveEditNote = async (noteId: string) => {
    const trimmed = editingNoteText.trim();
    if (!trimmed) return;
    await db.courseNotes.update(noteId, {
      content: trimmed,
      updatedAt: Date.now(),
    });
    setEditingNoteId(null);
    setEditingNoteText('');
  };

  const handleConfirmDeleteNote = async () => {
    if (!deleteNoteTarget) return;
    await db.courseNotes.delete(deleteNoteTarget.id);
    setDeleteNoteTarget(null);
  };

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="course-detail-title"
        className="fixed inset-0 z-40 flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
      >
        <div className="flex max-h-[92dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          {/* 頂部課程標題列 */}
          <div className="flex shrink-0 items-center justify-between gap-2 border-b border-zinc-100 bg-white px-4 py-3">
            <div className="flex min-w-0 items-center gap-2.5">
              <span
                aria-hidden="true"
                style={{ backgroundColor: course.color }}
                className="h-4 w-4 shrink-0 rounded-sm ring-1 ring-inset ring-black/15"
              />
              <div className="min-w-0">
                <h2
                  id="course-detail-title"
                  className="truncate text-base font-semibold text-zinc-900"
                >
                  {course.name}
                </h2>
                <p className="truncate text-xs text-zinc-500">
                  {organization?.name ?? '未指定單位'}
                  {academicYear ? ` · ${academicYear.name}` : ''}
                </p>
              </div>
            </div>

            <div className="flex shrink-0 items-center gap-1">
              {!course.isSystem && (
                <button
                  type="button"
                  onClick={() => onEditCourse(course)}
                  aria-label="編輯課程"
                  className="flex min-h-[44px] items-center justify-center gap-1 rounded-xl px-3 text-xs font-medium text-violet-700 hover:bg-violet-50"
                >
                  <Pencil size={15} aria-hidden="true" />
                  <span>編輯</span>
                </button>
              )}
              <button
                type="button"
                onClick={handleRequestClose}
                aria-label="關閉"
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* 課程資訊與四分頁切換 */}
          <div className="shrink-0 space-y-2.5 border-b border-zinc-100 bg-zinc-50/70 px-4 py-2.5">
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-zinc-600">
              {course.subject && (
                <span>
                  科目：
                  <strong className="font-medium text-zinc-900">
                    {course.subject}
                  </strong>
                </span>
              )}
              <span className="tabular-nums">
                預設時長：
                <strong className="font-medium text-zinc-900">
                  {course.defaultDurationMinutes} 分
                </strong>
              </span>
              {course.material && (
                <span className="truncate">
                  教材：
                  <strong className="font-medium text-zinc-900">
                    {course.material}
                  </strong>
                </span>
              )}
            </div>

            {regularSlots.length > 0 && (
              <p className="truncate text-xs text-zinc-600 tabular-nums">
                常用時段：
                {regularSlots
                  .map(
                    (s) =>
                      `${WEEKDAY_LABELS[s.weekday]}${s.periodLabel ? ` ${s.periodLabel}` : ''} ${s.startTime}–${s.endTime}`
                  )
                  .join(' · ')}
              </p>
            )}

            {!course.isSystem && course.studentSchoolIds !== undefined && (
              <p className="truncate text-xs text-zinc-600">
                學生來自：
                {(() => {
                  const schoolMap = new Map(
                    (organization?.studentSchools ?? []).map((s) => [s.id, s.name])
                  );
                  const names = course.studentSchoolIds
                    .map((id) => schoolMap.get(id))
                    .filter((n): n is string => Boolean(n));
                  return names.length > 0 ? names.join('、') : '未選取任何學校';
                })()}
              </p>
            )}

            <div
              role="tablist"
              aria-label="課程分頁"
              className="grid grid-cols-4 gap-1 rounded-2xl border border-violet-200/80 bg-white p-1"
            >
              {COURSE_TABS.map((tab) => {
                const active = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    role="tab"
                    aria-selected={active}
                    onClick={() => {
                      setActiveTab(tab.id);
                      if (tab.id !== 'history') {
                        setSelectionMode(false);
                        setSelectedIds([]);
                      }
                    }}
                    className={`flex min-h-[44px] items-center justify-center rounded-xl text-xs font-medium transition-colors sm:text-sm ${
                      active
                        ? 'bg-[#CDB8FF] font-semibold text-zinc-900'
                        : 'text-zinc-600 hover:text-zinc-900'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 分頁內容區 */}
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-4">
            {activeTab === 'history' && (
              <div className="space-y-3.5">
                {course.isSystem ? (
                  <button
                    type="button"
                    onClick={() => setCreateSessionOpen(true)}
                    className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-3 py-2 text-sm font-medium text-white transition-colors hover:bg-violet-700"
                  >
                    <Plus size={16} aria-hidden="true" />
                    <span>新增代課場次</span>
                  </button>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setCreateSessionOpen(true)}
                      className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-3 py-2 text-sm font-medium text-white transition-colors hover:bg-violet-700"
                    >
                      <Plus size={16} aria-hidden="true" />
                      <span>新增場次</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setBatchModalOpen(true)}
                      className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-violet-300 bg-[#F2ECFF] px-3 py-2 text-sm font-semibold text-zinc-900 transition-colors hover:bg-[#e8ddff]"
                    >
                      <Repeat size={15} aria-hidden="true" />
                      <span>依常用時段產生</span>
                    </button>
                  </div>
                )}

                {!course.isSystem && (
                  <div className="rounded-2xl border border-zinc-200 bg-white p-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <h3 className="text-xs font-semibold text-zinc-800">
                          班級任務與提醒
                        </h3>
                        <p className="text-[11px] text-zinc-500">
                          沒指定場次的任務會自動跟隨下一堂課
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingTask(null);
                          setTaskModalOpen(true);
                        }}
                        className="flex min-h-[40px] shrink-0 items-center justify-center gap-1 rounded-xl border border-violet-300 bg-[#F2ECFF] px-3 text-xs font-semibold text-zinc-900 transition-colors hover:bg-[#e8ddff] whitespace-nowrap"
                      >
                        <Plus size={14} aria-hidden="true" />
                        <span>新增任務</span>
                      </button>
                    </div>

                    {(courseTasks ?? []).length > 0 && (
                      <div className="mt-2 divide-y divide-zinc-100 border-t border-zinc-100 pt-1">
                        {(courseTasks ?? []).map((t) => (
                          <TaskRowItem
                            key={t.id}
                            task={t}
                            compact
                            metaText={
                              t.dueDate
                                ? formatSlashDateWithWeekday(t.dueDate)
                                : t.sessionId
                                  ? '指定場次'
                                  : '跟隨下一堂課'
                            }
                            onEdit={(target) => {
                              setEditingTask(target);
                              setTaskModalOpen(true);
                            }}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {(courseSessions ?? []).length > 0 && (
                  <div className="flex items-center justify-between gap-2 px-0.5">
                    <p className="text-xs font-medium text-zinc-500 tabular-nums">
                      共 {filteredSessions.length} 堂場次
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        if (selectionMode) {
                          setSelectionMode(false);
                          setSelectedIds([]);
                        } else {
                          setSelectionMode(true);
                        }
                      }}
                      className="flex min-h-[44px] shrink-0 items-center justify-center gap-1 rounded-xl px-2.5 text-xs font-medium text-violet-700 hover:bg-violet-50 whitespace-nowrap"
                    >
                      <CheckSquare size={15} aria-hidden="true" />
                      <span>{selectionMode ? '取消' : '多選'}</span>
                    </button>
                  </div>
                )}

                {courseSessions === undefined ? (
                  <p className="py-6 text-center text-sm text-zinc-500">
                    載入場次中…
                  </p>
                ) : filteredSessions.length === 0 ? (
                  <div className="rounded-2xl border border-zinc-200 bg-white p-6 text-center">
                    <CalendarPlus
                      size={22}
                      className="mx-auto text-zinc-400"
                      aria-hidden="true"
                    />
                    <p className="mt-2 text-sm text-zinc-600">
                      此課程尚無場次紀錄
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {filteredSessions.map((session) => (
                      <TimelineRow
                        key={session.id}
                        session={session}
                        orgMap={orgMap}
                        selectionMode={selectionMode}
                        selected={selectedIds.includes(session.id)}
                        onTap={handleTapSession}
                        onLongPress={handleLongPressSession}
                        onOpenMenu={openSessionMenu}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'exams' && (
              <div className="space-y-3.5">
                <button
                  type="button"
                  onClick={() => {
                    setEditingExam(null);
                    setExamModalOpen(true);
                  }}
                  className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-violet-700"
                >
                  <Plus size={16} aria-hidden="true" />
                  <span>新增考試</span>
                </button>

                {courseExams === undefined ? (
                  <p className="py-6 text-center text-sm text-zinc-500">載入中…</p>
                ) : courseExams.length === 0 ? (
                  <div className="rounded-2xl border border-zinc-200 bg-white p-6 text-center text-sm text-zinc-500">
                    尚無考試紀錄，點上方按鈕即可新增小考或段考資訊。
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {courseExams.map((exam) => {
                      const photos = examImagesMap.get(exam.id) ?? [];
                      const isHighlighted = highlightItemId === exam.id;
                      return (
                        <div
                          key={exam.id}
                          className={`rounded-2xl border p-3.5 ${
                            isHighlighted
                              ? 'border-2 border-violet-600 bg-[#FAF7FF]'
                              : 'border-zinc-200 bg-white'
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() => {
                              setEditingExam(exam);
                              setExamModalOpen(true);
                            }}
                            className="flex w-full items-start justify-between gap-2 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 rounded-xl"
                          >
                            <div className="min-w-0 flex-1 space-y-1">
                              <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                                <span className="text-base font-semibold text-zinc-900">
                                  {exam.title}
                                </span>
                                {exam.examType && (
                                  <span className="text-xs font-medium text-violet-700">
                                    · {exam.examType}
                                  </span>
                                )}
                              </div>

                              <p className="text-xs font-medium text-zinc-700 tabular-nums">
                                {formatSlashDateWithWeekday(exam.date)}
                                {exam.time ? ` ${exam.time}` : ''}
                              </p>

                              {exam.scope && (
                                <p className="text-xs text-zinc-600">
                                  範圍：{exam.scope}
                                </p>
                              )}
                              {exam.note && (
                                <p className="text-xs text-zinc-500">
                                  {exam.note}
                                </p>
                              )}
                            </div>

                            <ChevronRight
                              size={17}
                              aria-hidden="true"
                              className="mt-1 shrink-0 text-zinc-400"
                            />
                          </button>

                          {photos.length > 0 && <ThumbnailStrip images={photos} />}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'homeworks' && (
              <div className="space-y-3.5">
                <button
                  type="button"
                  onClick={() => {
                    setEditingHomework(null);
                    setHomeworkModalOpen(true);
                  }}
                  className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-violet-700"
                >
                  <Plus size={16} aria-hidden="true" />
                  <span>新增作業</span>
                </button>

                <div
                  role="tablist"
                  aria-label="依作業狀態篩選"
                  className="grid grid-cols-4 gap-1.5"
                >
                  {HOMEWORK_FILTERS.map((opt) => {
                    const active = homeworkFilter === opt.value;
                    return (
                      <button
                        key={opt.value}
                        type="button"
                        role="tab"
                        aria-selected={active}
                        onClick={() => setHomeworkFilter(opt.value)}
                        className={`flex min-h-[44px] items-center justify-center rounded-xl border text-xs font-medium transition-colors ${
                          active
                            ? 'border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                            : 'border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-50'
                        }`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>

                {courseHomeworks === undefined ? (
                  <p className="py-6 text-center text-sm text-zinc-500">載入中…</p>
                ) : filteredHomeworks.length === 0 ? (
                  <div className="rounded-2xl border border-zinc-200 bg-white p-6 text-center text-sm text-zinc-500">
                    {homeworkFilter === 'all'
                      ? '尚無作業紀錄'
                      : '此狀態下沒有作業'}
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {filteredHomeworks.map((hw) => (
                      <div
                        key={hw.id}
                        className={`space-y-2.5 rounded-2xl border p-3.5 ${
                          highlightItemId === hw.id
                            ? 'border-2 border-violet-600 bg-[#FAF7FF]'
                            : 'border-zinc-200 bg-white'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => {
                            setEditingHomework(hw);
                            setHomeworkModalOpen(true);
                          }}
                          className="flex w-full items-start justify-between gap-2 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 rounded-xl"
                        >
                          <div className="min-w-0 flex-1 space-y-1">
                            <p className="text-base font-semibold text-zinc-900">
                              {hw.title}
                            </p>
                            <p className="text-xs text-zinc-600 tabular-nums">
                              派出：{formatSlashDateWithWeekday(hw.assignedDate)}
                              {hw.dueDate
                                ? ` · 繳交：${formatSlashDateWithWeekday(hw.dueDate)}`
                                : ' · 未設繳交日'}
                            </p>
                            {hw.note && (
                              <p className="text-xs text-zinc-500">{hw.note}</p>
                            )}
                          </div>
                          <ChevronRight
                            size={17}
                            aria-hidden="true"
                            className="mt-1 shrink-0 text-zinc-400"
                          />
                        </button>

                        <div className="grid grid-cols-3 gap-1.5 border-t border-zinc-100 pt-2">
                          {HOMEWORK_STATUS_OPTIONS.map((opt) => {
                            const active = hw.status === opt.value;
                            return (
                              <button
                                key={opt.value}
                                type="button"
                                onClick={() => {
                                  void handleUpdateHomeworkStatus(hw, opt.value);
                                }}
                                className={`flex min-h-[44px] items-center justify-center rounded-xl border text-xs font-medium transition-colors ${
                                  active
                                    ? opt.value === 'graded'
                                      ? 'border-emerald-600 bg-emerald-50 font-semibold text-emerald-800'
                                      : opt.value === 'collected'
                                        ? 'border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                                        : 'border-amber-500 bg-amber-50 font-semibold text-amber-900'
                                    : 'border-zinc-200 bg-zinc-50/70 text-zinc-600 hover:bg-zinc-100'
                                }`}
                              >
                                {opt.label}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'notes' && (
              <div className="space-y-3.5">
                <div className="space-y-2 rounded-2xl border border-zinc-200 bg-white p-3.5">
                  <label
                    htmlFor="course-new-note-input"
                    className="block text-xs font-medium text-zinc-700"
                  >
                    新增課程備註
                  </label>
                  <textarea
                    id="course-new-note-input"
                    rows={3}
                    value={newNoteText}
                    onChange={(e) => setNewNoteText(e.target.value)}
                    placeholder="寫下全學期通用規則、學生狀況、教室位置或教學提醒…"
                    className="w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                  <button
                    type="button"
                    disabled={isSavingNote || !newNoteText.trim()}
                    onClick={() => {
                      void handleAddNote();
                    }}
                    className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-violet-700 disabled:bg-zinc-200 disabled:text-zinc-500"
                  >
                    <Plus size={16} aria-hidden="true" />
                    <span>{isSavingNote ? '新增中…' : '新增備註'}</span>
                  </button>
                </div>

                {course.note && (
                  <div className="rounded-2xl border border-zinc-200 bg-zinc-50/70 p-3.5">
                    <p className="text-xs font-medium text-zinc-500">
                      課程設定備註
                    </p>
                    <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed text-zinc-800">
                      {course.note}
                    </p>
                  </div>
                )}

                {courseNotes === undefined ? (
                  <p className="py-6 text-center text-sm text-zinc-500">載入中…</p>
                ) : courseNotes.length === 0 ? (
                  <div className="rounded-2xl border border-zinc-200 bg-white p-6 text-center text-sm text-zinc-500">
                    尚未新增課程備註，重要事項可加入後置頂。
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {courseNotes.map((noteItem) => {
                      const isEditingThis = editingNoteId === noteItem.id;
                      return (
                        <div
                          key={noteItem.id}
                          className={`rounded-2xl border p-3.5 ${
                            noteItem.pinned
                              ? 'border-violet-300 bg-[#FAF7FF]'
                              : 'border-zinc-200 bg-white'
                          }`}
                        >
                          {isEditingThis ? (
                            <div className="space-y-2">
                              <textarea
                                rows={3}
                                value={editingNoteText}
                                onChange={(e) => setEditingNoteText(e.target.value)}
                                className="w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                              />
                              <div className="grid grid-cols-2 gap-2">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingNoteId(null);
                                    setEditingNoteText('');
                                  }}
                                  className="flex min-h-[44px] items-center justify-center rounded-xl border border-zinc-200 bg-white text-xs font-medium text-zinc-700"
                                >
                                  取消
                                </button>
                                <button
                                  type="button"
                                  disabled={!editingNoteText.trim()}
                                  onClick={() => {
                                    void handleSaveEditNote(noteItem.id);
                                  }}
                                  className="flex min-h-[44px] items-center justify-center rounded-xl bg-violet-600 text-xs font-medium text-white disabled:opacity-50"
                                >
                                  儲存
                                </button>
                              </div>
                            </div>
                          ) : (
                            <>
                              <div className="flex items-center justify-between gap-2 text-xs text-zinc-500">
                                <span className="tabular-nums">
                                  {formatTimestamp(noteItem.updatedAt)}
                                  {noteItem.pinned ? (
                                    <strong className="ml-2 font-semibold text-violet-700">
                                      · 已置頂
                                    </strong>
                                  ) : null}
                                </span>
                              </div>

                              <p className="mt-1.5 whitespace-pre-wrap text-sm leading-relaxed text-zinc-900">
                                {noteItem.content}
                              </p>

                              <div className="mt-3 flex items-center gap-1.5 border-t border-zinc-100 pt-2">
                                <button
                                  type="button"
                                  onClick={() => {
                                    void handleTogglePinNote(noteItem);
                                  }}
                                  className={`flex min-h-[44px] flex-1 items-center justify-center gap-1 rounded-xl border px-2 text-xs font-medium transition-colors ${
                                    noteItem.pinned
                                      ? 'border-violet-300 bg-[#EDE6FF] text-zinc-900'
                                      : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                                  }`}
                                >
                                  {noteItem.pinned ? (
                                    <>
                                      <PinOff size={14} aria-hidden="true" />
                                      <span>取消置頂</span>
                                    </>
                                  ) : (
                                    <>
                                      <Pin size={14} aria-hidden="true" />
                                      <span>置頂</span>
                                    </>
                                  )}
                                </button>

                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingNoteId(noteItem.id);
                                    setEditingNoteText(noteItem.content);
                                  }}
                                  className="flex min-h-[44px] items-center justify-center gap-1 rounded-xl border border-zinc-200 bg-white px-3 text-xs font-medium text-zinc-700 hover:bg-zinc-50"
                                >
                                  <Pencil size={14} aria-hidden="true" />
                                  <span>編輯</span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => setDeleteNoteTarget(noteItem)}
                                  aria-label="刪除備註"
                                  className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-rose-200 bg-white text-rose-600 hover:bg-rose-50"
                                >
                                  <Trash2 size={15} aria-hidden="true" />
                                </button>
                              </div>
                            </>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* 底部動作列 */}
          {selectionMode && activeTab === 'history' ? (
            <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const allIds = filteredSessions.map((s) => s.id);
                    setSelectedIds(
                      selectedIds.length === allIds.length ? [] : allIds
                    );
                  }}
                  className="flex min-h-[44px] items-center justify-center rounded-xl border border-zinc-200 bg-white px-3.5 text-xs font-medium text-zinc-700 hover:bg-zinc-50"
                >
                  {selectedIds.length === filteredSessions.length
                    ? '取消全選'
                    : '全選'}
                </button>
                <button
                  type="button"
                  disabled={selectedIds.length === 0}
                  onClick={() => setMultiDeleteConfirmOpen(true)}
                  className="flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-rose-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-rose-700 disabled:opacity-50"
                >
                  <Trash2 size={16} aria-hidden="true" />
                  <span>刪除所選（{selectedIds.length} 堂）</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
              <button
                type="button"
                onClick={handleRequestClose}
                className="flex min-h-[44px] w-full items-center justify-center rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm font-medium text-zinc-700 hover:bg-zinc-50"
              >
                關閉
              </button>
            </div>
          )}
        </div>
      </div>

      <SessionDetailModal
        session={activeSession}
        course={course}
        organization={
          activeSession && isSubstituteSession(activeSession)
            ? activeSession.organizationId
              ? orgMap.get(activeSession.organizationId)
              : undefined
            : organization
        }
        allCourses={allCourses}
        allOrganizations={allOrganizations}
        onClose={() => setActiveSessionId(null)}
      />

      <SessionFormModal
        open={createSessionOpen}
        session={null}
        courses={allCourses}
        organizations={allOrganizations}
        defaultMode={course.isSystem ? 'substitute' : 'regular'}
        defaultCourseId={course.isSystem ? undefined : course.id}
        defaultKind={course.isSystem ? 'substitute' : 'regular'}
        onClose={() => setCreateSessionOpen(false)}
      />

      <BatchGenerateSessionsModal
        open={batchModalOpen}
        course={course}
        academicYear={academicYear}
        onClose={() => setBatchModalOpen(false)}
      />

      <ExamFormModal
        open={examModalOpen}
        exam={editingExam}
        courseId={course.id}
        onClose={() => setExamModalOpen(false)}
      />

      <HomeworkFormModal
        open={homeworkModalOpen}
        homework={editingHomework}
        courseId={course.id}
        onClose={() => setHomeworkModalOpen(false)}
      />

      <TaskFormModal
        open={taskModalOpen}
        task={editingTask}
        courses={allCourses}
        sessions={courseSessions ?? []}
        organizations={allOrganizations}
        defaultCourseId={course.id}
        onClose={() => setTaskModalOpen(false)}
      />

      <ConfirmDialog
        open={multiDeleteConfirmOpen}
        title="刪除多筆場次"
        description={`確定要刪除所選的 ${selectedIds.length} 堂場次嗎？刪除後 12 秒內可點擊「復原」。`}
        confirmLabel={`刪除 ${selectedIds.length} 堂`}
        isSubmitting={isDeleting}
        onCancel={() => setMultiDeleteConfirmOpen(false)}
        onConfirm={() => {
          void handleConfirmMultiDelete();
        }}
      />

      <ConfirmDialog
        open={deleteNoteTarget !== null}
        title="刪除課程備註"
        description="確定要刪除這則課程備註嗎？刪除後無法復原。"
        confirmLabel="確認刪除"
        onCancel={() => setDeleteNoteTarget(null)}
        onConfirm={() => {
          void handleConfirmDeleteNote();
        }}
      />

      <ConfirmDialog
        open={discardConfirmOpen}
        title="放棄未儲存的內容？"
        description="備註欄有尚未儲存的內容，確定要放棄並關閉嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardConfirmOpen(false)}
        onConfirm={() => {
          setDiscardConfirmOpen(false);
          onClose();
        }}
      />
      <SessionQuickActionsHost {...quickActionsProps} />
    </>
  );
}
