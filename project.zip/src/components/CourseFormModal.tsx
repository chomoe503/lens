import { Plus, RotateCcw, Trash2, X } from 'lucide-react';
import { useEffect, useState, type FormEvent } from 'react';
import { db } from '../db/database';
import { deleteCourseCascade, getCourseDeleteSummary } from '../db/repositories';
import type {
  AcademicYear,
  Course,
  CourseRegularSlot,
  Organization,
  Period,
} from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import { DEFAULT_ORG_COLOR, ORGANIZATION_TYPE_LABELS } from '../utils/colors';
import {
  composeCourseName,
  parseCourseQuickParts,
  QUICK_CLASSES,
  QUICK_GRADES,
} from '../utils/courseSort';
import { createId } from '../utils/id';
import { useLiveQuery } from '../utils/useLiveQuery';
import { ColorPickerGrid } from './ColorPickerGrid';
import { ConfirmDialog } from './ConfirmDialog';
import { CourseRegularSlotsEditor } from './CourseRegularSlotsEditor';
import { DurationSelector } from './DurationSelector';

interface CourseFormModalProps {
  open: boolean;
  course: Course | null;
  academicYears: AcademicYear[];
  organizations: Organization[];
  defaultAcademicYearId: string;
  defaultOrganizationId?: string;
  onClose: () => void;
  onSaved?: (savedCourse: Course) => void;
  onOpenNewOrganization?: () => void;
}

export function CourseFormModal({
  open,
  course,
  academicYears,
  organizations,
  defaultAcademicYearId,
  defaultOrganizationId,
  onClose,
  onSaved,
  onOpenNewOrganization,
}: CourseFormModalProps) {
  const [academicYearId, setAcademicYearId] = useState('');
  const [organizationId, setOrganizationId] = useState('');
  const [name, setName] = useState('');
  const [subject, setSubject] = useState('');
  const [color, setColor] = useState<string>(DEFAULT_ORG_COLOR);
  const [hasCustomColor, setHasCustomColor] = useState(false);
  const [durationMinutes, setDurationMinutes] = useState('50');
  const [regularSlots, setRegularSlots] = useState<CourseRegularSlot[]>([]);
  const [studentSchoolIds, setStudentSchoolIds] = useState<
    string[] | undefined
  >(undefined);
  const [material, setMaterial] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const [selectedGrade, setSelectedGrade] = useState<string | null>(null);
  const [selectedClass, setSelectedClass] = useState<string | null>(null);

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteSummary, setDeleteSummary] = useState<{
    sessionCount: number;
    imageCount: number;
  } | null>(null);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);
  const [initialSnapshot, setInitialSnapshot] = useState<string | null>(null);

  const orgPeriods = useLiveQuery(async (): Promise<Period[]> => {
    if (!open || !organizationId) return [];
    const rows = await db.periods
      .where('organizationId')
      .equals(organizationId)
      .toArray();
    return rows.sort((a, b) => a.startTime.localeCompare(b.startTime));
  }, [open, organizationId]);

  useEffect(() => {
    if (!open) return;

    if (course) {
      const org = organizations.find((o) => o.id === course.organizationId);
      const initDuration = String(course.defaultDurationMinutes || 50);
      const initSlots = course.regularSlots ?? [];
      const initSchoolIds =
        course.studentSchoolIds !== undefined
          ? [...course.studentSchoolIds]
          : undefined;
      setAcademicYearId(course.academicYearId);
      setOrganizationId(course.organizationId);
      setName(course.name);
      setSubject(course.subject ?? '');
      setColor(course.color);
      setHasCustomColor(
        org ? course.color.toLowerCase() !== org.color.toLowerCase() : false
      );
      setDurationMinutes(initDuration);
      setRegularSlots(initSlots);
      setStudentSchoolIds(initSchoolIds);
      setMaterial(course.material ?? '');
      setNote(course.note ?? '');
      const parsed = parseCourseQuickParts(course.name);
      setSelectedGrade(parsed.grade);
      setSelectedClass(parsed.classLetter);
      setInitialSnapshot(
        JSON.stringify({
          academicYearId: course.academicYearId,
          organizationId: course.organizationId,
          name: course.name,
          subject: course.subject ?? '',
          color: course.color,
          durationMinutes: initDuration,
          regularSlots: initSlots,
          studentSchoolIds: initSchoolIds ?? null,
          material: course.material ?? '',
          note: course.note ?? '',
        })
      );
    } else {
      const fallbackYearId =
        defaultAcademicYearId ||
        academicYears.find((y) => !y.archived)?.id ||
        academicYears[0]?.id ||
        '';
      const fallbackOrg =
        organizations.find((o) => o.id === defaultOrganizationId) ??
        organizations[0];
      const initOrgId = fallbackOrg?.id ?? '';
      const initColor = fallbackOrg?.color ?? DEFAULT_ORG_COLOR;

      setAcademicYearId(fallbackYearId);
      setOrganizationId(initOrgId);
      setName('');
      setSubject('');
      setColor(initColor);
      setHasCustomColor(false);
      setDurationMinutes('50');
      setRegularSlots([]);
      setStudentSchoolIds(undefined);
      setMaterial('');
      setNote('');
      setSelectedGrade(null);
      setSelectedClass(null);
      setInitialSnapshot(
        JSON.stringify({
          academicYearId: fallbackYearId,
          organizationId: initOrgId,
          name: '',
          subject: '',
          color: initColor,
          durationMinutes: '50',
          regularSlots: [],
          studentSchoolIds: null,
          material: '',
          note: '',
        })
      );
    }

    setError(null);
    setDeleteDialogOpen(false);
    setDeleteSummary(null);
    setDiscardConfirmOpen(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, course?.id]);

  useEffect(() => {
    if (!open) return;
    if (!organizationId && organizations.length > 0) {
      const firstOrg = organizations[0];
      setOrganizationId(firstOrg.id);
      if (!hasCustomColor) {
        setColor(firstOrg.color);
      }
    }
    if (!academicYearId && academicYears.length > 0) {
      const preferred =
        academicYears.find((y) => !y.archived) ?? academicYears[0];
      setAcademicYearId(preferred.id);
    }
  }, [open, organizationId, academicYearId, organizations, academicYears, hasCustomColor]);

  const isDirty =
    initialSnapshot !== null &&
    JSON.stringify({
      academicYearId,
      organizationId,
      name,
      subject,
      color,
      durationMinutes,
      regularSlots,
      studentSchoolIds: studentSchoolIds ?? null,
      material,
      note,
    }) !== initialSnapshot;

  const handleRequestClose = () => {
    if (isSaving) return;
    if (isDirty) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: open,
    zLayer: 55,
    onBack: handleRequestClose,
  });

  if (!open) {
    return null;
  }

  const currentOrg = organizations.find((o) => o.id === organizationId);
  const currentOrgSchools = currentOrg?.studentSchools ?? [];

  const handleOrganizationChange = (nextOrgId: string) => {
    setOrganizationId(nextOrgId);
    setStudentSchoolIds(undefined);
    const nextOrg = organizations.find((o) => o.id === nextOrgId);
    if (nextOrg && !hasCustomColor) {
      setColor(nextOrg.color);
    }
    if (error) setError(null);
  };

  const handleToggleStudentSchool = (schoolId: string) => {
    const allIds = currentOrgSchools.map((s) => s.id);
    const currentSelected =
      studentSchoolIds === undefined ? allIds : studentSchoolIds;
    const nextSelected = currentSelected.includes(schoolId)
      ? currentSelected.filter((id) => id !== schoolId)
      : [...currentSelected, schoolId];

    const isAllSelected =
      allIds.length > 0 && allIds.every((id) => nextSelected.includes(id));
    setStudentSchoolIds(isAllSelected ? undefined : nextSelected);
  };

  const handleToggleGrade = (grade: string) => {
    const nextGrade = selectedGrade === grade ? null : grade;
    setSelectedGrade(nextGrade);
    const composed = composeCourseName(nextGrade, selectedClass);
    if (composed) {
      setName(composed);
    }
    if (error) setError(null);
  };

  const handleToggleClass = (classLetter: string) => {
    const nextClass = selectedClass === classLetter ? null : classLetter;
    setSelectedClass(nextClass);
    const composed = composeCourseName(selectedGrade, nextClass);
    if (composed) {
      setName(composed);
    }
    if (error) setError(null);
  };

  const handleManualNameChange = (value: string) => {
    setName(value);
    const parsed = parseCourseQuickParts(value);
    setSelectedGrade(parsed.grade);
    setSelectedClass(parsed.classLetter);
    if (error) setError(null);
  };

  const handleResetToOrgColor = () => {
    if (currentOrg) {
      setColor(currentOrg.color);
      setHasCustomColor(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    if (!trimmedName) {
      setError('請輸入課程或班級名稱');
      return;
    }
    if (!academicYearId) {
      setError('請選擇學年');
      return;
    }
    if (!organizationId) {
      setError('請先選擇或建立任課單位');
      return;
    }

    const parsedDuration = Number.parseInt(durationMinutes, 10);
    if (!Number.isFinite(parsedDuration) || parsedDuration <= 0 || parsedDuration > 720) {
      setError('請輸入有效的預設時長（1～720 分鐘）');
      return;
    }
    const safeDuration = parsedDuration;

    setIsSaving(true);
    try {
      const now = Date.now();
      const orgSchoolIds = currentOrgSchools.map((s) => s.id);
      let normalizedStudentSchoolIds: string[] | undefined = undefined;
      if (!course?.isSystem && orgSchoolIds.length > 0 && studentSchoolIds !== undefined) {
        const filteredIds = orgSchoolIds.filter((id) =>
          studentSchoolIds.includes(id)
        );
        if (filteredIds.length < orgSchoolIds.length) {
          normalizedStudentSchoolIds = filteredIds;
        }
      }

      const savedCourse: Course = {
        id: course?.id ?? createId(),
        academicYearId,
        organizationId,
        name: trimmedName,
        subject: subject.trim() || undefined,
        color,
        defaultDurationMinutes: safeDuration,
        regularSlots,
        studentSchoolIds: normalizedStudentSchoolIds,
        material: material.trim() || undefined,
        note: note.trim() || undefined,
        ...(course?.defaultLocation ? { defaultLocation: course.defaultLocation } : {}),
        ...(course?.isSample !== undefined ? { isSample: course.isSample } : {}),
        ...(course?.isSystem !== undefined ? { isSystem: course.isSystem } : {}),
        createdAt: course?.createdAt ?? now,
        updatedAt: now,
      };
      await db.courses.put(savedCourse);
      onSaved?.(savedCourse);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const handleOpenDelete = async () => {
    if (!course) return;
    const summary = await getCourseDeleteSummary(course.id);
    setDeleteSummary(summary);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!course) return;
    setIsSaving(true);
    try {
      await deleteCourseCascade(course.id);
      setDeleteDialogOpen(false);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const deleteDescription = course
    ? `確定要刪除課程「${course.name}」嗎？這將會連同底下的 ${
        deleteSummary?.sessionCount ?? 0
      } 筆上課場次與 ${
        deleteSummary?.imageCount ?? 0
      } 張相關圖片資料一併刪除，且無法復原。`
    : '';

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="course-modal-title"
        className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
      >
        <div className="flex max-h-[90dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 bg-white px-4 py-3">
            <h2 id="course-modal-title" className="text-base font-semibold text-zinc-900">
              {course ? '編輯課程' : '新增課程'}
            </h2>
            <button
              type="button"
              onClick={handleRequestClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
            >
              <X size={20} />
            </button>
          </div>

          <form
            onSubmit={(e) => void handleSubmit(e)}
            className="flex min-h-0 flex-1 flex-col"
          >
            <div className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-4 scroll-mb-6">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="course-year-select"
                    className="block text-sm font-medium text-zinc-800"
                  >
                    學年
                  </label>
                  <select
                    id="course-year-select"
                    value={academicYearId}
                    onChange={(e) => setAcademicYearId(e.target.value)}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  >
                    {academicYears.map((y) => (
                      <option key={y.id} value={y.id}>
                        {y.name}
                        {y.archived ? '（已歸檔）' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <div className="flex items-center justify-between">
                    <label
                      htmlFor="course-org-select"
                      className="block text-sm font-medium text-zinc-800"
                    >
                      所屬單位 <span className="text-rose-600">*</span>
                    </label>
                    {onOpenNewOrganization && (
                      <button
                        type="button"
                        onClick={onOpenNewOrganization}
                        className="inline-flex min-h-[32px] items-center gap-0.5 px-1 text-xs font-medium text-violet-700 hover:underline"
                      >
                        <Plus size={14} />
                        <span>新增單位</span>
                      </button>
                    )}
                  </div>
                  <select
                    id="course-org-select"
                    value={organizationId}
                    onChange={(e) => handleOrganizationChange(e.target.value)}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  >
                    {organizations.length === 0 ? (
                      <option value="">尚無單位，請先新增</option>
                    ) : (
                      organizations.map((o) => (
                        <option key={o.id} value={o.id}>
                          {o.name}（{ORGANIZATION_TYPE_LABELS[o.type]}）
                        </option>
                      ))
                    )}
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="course-name-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  課程／班級名稱 <span className="text-rose-600">*</span>
                </label>
                <input
                  id="course-name-input"
                  type="text"
                  value={name}
                  onChange={(e) => handleManualNameChange(e.target.value)}
                  placeholder="例如：國一A班、國二B班、高三"
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />

                <div className="mt-2.5 space-y-2">
                  <div>
                    <span className="text-xs font-medium text-zinc-500">年級快捷</span>
                    <div className="mt-1 grid grid-cols-3 gap-1.5 sm:grid-cols-6">
                      {QUICK_GRADES.map((grade) => {
                        const active = selectedGrade === grade;
                        return (
                          <button
                            key={grade}
                            type="button"
                            onClick={() => handleToggleGrade(grade)}
                            className={`flex min-h-[44px] items-center justify-center rounded-xl border text-sm font-medium transition-colors ${
                              active
                                ? 'border-violet-600 bg-[#CDB8FF] text-zinc-900 font-semibold'
                                : 'border-zinc-200 bg-zinc-50 text-zinc-800 hover:bg-zinc-100'
                            }`}
                          >
                            {grade}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <span className="text-xs font-medium text-zinc-500">班別快捷</span>
                    <div className="mt-1 grid grid-cols-6 gap-1.5">
                      {QUICK_CLASSES.map((letter) => {
                        const active = selectedClass === letter;
                        return (
                          <button
                            key={letter}
                            type="button"
                            onClick={() => handleToggleClass(letter)}
                            className={`flex min-h-[44px] items-center justify-center rounded-xl border text-sm font-semibold transition-colors ${
                              active
                                ? 'border-violet-600 bg-[#CDB8FF] text-zinc-900'
                                : 'border-zinc-200 bg-zinc-50 text-zinc-800 hover:bg-zinc-100'
                            }`}
                          >
                            {letter}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {error && (
                  <p className="mt-1.5 text-xs font-medium text-rose-600">{error}</p>
                )}
              </div>

              <div>
                <label
                  htmlFor="course-subject-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  科目（選填）
                </label>
                <input
                  id="course-subject-input"
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="例如：理化"
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              {!course?.isSystem && currentOrgSchools.length > 0 && (
                <div className="space-y-2 rounded-2xl border border-zinc-200 bg-zinc-50/60 p-3.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-medium text-zinc-800">
                      學生來自哪些學校
                    </span>
                    <button
                      type="button"
                      onClick={() => setStudentSchoolIds(undefined)}
                      className={`min-h-[34px] rounded-lg border px-2.5 text-xs font-medium transition-colors ${
                        studentSchoolIds === undefined ||
                        currentOrgSchools.every((s) =>
                          studentSchoolIds.includes(s.id)
                        )
                          ? 'border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                          : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                      }`}
                    >
                      全選
                    </button>
                  </div>

                  <p className="text-xs leading-relaxed text-zinc-500">
                    預設全選。學生只來自某幾間學校時，取消其他學校，考試倒數就只會套用這幾間的考試。
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                    {currentOrgSchools.map((school) => {
                      const selected =
                        studentSchoolIds === undefined ||
                        studentSchoolIds.includes(school.id);
                      return (
                        <button
                          key={school.id}
                          type="button"
                          aria-pressed={selected}
                          onClick={() => handleToggleStudentSchool(school.id)}
                          className={`flex min-h-[38px] items-center justify-center rounded-xl border px-3 text-xs font-medium transition-colors ${
                            selected
                              ? 'border-violet-600 bg-[#CDB8FF] font-semibold text-zinc-900'
                              : 'border-zinc-200 bg-white text-zinc-500 hover:bg-zinc-50'
                          }`}
                        >
                          {school.name}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="space-y-1.5">
                <span className="block text-sm font-medium text-zinc-800">
                  預設時長
                </span>
                <DurationSelector
                  label="快捷時長"
                  activeMinutes={(() => {
                    const parsed = Number.parseInt(durationMinutes, 10);
                    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
                  })()}
                  customValue={durationMinutes}
                  onSelectPreset={(mins) => {
                    setDurationMinutes(String(mins));
                    if (error) setError(null);
                  }}
                  onCustomChange={(val) => {
                    setDurationMinutes(val);
                    if (error) setError(null);
                  }}
                />
              </div>

              <CourseRegularSlotsEditor
                organization={currentOrg}
                orgPeriods={orgPeriods ?? []}
                defaultDurationMinutes={
                  Number.parseInt(durationMinutes, 10) || 50
                }
                slots={regularSlots}
                onChangeSlots={setRegularSlots}
              />

              <div>
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-sm font-medium text-zinc-800">課程顏色</span>
                  {currentOrg &&
                    color.toLowerCase() !== currentOrg.color.toLowerCase() && (
                      <button
                        type="button"
                        onClick={handleResetToOrgColor}
                        className="inline-flex min-h-[36px] items-center gap-1 text-xs font-medium text-violet-700 hover:underline"
                      >
                        <RotateCcw size={13} />
                        <span>沿用單位顏色</span>
                      </button>
                    )}
                </div>
                <ColorPickerGrid
                  value={color}
                  onChange={(nextHex) => {
                    setColor(nextHex);
                    setHasCustomColor(true);
                  }}
                />
              </div>

              <div>
                <label
                  htmlFor="course-material-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  教材（選填）
                </label>
                <input
                  id="course-material-input"
                  type="text"
                  value={material}
                  onChange={(e) => setMaterial(e.target.value)}
                  placeholder="例如：南一版理化講義、自編複習卷"
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              <div>
                <label
                  htmlFor="course-note-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  備註（選填）
                </label>
                <textarea
                  id="course-note-input"
                  rows={3}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="班級狀況、教室位置或教學提醒"
                  className="mt-1.5 w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2.5 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              {course && !course.isSystem && (
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      void handleOpenDelete();
                    }}
                    disabled={isSaving}
                    className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl border border-rose-200 bg-white px-4 py-2.5 text-sm font-medium text-rose-600 transition-colors hover:bg-rose-50 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-600"
                  >
                    <Trash2 size={16} aria-hidden="true" />
                    <span>刪除課程</span>
                  </button>
                </div>
              )}
            </div>

            <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
              <button
                type="submit"
                disabled={isSaving}
                className="flex min-h-[44px] w-full items-center justify-center rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-violet-700 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2"
              >
                {isSaving ? '儲存中…' : course ? '儲存變更' : '建立課程'}
              </button>
            </div>
          </form>
        </div>
      </div>

      <ConfirmDialog
        open={deleteDialogOpen}
        title="刪除課程"
        description={deleteDescription}
        confirmLabel="確認刪除"
        isSubmitting={isSaving}
        onCancel={() => setDeleteDialogOpen(false)}
        onConfirm={() => {
          void handleConfirmDelete();
        }}
      />

      <ConfirmDialog
        open={discardConfirmOpen}
        title="放棄未儲存的內容？"
        description="目前有尚未儲存的修改，確定要放棄並返回嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardConfirmOpen(false)}
        onConfirm={() => {
          setDiscardConfirmOpen(false);
          onClose();
        }}
      />
    </>
  );
}
