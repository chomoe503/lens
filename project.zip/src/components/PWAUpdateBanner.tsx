import { RefreshCw } from 'lucide-react';

interface PWAUpdateBannerProps {
  visible: boolean;
  onUpdate: () => void;
}

export function PWAUpdateBanner({ visible, onUpdate }: PWAUpdateBannerProps) {
  if (!visible) {
    return null;
  }

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed inset-x-0 bottom-[calc(var(--bottom-nav-height)+env(safe-area-inset-bottom)+1rem)] z-40 px-4"
    >
      <div className="mx-auto w-full max-w-2xl">
        <button
          type="button"
          onClick={onUpdate}
          className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-medium text-white shadow-lg shadow-violet-900/20 transition-colors duration-150 hover:bg-violet-700 active:scale-[0.99] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2"
        >
          <RefreshCw size={16} aria-hidden="true" />
          <span className="whitespace-nowrap">有新版本，點此更新</span>
        </button>
      </div>
    </div>
  );
}
