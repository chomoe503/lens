import { BookOpen, CalendarDays, CalendarRange, Ellipsis, type LucideIcon } from 'lucide-react';
import type { NavTabId } from '../db/types';

interface BottomNavProps {
  activeTab: NavTabId;
  onSelectTab: (tab: NavTabId) => void;
  hidden?: boolean;
}

interface NavItem {
  id: NavTabId;
  label: string;
  icon: LucideIcon;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'today', label: '今天', icon: CalendarDays },
  { id: 'week', label: '週課表', icon: CalendarRange },
  { id: 'courses', label: '課程', icon: BookOpen },
  { id: 'more', label: '更多', icon: Ellipsis },
];

export function BottomNav({ activeTab, onSelectTab, hidden = false }: BottomNavProps) {
  if (hidden) {
    return null;
  }

  return (
    <nav
      aria-label="主導覽列"
      className="fixed inset-x-0 bottom-0 z-30 border-t border-violet-200/70 bg-white/95 backdrop-blur-md pb-[env(safe-area-inset-bottom)]"
    >
      <div className="mx-auto grid h-[var(--bottom-nav-height)] w-full max-w-2xl grid-cols-4 items-stretch">
        {NAV_ITEMS.map(({ id, label, icon: Icon }) => {
          const isActive = activeTab === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onSelectTab(id)}
              aria-current={isActive ? 'page' : undefined}
              className={`flex min-h-[44px] flex-col items-center justify-center gap-0.5 px-2 transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-violet-600 ${
                isActive
                  ? 'text-violet-700'
                  : 'text-zinc-500 hover:text-zinc-900 active:text-zinc-900'
              }`}
            >
              <Icon
                size={21}
                strokeWidth={isActive ? 2.25 : 1.75}
                aria-hidden="true"
              />
              <span
                className={`text-[11px] leading-tight whitespace-nowrap ${
                  isActive ? 'font-semibold' : 'font-medium'
                }`}
              >
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
