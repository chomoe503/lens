import { AlertTriangle, CheckCircle2, Download, Upload, X } from 'lucide-react';
import { useRef, useState, type ChangeEvent } from 'react';
import {
  exportAndDeliverBackup,
  importBackupData,
  parseBackupZip,
  type ImportMode,
  type ParsedBackupPackage,
  type TableCountSummary,
} from '../db/backup';
import { useBackLayer } from '../utils/backNavigation';
import { useBackupStatus } from '../utils/backupStore';
import { formatTimestamp } from '../utils/date';
import { ConfirmDialog } from './ConfirmDialog';

interface ImportResultFeedback {
  mode: ImportMode;
  fileName: string;
  counts: TableCountSummary[];
  autoBackupFileName?: string;
}

export function BackupRestoreSection() {
  const { lastBackupAt, isOverdue } = useBackupStatus();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [isExporting, setIsExporting] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);

  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [importResult, setImportResult] = useState<ImportResultFeedback | null>(null);

  const [pendingPackage, setPendingPackage] = useState<ParsedBackupPackage | null>(null);
  const [importMode, setImportMode] = useState<ImportMode>('merge');
  const [overwriteConfirmOpen, setOverwriteConfirmOpen] = useState(false);

  useBackLayer({
    active: pendingPackage !== null,
    zLayer: 50,
    onBack: () => {
      if (!isImporting) {
        setPendingPackage(null);
      }
    },
  });

  const handleExportClick = async () => {
    setErrorMessage(null);
    setStatusMessage(null);
    setImportResult(null);
    setIsExporting(true);
    try {
      const result = await exportAndDeliverBackup(true);
      if (result.outcome === 'shared') {
        setStatusMessage(`已透過分享面板儲存備份檔「${result.fileName}」。`);
      } else if (result.outcome === 'downloaded') {
        setStatusMessage(`已匯出並下載備份檔「${result.fileName}」。`);
      } else {
        setStatusMessage('已取消匯出分享（尚未儲存此次備份）。');
      }
    } catch (error) {
      setErrorMessage(
        error instanceof Error && error.message
          ? error.message
          : '匯出備份時發生錯誤，請稍後再試。'
      );
    } finally {
      setIsExporting(false);
    }
  };

  const handleTriggerFilePicker = () => {
    setErrorMessage(null);
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    setErrorMessage(null);
    setStatusMessage(null);
    setImportResult(null);
    setIsParsing(true);

    try {
      const parsed = await parseBackupZip(file);
      setPendingPackage(parsed);
      setImportMode('merge');
      setOverwriteConfirmOpen(false);
    } catch (error) {
      setErrorMessage(
        error instanceof Error && error.message
          ? error.message
          : '無法讀取備份檔，請確認檔案格式是否正確。'
      );
    } finally {
      setIsParsing(false);
    }
  };

  const executeImport = async (mode: ImportMode) => {
    if (!pendingPackage) return;
    setIsImporting(true);
    setErrorMessage(null);

    try {
      let autoBackupFileName: string | undefined;
      if (mode === 'overwrite') {
        const autoBackup = await exportAndDeliverBackup(false);
        autoBackupFileName = autoBackup.fileName;
      }

      const counts = await importBackupData(pendingPackage, mode);
      setImportResult({
        mode,
        fileName: pendingPackage.fileName,
        counts,
        autoBackupFileName,
      });
      setPendingPackage(null);
      setOverwriteConfirmOpen(false);
    } catch (error) {
      setOverwriteConfirmOpen(false);
      setErrorMessage(
        error instanceof Error && error.message
          ? error.message
          : '匯入資料時發生錯誤，未變更原有資料。'
      );
    } finally {
      setIsImporting(false);
    }
  };

  const handleProceedImport = () => {
    if (!pendingPackage) return;
    if (importMode === 'overwrite') {
      setOverwriteConfirmOpen(true);
      return;
    }
    void executeImport('merge');
  };

  return (
    <>
      <div className="rounded-2xl border border-zinc-200 bg-white">
        <div className="border-b border-zinc-100 px-4 py-3">
          <h2 className="text-sm font-semibold text-zinc-900">備份與還原</h2>
          <p className="mt-0.5 text-xs text-zinc-500">
            匯出所有資料表與照片為 .zip 壓縮檔，可隨時於任何裝置匯入還原。
          </p>
        </div>

        <dl className="divide-y divide-zinc-100">
          <div className="flex items-center justify-between gap-4 px-4 py-3.5">
            <dt className="text-sm text-zinc-600">上次備份時間</dt>
            <dd
              className={`text-sm font-medium tabular-nums ${
                isOverdue ? 'text-amber-700' : 'text-zinc-900'
              }`}
            >
              {lastBackupAt ? formatTimestamp(lastBackupAt) : '尚未備份'}
            </dd>
          </div>
        </dl>

        {errorMessage && (
          <div
            role="alert"
            className="flex items-start gap-2 border-t border-rose-100 bg-rose-50 px-4 py-3 text-xs leading-relaxed text-rose-800"
          >
            <AlertTriangle size={15} className="mt-0.5 shrink-0" aria-hidden="true" />
            <span>{errorMessage}</span>
          </div>
        )}

        {statusMessage && (
          <div
            role="status"
            aria-live="polite"
            className="flex items-start gap-2 border-t border-zinc-100 bg-emerald-50/70 px-4 py-3 text-xs leading-relaxed text-emerald-800"
          >
            <CheckCircle2 size={15} className="mt-0.5 shrink-0" aria-hidden="true" />
            <span>{statusMessage}</span>
          </div>
        )}

        {importResult && (
          <div
            role="status"
            aria-live="polite"
            className="space-y-2 border-t border-zinc-100 bg-emerald-50/70 px-4 py-3 text-xs text-emerald-900"
          >
            <div className="flex items-start gap-2">
              <CheckCircle2 size={15} className="mt-0.5 shrink-0" aria-hidden="true" />
              <div className="space-y-1">
                <p className="font-semibold">
                  已完成{importResult.mode === 'overwrite' ? '「整個覆蓋」' : '「合併新增」'}匯入（
                  {importResult.fileName}）
                </p>
                {importResult.autoBackupFileName && (
                  <p className="text-emerald-800">
                    覆蓋前已自動匯出原資料：{importResult.autoBackupFileName}
                  </p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-1.5 pt-1">
              {importResult.counts.map((item) => (
                <div
                  key={item.tableName}
                  className="flex items-center justify-between rounded-lg bg-white/80 px-2.5 py-1.5 text-xs"
                >
                  <span className="text-zinc-600">{item.label}</span>
                  <span className="font-semibold text-zinc-900 tabular-nums">
                    {item.count} 筆
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 border-t border-zinc-100 px-4 py-3">
          <button
            type="button"
            onClick={() => {
              void handleExportClick();
            }}
            disabled={isExporting || isParsing || isImporting}
            className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-3 py-2 text-sm font-medium text-white transition-colors hover:bg-violet-700 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2 whitespace-nowrap"
          >
            <Download size={16} aria-hidden="true" />
            <span>{isExporting ? '打包中…' : '匯出備份'}</span>
          </button>

          <button
            type="button"
            onClick={handleTriggerFilePicker}
            disabled={isExporting || isParsing || isImporting}
            className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-zinc-200 bg-white px-3 py-2 text-sm font-medium text-zinc-800 transition-colors hover:bg-zinc-50 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 whitespace-nowrap"
          >
            <Upload size={16} aria-hidden="true" />
            <span>{isParsing ? '讀取中…' : '匯入還原'}</span>
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept=".zip,application/zip"
            onChange={(event) => {
              void handleFileChange(event);
            }}
            className="hidden"
            aria-label="選擇備份 .zip 檔案"
          />
        </div>
      </div>

      {pendingPackage && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="backup-import-modal-title"
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-0 backdrop-blur-xs sm:items-center sm:p-4"
        >
          <div className="flex max-h-[90dvh] w-full max-w-md flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
            <div className="flex items-center justify-between border-b border-zinc-100 px-5 py-3.5">
              <h3
                id="backup-import-modal-title"
                className="text-base font-semibold text-zinc-900"
              >
                匯入備份檔案
              </h3>
              <button
                type="button"
                onClick={() => {
                  if (!isImporting) setPendingPackage(null);
                }}
                aria-label="關閉視窗"
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
              >
                <X size={20} aria-hidden="true" />
              </button>
            </div>

            <div className="space-y-4 overflow-y-auto px-5 py-4">
              <div className="rounded-xl border border-zinc-200 bg-zinc-50 p-3.5 text-xs">
                <p className="truncate font-semibold text-zinc-900">
                  {pendingPackage.fileName}
                </p>
                <p className="mt-1 text-zinc-600 tabular-nums">
                  匯出時間：{formatTimestamp(pendingPackage.manifest.exportedAtMs)} · 資料庫版本：v
                  {pendingPackage.manifest.dbVersion}
                </p>

                <div className="mt-3 grid grid-cols-2 gap-1.5">
                  {pendingPackage.previewCounts.map((item) => (
                    <div
                      key={item.tableName}
                      className="flex items-center justify-between rounded-lg bg-white px-2.5 py-1.5"
                    >
                      <span className="text-zinc-600">{item.label}</span>
                      <span className="font-semibold text-zinc-900 tabular-nums">
                        {item.count} 筆
                      </span>
                    </div>
                  ))}
                </div>

                {pendingPackage.extraTableNames.length > 0 && (
                  <p className="mt-2 text-zinc-500">
                    另含未對應資料表：{pendingPackage.extraTableNames.join('、')}（將略過）
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium text-zinc-900">選擇匯入方式</p>

                <button
                  type="button"
                  onClick={() => setImportMode('merge')}
                  className={`flex min-h-[56px] w-full flex-col items-start rounded-xl border px-3.5 py-2.5 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 ${
                    importMode === 'merge'
                      ? 'border-2 border-violet-600 bg-[#EDE6FF]'
                      : 'border-zinc-200 bg-white hover:bg-zinc-50'
                  }`}
                >
                  <span className="text-sm font-semibold text-zinc-900">
                    合併新增（保留現有資料）
                  </span>
                  <span className="mt-0.5 text-xs leading-relaxed text-zinc-600">
                    以 id 判斷，新增目前沒有的紀錄；若 id 相同則以匯入檔內容為準。
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setImportMode('overwrite')}
                  className={`flex min-h-[56px] w-full flex-col items-start rounded-xl border px-3.5 py-2.5 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 ${
                    importMode === 'overwrite'
                      ? 'border-2 border-rose-600 bg-rose-50'
                      : 'border-zinc-200 bg-white hover:bg-zinc-50'
                  }`}
                >
                  <span className="text-sm font-semibold text-zinc-900">
                    整個覆蓋（清空後還原）
                  </span>
                  <span className="mt-0.5 text-xs leading-relaxed text-zinc-600">
                    先清空目前所有資料表再寫入備份內容。覆蓋前會先自動匯出目前資料一次。
                  </span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2.5 border-t border-zinc-100 px-5 py-3.5 pb-[calc(0.875rem+env(safe-area-inset-bottom))] sm:pb-3.5">
              <button
                type="button"
                onClick={() => setPendingPackage(null)}
                disabled={isImporting}
                className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm font-medium text-zinc-700 transition-colors hover:bg-zinc-50 disabled:opacity-60"
              >
                取消
              </button>
              <button
                type="button"
                onClick={handleProceedImport}
                disabled={isImporting}
                className={`flex min-h-[44px] flex-1 items-center justify-center rounded-xl px-4 py-2 text-sm font-medium text-white transition-colors disabled:opacity-60 ${
                  importMode === 'overwrite'
                    ? 'bg-rose-600 hover:bg-rose-700'
                    : 'bg-violet-600 hover:bg-violet-700'
                }`}
              >
                {isImporting
                  ? '匯入中…'
                  : importMode === 'overwrite'
                    ? '下一步：確認覆蓋'
                    : '開始合併匯入'}
              </button>
            </div>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={overwriteConfirmOpen && pendingPackage !== null}
        title="確定要整個覆蓋目前資料嗎？"
        description={
          pendingPackage
            ? `此操作會清空目前資料庫中的所有學年、單位、節次、課程、場次、批次與圖片，並還原為「${pendingPackage.fileName}」的內容。按下確認後，系統會先自動匯出並下載目前的資料一次，再進行覆蓋。`
            : ''
        }
        confirmLabel="先自動備份並覆蓋"
        danger
        isSubmitting={isImporting}
        onCancel={() => {
          if (!isImporting) setOverwriteConfirmOpen(false);
        }}
        onConfirm={() => {
          void executeImport('overwrite');
        }}
      />
    </>
  );
}
