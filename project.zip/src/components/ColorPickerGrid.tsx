import { Check } from 'lucide-react';
import { isLightHexColor, ORG_COLOR_PALETTE } from '../utils/colors';

interface ColorPickerGridProps {
  value: string;
  onChange: (hex: string) => void;
}

export function ColorPickerGrid({ value, onChange }: ColorPickerGridProps) {
  const normalizedValue = value.toLowerCase();
  const isPreset = ORG_COLOR_PALETTE.some(
    (item) => item.hex.toLowerCase() === normalizedValue
  );

  return (
    <div className="space-y-2.5">
      <div className="grid grid-cols-4 gap-2">
        {ORG_COLOR_PALETTE.map((item) => {
          const isSelected = normalizedValue === item.hex.toLowerCase();
          const checkColorClass = isLightHexColor(item.hex)
            ? 'text-zinc-900'
            : 'text-white';

          return (
            <button
              key={item.hex}
              type="button"
              onClick={() => onChange(item.hex)}
              aria-label={item.label}
              aria-pressed={isSelected}
              title={item.label}
              style={{ backgroundColor: item.hex }}
              className={`flex min-h-[44px] min-w-[44px] w-full items-center justify-center rounded-xl transition-transform active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2 ${
                isSelected
                  ? 'border-2 border-zinc-900 ring-2 ring-zinc-900/20'
                  : 'border border-black/10'
              }`}
            >
              {isSelected && (
                <Check size={18} strokeWidth={2.75} className={checkColorClass} />
              )}
            </button>
          );
        })}
      </div>

      <label
        className={`flex min-h-[44px] w-full cursor-pointer items-center justify-between rounded-xl border px-3.5 py-2 transition-colors hover:bg-zinc-50 ${
          !isPreset ? 'border-2 border-zinc-900 bg-zinc-50/70' : 'border-zinc-200 bg-white'
        }`}
      >
        <span className="flex items-center gap-2.5 text-sm font-medium text-zinc-800">
          <span
            aria-hidden="true"
            style={{ backgroundColor: value }}
            className="h-5 w-5 rounded-md border border-black/15"
          />
          <span>自訂</span>
          {!isPreset && (
            <span className="font-mono text-xs text-zinc-500 uppercase">
              {value}
            </span>
          )}
        </span>
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          aria-label="自訂顏色"
          className="h-7 w-9 cursor-pointer rounded border-0 bg-transparent p-0"
        />
      </label>
    </div>
  );
}
