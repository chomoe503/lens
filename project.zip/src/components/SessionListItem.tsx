import { AlertTriangle, Check } from 'lucide-react';
import { useRef, type PointerEvent } from 'react';
import type { ClassSession, Course, Organization } from '../db/types';
import { formatSlashDate, formatSlashDateWithWeekday } from '../utils/date';
import { isSessionCancelled, isSubstituteSession } from '../utils/sessionDisplay';
import { CancelledBadge, SessionMenuButton } from './SessionQuickActions';
import { SubstituteBadge } from './SubstituteBadge';

interface SessionListItemProps {
  session: ClassSession;
  course?: Course;
  organization?: Organization;
  linkedCancelledSession?: ClassSession;
  hasOverlap?: boolean;
  showCourseHeader?: boolean;
  selectionMode: boolean;
  selected: boolean;
  onTap: (session: ClassSession) => void;
  onLongPress: (session: ClassSession) => void;
  onOpenMenu?: (session: ClassSession) => void;
  onCreateMakeup?: (cancelledSession: ClassSession) => void;
}

export function SessionListItem({
  session,
  course,
  organization,
  linkedCancelledSession,
  hasOverlap = false,
  showCourseHeader = true,
  selectionMode,
  selected,
  onTap,
  onLongPress,
  onOpenMenu,
  onCreateMakeup,
}: SessionListItemProps) {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const startPosRef = useRef<{ x: number; y: number } | null>(null);
  const longPressFiredRef = useRef(false);

  const clearTimer = () => {
    if (timerRef.current !== null) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  const handlePointerDown = (e: PointerEvent<HTMLDivElement>) => {
    if (selectionMode) return;
    longPressFiredRef.current = false;
    startPosRef.current = { x: e.clientX, y: e.clientY };
    clearTimer();
    timerRef.current = setTimeout(() => {
      longPressFiredRef.current = true;
      onLongPress(session);
    }, 450);
  };

  const handlePointerMove = (e: PointerEvent<HTMLDivElement>) => {
    if (!startPosRef.current || timerRef.current === null) return;
    const dx = Math.abs(e.clientX - startPosRef.current.x);
    const dy = Math.abs(e.clientY - startPosRef.current.y);
    if (dx > 10 || dy > 10) {
      clearTimer();
    }
  };

  const handlePointerUpOrCancel = () => {
    clearTimer();
    startPosRef.current = null;
  };

  const handleClick = () => {
    if (longPressFiredRef.current) {
      longPressFiredRef.current = false;
      return;
    }
    onTap(session);
  };

  const isCancelled = isSessionCancelled(session);

  const kindMeta =
    session.kind === 'makeup'
      ? linkedCancelledSession
        ? `補課（補 ${formatSlashDate(linkedCancelledSession.date)}）`
        : '補課'
      : session.kind === 'extra'
        ? '加課'
        : null;

  return (
    <div
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUpOrCancel}
      onPointerCancel={handlePointerUpOrCancel}
      onContextMenu={(e) => {
        if (!selectionMode) {
          e.preventDefault();
          onLongPress(session);
        }
      }}
      className={`select-none rounded-2xl border transition-colors ${
        selected
          ? 'border-violet-600 bg-[#F2ECFF]/70'
          : hasOverlap && !isCancelled
            ? 'border-amber-300 bg-amber-50/40'
            : isCancelled
              ? 'border-zinc-200/80 bg-zinc-50/60'
              : 'border-zinc-200 bg-white'
      }`}
    >
      <div className="flex min-h-[56px] w-full items-center gap-1">
        <button
          type="button"
          onClick={handleClick}
          className="flex min-w-0 flex-1 items-center gap-3 rounded-l-2xl py-3 pl-4 pr-1 text-left transition-colors hover:bg-zinc-50/80 active:bg-zinc-100/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
        >
          {selectionMode && (
            <span
              aria-hidden="true"
              className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${
                selected
                  ? 'border-violet-700 bg-violet-700 text-white'
                  : 'border-zinc-300 bg-white'
              }`}
            >
              {selected && <Check size={14} strokeWidth={2.5} />}
            </span>
          )}

          <div className="min-w-0 flex-1 space-y-0.5">
            {showCourseHeader && (() => {
              const isSub = isSubstituteSession(session);
              const displayTitle = isSub ? session.title : (course?.name ?? session.title);
              const swatchColor = isSub
                ? (organization?.color ?? '#FDE68A')
                : (course?.color ?? organization?.color ?? '#CDB8FF');
              const subFor = isSub ? session.substituteFor?.trim() : undefined;

              return (
                <div>
                  <div className="flex items-center gap-2">
                    <span
                      aria-hidden="true"
                      style={{ backgroundColor: swatchColor }}
                      className={`h-3 w-3 shrink-0 rounded-sm ring-1 ring-inset ring-black/15 ${
                        isCancelled ? 'opacity-45' : ''
                      }`}
                    />
                    <span
                      className={`truncate text-base font-semibold ${
                        isCancelled ? 'text-zinc-400 line-through' : 'text-zinc-900'
                      }`}
                    >
                      {displayTitle}
                    </span>
                  </div>
                  <div className="mt-0.5 flex flex-wrap items-center gap-1.5 pl-5 text-xs text-zinc-500">
                    <span>{organization?.name ?? '未指定單位'}</span>
                    {isSub && <SubstituteBadge />}
                    {subFor && (
                      <span className={isCancelled ? 'text-zinc-400' : 'text-zinc-700'}>
                        （代 {subFor}）
                      </span>
                    )}
                  </div>
                </div>
              );
            })()}

            <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-sm tabular-nums">
              <span
                className={`font-medium ${
                  isCancelled ? 'text-zinc-400 line-through' : 'text-zinc-800'
                }`}
              >
                {formatSlashDateWithWeekday(session.date)} {session.startTime}–
                {session.endTime}
              </span>
              {session.periodLabel && (
                <span className={`text-xs ${isCancelled ? 'text-zinc-400' : 'text-zinc-500'}`}>
                  · {session.periodLabel}
                </span>
              )}
              {isCancelled && (
                <>
                  <CancelledBadge />
                  {session.cancelReason && (
                    <span className="text-xs text-zinc-500">
                      {session.cancelReason}
                    </span>
                  )}
                </>
              )}
            </div>

            {session.originalDate && session.originalStartTime && (
              <p
                className={`text-xs font-medium tabular-nums ${
                  isCancelled ? 'text-zinc-400' : 'text-violet-700'
                }`}
              >
                調課：原定 {formatSlashDate(session.originalDate)}{' '}
                {session.originalStartTime}
              </p>
            )}

            {kindMeta && (
              <p
                className={`text-xs font-medium ${
                  isCancelled ? 'text-zinc-400' : 'text-violet-700'
                }`}
              >
                {kindMeta}
              </p>
            )}

            {hasOverlap && !isCancelled && (
              <p className="flex items-center gap-1 text-xs font-medium text-amber-800">
                <AlertTriangle size={13} className="shrink-0" aria-hidden="true" />
                <span>與同時段其他場次時間重疊</span>
              </p>
            )}
          </div>
        </button>

        {!selectionMode && onOpenMenu && (
          <SessionMenuButton
            onClick={() => onOpenMenu(session)}
            ariaLabel={`更多操作：${course?.name ?? session.title}`}
            className="mr-1.5"
          />
        )}
      </div>

      {!selectionMode && isCancelled && onCreateMakeup && (
        <div className="border-t border-zinc-100 px-4 py-2">
          <button
            type="button"
            onClick={() => onCreateMakeup(session)}
            className="flex min-h-[44px] w-full items-center justify-center rounded-xl border border-violet-200 bg-[#F2ECFF]/60 px-3 text-xs font-semibold text-zinc-900 transition-colors hover:bg-[#F2ECFF]"
          >
            為此已取消場次新增補課
          </button>
        </div>
      )}
    </div>
  );
}
