import { Search } from 'lucide-react';
import type { NavTabId } from '../db/types';
import { formatMonthDayWeekday } from '../utils/date';

interface TopBarProps {
  activeTab: NavTabId;
  onOpenSearch: () => void;
}

const TAB_TITLES: Record<NavTabId, string> = {
  today: '今天',
  week: '週課表',
  courses: '課程',
  more: '更多',
};

export function TopBar({ activeTab, onOpenSearch }: TopBarProps) {
  const title = TAB_TITLES[activeTab];
  const todayLabel = activeTab === 'today' ? formatMonthDayWeekday(new Date()) : null;

  return (
    <header className="sticky top-0 z-30 h-12 border-b border-violet-200/70 bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex h-full w-full max-w-2xl items-center justify-between gap-2 px-4">
        <div className="flex min-w-0 items-baseline gap-2">
          <h1 className="text-base font-semibold tracking-tight text-zinc-900 whitespace-nowrap">
            {title}
          </h1>
          {todayLabel && (
            <span className="truncate text-xs font-medium text-zinc-500 tabular-nums whitespace-nowrap">
              {todayLabel}
            </span>
          )}
        </div>

        <button
          type="button"
          onClick={onOpenSearch}
          aria-label="搜尋課程與紀錄"
          className="flex min-h-[44px] shrink-0 items-center justify-center gap-1.5 rounded-xl px-2.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-violet-50 hover:text-violet-800 active:bg-violet-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 whitespace-nowrap"
        >
          <Search size={17} aria-hidden="true" />
          <span>搜尋</span>
        </button>
      </div>
    </header>
  );
}

