import { Download } from 'lucide-react';
import { useState } from 'react';
import { usePWAInstall } from '../utils/usePWAInstall';

export function PWAInstallButton() {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <div className="rounded-2xl border border-zinc-200 bg-white p-4">
        <div className="flex items-center justify-between gap-4">
          <div className="min-w-0">
            <h2 className="text-sm font-semibold text-zinc-900">安裝應用程式</h2>
            <p className="mt-0.5 text-xs leading-relaxed text-zinc-500">
              加入主畫面後可全螢幕獨立開啟並離線使用。
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              void install();
            }}
            className="flex min-h-[44px] shrink-0 items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-4 py-2 text-sm font-medium text-white transition-colors duration-150 hover:bg-violet-700 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2 whitespace-nowrap"
          >
            <Download size={16} aria-hidden="true" />
            <span>安裝</span>
          </button>
        </div>
      </div>
    );
  }

  if (isIOS) {
    return (
      <div className="rounded-2xl border border-zinc-200 bg-white p-4">
        <div className="flex items-center justify-between gap-4">
          <div className="min-w-0">
            <h2 className="text-sm font-semibold text-zinc-900">安裝應用程式</h2>
            <p className="mt-0.5 text-xs leading-relaxed text-zinc-500">
              在 Safari 點選「分享」→「加入主畫面」即可安裝。
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowIOSGuide(true)}
            className="flex min-h-[44px] shrink-0 items-center justify-center rounded-xl border border-zinc-300 bg-white px-4 py-2 text-sm font-medium text-zinc-800 transition-colors duration-150 hover:bg-zinc-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 whitespace-nowrap"
          >
            安裝說明
          </button>
        </div>

        {showIOSGuide && (
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="ios-install-title"
            className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-0 backdrop-blur-xs sm:items-center sm:p-4"
          >
            <div className="max-h-[90dvh] w-full max-w-sm overflow-y-auto rounded-t-3xl bg-white p-6 pb-[calc(1.5rem+env(safe-area-inset-bottom))] shadow-xl sm:rounded-2xl sm:pb-6">
              <h3 id="ios-install-title" className="text-base font-semibold text-zinc-900">
                在 Safari 加入主畫面
              </h3>
              <ol className="mt-3 space-y-2 text-sm leading-relaxed text-zinc-600">
                <li>1. 點擊 Safari 工具列的「分享」按鈕。</li>
                <li>2. 向下滑動並選擇「加入主畫面」。</li>
                <li>3. 點擊右上角「新增」即可完成安裝。</li>
              </ol>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 flex min-h-[44px] w-full items-center justify-center rounded-xl bg-zinc-900 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-zinc-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
              >
                我知道了
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-zinc-200 bg-white p-4">
      <h2 className="text-sm font-semibold text-zinc-900">安裝應用程式</h2>
      <p className="mt-1 text-xs leading-relaxed text-zinc-600">
        Chrome 選單 ⋮ →『安裝應用程式』或『新增至主畫面』
      </p>
    </div>
  );
}
