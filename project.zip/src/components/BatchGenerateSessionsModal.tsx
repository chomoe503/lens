import { AlertTriangle, Check, X } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { db } from '../db/database';
import { createBatchSessions } from '../db/repositories';
import type { AcademicYear, ClassSession, Course } from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import {
  addMinutesToTime,
  doTimeRangesOverlap,
  enumerateDateKeysInRange,
  formatSlashDateWithWeekday,
  parseDateKey,
  timeToMinutes,
  toDateKey,
  WEEKDAY_LABELS,
} from '../utils/date';
import { isSessionCancelled } from '../utils/sessionDisplay';
import { useLiveQuery } from '../utils/useLiveQuery';
import { ConfirmDialog } from './ConfirmDialog';
import { DurationSelector } from './DurationSelector';

interface BatchGenerateSessionsModalProps {
  open: boolean;
  course: Course;
  academicYear?: AcademicYear;
  preferFullAcademicYear?: boolean;
  onClose: () => void;
  onGenerated?: (count: number) => void;
}

interface PreviewOccurrence {
  key: string; // `${date}::${slotId}`
  date: string;
  slotId: string;
  startTime: string;
  endTime: string;
  periodLabel?: string;
  included: boolean;
}

export function BatchGenerateSessionsModal({
  open,
  course,
  academicYear,
  preferFullAcademicYear = false,
  onClose,
  onGenerated,
}: BatchGenerateSessionsModalProps) {
  const slots = course.regularSlots ?? [];
  const [selectedSlotIds, setSelectedSlotIds] = useState<string[]>([]);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [occurrences, setOccurrences] = useState<PreviewOccurrence[]>([]);
  const [customDuration, setCustomDuration] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [confirmLargeBatchOpen, setConfirmLargeBatchOpen] = useState(false);
  const [hasUserEdited, setHasUserEdited] = useState(false);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);

  const existingSessions = useLiveQuery(async () => {
    if (!open || !startDate || !endDate) return [];
    return db.sessions
      .where('date')
      .between(startDate, endDate, true, true)
      .toArray();
  }, [open, startDate, endDate]);

  useEffect(() => {
    if (!open) return;
    const todayKey = toDateKey(new Date());
    const fallbackStart =
      preferFullAcademicYear && academicYear
        ? academicYear.startDate
        : academicYear && todayKey < academicYear.startDate
          ? academicYear.startDate
          : todayKey;
    const fallbackEnd =
      preferFullAcademicYear && academicYear
        ? academicYear.endDate
        : academicYear && academicYear.endDate >= fallbackStart
          ? academicYear.endDate
          : fallbackStart;

    setSelectedSlotIds(slots.map((s) => s.id));
    setStartDate(fallbackStart);
    setEndDate(fallbackEnd);
    setError(null);
    setConfirmLargeBatchOpen(false);
    setHasUserEdited(false);
    setDiscardConfirmOpen(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, course.id, preferFullAcademicYear, academicYear?.id]);

  // Rebuild preview list whenever date range or selected slots change,
  // preserving per-date checked state and custom time overrides.
  useEffect(() => {
    if (!open) return;
    if (!startDate || !endDate || startDate > endDate || selectedSlotIds.length === 0) {
      setOccurrences([]);
      return;
    }

    const activeSlots = slots.filter((s) => selectedSlotIds.includes(s.id));
    const dateKeys = enumerateDateKeysInRange(startDate, endDate);

    setOccurrences((prev) => {
      const prevMap = new Map(prev.map((item) => [item.key, item]));
      const next: PreviewOccurrence[] = [];

      for (const dKey of dateKeys) {
        const weekday = parseDateKey(dKey).getDay();
        const matchingSlots = activeSlots.filter((s) => s.weekday === weekday);
        for (const slot of matchingSlots) {
          const key = `${dKey}::${slot.id}`;
          const existing = prevMap.get(key);
          next.push({
            key,
            date: dKey,
            slotId: slot.id,
            startTime: existing ? existing.startTime : slot.startTime,
            endTime: existing ? existing.endTime : slot.endTime,
            periodLabel: existing ? existing.periodLabel : slot.periodLabel,
            included: existing ? existing.included : true,
          });
        }
      }

      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, startDate, endDate, selectedSlotIds, course.id]);

  const existingByDate = useMemo(() => {
    const map = new Map<string, ClassSession[]>();
    for (const s of existingSessions ?? []) {
      if (isSessionCancelled(s)) continue;
      const arr = map.get(s.date) ?? [];
      arr.push(s);
      map.set(s.date, arr);
    }
    return map;
  }, [existingSessions]);

  const uniformDuration = useMemo(() => {
    const included = occurrences.filter((o) => o.included);
    if (included.length === 0) return null;
    const first =
      included[0].startTime &&
      included[0].endTime &&
      included[0].startTime < included[0].endTime
        ? timeToMinutes(included[0].endTime) -
          timeToMinutes(included[0].startTime)
        : 0;
    if (first <= 0) return null;
    for (let i = 1; i < included.length; i++) {
      const o = included[i];
      if (!o.startTime || !o.endTime || o.startTime >= o.endTime) {
        return null;
      }
      if (timeToMinutes(o.endTime) - timeToMinutes(o.startTime) !== first) {
        return null;
      }
    }
    return first;
  }, [occurrences]);

  useEffect(() => {
    if (!open) return;
    setCustomDuration(uniformDuration !== null ? String(uniformDuration) : '');
  }, [open, uniformDuration]);

  const handleRequestClose = () => {
    if (isSaving) return;
    if (hasUserEdited && slots.length > 0) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: open,
    zLayer: 55,
    onBack: handleRequestClose,
  });

  if (!open) {
    return null;
  }

  const includedOccurrences = occurrences.filter((o) => o.included);
  const totalCount = includedOccurrences.length;

  const toggleSlot = (slotId: string) => {
    setHasUserEdited(true);
    setSelectedSlotIds((prev) =>
      prev.includes(slotId) ? prev.filter((id) => id !== slotId) : [...prev, slotId]
    );
  };

  const toggleOccurrence = (key: string) => {
    setHasUserEdited(true);
    setOccurrences((prev) =>
      prev.map((o) => (o.key === key ? { ...o, included: !o.included } : o))
    );
  };

  const updateOccurrenceTime = (
    key: string,
    field: 'startTime' | 'endTime',
    value: string
  ) => {
    setHasUserEdited(true);
    setOccurrences((prev) =>
      prev.map((o) =>
        o.key === key ? { ...o, [field]: value, periodLabel: undefined } : o
      )
    );
  };

  const applyDurationToIncluded = (mins: number) => {
    setHasUserEdited(true);
    setOccurrences((prev) =>
      prev.map((o) =>
        o.included && o.startTime
          ? {
              ...o,
              endTime: addMinutesToTime(o.startTime, mins),
              periodLabel: undefined,
            }
          : o
      )
    );
    if (error) setError(null);
  };

  const handleSelectPresetDuration = (mins: number) => {
    setCustomDuration(String(mins));
    applyDurationToIncluded(mins);
  };

  const handleCustomDurationChange = (val: string) => {
    setHasUserEdited(true);
    setCustomDuration(val);
    const parsed = Number.parseInt(val, 10);
    if (Number.isFinite(parsed) && parsed > 0 && parsed <= 720) {
      applyDurationToIncluded(parsed);
    }
  };

  const executeCreate = async () => {
    setIsSaving(true);
    try {
      const selectedSlots = slots.filter((s) => selectedSlotIds.includes(s.id));
      const slotSummary = selectedSlots
        .map(
          (s) =>
            `${WEEKDAY_LABELS[s.weekday]}${s.periodLabel ? ` ${s.periodLabel}` : ''} ${s.startTime}–${s.endTime}`
        )
        .join('、');

      const result = await createBatchSessions({
        course,
        startDate,
        endDate,
        slotSummary,
        items: includedOccurrences.map((o) => ({
          date: o.date,
          startTime: o.startTime,
          endTime: o.endTime,
          periodLabel: o.periodLabel,
        })),
      });

      setConfirmLargeBatchOpen(false);
      onGenerated?.(result.createdCount);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const handleRequestSubmit = () => {
    if (slots.length === 0) {
      setError('請先於課程設定新增常用時段');
      return;
    }
    if (selectedSlotIds.length === 0) {
      setError('請至少勾選一個常用時段');
      return;
    }
    if (!startDate || !endDate || startDate > endDate) {
      setError('請確認起訖日期（起日不可晚於迄日）');
      return;
    }
    if (includedOccurrences.length === 0) {
      setError('沒有勾選任何要產生的日期');
      return;
    }
    const invalidTime = includedOccurrences.find(
      (o) => !o.startTime || !o.endTime || o.startTime >= o.endTime
    );
    if (invalidTime) {
      setError(
        `${formatSlashDateWithWeekday(invalidTime.date)} 的結束時間必須晚於開始時間`
      );
      return;
    }

    setError(null);
    if (includedOccurrences.length > 60) {
      setConfirmLargeBatchOpen(true);
      return;
    }
    void executeCreate();
  };

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="batch-gen-title"
        className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
      >
        <div className="flex max-h-[90dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 bg-white px-4 py-3">
            <h2 id="batch-gen-title" className="text-base font-semibold text-zinc-900">
              依常用時段產生場次 · {course.name}
            </h2>
            <button
              type="button"
              onClick={handleRequestClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900"
            >
              <X size={20} />
            </button>
          </div>

          <div className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-4 scroll-mb-6">
            {slots.length === 0 ? (
              <div className="rounded-xl border border-zinc-200 bg-zinc-50 p-4 text-center text-sm text-zinc-600">
                這門課尚未設定「常用時段」，請先編輯課程加入常用時段後再產生場次。
              </div>
            ) : (
              <>
                <div>
                  <span className="block text-sm font-medium text-zinc-800">
                    1. 選擇要使用的常用時段（可多選）
                  </span>
                  <div className="mt-1.5 space-y-1.5">
                    {slots.map((slot) => {
                      const checked = selectedSlotIds.includes(slot.id);
                      return (
                        <button
                          key={slot.id}
                          type="button"
                          onClick={() => toggleSlot(slot.id)}
                          className={`flex min-h-[44px] w-full items-center justify-between rounded-xl border px-3.5 py-2 text-left transition-colors ${
                            checked
                              ? 'border-violet-600 bg-[#F2ECFF] text-zinc-900'
                              : 'border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-50'
                          }`}
                        >
                          <span className="text-sm font-medium tabular-nums">
                            {WEEKDAY_LABELS[slot.weekday]}
                            {slot.periodLabel ? ` ${slot.periodLabel}` : ''}{' '}
                            {slot.startTime}–{slot.endTime}
                          </span>
                          <span
                            className={`flex h-5 w-5 items-center justify-center rounded-md border ${
                              checked
                                ? 'border-violet-700 bg-violet-700 text-white'
                                : 'border-zinc-300 bg-white'
                            }`}
                          >
                            {checked && <Check size={14} strokeWidth={2.5} />}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <span className="block text-sm font-medium text-zinc-800">
                    2. 選擇起訖日期
                  </span>
                  <div className="mt-1.5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <div className="min-w-0">
                      <label htmlFor="batch-start-date" className="block text-xs text-zinc-500">
                        起日
                      </label>
                      <input
                        id="batch-start-date"
                        type="date"
                        value={startDate}
                        onChange={(e) => {
                          setHasUserEdited(true);
                          setStartDate(e.target.value);
                        }}
                        className="mt-1 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                      />
                    </div>
                    <div className="min-w-0">
                      <label htmlFor="batch-end-date" className="block text-xs text-zinc-500">
                        迄日
                      </label>
                      <input
                        id="batch-end-date"
                        type="date"
                        value={endDate}
                        onChange={(e) => {
                          setHasUserEdited(true);
                          setEndDate(e.target.value);
                        }}
                        className="mt-1 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-medium text-zinc-800">
                      3. 預覽與微調日期清單
                    </span>
                    <span className="text-sm font-semibold text-violet-700 tabular-nums">
                      將建立 {totalCount} 堂
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-zinc-500">
                    可取消勾選假日或臨時調整單日時間；建立後每堂各自獨立。
                  </p>

                  {occurrences.length > 0 && (
                    <div className="mt-2.5 rounded-xl border border-zinc-200 bg-zinc-50/60 p-3">
                      <DurationSelector
                        label="批次套用時長（依各日開始時間推算結束時間）"
                        activeMinutes={uniformDuration}
                        customValue={customDuration}
                        customPlaceholder={
                          uniformDuration === null && occurrences.some((o) => o.included)
                            ? '各時段不同，可輸入分鐘數統一套用'
                            : '輸入分鐘數'
                        }
                        onSelectPreset={handleSelectPresetDuration}
                        onCustomChange={handleCustomDurationChange}
                      />
                    </div>
                  )}

                  {occurrences.length === 0 ? (
                    <div className="mt-2 rounded-xl border border-zinc-200 bg-zinc-50 p-4 text-center text-xs text-zinc-500">
                      此日期範圍內沒有符合所選時段的日期。
                    </div>
                  ) : (
                    <div className="mt-2 divide-y divide-zinc-100 rounded-xl border border-zinc-200 bg-white">
                      {occurrences.map((item) => {
                        const daySessions = existingByDate.get(item.date) ?? [];
                        const hasOverlap =
                          item.included &&
                          daySessions.some((s) =>
                            doTimeRangesOverlap(
                              item.startTime,
                              item.endTime,
                              s.startTime,
                              s.endTime
                            )
                          );

                        return (
                          <div
                            key={item.key}
                            className={`space-y-1.5 px-3 py-2.5 ${
                              item.included ? 'bg-white' : 'bg-zinc-50/80 opacity-60'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <button
                                type="button"
                                onClick={() => toggleOccurrence(item.key)}
                                className="flex min-h-[44px] items-center gap-2.5 text-left"
                              >
                                <span
                                  className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${
                                    item.included
                                      ? 'border-violet-700 bg-violet-700 text-white'
                                      : 'border-zinc-300 bg-white'
                                  }`}
                                >
                                  {item.included && <Check size={14} strokeWidth={2.5} />}
                                </span>
                                <span className="text-sm font-medium text-zinc-900 tabular-nums">
                                  {formatSlashDateWithWeekday(item.date)}
                                  {item.periodLabel ? (
                                    <span className="ml-1.5 text-xs font-medium text-violet-700">
                                      {item.periodLabel}
                                    </span>
                                  ) : null}
                                </span>
                              </button>

                              {hasOverlap && (
                                <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-700">
                                  <AlertTriangle size={13} aria-hidden="true" />
                                  <span>重疊</span>
                                </span>
                              )}
                            </div>

                            {item.included && (
                              <div className="flex items-center gap-1.5 pl-1 sm:pl-7">
                                <input
                                  type="time"
                                  value={item.startTime}
                                  onChange={(e) =>
                                    updateOccurrenceTime(
                                      item.key,
                                      'startTime',
                                      e.target.value
                                    )
                                  }
                                  aria-label={`${item.date} 開始時間`}
                                  className="min-h-[44px] min-w-0 flex-1 rounded-lg border border-zinc-200 bg-zinc-50 px-2 py-1.5 text-base text-zinc-900 tabular-nums"
                                />
                                <span className="shrink-0 text-xs text-zinc-400">–</span>
                                <input
                                  type="time"
                                  value={item.endTime}
                                  onChange={(e) =>
                                    updateOccurrenceTime(
                                      item.key,
                                      'endTime',
                                      e.target.value
                                    )
                                  }
                                  aria-label={`${item.date} 結束時間`}
                                  className="min-h-[44px] min-w-0 flex-1 rounded-lg border border-zinc-200 bg-zinc-50 px-2 py-1.5 text-base text-zinc-900 tabular-nums"
                                />
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </>
            )}

            {error && <p className="text-xs font-medium text-rose-600">{error}</p>}
          </div>

          <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
            <button
              type="button"
              onClick={handleRequestSubmit}
              disabled={isSaving || slots.length === 0}
              className="flex min-h-[44px] w-full items-center justify-center rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-violet-700 disabled:opacity-50"
            >
              {isSaving
                ? '建立中…'
                : totalCount > 0
                  ? `確認建立（將建立 ${totalCount} 堂）`
                  : '確認建立'}
            </button>
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={confirmLargeBatchOpen}
        title="一次建立超過 60 堂場次"
        description={`即將一次建立 ${totalCount} 堂場次（已超過 60 堂），請再次確認起訖日期與時段設定是否正確？`}
        confirmLabel={`確定建立 ${totalCount} 堂`}
        danger={false}
        isSubmitting={isSaving}
        onCancel={() => setConfirmLargeBatchOpen(false)}
        onConfirm={() => {
          void executeCreate();
        }}
      />

      <ConfirmDialog
        open={discardConfirmOpen}
        title="放棄未儲存的內容？"
        description="目前有尚未儲存的修改，確定要放棄並返回嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardConfirmOpen(false)}
        onConfirm={() => {
          setDiscardConfirmOpen(false);
          onClose();
        }}
      />
    </>
  );
}
