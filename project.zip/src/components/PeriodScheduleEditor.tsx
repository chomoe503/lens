import { ChevronDown, ChevronUp, Clock, Minus, Plus, Sparkles, Trash2 } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { Period } from '../db/types';
import { addMinutesToTime, minutesToTime, timeToMinutes } from '../utils/date';
import { createId } from '../utils/id';
import {
  canShiftTimeMinutes,
  generatePeriodsSchedule,
  getNextPeriodName,
  shiftTimeMinutes,
} from '../utils/periodSchedule';
import { ConfirmDialog } from './ConfirmDialog';

interface PeriodScheduleEditorProps {
  organizationId: string;
  periods: Period[];
  periodErrors: Map<string, string>;
  onChangePeriods: (nextPeriods: Period[]) => void;
}

const PERIOD_LENGTH_PRESETS = [45, 50] as const;
const BREAK_LENGTH_PRESETS = [5, 10, 15, 20] as const;
const INLINE_BREAK_PRESETS = [5, 10, 15, 20, 60] as const;

export function PeriodScheduleEditor({
  organizationId,
  periods,
  periodErrors,
  onChangePeriods,
}: PeriodScheduleEditorProps) {
  // Section A: Quick generator state (expanded by default)
  const [quickOpen, setQuickOpen] = useState(true);
  const [quickStartTime, setQuickStartTime] = useState('08:30');
  const [periodLengthInput, setPeriodLengthInput] = useState('45');
  const [breakLengthInput, setBreakLengthInput] = useState('10');
  const [periodCount, setPeriodCount] = useState(8);
  const [lunchEnabled, setLunchEnabled] = useState(false);
  const [lunchAfterPeriod, setLunchAfterPeriod] = useState(4);
  const [lunchDurationInput, setLunchDurationInput] = useState('60');

  // Section B: Linked adjustment & inline break editing
  const [rippleNext, setRippleNext] = useState(true);
  const [editingBreakIndex, setEditingBreakIndex] = useState<number | null>(null);
  const [breakDraftInput, setBreakDraftInput] = useState('10');

  // Section C: Confirmation dialogs
  const [confirmApplyOpen, setConfirmApplyOpen] = useState(false);
  const [deleteTargetPeriod, setDeleteTargetPeriod] = useState<Period | null>(null);

  const parsedPeriodLength = useMemo(() => {
    const n = Number.parseInt(periodLengthInput, 10);
    return Number.isFinite(n) && n > 0 ? Math.min(360, n) : 45;
  }, [periodLengthInput]);

  const parsedBreakLength = useMemo(() => {
    const n = Number.parseInt(breakLengthInput, 10);
    return Number.isFinite(n) && n >= 0 ? Math.min(180, n) : 10;
  }, [breakLengthInput]);

  const parsedLunchDuration = useMemo(() => {
    const n = Number.parseInt(lunchDurationInput, 10);
    return Number.isFinite(n) && n >= 0 ? Math.min(240, n) : 60;
  }, [lunchDurationInput]);

  const safeLunchAfter = Math.max(
    1,
    Math.min(Math.max(1, periodCount - 1), lunchAfterPeriod)
  );

  const quickPreview = useMemo(() => {
    return generatePeriodsSchedule({
      organizationId,
      startTime: /^\d{2}:\d{2}$/.test(quickStartTime) ? quickStartTime : '08:30',
      periodDuration: parsedPeriodLength,
      breakDuration: parsedBreakLength,
      count: periodCount,
      lunchEnabled: lunchEnabled && periodCount > 1,
      lunchAfterPeriod: safeLunchAfter,
      lunchDuration: parsedLunchDuration,
    });
  }, [
    organizationId,
    quickStartTime,
    parsedPeriodLength,
    parsedBreakLength,
    periodCount,
    lunchEnabled,
    safeLunchAfter,
    parsedLunchDuration,
  ]);

  const applyQuickSchedule = () => {
    const fresh = generatePeriodsSchedule({
      organizationId,
      startTime: /^\d{2}:\d{2}$/.test(quickStartTime) ? quickStartTime : '08:30',
      periodDuration: parsedPeriodLength,
      breakDuration: parsedBreakLength,
      count: periodCount,
      lunchEnabled: lunchEnabled && periodCount > 1,
      lunchAfterPeriod: safeLunchAfter,
      lunchDuration: parsedLunchDuration,
    });
    onChangePeriods(fresh.periods);
    setEditingBreakIndex(null);
    setConfirmApplyOpen(false);
  };

  const handleRequestApplyQuick = () => {
    if (quickPreview.overflowsMidnight) return;
    if (periods.length > 0) {
      setConfirmApplyOpen(true);
      return;
    }
    applyQuickSchedule();
  };

  const handleRenamePeriod = (index: number, nextName: string) => {
    const next = periods.map((p, i) =>
      i === index ? { ...p, name: nextName, updatedAt: Date.now() } : p
    );
    onChangePeriods(next);
  };

  const handleUpdatePeriodStart = (index: number, nextStart: string) => {
    if (!/^\d{2}:\d{2}$/.test(nextStart)) return;
    const target = periods[index];
    if (!target) return;

    const delta = timeToMinutes(nextStart) - timeToMinutes(target.startTime);
    if (delta === 0) return;

    const now = Date.now();
    const next = periods.map((p, i) => {
      if (i === index) {
        if (rippleNext) {
          // Preserve this period's own length and ripple all following periods
          return {
            ...p,
            startTime: nextStart,
            endTime: shiftTimeMinutes(p.endTime, delta),
            updatedAt: now,
          };
        }
        return {
          ...p,
          startTime: nextStart,
          updatedAt: now,
        };
      }
      if (rippleNext && i > index) {
        return {
          ...p,
          startTime: shiftTimeMinutes(p.startTime, delta),
          endTime: shiftTimeMinutes(p.endTime, delta),
          updatedAt: now,
        };
      }
      return p;
    });
    onChangePeriods(next);
  };

  const handleUpdatePeriodEnd = (index: number, nextEnd: string) => {
    if (!/^\d{2}:\d{2}$/.test(nextEnd)) return;
    const target = periods[index];
    if (!target) return;

    const delta = timeToMinutes(nextEnd) - timeToMinutes(target.endTime);
    if (delta === 0) return;

    const now = Date.now();
    const next = periods.map((p, i) => {
      if (i === index) {
        return {
          ...p,
          endTime: nextEnd,
          updatedAt: now,
        };
      }
      if (rippleNext && i > index) {
        return {
          ...p,
          startTime: shiftTimeMinutes(p.startTime, delta),
          endTime: shiftTimeMinutes(p.endTime, delta),
          updatedAt: now,
        };
      }
      return p;
    });
    onChangePeriods(next);
  };

  const handleNudgeStart = (index: number, delta: number) => {
    const p = periods[index];
    if (!p || !canShiftTimeMinutes(p.startTime, delta)) return;
    handleUpdatePeriodStart(index, shiftTimeMinutes(p.startTime, delta));
  };

  const handleNudgeEnd = (index: number, delta: number) => {
    const p = periods[index];
    if (!p || !canShiftTimeMinutes(p.endTime, delta)) return;
    handleUpdatePeriodEnd(index, shiftTimeMinutes(p.endTime, delta));
  };

  const handleApplyBreakMinutes = (index: number, newBreakMinutes: number) => {
    const current = periods[index];
    const nextPeriod = periods[index + 1];
    if (!current || !nextPeriod) return;

    const targetStartMins = Math.min(
      23 * 60 + 59,
      Math.max(0, timeToMinutes(current.endTime) + newBreakMinutes)
    );
    const delta = targetStartMins - timeToMinutes(nextPeriod.startTime);
    const now = Date.now();

    const updated = periods.map((p, i) => {
      if (i === index + 1) {
        return {
          ...p,
          startTime: minutesToTime(targetStartMins),
          endTime: shiftTimeMinutes(p.endTime, delta),
          updatedAt: now,
        };
      }
      if (rippleNext && i > index + 1) {
        return {
          ...p,
          startTime: shiftTimeMinutes(p.startTime, delta),
          endTime: shiftTimeMinutes(p.endTime, delta),
          updatedAt: now,
        };
      }
      return p;
    });

    onChangePeriods(updated);
    setEditingBreakIndex(null);
  };

  const handleAddSinglePeriod = () => {
    const now = Date.now();
    let startTime = /^\d{2}:\d{2}$/.test(quickStartTime) ? quickStartTime : '08:30';

    if (periods.length > 0) {
      const last = periods[periods.length - 1];
      startTime = addMinutesToTime(last.endTime, parsedBreakLength);
    }

    const endTime = addMinutesToTime(startTime, parsedPeriodLength);
    const nextPeriod: Period = {
      id: createId(),
      organizationId,
      name: getNextPeriodName(periods),
      startTime,
      endTime,
      sortOrder: periods.length,
      createdAt: now,
      updatedAt: now,
    };

    onChangePeriods([...periods, nextPeriod]);
  };

  const handleConfirmDeletePeriod = () => {
    if (!deleteTargetPeriod) return;
    onChangePeriods(periods.filter((p) => p.id !== deleteTargetPeriod.id));
    setEditingBreakIndex(null);
    setDeleteTargetPeriod(null);
  };

  const activeQuickPeriodLen = (() => {
    const n = Number.parseInt(periodLengthInput, 10);
    return Number.isFinite(n) && n > 0 ? n : null;
  })();

  const activeQuickBreakLen = (() => {
    const n = Number.parseInt(breakLengthInput, 10);
    return Number.isFinite(n) && n >= 0 ? n : null;
  })();

  return (
    <div className="space-y-3 border-t border-zinc-100 pt-4">
      <div>
        <span className="block text-sm font-medium text-zinc-800">
          節次表（選填）
        </span>
        <p className="mt-0.5 text-xs text-zinc-500">
          學校有固定上課節次時可設定；修改只影響之後新建場次，不會改動已建立場次的實際時間。
        </p>
      </div>

      {/* A. 快速產生節次（預設展開） */}
      <div className="overflow-hidden rounded-2xl border border-violet-200 bg-[#F9F6FF]">
        <button
          type="button"
          onClick={() => setQuickOpen((v) => !v)}
          aria-expanded={quickOpen}
          className="flex min-h-[44px] w-full items-center justify-between gap-2 px-3.5 py-2.5 text-left transition-colors hover:bg-[#F2ECFF]"
        >
          <span className="flex items-center gap-1.5 text-sm font-semibold text-zinc-900">
            <Sparkles size={15} className="text-violet-700" aria-hidden="true" />
            <span>快速產生節次</span>
          </span>
          {quickOpen ? (
            <ChevronUp size={18} className="text-zinc-500" aria-hidden="true" />
          ) : (
            <ChevronDown size={18} className="text-zinc-500" aria-hidden="true" />
          )}
        </button>

        {quickOpen && (
          <div className="space-y-3.5 border-t border-violet-200/70 bg-white p-3.5">
            {/* 第一節開始時間 + 節數 */}
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="quick-first-start"
                  className="block text-xs font-medium text-zinc-700"
                >
                  第一節開始時間
                </label>
                <input
                  id="quick-first-start"
                  type="time"
                  step={300}
                  value={quickStartTime}
                  onChange={(e) => setQuickStartTime(e.target.value)}
                  className="mt-1 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                />
              </div>

              <div>
                <span className="block text-xs font-medium text-zinc-700">
                  節數
                </span>
                <div className="mt-1 flex items-center gap-1.5">
                  <button
                    type="button"
                    aria-label="減少節數"
                    disabled={periodCount <= 1}
                    onClick={() => setPeriodCount((c) => Math.max(1, c - 1))}
                    className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-zinc-200 bg-white text-zinc-800 hover:bg-zinc-50 disabled:opacity-40"
                  >
                    <Minus size={16} />
                  </button>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    inputMode="numeric"
                    pattern="[0-9]*"
                    aria-label="節數"
                    value={periodCount}
                    onChange={(e) => {
                      const n = Number.parseInt(e.target.value, 10);
                      if (Number.isFinite(n)) {
                        setPeriodCount(Math.max(1, Math.min(20, n)));
                      }
                    }}
                    className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-zinc-300 bg-white px-2 text-center text-base font-semibold text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                  />
                  <button
                    type="button"
                    aria-label="增加節數"
                    disabled={periodCount >= 20}
                    onClick={() => setPeriodCount((c) => Math.min(20, c + 1))}
                    className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-zinc-200 bg-white text-zinc-800 hover:bg-zinc-50 disabled:opacity-40"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>
            </div>

            {/* 每節長度 */}
            <div className="space-y-1.5">
              <span className="block text-xs font-medium text-zinc-700">
                每節長度
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                {PERIOD_LENGTH_PRESETS.map((mins) => {
                  const active = activeQuickPeriodLen === mins;
                  return (
                    <button
                      key={mins}
                      type="button"
                      aria-pressed={active}
                      onClick={() => setPeriodLengthInput(String(mins))}
                      className={`flex min-h-[44px] items-center justify-center rounded-xl px-2 text-xs tabular-nums transition-colors ${
                        active
                          ? 'border-2 border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                          : 'border border-zinc-200 bg-white font-medium text-zinc-700 hover:bg-zinc-50'
                      }`}
                    >
                      {mins} 分
                    </button>
                  );
                })}
                <div className="flex min-w-0 items-center gap-1 rounded-xl border border-zinc-300 bg-white px-2">
                  <input
                    type="number"
                    min={1}
                    max={360}
                    inputMode="numeric"
                    pattern="[0-9]*"
                    aria-label="自訂每節長度（分鐘）"
                    value={periodLengthInput}
                    onChange={(e) => setPeriodLengthInput(e.target.value)}
                    placeholder="自訂"
                    className="min-h-[42px] w-full min-w-0 bg-transparent text-center text-base text-zinc-900 tabular-nums focus:outline-none"
                  />
                  <span className="shrink-0 text-[11px] text-zinc-500">分</span>
                </div>
              </div>
            </div>

            {/* 下課時間 */}
            <div className="space-y-1.5">
              <span className="block text-xs font-medium text-zinc-700">
                下課時間
              </span>
              <div className="grid grid-cols-4 gap-1.5">
                {BREAK_LENGTH_PRESETS.map((mins) => {
                  const active = activeQuickBreakLen === mins;
                  return (
                    <button
                      key={mins}
                      type="button"
                      aria-pressed={active}
                      onClick={() => setBreakLengthInput(String(mins))}
                      className={`flex min-h-[44px] items-center justify-center rounded-xl px-2 text-xs tabular-nums transition-colors ${
                        active
                          ? 'border-2 border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                          : 'border border-zinc-200 bg-white font-medium text-zinc-700 hover:bg-zinc-50'
                      }`}
                    >
                      {mins} 分
                    </button>
                  );
                })}
              </div>
              <div className="flex items-center gap-2">
                <label
                  htmlFor="quick-break-custom"
                  className="shrink-0 text-xs font-medium text-zinc-600"
                >
                  自訂下課
                </label>
                <input
                  id="quick-break-custom"
                  type="number"
                  min={0}
                  max={180}
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={breakLengthInput}
                  onChange={(e) => setBreakLengthInput(e.target.value)}
                  className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                />
                <span className="shrink-0 text-xs text-zinc-500">分鐘</span>
              </div>
            </div>

            {/* 選填午休 */}
            <div className="space-y-2 rounded-xl border border-zinc-200 bg-zinc-50/70 p-3">
              <button
                type="button"
                role="switch"
                aria-checked={lunchEnabled}
                disabled={periodCount <= 1}
                onClick={() => setLunchEnabled((v) => !v)}
                className="flex min-h-[44px] w-full items-center justify-between gap-2 text-left disabled:opacity-50"
              >
                <span className="text-xs font-medium text-zinc-800">
                  午休加長休息（選填）
                </span>
                <span
                  aria-hidden="true"
                  className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                    lunchEnabled && periodCount > 1 ? 'bg-violet-600' : 'bg-zinc-300'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 rounded-full bg-white shadow transition-transform ${
                      lunchEnabled && periodCount > 1
                        ? 'translate-x-6'
                        : 'translate-x-1'
                    }`}
                  />
                </span>
              </button>

              {lunchEnabled && periodCount > 1 && (
                <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-700">
                  <span>在第</span>
                  <select
                    value={safeLunchAfter}
                    onChange={(e) =>
                      setLunchAfterPeriod(Number.parseInt(e.target.value, 10))
                    }
                    aria-label="午休前節次"
                    className="min-h-[44px] rounded-xl border border-zinc-300 bg-white px-2.5 text-base font-medium text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                  >
                    {Array.from({ length: periodCount - 1 }, (_, i) => i + 1).map(
                      (n) => (
                        <option key={n} value={n}>
                          第 {n} 節
                        </option>
                      )
                    )}
                  </select>
                  <span>後休息</span>
                  <input
                    type="number"
                    min={5}
                    max={240}
                    inputMode="numeric"
                    pattern="[0-9]*"
                    aria-label="午休分鐘數"
                    value={lunchDurationInput}
                    onChange={(e) => setLunchDurationInput(e.target.value)}
                    className="min-h-[44px] w-20 rounded-xl border border-zinc-300 bg-white px-2.5 text-center text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                  />
                  <span>分</span>
                </div>
              )}
            </div>

            {/* 即時預覽產生結果 */}
            <div className="space-y-1.5">
              <span className="block text-xs font-medium text-zinc-600">
                即時預覽（共 {quickPreview.periods.length} 節）
              </span>
              <div className="max-h-36 space-y-1 overflow-y-auto rounded-xl border border-zinc-200 bg-zinc-50/70 px-3 py-2 text-xs text-zinc-700 tabular-nums">
                {quickPreview.periods.map((p, idx) => (
                  <div key={p.id}>
                    <div className="flex items-center justify-between py-0.5">
                      <span className="font-medium text-zinc-900">{p.name}</span>
                      <span>
                        {p.startTime}–{p.endTime}
                      </span>
                    </div>
                    {lunchEnabled &&
                      periodCount > 1 &&
                      idx + 1 === safeLunchAfter && (
                        <div className="py-0.5 text-[11px] font-medium text-violet-700">
                          ↳ 午休 {parsedLunchDuration} 分
                        </div>
                      )}
                  </div>
                ))}
              </div>
              {quickPreview.overflowsMidnight && (
                <p className="text-xs font-medium text-rose-600">
                  排程時間已超過 23:59，請調早第一節開始時間或減少節數／時長。
                </p>
              )}
            </div>

            <button
              type="button"
              disabled={quickPreview.overflowsMidnight}
              onClick={handleRequestApplyQuick}
              className="flex min-h-[44px] w-full items-center justify-center rounded-xl border-2 border-violet-600 bg-[#EDE6FF] px-4 py-2 text-sm font-semibold text-zinc-900 transition-colors hover:bg-[#e1d6ff] disabled:opacity-50"
            >
              套用到節次表
            </button>
          </div>
        )}
      </div>

      {/* B. 節次表列表：連動調整 */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between gap-2 rounded-xl border border-zinc-200 bg-zinc-50/70 px-3 py-1.5">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-zinc-900">
              後面的節次跟著移動
            </p>
            <p className="text-[11px] text-zinc-500">
              {rippleNext
                ? '調整任一節或下課時間時，後續節次自動平移'
                : '已關閉連動，調整時只修改該節次'}
            </p>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={rippleNext}
            aria-label="後面的節次跟著移動"
            onClick={() => setRippleNext((v) => !v)}
            className="flex min-h-[44px] shrink-0 items-center pl-2"
          >
            <span
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                rippleNext ? 'bg-violet-600' : 'bg-zinc-300'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 rounded-full bg-white shadow transition-transform ${
                  rippleNext ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </span>
          </button>
        </div>

        {periods.length === 0 ? (
          <div className="rounded-xl border border-dashed border-zinc-300 bg-zinc-50/50 p-4 text-center text-xs text-zinc-500">
            尚未設定節次，可使用上方「快速產生節次」套用，或點下方「加入節次」逐筆新增。
          </div>
        ) : (
          <div className="space-y-1.5">
            {periods.map((p, index) => {
              const rowError = periodErrors.get(p.id);
              const durationMins =
                p.startTime && p.endTime && p.startTime < p.endTime
                  ? timeToMinutes(p.endTime) - timeToMinutes(p.startTime)
                  : null;
              const nextPeriod =
                index < periods.length - 1 ? periods[index + 1] : null;
              const breakMins = nextPeriod
                ? timeToMinutes(nextPeriod.startTime) - timeToMinutes(p.endTime)
                : null;
              const isBreakEditing = editingBreakIndex === index;

              return (
                <div key={p.id} className="space-y-1.5">
                  <div
                    className={`space-y-2 rounded-2xl border p-3 ${
                      rowError
                        ? 'border-rose-400 bg-rose-50/40'
                        : 'border-zinc-200 bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={p.name}
                        onChange={(e) => handleRenamePeriod(index, e.target.value)}
                        aria-label={`第 ${index + 1} 筆節次名稱`}
                        placeholder={`第${index + 1}節`}
                        className="min-h-[44px] w-24 shrink-0 rounded-xl border border-zinc-200 bg-zinc-50 px-2.5 text-base font-semibold text-zinc-900 focus:border-violet-600 focus:bg-white focus:outline-none"
                      />
                      <div className="min-w-0 flex-1 text-xs text-zinc-600 tabular-nums">
                        <p className="truncate font-medium text-zinc-900">
                          {p.startTime}–{p.endTime}
                        </p>
                        <p className="text-[11px] text-zinc-500">
                          {durationMins !== null ? `${durationMins} 分鐘` : '時間需檢查'}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setDeleteTargetPeriod(p)}
                        aria-label={`刪除 ${p.name || `第${index + 1}節`}`}
                        className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl text-rose-600 hover:bg-rose-50"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>

                    {/* Start time row */}
                    <div className="flex items-center gap-1.5">
                      <span className="w-9 shrink-0 text-xs font-medium text-zinc-600">
                        開始
                      </span>
                      <button
                        type="button"
                        onClick={() => handleNudgeStart(index, -5)}
                        disabled={!canShiftTimeMinutes(p.startTime, -5)}
                        aria-label={`${p.name} 開始時間減 5 分鐘`}
                        className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-xs font-semibold text-zinc-800 tabular-nums hover:bg-zinc-100 disabled:opacity-40"
                      >
                        −5
                      </button>
                      <input
                        type="time"
                        step={300}
                        value={p.startTime}
                        onChange={(e) =>
                          handleUpdatePeriodStart(index, e.target.value)
                        }
                        aria-label={`${p.name} 開始時間`}
                        className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-zinc-300 bg-white px-2.5 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => handleNudgeStart(index, 5)}
                        disabled={!canShiftTimeMinutes(p.startTime, 5)}
                        aria-label={`${p.name} 開始時間加 5 分鐘`}
                        className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-xs font-semibold text-zinc-800 tabular-nums hover:bg-zinc-100 disabled:opacity-40"
                      >
                        +5
                      </button>
                    </div>

                    {/* End time row */}
                    <div className="flex items-center gap-1.5">
                      <span className="w-9 shrink-0 text-xs font-medium text-zinc-600">
                        結束
                      </span>
                      <button
                        type="button"
                        onClick={() => handleNudgeEnd(index, -5)}
                        disabled={!canShiftTimeMinutes(p.endTime, -5)}
                        aria-label={`${p.name} 結束時間減 5 分鐘`}
                        className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-xs font-semibold text-zinc-800 tabular-nums hover:bg-zinc-100 disabled:opacity-40"
                      >
                        −5
                      </button>
                      <input
                        type="time"
                        step={300}
                        value={p.endTime}
                        onChange={(e) =>
                          handleUpdatePeriodEnd(index, e.target.value)
                        }
                        aria-label={`${p.name} 結束時間`}
                        className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-zinc-300 bg-white px-2.5 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => handleNudgeEnd(index, 5)}
                        disabled={!canShiftTimeMinutes(p.endTime, 5)}
                        aria-label={`${p.name} 結束時間加 5 分鐘`}
                        className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-xs font-semibold text-zinc-800 tabular-nums hover:bg-zinc-100 disabled:opacity-40"
                      >
                        +5
                      </button>
                    </div>

                    {rowError && (
                      <p className="text-xs font-medium text-rose-600">{rowError}</p>
                    )}
                  </div>

                  {/* Break connector between periods */}
                  {breakMins !== null && (
                    <div className="px-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (isBreakEditing) {
                            setEditingBreakIndex(null);
                          } else {
                            setEditingBreakIndex(index);
                            setBreakDraftInput(String(Math.max(0, breakMins)));
                          }
                        }}
                        className={`flex min-h-[44px] w-full items-center justify-between gap-2 rounded-xl border px-3 text-xs tabular-nums transition-colors ${
                          breakMins < 0
                            ? 'border-rose-300 bg-rose-50 font-semibold text-rose-700'
                            : 'border-dashed border-zinc-300 bg-zinc-50/70 font-medium text-zinc-600 hover:bg-zinc-100'
                        }`}
                      >
                        <span className="flex items-center gap-1.5">
                          <Clock size={13} aria-hidden="true" />
                          <span>
                            {breakMins < 0
                              ? `時間重疊 ${Math.abs(breakMins)} 分（點此調整間隔）`
                              : `下課 ${breakMins} 分`}
                          </span>
                        </span>
                        <span className="text-[11px] font-medium text-violet-700">
                          {isBreakEditing ? '收合' : '調整下課'}
                        </span>
                      </button>

                      {isBreakEditing && (
                        <div className="mt-1.5 space-y-2 rounded-xl border border-violet-200 bg-[#F9F6FF] p-3">
                          <div className="grid grid-cols-5 gap-1">
                            {INLINE_BREAK_PRESETS.map((mins) => (
                              <button
                                key={mins}
                                type="button"
                                onClick={() => handleApplyBreakMinutes(index, mins)}
                                className={`flex min-h-[44px] items-center justify-center rounded-xl text-xs tabular-nums transition-colors ${
                                  breakMins === mins
                                    ? 'border-2 border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                                    : 'border border-zinc-200 bg-white font-medium text-zinc-700 hover:bg-zinc-50'
                                }`}
                              >
                                {mins}分
                              </button>
                            ))}
                          </div>
                          <div className="flex items-center gap-2">
                            <input
                              type="number"
                              min={0}
                              max={240}
                              inputMode="numeric"
                              pattern="[0-9]*"
                              aria-label="自訂下課分鐘數"
                              value={breakDraftInput}
                              onChange={(e) => setBreakDraftInput(e.target.value)}
                              className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-zinc-300 bg-white px-3 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                const val = Number.parseInt(breakDraftInput, 10);
                                if (Number.isFinite(val) && val >= 0 && val <= 240) {
                                  handleApplyBreakMinutes(index, val);
                                }
                              }}
                              className="flex min-h-[44px] items-center justify-center rounded-xl bg-violet-600 px-4 text-xs font-semibold text-white hover:bg-violet-700"
                            >
                              套用
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <button
          type="button"
          onClick={handleAddSinglePeriod}
          className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl border border-violet-300 bg-[#F2ECFF] px-3 py-2 text-xs font-semibold text-zinc-900 transition-colors hover:bg-[#e8ddff]"
        >
          <Plus size={15} aria-hidden="true" />
          <span>
            加入節次（{parsedPeriodLength} 分
            {periods.length > 0 ? `，接在 ${parsedBreakLength} 分下課後` : ''}）
          </span>
        </button>
      </div>

      <ConfirmDialog
        open={confirmApplyOpen}
        title="取代目前節次表"
        description={`此單位目前已有 ${periods.length} 個節次，套用快速產生將會取代目前的節次表（不會改動已建立場次的實際時間）。確定要取代嗎？`}
        confirmLabel="確定取代"
        danger
        onCancel={() => setConfirmApplyOpen(false)}
        onConfirm={applyQuickSchedule}
      />

      <ConfirmDialog
        open={deleteTargetPeriod !== null}
        title="刪除節次"
        description={
          deleteTargetPeriod
            ? `確定要刪除「${deleteTargetPeriod.name || '此節次'}」（${deleteTargetPeriod.startTime}–${deleteTargetPeriod.endTime}）嗎？（不會改動已建立場次的實際時間）`
            : ''
        }
        confirmLabel="確定刪除"
        danger
        onCancel={() => setDeleteTargetPeriod(null)}
        onConfirm={handleConfirmDeletePeriod}
      />
    </div>
  );
}
