import { Camera, ChevronLeft, ChevronRight, ImagePlus, Trash2, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type ChangeEvent } from 'react';
import type { StoredImage } from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import { compressImageFile, type CompressedImageResult } from '../utils/imageCompression';
import { ConfirmDialog } from './ConfirmDialog';

export interface DisplayImageItem {
  id: string;
  fileName: string;
  blob: Blob;
  thumbnailBlob?: Blob;
}

function useBlobUrl(blob: Blob | undefined): string | null {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!blob) {
      setUrl(null);
      return undefined;
    }
    const objectUrl = URL.createObjectURL(blob);
    setUrl(objectUrl);
    return () => {
      URL.revokeObjectURL(objectUrl);
    };
  }, [blob]);

  return url;
}

interface ThumbnailTileProps {
  image: DisplayImageItem;
  sizeClassName?: string;
  onClick: () => void;
}

function ThumbnailTile({
  image,
  sizeClassName = 'aspect-square w-full',
  onClick,
}: ThumbnailTileProps) {
  // 列表只使用縮圖（若舊資料沒有 thumbnailBlob 才退回使用 blob）
  const thumbSource = image.thumbnailBlob ?? image.blob;
  const thumbUrl = useBlobUrl(thumbSource);

  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={`放大檢視照片 ${image.fileName}`}
      className={`group relative overflow-hidden rounded-xl border border-zinc-200 bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 ${sizeClassName}`}
    >
      {thumbUrl ? (
        <img
          src={thumbUrl}
          alt={image.fileName}
          className="h-full w-full object-cover transition-transform duration-150 group-hover:scale-[1.03]"
        />
      ) : (
        <span className="flex h-full w-full items-center justify-center text-xs text-zinc-400">
          載入中
        </span>
      )}
    </button>
  );
}

interface ImageLightboxModalProps {
  images: DisplayImageItem[];
  activeIndex: number | null;
  onChangeIndex: (index: number | null) => void;
  onDeleteImage?: (image: DisplayImageItem) => void | Promise<void>;
}

export function ImageLightboxModal({
  images,
  activeIndex,
  onChangeIndex,
  onDeleteImage,
}: ImageLightboxModalProps) {
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const currentImage =
    activeIndex !== null && activeIndex >= 0 && activeIndex < images.length
      ? images[activeIndex]
      : null;

  // 放大檢視時載入最長邊 1280px 壓縮大圖
  const fullUrl = useBlobUrl(currentImage?.blob);

  useEffect(() => {
    setConfirmDeleteOpen(false);
  }, [activeIndex, currentImage?.id]);

  useBackLayer({
    active: currentImage !== null && activeIndex !== null,
    zLayer: 70,
    onBack: () => {
      if (!isDeleting) {
        onChangeIndex(null);
      }
    },
  });

  if (!currentImage || activeIndex === null) {
    return null;
  }

  const hasPrev = activeIndex > 0;
  const hasNext = activeIndex < images.length - 1;

  const handleConfirmDelete = async () => {
    if (!onDeleteImage) return;
    setIsDeleting(true);
    try {
      await onDeleteImage(currentImage);
      setConfirmDeleteOpen(false);
      if (images.length <= 1) {
        onChangeIndex(null);
      } else if (activeIndex >= images.length - 1) {
        onChangeIndex(images.length - 2);
      }
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="照片放大檢視"
        className="fixed inset-0 z-[70] flex flex-col bg-black/95 text-white"
      >
        <div className="flex shrink-0 items-center justify-between gap-2 px-3 py-2.5 pt-[calc(0.625rem+env(safe-area-inset-top))]">
          <button
            type="button"
            onClick={() => onChangeIndex(null)}
            aria-label="關閉放大檢視"
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-white/90 transition-colors hover:bg-white/10"
          >
            <X size={22} />
          </button>

          <span className="truncate text-xs font-medium text-white/80 tabular-nums">
            {activeIndex + 1} / {images.length}
          </span>

          {onDeleteImage ? (
            <button
              type="button"
              onClick={() => setConfirmDeleteOpen(true)}
              aria-label="刪除此照片"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-rose-300 transition-colors hover:bg-white/10"
            >
              <Trash2 size={20} />
            </button>
          ) : (
            <div className="w-[44px]" aria-hidden="true" />
          )}
        </div>

        <div className="relative flex min-h-0 flex-1 items-center justify-center px-3 py-2">
          {fullUrl && (
            <img
              src={fullUrl}
              alt={currentImage.fileName}
              className="max-h-full max-w-full rounded-lg object-contain"
            />
          )}

          {hasPrev && (
            <button
              type="button"
              onClick={() => onChangeIndex(activeIndex - 1)}
              aria-label="上一張照片"
              className="absolute left-2 top-1/2 flex min-h-[44px] min-w-[44px] -translate-y-1/2 items-center justify-center rounded-full bg-black/60 text-white hover:bg-black/80"
            >
              <ChevronLeft size={22} />
            </button>
          )}

          {hasNext && (
            <button
              type="button"
              onClick={() => onChangeIndex(activeIndex + 1)}
              aria-label="下一張照片"
              className="absolute right-2 top-1/2 flex min-h-[44px] min-w-[44px] -translate-y-1/2 items-center justify-center rounded-full bg-black/60 text-white hover:bg-black/80"
            >
              <ChevronRight size={22} />
            </button>
          )}
        </div>

        <div className="shrink-0 px-4 py-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] text-center text-xs text-white/70">
          <p className="truncate">{currentImage.fileName}</p>
        </div>
      </div>

      <ConfirmDialog
        open={confirmDeleteOpen}
        title="刪除照片"
        description="確定要刪除這張照片嗎？刪除後無法復原。"
        confirmLabel="確認刪除"
        isSubmitting={isDeleting}
        onCancel={() => setConfirmDeleteOpen(false)}
        onConfirm={() => {
          void handleConfirmDelete();
        }}
      />
    </>
  );
}

interface ThumbnailStripProps {
  images: StoredImage[];
  onSelectImage?: (index: number) => void;
}

export function ThumbnailStrip({ images, onSelectImage }: ThumbnailStripProps) {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  if (images.length === 0) return null;

  return (
    <>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {images.map((img, idx) => (
          <ThumbnailTile
            key={img.id}
            image={img}
            sizeClassName="h-14 w-14 shrink-0"
            onClick={() => {
              if (onSelectImage) {
                onSelectImage(idx);
              } else {
                setLightboxIndex(idx);
              }
            }}
          />
        ))}
      </div>

      {!onSelectImage && (
        <ImageLightboxModal
          images={images}
          activeIndex={lightboxIndex}
          onChangeIndex={setLightboxIndex}
        />
      )}
    </>
  );
}

interface PhotoGallerySectionProps {
  title?: string;
  images: DisplayImageItem[];
  onAddCompressedImages: (results: CompressedImageResult[]) => Promise<void> | void;
  onDeleteImage: (image: DisplayImageItem) => Promise<void> | void;
}

export function PhotoGallerySection({
  title = '照片紀錄',
  images,
  onAddCompressedImages,
  onDeleteImage,
}: PhotoGallerySectionProps) {
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const albumInputRef = useRef<HTMLInputElement | null>(null);

  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const handleFilesSelected = async (event: ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files ? Array.from(event.target.files) : [];
    event.target.value = '';
    if (files.length === 0) return;

    setError(null);
    setIsProcessing(true);
    try {
      const compressed: CompressedImageResult[] = [];
      for (const file of files) {
        const result = await compressImageFile(file);
        compressed.push(result);
      }
      await onAddCompressedImages(compressed);
    } catch (err) {
      setError(
        err instanceof Error && err.message
          ? err.message
          : '圖片處理失敗，請稍後再試。'
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const countLabel = useMemo(
    () => (images.length > 0 ? `${images.length} 張` : '尚未新增'),
    [images.length]
  );

  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between gap-2">
        <span className="text-sm font-medium text-zinc-800">{title}</span>
        <span className="text-xs text-zinc-500 tabular-nums">{countLabel}</span>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => cameraInputRef.current?.click()}
          disabled={isProcessing}
          className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-zinc-200 bg-white px-3 py-2 text-xs font-medium text-zinc-800 transition-colors hover:bg-zinc-50 disabled:opacity-60"
        >
          <Camera size={15} aria-hidden="true" />
          <span>{isProcessing ? '壓縮中…' : '拍照'}</span>
        </button>

        <button
          type="button"
          onClick={() => albumInputRef.current?.click()}
          disabled={isProcessing}
          className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-zinc-200 bg-white px-3 py-2 text-xs font-medium text-zinc-800 transition-colors hover:bg-zinc-50 disabled:opacity-60"
        >
          <ImagePlus size={15} aria-hidden="true" />
          <span>{isProcessing ? '壓縮中…' : '選相簿（多張）'}</span>
        </button>

        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={(e) => {
            void handleFilesSelected(e);
          }}
          className="hidden"
          aria-label="拍照新增照片"
        />
        <input
          ref={albumInputRef}
          type="file"
          accept="image/*"
          multiple
          onChange={(e) => {
            void handleFilesSelected(e);
          }}
          className="hidden"
          aria-label="從相簿選擇多張照片"
        />
      </div>

      {error && (
        <p role="alert" className="text-xs font-medium text-rose-600">
          {error}
        </p>
      )}

      {images.length > 0 && (
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {images.map((img, idx) => (
            <ThumbnailTile
              key={img.id}
              image={img}
              onClick={() => setLightboxIndex(idx)}
            />
          ))}
        </div>
      )}

      <ImageLightboxModal
        images={images}
        activeIndex={lightboxIndex}
        onChangeIndex={setLightboxIndex}
        onDeleteImage={onDeleteImage}
      />
    </div>
  );
}
