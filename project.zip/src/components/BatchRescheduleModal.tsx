import { X } from 'lucide-react';
import { useEffect, useState, type FormEvent } from 'react';
import { db } from '../db/database';
import { rescheduleBatchSessions } from '../db/repositories';
import type { SessionBatch } from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import { addMinutesToTime, timeToMinutes, toDateKey } from '../utils/date';
import { useLiveQuery } from '../utils/useLiveQuery';
import { ConfirmDialog } from './ConfirmDialog';
import { DurationSelector } from './DurationSelector';

interface BatchRescheduleModalProps {
  open: boolean;
  batch: SessionBatch | null;
  onClose: () => void;
  onCompleted?: (updatedCount: number) => void;
}

export function BatchRescheduleModal({
  open,
  batch,
  onClose,
  onCompleted,
}: BatchRescheduleModalProps) {
  const [fromDate, setFromDate] = useState('');
  const [startTime, setStartTime] = useState('19:00');
  const [endTime, setEndTime] = useState('19:50');
  const [customDuration, setCustomDuration] = useState('50');
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [hasUserEdited, setHasUserEdited] = useState(false);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);

  const batchSessions = useLiveQuery(async () => {
    if (!open || !batch) return [];
    const list = await db.sessions.where('batchId').equals(batch.id).toArray();
    return list.sort((a, b) => a.date.localeCompare(b.date));
  }, [open, batch?.id]);

  useEffect(() => {
    if (!open || !batch) return;
    setFromDate(toDateKey(new Date()));
    setStartTime('19:00');
    setEndTime('19:50');
    setCustomDuration('50');
    setError(null);
    setHasUserEdited(false);
    setDiscardConfirmOpen(false);
  }, [open, batch?.id]);

  useEffect(() => {
    if (!open || !batchSessions || batchSessions.length === 0) return;
    const first = batchSessions[0];
    setStartTime(first.startTime);
    setEndTime(first.endTime);
    const diff =
      first.startTime && first.endTime && first.startTime < first.endTime
        ? timeToMinutes(first.endTime) - timeToMinutes(first.startTime)
        : 0;
    setCustomDuration(diff > 0 ? String(diff) : '');
  }, [open, batchSessions]);

  const isActive = open && batch !== null;

  const handleRequestClose = () => {
    if (isSaving) return;
    if (hasUserEdited) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: isActive,
    zLayer: 55,
    onBack: handleRequestClose,
  });

  if (!open || !batch) {
    return null;
  }

  const affectedCount = (batchSessions ?? []).filter(
    (s) => s.date >= fromDate
  ).length;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!fromDate) {
      setError('請選擇起始日期');
      return;
    }
    if (!startTime || !endTime || startTime >= endTime) {
      setError('結束時間必須晚於開始時間');
      return;
    }
    if (affectedCount === 0) {
      setError('該日期之後沒有屬於此批次的場次');
      return;
    }

    setIsSaving(true);
    try {
      const updatedCount = await rescheduleBatchSessions({
        batchId: batch.id,
        fromDate,
        startTime,
        endTime,
      });
      onCompleted?.(updatedCount);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="batch-reschedule-title"
        className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
      >
        <div className="flex max-h-[90dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 bg-white px-4 py-3">
            <h2 id="batch-reschedule-title" className="text-base font-semibold text-zinc-900">
              整批改時間 · {batch.courseName}
            </h2>
            <button
              type="button"
              onClick={handleRequestClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900"
            >
              <X size={20} />
            </button>
          </div>

        <form
          onSubmit={(e) => void handleSubmit(e)}
          className="flex min-h-0 flex-1 flex-col"
        >
          <div className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-4 scroll-mb-6">
            <p className="text-xs leading-relaxed text-zinc-600">
              將此批次中「起始日期（含）之後」的場次統一改為新的開始與結束時間。此操作只會修改時間，不會刪除任何場次或紀錄。
            </p>

            <div>
              <label
                htmlFor="batch-reschedule-from"
                className="block text-sm font-medium text-zinc-800"
              >
                起始日期（含當日之後）
              </label>
              <input
                id="batch-reschedule-from"
                type="date"
                value={fromDate}
                onChange={(e) => {
                  setHasUserEdited(true);
                  setFromDate(e.target.value);
                  if (error) setError(null);
                }}
                className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="min-w-0">
                <label
                  htmlFor="batch-reschedule-start"
                  className="block text-sm font-medium text-zinc-800"
                >
                  新開始時間
                </label>
                <input
                  id="batch-reschedule-start"
                  type="time"
                  value={startTime}
                  onChange={(e) => {
                    const nextStart = e.target.value;
                    setHasUserEdited(true);
                    setStartTime(nextStart);
                    const diff =
                      nextStart && endTime && nextStart < endTime
                        ? timeToMinutes(endTime) - timeToMinutes(nextStart)
                        : 0;
                    setCustomDuration(diff > 0 ? String(diff) : '');
                    if (error) setError(null);
                  }}
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                />
              </div>
              <div className="min-w-0">
                <label
                  htmlFor="batch-reschedule-end"
                  className="block text-sm font-medium text-zinc-800"
                >
                  新結束時間
                </label>
                <input
                  id="batch-reschedule-end"
                  type="time"
                  value={endTime}
                  onChange={(e) => {
                    const nextEnd = e.target.value;
                    setHasUserEdited(true);
                    setEndTime(nextEnd);
                    const diff =
                      startTime && nextEnd && startTime < nextEnd
                        ? timeToMinutes(nextEnd) - timeToMinutes(startTime)
                        : 0;
                    setCustomDuration(diff > 0 ? String(diff) : '');
                    if (error) setError(null);
                  }}
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                />
              </div>
            </div>

            <DurationSelector
              label="快捷時長（依開始時間推算結束時間）"
              activeMinutes={
                startTime && endTime && startTime < endTime
                  ? timeToMinutes(endTime) - timeToMinutes(startTime)
                  : null
              }
              customValue={customDuration}
              onSelectPreset={(mins) => {
                setHasUserEdited(true);
                setCustomDuration(String(mins));
                if (startTime) {
                  setEndTime(addMinutesToTime(startTime, mins));
                }
                if (error) setError(null);
              }}
              onCustomChange={(val) => {
                setHasUserEdited(true);
                setCustomDuration(val);
                const parsed = Number.parseInt(val, 10);
                if (Number.isFinite(parsed) && parsed > 0 && parsed <= 720 && startTime) {
                  setEndTime(addMinutesToTime(startTime, parsed));
                }
                if (error) setError(null);
              }}
            />

            <div className="rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 py-2.5 text-sm text-zinc-700 tabular-nums">
              預計修改 <span className="font-semibold text-violet-700">{affectedCount}</span> 堂場次
            </div>

            {error && <p className="text-xs font-medium text-rose-600">{error}</p>}
          </div>

          <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
            <button
              type="submit"
              disabled={isSaving || affectedCount === 0}
              className="flex min-h-[44px] w-full items-center justify-center rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-violet-700 disabled:opacity-50"
            >
              {isSaving ? '修改中…' : `確認修改 ${affectedCount} 堂時間`}
            </button>
          </div>
        </form>
      </div>
    </div>

    <ConfirmDialog
      open={discardConfirmOpen}
      title="放棄未儲存的內容？"
      description="目前有尚未儲存的修改，確定要放棄並返回嗎？"
      confirmLabel="放棄變更"
      cancelLabel="繼續編輯"
      danger
      onCancel={() => setDiscardConfirmOpen(false)}
      onConfirm={() => {
        setDiscardConfirmOpen(false);
        onClose();
      }}
    />
  </>
  );
}
