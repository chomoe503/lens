import { Check, Search, Trash2, X } from 'lucide-react';
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { db } from '../db/database';
import type {
  AcademicYear,
  Course,
  ExamPeriod,
  ExamPeriodKind,
  Organization,
} from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import {
  EXAM_KIND_LABELS,
  getExamDisplayTitle,
  resolveExamCourseIds,
} from '../utils/examCountdown';
import { createId } from '../utils/id';
import { toDateKey } from '../utils/date';
import { pushUndoCustomAction } from '../utils/undoStore';
import { ConfirmDialog } from './ConfirmDialog';

interface ExamPeriodFormModalProps {
  open: boolean;
  examPeriod: ExamPeriod | null;
  organizations: Organization[];
  courses: Course[];
  academicYears: AcademicYear[];
  onClose: () => void;
}

const KIND_OPTIONS: Array<{ value: ExamPeriodKind; label: string }> = [
  { value: 'midterm', label: EXAM_KIND_LABELS.midterm },
  { value: 'final', label: EXAM_KIND_LABELS.final },
  { value: 'mock', label: EXAM_KIND_LABELS.mock },
  { value: 'other', label: EXAM_KIND_LABELS.other },
];

const QUICK_TITLE_PRESETS: Array<{ title: string; kind: ExamPeriodKind }> = [
  { title: '第一次段考', kind: 'midterm' },
  { title: '第二次段考', kind: 'midterm' },
  { title: '第三次段考', kind: 'midterm' },
  { title: '期末考', kind: 'final' },
  { title: '模考', kind: 'mock' },
];

function normalizeIdList(ids: string[]): string[] {
  return [...ids].sort();
}

export function ExamPeriodFormModal({
  open,
  examPeriod,
  organizations,
  courses,
  academicYears,
  onClose,
}: ExamPeriodFormModalProps) {
  const isEditing = examPeriod !== null;
  const todayKey = toDateKey(new Date());

  const [organizationId, setOrganizationId] = useState('');
  const [studentSchoolId, setStudentSchoolId] = useState('');
  const [title, setTitle] = useState('');
  const [kind, setKind] = useState<ExamPeriodKind>('midterm');
  const [startDate, setStartDate] = useState(todayKey);
  const [endDate, setEndDate] = useState(todayKey);
  const [endDateDiverged, setEndDateDiverged] = useState(false);
  const [subjectDate, setSubjectDate] = useState('');
  const [subjectNote, setSubjectNote] = useState('');
  const [scope, setScope] = useState('');
  const [note, setNote] = useState('');
  const [appliesToAll, setAppliesToAll] = useState(true);
  const [courseIds, setCourseIds] = useState<string[]>([]);

  const [courseSearch, setCourseSearch] = useState('');
  const [showArchivedCourses, setShowArchivedCourses] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);
  const [initialSnapshot, setInitialSnapshot] = useState('');

  const orgMap = useMemo(() => {
    const map = new Map<string, Organization>();
    for (const o of organizations) map.set(o.id, o);
    return map;
  }, [organizations]);

  const yearMap = useMemo(() => {
    const map = new Map<string, AcademicYear>();
    for (const y of academicYears) map.set(y.id, y);
    return map;
  }, [academicYears]);

  const regularCourses = useMemo(
    () =>
      courses
        .filter((c) => !c.isSystem)
        .sort((a, b) => a.name.localeCompare(b.name, 'zh-Hant')),
    [courses]
  );

  const visibleCourses = useMemo(() => {
    const query = courseSearch.trim().toLowerCase();
    return regularCourses.filter((c) => {
      if (organizationId && c.organizationId !== organizationId) {
        return false;
      }
      if (!showArchivedCourses) {
        const year = yearMap.get(c.academicYearId);
        if (year?.archived && !courseIds.includes(c.id)) {
          return false;
        }
      }
      if (!query) return true;
      const orgName = orgMap.get(c.organizationId)?.name ?? '';
      return (
        c.name.toLowerCase().includes(query) ||
        orgName.toLowerCase().includes(query)
      );
    });
  }, [
    regularCourses,
    organizationId,
    showArchivedCourses,
    yearMap,
    courseIds,
    courseSearch,
    orgMap,
  ]);

  const groupedVisibleCourses = useMemo(() => {
    if (organizationId) {
      return [
        {
          orgId: organizationId,
          orgName: orgMap.get(organizationId)?.name ?? '未指定單位',
          orgColor: orgMap.get(organizationId)?.color ?? '#CDB8FF',
          items: visibleCourses,
        },
      ];
    }

    const groupsMap = new Map<string, Course[]>();
    for (const c of visibleCourses) {
      const key = c.organizationId || '__none__';
      const arr = groupsMap.get(key) ?? [];
      arr.push(c);
      groupsMap.set(key, arr);
    }

    const groups: Array<{
      orgId: string;
      orgName: string;
      orgColor: string;
      items: Course[];
    }> = [];

    for (const org of organizations) {
      const items = groupsMap.get(org.id);
      if (items && items.length > 0) {
        groups.push({
          orgId: org.id,
          orgName: org.name,
          orgColor: org.color,
          items,
        });
        groupsMap.delete(org.id);
      }
    }

    for (const [orgId, items] of groupsMap.entries()) {
      if (items.length === 0) continue;
      groups.push({
        orgId,
        orgName: orgMap.get(orgId)?.name ?? '未指定單位',
        orgColor: orgMap.get(orgId)?.color ?? '#CDB8FF',
        items,
      });
    }

    return groups;
  }, [organizationId, visibleCourses, organizations, orgMap]);

  useEffect(() => {
    if (!open) return;

    if (examPeriod) {
      const initOrgId = examPeriod.organizationId ?? '';
      const initSchoolId =
        initOrgId && examPeriod.studentSchoolId
          ? examPeriod.studentSchoolId
          : '';
      const initAppliesAll = initOrgId ? examPeriod.appliesToAll : false;
      const initCourseIds = initAppliesAll ? [] : [...examPeriod.courseIds];
      const initSubjectDate = examPeriod.subjectDate ?? '';
      const initSubjectNote = examPeriod.subjectNote ?? '';
      const initScope = examPeriod.scope ?? '';
      const initNote = examPeriod.note ?? '';

      setOrganizationId(initOrgId);
      setStudentSchoolId(initSchoolId);
      setTitle(examPeriod.title);
      setKind(examPeriod.kind);
      setStartDate(examPeriod.startDate);
      setEndDate(examPeriod.endDate);
      setEndDateDiverged(examPeriod.endDate !== examPeriod.startDate);
      setSubjectDate(initSubjectDate);
      setSubjectNote(initSubjectNote);
      setScope(initScope);
      setNote(initNote);
      setAppliesToAll(initAppliesAll);
      setCourseIds(initCourseIds);
      setCourseSearch('');
      setShowArchivedCourses(false);
      setError(null);
      setDeleteConfirmOpen(false);
      setDiscardConfirmOpen(false);
      setInitialSnapshot(
        JSON.stringify({
          organizationId: initOrgId,
          studentSchoolId: initSchoolId,
          title: examPeriod.title,
          kind: examPeriod.kind,
          startDate: examPeriod.startDate,
          endDate: examPeriod.endDate,
          subjectDate: initSubjectDate,
          subjectNote: initSubjectNote,
          scope: initScope,
          note: initNote,
          appliesToAll: initAppliesAll,
          courseIds: normalizeIdList(initCourseIds),
        })
      );
      return;
    }

    const defaultOrgId = organizations[0]?.id ?? '';
    const defaultAppliesAll = Boolean(defaultOrgId);

    setOrganizationId(defaultOrgId);
    setStudentSchoolId('');
    setTitle('');
    setKind('midterm');
    setStartDate(todayKey);
    setEndDate(todayKey);
    setEndDateDiverged(false);
    setSubjectDate('');
    setSubjectNote('');
    setScope('');
    setNote('');
    setAppliesToAll(defaultAppliesAll);
    setCourseIds([]);
    setCourseSearch('');
    setShowArchivedCourses(false);
    setError(null);
    setDeleteConfirmOpen(false);
    setDiscardConfirmOpen(false);
    setInitialSnapshot(
      JSON.stringify({
        organizationId: defaultOrgId,
        studentSchoolId: '',
        title: '',
        kind: 'midterm',
        startDate: todayKey,
        endDate: todayKey,
        subjectDate: '',
        subjectNote: '',
        scope: '',
        note: '',
        appliesToAll: defaultAppliesAll,
        courseIds: [],
      })
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, examPeriod]);

  const isDirty = useMemo(() => {
    if (!open || !initialSnapshot) return false;
    return (
      JSON.stringify({
        organizationId,
        studentSchoolId,
        title,
        kind,
        startDate,
        endDate,
        subjectDate,
        subjectNote,
        scope,
        note,
        appliesToAll: organizationId ? appliesToAll : false,
        courseIds: normalizeIdList(courseIds),
      }) !== initialSnapshot
    );
  }, [
    open,
    initialSnapshot,
    organizationId,
    studentSchoolId,
    title,
    kind,
    startDate,
    endDate,
    subjectDate,
    subjectNote,
    scope,
    note,
    appliesToAll,
    courseIds,
  ]);

  const selectedOrg = organizationId ? orgMap.get(organizationId) : undefined;
  const orgSchools = selectedOrg?.studentSchools ?? [];
  const selectedSchool =
    organizationId && studentSchoolId
      ? orgSchools.find((s) => s.id === studentSchoolId)
      : undefined;

  const autoMatchedCourses = useMemo(() => {
    if (!organizationId || !selectedSchool) return [];
    const matchedIds = resolveExamCourseIds(
      {
        organizationId,
        appliesToAll: true,
        courseIds: [],
        studentSchoolId: selectedSchool.id,
      },
      courses
    );
    return regularCourses.filter((c) => matchedIds.has(c.id));
  }, [organizationId, selectedSchool, courses, regularCourses]);

  const handleRequestClose = () => {
    if (isSaving || isDeleting) return;
    if (isDirty) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: open,
    zLayer: 65,
    onBack: handleRequestClose,
  });

  if (!open) return null;

  const handleOrganizationChange = (nextOrgId: string) => {
    setOrganizationId(nextOrgId);
    setStudentSchoolId('');
    setCourseSearch('');
    if (error) setError(null);

    if (!nextOrgId) {
      setAppliesToAll(false);
      setCourseIds([]);
    } else {
      setAppliesToAll(true);
      setCourseIds([]);
    }
  };

  const handleStartDateChange = (nextStart: string) => {
    setStartDate(nextStart);
    if (error) setError(null);
    if (!nextStart) return;
    if (!endDateDiverged || !endDate || endDate < nextStart) {
      setEndDate(nextStart);
    }
  };

  const handleEndDateChange = (nextEnd: string) => {
    setEndDate(nextEnd);
    setEndDateDiverged(nextEnd !== startDate);
    if (error) setError(null);
  };

  const toggleCourseSelection = (courseId: string) => {
    if (error) setError(null);
    setCourseIds((prev) =>
      prev.includes(courseId)
        ? prev.filter((id) => id !== courseId)
        : [...prev, courseId]
    );
  };

  const handleSelectAllVisible = () => {
    if (error) setError(null);
    setCourseIds((prev) => {
      const set = new Set(prev);
      for (const c of visibleCourses) {
        set.add(c.id);
      }
      return Array.from(set);
    });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const trimmedTitle = title.trim();
    if (!trimmedTitle) {
      setError('請輸入考試期間名稱');
      return;
    }
    if (!startDate) {
      setError('請選擇開始日期');
      return;
    }
    const effectiveEndDate = endDate || startDate;
    if (effectiveEndDate < startDate) {
      setError('結束日期不可早於開始日期');
      return;
    }
    if (subjectDate && (subjectDate < startDate || subjectDate > effectiveEndDate)) {
      setError('理化考試日必須介於開始日期與結束日期之間');
      return;
    }

    const effectiveAppliesAll = Boolean(organizationId) && appliesToAll;
    const validCourseIds = effectiveAppliesAll ? [] : courseIds;
    if (!effectiveAppliesAll && validCourseIds.length === 0) {
      setError('請至少勾選一個適用班級');
      return;
    }

    setIsSaving(true);
    setError(null);
    try {
      const now = Date.now();
      const record: ExamPeriod = {
        id: examPeriod?.id ?? createId(),
        organizationId: organizationId || undefined,
        studentSchoolId:
          organizationId && studentSchoolId ? studentSchoolId : undefined,
        title: trimmedTitle,
        kind,
        startDate,
        endDate: effectiveEndDate,
        subjectDate: subjectDate || undefined,
        subjectNote: subjectNote.trim() || undefined,
        scope: scope.trim() || undefined,
        note: note.trim() || undefined,
        appliesToAll: effectiveAppliesAll,
        courseIds: validCourseIds,
        createdAt: examPeriod?.createdAt ?? now,
        updatedAt: now,
      };
      await db.examPeriods.put(record);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : '儲存考試期間失敗');
    } finally {
      setIsSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!examPeriod) return;
    setIsDeleting(true);
    try {
      const snapshot = { ...examPeriod, courseIds: [...examPeriod.courseIds] };
      const displayName = getExamDisplayTitle(snapshot, organizations);
      await db.examPeriods.delete(examPeriod.id);
      pushUndoCustomAction(`已刪除「${displayName}」`, async () => {
        await db.examPeriods.put(snapshot);
      });
      setDeleteConfirmOpen(false);
      onClose();
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="exam-period-form-title"
        className="fixed inset-0 z-[65] flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
        onClick={(e) => {
          if (e.target === e.currentTarget) {
            handleRequestClose();
          }
        }}
      >
        <div className="flex max-h-[92dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 px-5 py-3.5">
            <h2
              id="exam-period-form-title"
              className="text-base font-semibold text-zinc-900"
            >
              {isEditing ? '編輯考試期間' : '新增考試期間'}
            </h2>
            <button
              type="button"
              onClick={handleRequestClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
            >
              <X size={20} />
            </button>
          </div>

          <form
            noValidate
            onSubmit={(e) => void handleSubmit(e)}
            className="flex min-h-0 flex-1 flex-col overflow-hidden"
          >
            <div className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-5">
              {error && (
                <div
                  role="alert"
                  className="rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-medium text-rose-700"
                >
                  {error}
                </div>
              )}

              <div>
                <label
                  htmlFor="exam-period-org"
                  className="block text-xs font-medium text-zinc-700"
                >
                  單位
                </label>
                <select
                  id="exam-period-org"
                  value={organizationId}
                  onChange={(e) => handleOrganizationChange(e.target.value)}
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                >
                  <option value="">不指定（模考／跨校）</option>
                  {organizations.map((org) => (
                    <option key={org.id} value={org.id}>
                      {org.name}
                    </option>
                  ))}
                </select>
              </div>

              {organizationId && orgSchools.length > 0 && (
                <div>
                  <label
                    htmlFor="exam-period-school"
                    className="block text-xs font-medium text-zinc-700"
                  >
                    學校
                  </label>
                  <select
                    id="exam-period-school"
                    value={studentSchoolId}
                    onChange={(e) => {
                      setStudentSchoolId(e.target.value);
                      if (error) setError(null);
                    }}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  >
                    <option value="">不指定（整個單位）</option>
                    {orgSchools.map((school) => (
                      <option key={school.id} value={school.id}>
                        {school.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label
                  htmlFor="exam-period-title"
                  className="block text-xs font-medium text-zinc-700"
                >
                  名稱 <span className="text-rose-600">*</span>
                </label>
                <input
                  id="exam-period-title"
                  type="text"
                  value={title}
                  onChange={(e) => {
                    setTitle(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="例如：第一次段考、期末考、第二次模考"
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
                {selectedSchool && (
                  <p className="mt-1 text-xs text-zinc-500">
                    學校名稱會自動加在前面，不用寫進名稱
                  </p>
                )}
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {QUICK_TITLE_PRESETS.map((preset) => {
                    const active = title === preset.title && kind === preset.kind;
                    return (
                      <button
                        key={preset.title}
                        type="button"
                        onClick={() => {
                          setTitle(preset.title);
                          setKind(preset.kind);
                          if (error) setError(null);
                        }}
                        className={`min-h-[36px] rounded-xl border px-3 text-xs font-medium transition-colors ${
                          active
                            ? 'border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                            : 'border-zinc-200 bg-zinc-50 text-zinc-700 hover:bg-zinc-100'
                        }`}
                      >
                        {preset.title}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <span className="block text-xs font-medium text-zinc-700">
                  類型
                </span>
                <div className="mt-1.5 grid grid-cols-4 gap-1.5">
                  {KIND_OPTIONS.map((opt) => {
                    const active = kind === opt.value;
                    return (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => setKind(opt.value)}
                        className={`flex min-h-[44px] items-center justify-center rounded-xl border px-2 text-xs font-medium transition-colors sm:text-sm ${
                          active
                            ? 'border-violet-600 bg-[#CDB8FF] font-semibold text-zinc-900'
                            : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                        }`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="exam-period-start"
                    className="block text-xs font-medium text-zinc-700"
                  >
                    開始日期 <span className="text-rose-600">*</span>
                  </label>
                  <input
                    id="exam-period-start"
                    type="date"
                    value={startDate}
                    onChange={(e) => handleStartDateChange(e.target.value)}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>

                <div>
                  <label
                    htmlFor="exam-period-end"
                    className="block text-xs font-medium text-zinc-700"
                  >
                    結束日期 <span className="text-rose-600">*</span>
                  </label>
                  <input
                    id="exam-period-end"
                    type="date"
                    min={startDate || undefined}
                    value={endDate}
                    onChange={(e) => handleEndDateChange(e.target.value)}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <label
                      htmlFor="exam-period-subject-date"
                      className="block text-xs font-medium text-zinc-700"
                    >
                      理化考試日（選填）
                    </label>
                    {subjectDate && (
                      <button
                        type="button"
                        onClick={() => {
                          setSubjectDate('');
                          if (error) setError(null);
                        }}
                        className="text-xs font-medium text-violet-700 hover:underline"
                      >
                        清除
                      </button>
                    )}
                  </div>
                  <input
                    id="exam-period-subject-date"
                    type="date"
                    min={startDate || undefined}
                    max={endDate || startDate || undefined}
                    value={subjectDate}
                    onChange={(e) => {
                      setSubjectDate(e.target.value);
                      if (error) setError(null);
                    }}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>

                <div>
                  <label
                    htmlFor="exam-period-subject-note"
                    className="block text-xs font-medium text-zinc-700"
                  >
                    時間／節次說明（選填）
                  </label>
                  <input
                    id="exam-period-subject-note"
                    type="text"
                    value={subjectNote}
                    onChange={(e) => setSubjectNote(e.target.value)}
                    placeholder="例如：第 3 節 10:30"
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>
              </div>

              {/* 適用班級 */}
              <div className="space-y-2.5">
                <span className="block text-xs font-medium text-zinc-700">
                  適用班級
                </span>

                {organizationId && (
                  <>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={appliesToAll}
                      onClick={() => {
                        setAppliesToAll((prev) => !prev);
                        if (error) setError(null);
                      }}
                      className={`flex min-h-[48px] w-full items-center justify-between gap-3 rounded-2xl border px-3.5 py-2.5 text-left transition-colors ${
                        appliesToAll
                          ? 'border-violet-400 bg-[#F2ECFF]/75'
                          : 'border-zinc-200 bg-white hover:bg-zinc-50'
                      }`}
                    >
                      <span className="text-sm font-medium text-zinc-900">
                        {selectedSchool
                          ? `自動套用到有「${selectedSchool.name}」學生的班級（含之後新增的）`
                          : '該單位全部班級（含之後新增的）'}
                      </span>
                      <span
                        aria-hidden="true"
                        className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors ${
                          appliesToAll ? 'bg-violet-600' : 'bg-zinc-300'
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            appliesToAll ? 'translate-x-6' : 'translate-x-1'
                          }`}
                        />
                      </span>
                    </button>

                    {selectedSchool && appliesToAll && (
                      <div
                        className={`rounded-xl border px-3 py-2 text-xs leading-relaxed ${
                          autoMatchedCourses.length > 0
                            ? 'border-zinc-200 bg-zinc-50 text-zinc-700'
                            : 'border-amber-200 bg-amber-50 font-medium text-amber-900'
                        }`}
                      >
                        {autoMatchedCourses.length > 0
                          ? `目前套用：${autoMatchedCourses
                              .map((c) => c.name)
                              .join('、')}（共 ${autoMatchedCourses.length} 班）`
                          : '目前沒有任何班級包含這間學校，這筆考試不會顯示倒數'}
                      </div>
                    )}
                  </>
                )}

                {(!organizationId || !appliesToAll) && (
                  <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white">
                    <div className="space-y-2 border-b border-zinc-100 bg-zinc-50/70 p-2.5">
                      <div className="relative">
                        <Search
                          size={15}
                          aria-hidden="true"
                          className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400"
                        />
                        <input
                          type="search"
                          value={courseSearch}
                          onChange={(e) => setCourseSearch(e.target.value)}
                          placeholder="搜尋班級或單位名稱…"
                          aria-label="搜尋適用班級"
                          className="min-h-[44px] w-full rounded-xl border border-zinc-200 bg-white pl-9 pr-3 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                        />
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-violet-800 tabular-nums">
                          已選 {courseIds.length} 個班級
                        </span>

                        <div className="flex flex-wrap items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() =>
                              setShowArchivedCourses((prev) => !prev)
                            }
                            aria-pressed={showArchivedCourses}
                            className={`flex min-h-[36px] items-center rounded-lg border px-2.5 text-xs font-medium transition-colors ${
                              showArchivedCourses
                                ? 'border-violet-500 bg-[#EDE6FF] font-semibold text-zinc-900'
                                : 'border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-50'
                            }`}
                          >
                            顯示全部
                          </button>
                          <button
                            type="button"
                            disabled={visibleCourses.length === 0}
                            onClick={handleSelectAllVisible}
                            className="flex min-h-[36px] items-center rounded-lg border border-zinc-200 bg-white px-2.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-50 disabled:opacity-50"
                          >
                            全選
                          </button>
                          <button
                            type="button"
                            disabled={courseIds.length === 0}
                            onClick={() => setCourseIds([])}
                            className="flex min-h-[36px] items-center rounded-lg border border-zinc-200 bg-white px-2.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-50 disabled:opacity-50"
                          >
                            清除
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="max-h-[36dvh] overflow-y-auto overscroll-contain">
                      {visibleCourses.length === 0 ? (
                        <p className="px-4 py-6 text-center text-xs text-zinc-500">
                          {organizationId
                            ? '此單位目前沒有符合的班級'
                            : '目前尚未建立班級課程'}
                        </p>
                      ) : (
                        groupedVisibleCourses.map((group) => (
                          <div key={group.orgId}>
                            {!organizationId && (
                              <div className="sticky top-0 z-10 flex items-center gap-2 border-y border-zinc-100 bg-zinc-50/95 px-3 py-1.5 first:border-t-0">
                                <span
                                  aria-hidden="true"
                                  style={{ backgroundColor: group.orgColor }}
                                  className="h-2.5 w-2.5 shrink-0 rounded-full ring-1 ring-inset ring-black/15"
                                />
                                <span className="text-xs font-semibold text-zinc-700">
                                  {group.orgName}
                                </span>
                              </div>
                            )}

                            <div className="divide-y divide-zinc-100">
                              {group.items.map((c) => {
                                const checked = courseIds.includes(c.id);
                                const org = orgMap.get(c.organizationId);
                                const dotColor = org?.color ?? c.color;
                                const year = yearMap.get(c.academicYearId);
                                return (
                                  <button
                                    key={c.id}
                                    type="button"
                                    role="checkbox"
                                    aria-checked={checked}
                                    onClick={() => toggleCourseSelection(c.id)}
                                    className={`flex min-h-[48px] w-full items-center gap-2.5 px-3 py-2 text-left transition-colors ${
                                      checked
                                        ? 'bg-[#F2ECFF]/65'
                                        : 'hover:bg-zinc-50 active:bg-zinc-100'
                                    }`}
                                  >
                                    <span
                                      aria-hidden="true"
                                      className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-colors ${
                                        checked
                                          ? 'border-violet-700 bg-violet-700 text-white'
                                          : 'border-zinc-300 bg-white text-transparent'
                                      }`}
                                    >
                                      <Check size={13} strokeWidth={2.75} />
                                    </span>

                                    <span
                                      aria-hidden="true"
                                      style={{ backgroundColor: dotColor }}
                                      className="h-3 w-3 shrink-0 rounded-full ring-1 ring-inset ring-black/15"
                                    />

                                    <div className="min-w-0 flex-1">
                                      <p className="truncate text-sm font-medium text-zinc-900">
                                        {c.name}
                                      </p>
                                      <p className="truncate text-xs text-zinc-500">
                                        {org?.name ?? '未指定單位'}
                                        {year?.archived
                                          ? ` · ${year.name}（已封存）`
                                          : ''}
                                      </p>
                                    </div>
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label
                  htmlFor="exam-period-scope"
                  className="block text-xs font-medium text-zinc-700"
                >
                  考試範圍（選填）
                </label>
                <textarea
                  id="exam-period-scope"
                  rows={2}
                  value={scope}
                  onChange={(e) => setScope(e.target.value)}
                  placeholder="例如：第 3～4 章 光與聲音、實驗 3-2"
                  className="mt-1.5 w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              <div>
                <label
                  htmlFor="exam-period-note"
                  className="block text-xs font-medium text-zinc-700"
                >
                  備註（選填）
                </label>
                <textarea
                  id="exam-period-note"
                  rows={2}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="考前複習提醒或注意事項"
                  className="mt-1.5 w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>
            </div>

            <div className="shrink-0 border-t border-zinc-100 bg-white px-5 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
              <div className="flex items-center gap-2">
                {isEditing && (
                  <button
                    type="button"
                    onClick={() => setDeleteConfirmOpen(true)}
                    aria-label="刪除考試期間"
                    className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-rose-200 bg-white px-3 text-rose-600 transition-colors hover:bg-rose-50"
                  >
                    <Trash2 size={18} aria-hidden="true" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleRequestClose}
                  className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm font-medium text-zinc-700 hover:bg-zinc-50"
                >
                  取消
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl bg-violet-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-violet-700 disabled:opacity-60"
                >
                  {isSaving ? '儲存中…' : isEditing ? '儲存變更' : '儲存'}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>

      <ConfirmDialog
        open={deleteConfirmOpen}
        title="刪除考試期間"
        description={`確定要刪除「${
          examPeriod ? getExamDisplayTitle(examPeriod, organizations) : ''
        }」嗎？`}
        confirmLabel="確認刪除"
        isSubmitting={isDeleting}
        onCancel={() => setDeleteConfirmOpen(false)}
        onConfirm={() => {
          void handleConfirmDelete();
        }}
      />

      <ConfirmDialog
        open={discardConfirmOpen}
        title="放棄未儲存的內容？"
        description="考試期間有尚未儲存的修改，確定要放棄並關閉嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardConfirmOpen(false)}
        onConfirm={() => {
          setDiscardConfirmOpen(false);
          onClose();
        }}
      />
    </>
  );
}
