import { Trash2, X } from 'lucide-react';
import { useEffect, useState, type FormEvent } from 'react';
import { db } from '../db/database';
import type { Homework, HomeworkStatus } from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import { toDateKey } from '../utils/date';
import { createId } from '../utils/id';
import { ConfirmDialog } from './ConfirmDialog';

interface HomeworkFormModalProps {
  open: boolean;
  homework: Homework | null;
  courseId: string;
  defaultSessionId?: string;
  defaultAssignedDate?: string;
  onClose: () => void;
}

export const HOMEWORK_STATUS_OPTIONS: Array<{
  value: HomeworkStatus;
  label: string;
}> = [
  { value: 'uncollected', label: '未收' },
  { value: 'collected', label: '收齊' },
  { value: 'graded', label: '已批改' },
];

export function HomeworkFormModal({
  open,
  homework,
  courseId,
  defaultSessionId,
  defaultAssignedDate,
  onClose,
}: HomeworkFormModalProps) {
  const [title, setTitle] = useState('');
  const [assignedDate, setAssignedDate] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [status, setStatus] = useState<HomeworkStatus>('uncollected');
  const [note, setNote] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);
  const [initialSnapshot, setInitialSnapshot] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;

    if (homework) {
      setTitle(homework.title);
      setAssignedDate(homework.assignedDate);
      setDueDate(homework.dueDate ?? '');
      setStatus(homework.status);
      setNote(homework.note ?? '');
      setInitialSnapshot(
        JSON.stringify({
          title: homework.title,
          assignedDate: homework.assignedDate,
          dueDate: homework.dueDate ?? '',
          status: homework.status,
          note: homework.note ?? '',
        })
      );
    } else {
      const initAssigned = defaultAssignedDate || toDateKey(new Date());
      setTitle('');
      setAssignedDate(initAssigned);
      setDueDate('');
      setStatus('uncollected');
      setNote('');
      setInitialSnapshot(
        JSON.stringify({
          title: '',
          assignedDate: initAssigned,
          dueDate: '',
          status: 'uncollected',
          note: '',
        })
      );
    }
    setError(null);
    setDeleteConfirmOpen(false);
    setDiscardConfirmOpen(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, homework?.id]);

  const isDirty =
    initialSnapshot !== null &&
    JSON.stringify({ title, assignedDate, dueDate, status, note }) !==
      initialSnapshot;

  const handleRequestClose = () => {
    if (isSaving) return;
    if (isDirty) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: open,
    zLayer: 60,
    onBack: handleRequestClose,
  });

  if (!open) {
    return null;
  }

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const trimmedTitle = title.trim();
    if (!trimmedTitle) {
      setError('請輸入作業名稱');
      return;
    }
    if (!assignedDate) {
      setError('請選擇派出日');
      return;
    }
    if (dueDate && dueDate < assignedDate) {
      setError('繳交日不可早於派出日');
      return;
    }

    setIsSaving(true);
    try {
      const now = Date.now();
      const record: Homework = {
        id: homework?.id ?? createId(),
        courseId: homework?.courseId ?? courseId,
        sessionId: homework?.sessionId ?? defaultSessionId,
        title: trimmedTitle,
        assignedDate,
        dueDate: dueDate || undefined,
        status,
        note: note.trim() || undefined,
        createdAt: homework?.createdAt ?? now,
        updatedAt: now,
      };
      await db.homeworks.put(record);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!homework) return;
    setIsSaving(true);
    try {
      await db.homeworks.delete(homework.id);
      setDeleteConfirmOpen(false);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="homework-modal-title"
        className="fixed inset-0 z-[60] flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
      >
        <div className="flex max-h-[90dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 px-4 py-3">
            <h2
              id="homework-modal-title"
              className="text-base font-semibold text-zinc-900"
            >
              {homework ? '編輯作業' : '新增作業'}
            </h2>
            <button
              type="button"
              onClick={handleRequestClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
            >
              <X size={20} />
            </button>
          </div>

          <form
            onSubmit={(e) => void handleSubmit(e)}
            noValidate
            className="flex min-h-0 flex-1 flex-col"
          >
            <div className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-4">
              <div>
                <label
                  htmlFor="homework-title-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  作業名稱 <span className="text-rose-600">*</span>
                </label>
                <input
                  id="homework-title-input"
                  type="text"
                  value={title}
                  onChange={(e) => {
                    setTitle(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="例如：講義第 3 章習題 1–20 題"
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="min-w-0">
                  <label
                    htmlFor="homework-assigned-input"
                    className="block text-sm font-medium text-zinc-800"
                  >
                    派出日 <span className="text-rose-600">*</span>
                  </label>
                  <input
                    id="homework-assigned-input"
                    type="date"
                    value={assignedDate}
                    onChange={(e) => {
                      setAssignedDate(e.target.value);
                      if (error) setError(null);
                    }}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>

                <div className="min-w-0">
                  <label
                    htmlFor="homework-due-input"
                    className="block text-sm font-medium text-zinc-800"
                  >
                    繳交日（選填）
                  </label>
                  <input
                    id="homework-due-input"
                    type="date"
                    value={dueDate}
                    onChange={(e) => {
                      setDueDate(e.target.value);
                      if (error) setError(null);
                    }}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>
              </div>

              <div>
                <span className="block text-sm font-medium text-zinc-800">
                  狀態
                </span>
                <div className="mt-1.5 grid grid-cols-3 gap-2">
                  {HOMEWORK_STATUS_OPTIONS.map((opt) => {
                    const active = status === opt.value;
                    return (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => setStatus(opt.value)}
                        className={`flex min-h-[44px] items-center justify-center rounded-xl border text-sm font-medium transition-colors ${
                          active
                            ? 'border-2 border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                            : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                        }`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label
                  htmlFor="homework-note-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  備註（選填）
                </label>
                <textarea
                  id="homework-note-input"
                  rows={3}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="缺交同學名單、訂正要求或批改說明"
                  className="mt-1.5 w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              {error && (
                <p role="alert" className="text-xs font-medium text-rose-600">
                  {error}
                </p>
              )}

              {homework && (
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => setDeleteConfirmOpen(true)}
                    disabled={isSaving}
                    className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl border border-rose-200 bg-white px-4 py-2.5 text-sm font-medium text-rose-600 transition-colors hover:bg-rose-50 disabled:opacity-60"
                  >
                    <Trash2 size={16} aria-hidden="true" />
                    <span>刪除此作業</span>
                  </button>
                </div>
              )}
            </div>

            <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
              <button
                type="submit"
                disabled={isSaving}
                className="flex min-h-[44px] w-full items-center justify-center rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-violet-700 disabled:opacity-60"
              >
                {isSaving ? '儲存中…' : homework ? '儲存變更' : '建立作業'}
              </button>
            </div>
          </form>
        </div>
      </div>

      <ConfirmDialog
        open={deleteConfirmOpen}
        title="刪除作業"
        description={
          homework ? `確定要刪除作業「${homework.title}」嗎？` : ''
        }
        confirmLabel="確認刪除"
        isSubmitting={isSaving}
        onCancel={() => setDeleteConfirmOpen(false)}
        onConfirm={() => {
          void handleConfirmDelete();
        }}
      />

      <ConfirmDialog
        open={discardConfirmOpen}
        title="放棄未儲存的內容？"
        description="目前有尚未儲存的修改，確定要放棄並返回嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardConfirmOpen(false)}
        onConfirm={() => {
          setDiscardConfirmOpen(false);
          onClose();
        }}
      />
    </>
  );
}
