import { Clock } from 'lucide-react';
import { useId } from 'react';

export const DURATION_PRESETS = [
  { minutes: 45, label: '45 分' },
  { minutes: 50, label: '50 分' },
  { minutes: 120, label: '2 小時' },
  { minutes: 180, label: '3 小時' },
] as const;

interface DurationSelectorProps {
  label?: string;
  activeMinutes: number | null;
  customValue: string;
  customPlaceholder?: string;
  onSelectPreset: (minutes: number) => void;
  onCustomChange: (value: string) => void;
}

export function DurationSelector({
  label = '快捷時長',
  activeMinutes,
  customValue,
  customPlaceholder = '輸入分鐘數',
  onSelectPreset,
  onCustomChange,
}: DurationSelectorProps) {
  const inputId = useId();

  return (
    <div className="space-y-2">
      {label && (
        <span className="flex items-center gap-1 text-xs font-medium text-zinc-600">
          <Clock size={12} aria-hidden="true" />
          <span>{label}</span>
        </span>
      )}

      <div className="grid grid-cols-4 gap-1.5">
        {DURATION_PRESETS.map((preset) => {
          const isSelected = activeMinutes === preset.minutes;
          return (
            <button
              key={preset.minutes}
              type="button"
              aria-pressed={isSelected}
              onClick={() => onSelectPreset(preset.minutes)}
              className={`flex min-h-[44px] items-center justify-center rounded-xl px-1.5 text-[13px] tabular-nums transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 ${
                isSelected
                  ? 'border-2 border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                  : 'border border-zinc-200 bg-white font-medium text-zinc-700 hover:bg-zinc-50'
              }`}
            >
              {preset.label}
            </button>
          );
        })}
      </div>

      <div className="flex items-center gap-2">
        <label
          htmlFor={inputId}
          className="shrink-0 text-xs font-medium text-zinc-600"
        >
          自訂
        </label>
        <input
          id={inputId}
          type="number"
          min={1}
          max={720}
          inputMode="numeric"
          pattern="[0-9]*"
          value={customValue}
          onChange={(e) => onCustomChange(e.target.value)}
          placeholder={customPlaceholder}
          className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 placeholder:text-zinc-400 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
        />
        <span className="shrink-0 text-xs text-zinc-500">分鐘</span>
      </div>
    </div>
  );
}
