import { useMemo } from 'react';
import type {
  ClassSession,
  Course,
  Exam,
  ExamPeriod,
  Homework,
  Organization,
  TaskItem,
  WeekGridDays,
} from '../db/types';
import {
  formatSlashDate,
  timeToMinutes,
  toDateKey,
  WEEKDAY_LABELS,
} from '../utils/date';
import {
  getExamDisplayTitle,
  type SessionCountdown,
} from '../utils/examCountdown';
import {
  computeWeekGridHours,
  isLightHexColor,
  layoutDaySessionsForGrid,
} from '../utils/scheduleGrid';
import {
  isSessionCancelled,
  isSubstituteSession,
  resolveSessionDisplay,
} from '../utils/sessionDisplay';
import { hasSessionEnded, type PlacedTaskEntry } from '../utils/taskPlacement';
import { SessionMenuButton } from './SessionQuickActions';
import { SubstituteBadge } from './SubstituteBadge';

interface WeekScheduleGridProps {
  daysCount: WeekGridDays;
  displayDates: Date[];
  sessions: ClassSession[];
  courseMap: Map<string, Course>;
  orgMap: Map<string, Organization>;
  tasksBySessionId: Record<string, PlacedTaskEntry[]>;
  otherTasksByDate: Record<string, TaskItem[]>;
  homeworksByCourseDate: Map<string, Homework[]>;
  examsByCourseDate: Map<string, Exam[]>;
  examPeriods?: ExamPeriod[];
  countdownBySessionId?: Record<string, SessionCountdown>;
  onSelectSession: (session: ClassSession) => void;
  onSelectExamPeriod?: (period: ExamPeriod) => void;
  onOpenSessionMenu?: (session: ClassSession) => void;
  onSwitchToDayView: (dateKey: string) => void;
  onOpenUnattachedDate: (dateKey: string) => void;
}

interface BlockTagChip {
  key: string;
  label: string;
  bgClass: string;
}

export function WeekScheduleGrid({
  daysCount,
  displayDates,
  sessions,
  courseMap,
  orgMap,
  tasksBySessionId,
  otherTasksByDate,
  homeworksByCourseDate,
  examsByCourseDate,
  examPeriods = [],
  countdownBySessionId = {},
  onSelectSession,
  onSelectExamPeriod,
  onOpenSessionMenu,
  onSwitchToDayView,
  onOpenUnattachedDate,
}: WeekScheduleGridProps) {
  const now = new Date();
  const todayKey = toDateKey(now);

  const organizationsList = useMemo(
    () => Array.from(orgMap.values()),
    [orgMap]
  );

  const pixelsPerHour = daysCount === 7 ? 64 : daysCount === 3 ? 90 : 104;

  const { startHour, endHour } = useMemo(
    () => computeWeekGridHours(sessions),
    [sessions]
  );

  const hours = useMemo(() => {
    const list: number[] = [];
    for (let h = startHour; h < endHour; h += 1) {
      list.push(h);
    }
    return list;
  }, [startHour, endHour]);

  const gridStartMinutes = startHour * 60;
  const totalHeightPx = (endHour - startHour) * pixelsPerHour;

  const sessionsByDate = useMemo(() => {
    const map = new Map<string, ClassSession[]>();
    for (const d of displayDates) {
      map.set(toDateKey(d), []);
    }
    for (const s of sessions) {
      const arr = map.get(s.date);
      if (arr) {
        arr.push(s);
      }
    }
    return map;
  }, [displayDates, sessions]);

  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  const showNowLine =
    nowMinutes >= gridStartMinutes && nowMinutes <= endHour * 60;
  const nowTopPx = ((nowMinutes - gridStartMinutes) / 60) * pixelsPerHour;

  const gridColsClass =
    daysCount === 1
      ? 'grid-cols-1'
      : daysCount === 3
        ? 'grid-cols-3'
        : 'grid-cols-7';

  return (
    <div className="space-y-2">
      <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white">
        <div className="overflow-x-auto overscroll-x-contain">
          <div className={daysCount === 7 ? 'min-w-[560px] w-full' : 'w-full'}>
            {/* 橫軸：星期列 */}
            <div className="flex border-b border-zinc-200 bg-zinc-50/80">
              <div className="sticky left-0 z-20 flex w-12 shrink-0 items-center justify-center border-r border-zinc-200 bg-zinc-50 px-1 py-2 text-[11px] font-medium text-zinc-500">
                時間
              </div>
              <div className={`grid flex-1 ${gridColsClass}`}>
                {displayDates.map((date) => {
                  const dateKey = toDateKey(date);
                  const isToday = dateKey === todayKey;
                  const weekdayShort = WEEKDAY_LABELS[date.getDay()].replace(
                    '週',
                    ''
                  );
                  const unattachedList = otherTasksByDate[dateKey] ?? [];
                  const hasUnattached = unattachedList.length > 0;
                  const dayExamPeriods = examPeriods.filter(
                    (p) => p.startDate <= dateKey && dateKey <= p.endDate
                  );
                  const visibleExamBars = dayExamPeriods.slice(0, 2);
                  const extraExamCount = Math.max(
                    0,
                    dayExamPeriods.length - visibleExamBars.length
                  );

                  return (
                    <div
                      key={dateKey}
                      className={`flex flex-col items-center justify-between border-l border-zinc-100 py-1.5 text-center first:border-l-0 ${
                        isToday ? 'bg-[#F2ECFF]/85' : ''
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => onSwitchToDayView(dateKey)}
                        aria-label={`切換為 ${formatSlashDate(dateKey)} 單日檢視`}
                        className="flex min-h-[36px] w-full flex-col items-center justify-center rounded-lg px-1 py-0.5 transition-colors hover:bg-black/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-violet-600"
                      >
                        <span
                          className={`text-xs font-semibold ${
                            isToday ? 'text-violet-900' : 'text-zinc-800'
                          }`}
                        >
                          週{weekdayShort}
                        </span>
                        <span
                          className={`mt-0.5 text-[11px] tabular-nums ${
                            isToday
                              ? 'font-semibold text-violet-700'
                              : 'text-zinc-500'
                          }`}
                        >
                          {formatSlashDate(dateKey)}
                        </span>
                      </button>

                      {visibleExamBars.length > 0 && (
                        <div className="mt-1 flex w-full flex-col gap-0.5 px-1">
                          {visibleExamBars.map((period) => {
                            const org = period.organizationId
                              ? orgMap.get(period.organizationId)
                              : undefined;
                            const barBg = org?.color ?? '#CDB8FF';
                            const barDarkText = isLightHexColor(barBg);
                            const displayTitle = getExamDisplayTitle(
                              period,
                              organizationsList
                            );
                            const barTitle = org
                              ? `${org.name} ${displayTitle}`
                              : displayTitle;

                            return (
                              <button
                                key={period.id}
                                type="button"
                                onClick={() => onSelectExamPeriod?.(period)}
                                title={barTitle}
                                aria-label={`考試期間：${barTitle}`}
                                style={{ backgroundColor: barBg }}
                                className={`w-full ring-1 ring-inset ring-black/10 transition-opacity hover:opacity-85 ${
                                  daysCount === 7
                                    ? 'h-2 rounded-sm'
                                    : `truncate rounded-md px-1.5 py-0.5 text-left text-[10px] font-semibold leading-tight ${
                                        barDarkText
                                          ? 'text-zinc-900'
                                          : 'text-white'
                                      }`
                                }`}
                              >
                                {daysCount !== 7 ? barTitle : null}
                              </button>
                            );
                          })}
                          {extraExamCount > 0 && (
                            <button
                              type="button"
                              onClick={() =>
                                onSelectExamPeriod?.(dayExamPeriods[2])
                              }
                              className="w-full rounded bg-zinc-200/80 px-1 text-center text-[9px] font-semibold text-zinc-700 tabular-nums hover:bg-zinc-300/80"
                            >
                              +{extraExamCount}
                            </button>
                          )}
                        </div>
                      )}

                      {hasUnattached && (
                        <button
                          type="button"
                          onClick={() => onOpenUnattachedDate(dateKey)}
                          aria-label={`${formatSlashDate(dateKey)} 有 ${unattachedList.length} 筆其他任務`}
                          className="mt-0.5 inline-flex min-h-[24px] items-center gap-1 rounded-full bg-violet-100/90 px-2 py-0.5 text-[10px] font-semibold text-violet-800 transition-colors hover:bg-violet-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
                        >
                          <span
                            aria-hidden="true"
                            className="h-2 w-2 rounded-full bg-violet-600"
                          />
                          {daysCount !== 7 && (
                            <span className="tabular-nums">
                              其他 {unattachedList.length}
                            </span>
                          )}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 縱軸：時間刻度 + 每日實際時段方塊 */}
            <div
              className="relative flex"
              style={{ height: `${totalHeightPx}px` }}
            >
              <div
                aria-hidden="true"
                className="sticky left-0 z-20 w-12 shrink-0 border-r border-zinc-200 bg-white"
              >
                {hours.map((hour) => (
                  <div
                    key={hour}
                    style={{ height: `${pixelsPerHour}px` }}
                    className="relative border-t border-zinc-100 first:border-t-0"
                  >
                    <span className="absolute -top-2 right-1.5 bg-white px-0.5 text-[10px] font-medium text-zinc-400 tabular-nums">
                      {String(hour).padStart(2, '0')}:00
                    </span>
                  </div>
                ))}
              </div>

              <div className={`relative grid flex-1 ${gridColsClass}`}>
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-0"
                >
                  {hours.map((hour) => (
                    <div
                      key={hour}
                      style={{ height: `${pixelsPerHour}px` }}
                      className="relative border-t border-zinc-100 first:border-t-0"
                    >
                      <div
                        style={{ top: `${pixelsPerHour / 2}px` }}
                        className="absolute inset-x-0 border-t border-dashed border-zinc-100/80"
                      />
                    </div>
                  ))}
                </div>

                {displayDates.map((date) => {
                  const dateKey = toDateKey(date);
                  const isToday = dateKey === todayKey;
                  const daySessions = sessionsByDate.get(dateKey) ?? [];
                  const positioned = layoutDaySessionsForGrid(daySessions);

                  return (
                    <div
                      key={dateKey}
                      className={`relative h-full border-l border-zinc-100 first:border-l-0 ${
                        isToday ? 'bg-[#FAF7FF]/60' : ''
                      }`}
                    >
                      {isToday && showNowLine && (
                        <div
                          aria-hidden="true"
                          style={{ top: `${nowTopPx}px` }}
                          className="pointer-events-none absolute inset-x-0 z-10 border-t-2 border-violet-600/75"
                        />
                      )}

                      {positioned.map((item) => {
                        const { session } = item;
                        const resolved = resolveSessionDisplay(
                          session,
                          courseMap,
                          orgMap
                        );

                        const startMin = timeToMinutes(session.startTime);
                        const endMin = Math.max(
                          startMin + 15,
                          timeToMinutes(session.endTime)
                        );
                        const topPx =
                          ((startMin - gridStartMinutes) / 60) * pixelsPerHour;
                        const rawHeightPx =
                          ((endMin - startMin) / 60) * pixelsPerHour;
                        const blockHeightPx = Math.max(
                          daysCount === 7 ? 28 : 36,
                          rawHeightPx - 2
                        );

                        const leftPct = (item.laneIndex / item.laneCount) * 100;
                        const widthPct = 100 / item.laneCount;

                        const isCancelled = isSessionCancelled(session);
                        const blockBg =
                          resolved.isSubstitute && !resolved.organization
                            ? '#FEF3C7'
                            : resolved.color;
                        const useDarkText = isCancelled
                          ? true
                          : isLightHexColor(blockBg);

                        const displayName = resolved.title;
                        const orgName =
                          resolved.organization?.name ??
                          (resolved.isSubstitute ? '未指定單位' : '');

                        const progressText = session.progress?.trim() ?? '';
                        const hasProgress = Boolean(progressText);
                        const ended = hasSessionEnded(session, now);

                        // 只在格狀圖顯示未打勾的待辦與提醒
                        const activeTasks = (
                          tasksBySessionId[session.id] ?? []
                        ).filter((entry) => !entry.task.done);
                        const activeTodos = activeTasks.filter(
                          (entry) => entry.task.type === 'todo'
                        );
                        const activeReminders = activeTasks.filter(
                          (entry) => entry.task.type === 'reminder'
                        );

                        const courseDateKey =
                          !isSubstituteSession(session) &&
                          !isCancelled &&
                          session.courseId
                            ? `${session.courseId}__${session.date}`
                            : '';
                        const dueHomeworks = courseDateKey
                          ? (homeworksByCourseDate.get(courseDateKey) ?? [])
                          : [];
                        const dayExams = courseDateKey
                          ? (examsByCourseDate.get(courseDateKey) ?? [])
                          : [];

                        const countdown = !isCancelled
                          ? countdownBySessionId[session.id]
                          : undefined;

                        if (daysCount === 7) {
                          const dotItems: Array<{
                            key: string;
                            colorClass: string;
                            label: string;
                          }> = [];
                          if (!isCancelled) {
                            if (hasProgress) {
                              dotItems.push({
                                key: 'progress',
                                colorClass: 'bg-sky-500 ring-white/80',
                                label: '已記錄進度',
                              });
                            }
                            if (activeTodos.length > 0) {
                              dotItems.push({
                                key: 'todo',
                                colorClass: 'bg-violet-600 ring-white/80',
                                label: `待辦 ${activeTodos.length} 項`,
                              });
                            }
                            if (activeReminders.length > 0) {
                              dotItems.push({
                                key: 'reminder',
                                colorClass: 'bg-amber-400 ring-white/80',
                                label: `提醒 ${activeReminders.length} 項`,
                              });
                            }
                            if (dueHomeworks.length > 0) {
                              dotItems.push({
                                key: 'homework',
                                colorClass: 'bg-emerald-500 ring-white/80',
                                label: `作業繳交 ${dueHomeworks.length} 項`,
                              });
                            }
                            if (dayExams.length > 0) {
                              dotItems.push({
                                key: 'exam',
                                colorClass: 'bg-pink-500 ring-white/80',
                                label: `考試 ${dayExams.length} 項`,
                              });
                            }
                          }

                          return (
                            <div
                              key={session.id}
                              style={{
                                top: `${topPx + 1}px`,
                                height: `${blockHeightPx}px`,
                                left: `calc(${leftPct}% + 1px)`,
                                width: `calc(${widthPct}% - 2px)`,
                                backgroundColor: isCancelled
                                  ? undefined
                                  : blockBg,
                                color: isCancelled
                                  ? undefined
                                  : useDarkText
                                    ? '#18181b'
                                    : '#ffffff',
                              }}
                              className={`absolute z-10 overflow-hidden rounded-lg transition-opacity ${
                                isCancelled
                                  ? 'border border-dashed border-zinc-300 bg-zinc-100/95 text-zinc-500'
                                  : resolved.isSubstitute && !resolved.organization
                                    ? 'ring-1 ring-inset ring-amber-300'
                                    : 'ring-1 ring-inset ring-black/15'
                              }`}
                            >
                              <button
                                type="button"
                                onClick={() => onSelectSession(session)}
                                aria-label={`${displayName} ${session.startTime}–${session.endTime}${
                                  countdown
                                    ? countdown.isLast
                                      ? `（${countdown.title}考前最後一堂）`
                                      : `（${countdown.title}倒數 ${countdown.sessionsLeft} 堂）`
                                    : ''
                                }${
                                  dotItems.length > 0
                                    ? `（${dotItems.map((d) => d.label).join('、')}）`
                                    : ''
                                }`}
                                className="relative flex h-full w-full flex-col justify-between overflow-hidden rounded-lg p-1 text-left hover:opacity-90 focus-visible:z-30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-violet-700"
                              >
                                <span
                                  className={`text-[11px] font-semibold leading-tight ${
                                    countdown ? 'pr-4' : ''
                                  } ${
                                    blockHeightPx < 48
                                      ? 'truncate'
                                      : 'line-clamp-2'
                                  } ${isCancelled ? 'line-through' : ''}`}
                                >
                                  {displayName}
                                </span>

                                {countdown && (
                                  <span
                                    aria-hidden="true"
                                    className={`pointer-events-none absolute right-0.5 top-0.5 flex h-4 min-w-[16px] items-center justify-center rounded-full px-1 text-[9px] font-bold leading-none tabular-nums shadow-xs ${
                                      countdown.isLast
                                        ? 'bg-pink-500 text-white'
                                        : 'bg-amber-400 text-zinc-950'
                                    }`}
                                  >
                                    {countdown.isLast
                                      ? '!'
                                      : countdown.sessionsLeft}
                                  </span>
                                )}

                                {dotItems.length > 0 && (
                                  <span
                                    aria-hidden="true"
                                    className="mt-0.5 flex flex-wrap items-center gap-1"
                                  >
                                    {dotItems.map((dot) => (
                                      <span
                                        key={dot.key}
                                        className={`h-2 w-2 rounded-full ring-1 ${dot.colorClass}`}
                                      />
                                    ))}
                                  </span>
                                )}
                              </button>
                            </div>
                          );
                        }

                        // 1 天 / 3 天模式：顯示班級、單位、進度（已結束且無進度顯示「尚未記錄」）、以及底部彩色標籤（考前倒數排在最前面）
                        const tags: BlockTagChip[] = [];
                        if (!isCancelled) {
                          if (countdown) {
                            tags.push({
                              key: `cd-${countdown.examPeriodId}`,
                              label: countdown.isLast
                                ? '最後一堂'
                                : `倒數 ${countdown.sessionsLeft}`,
                              bgClass: countdown.isLast
                                ? 'bg-[#FCE7F3] text-pink-900 font-bold'
                                : 'bg-[#FFEDD5] text-orange-950 font-semibold',
                            });
                          }
                          for (const entry of activeTodos) {
                            tags.push({
                              key: `t-${entry.task.id}`,
                              label: entry.task.title,
                              bgClass: 'bg-[#EDE6FF] text-violet-950',
                            });
                          }
                          for (const entry of activeReminders) {
                            tags.push({
                              key: `r-${entry.task.id}`,
                              label: entry.task.title,
                              bgClass: 'bg-[#FEF3C7] text-amber-950',
                            });
                          }
                          for (const hw of dueHomeworks) {
                            tags.push({
                              key: `h-${hw.id}`,
                              label: `作業：${hw.title}`,
                              bgClass: 'bg-[#DCFCE7] text-emerald-950',
                            });
                          }
                          for (const ex of dayExams) {
                            tags.push({
                              key: `e-${ex.id}`,
                              label: `考試：${ex.title}`,
                              bgClass: 'bg-[#FCE7F3] text-pink-950',
                            });
                          }
                        }

                        const maxTags =
                          blockHeightPx < 46
                            ? 0
                            : blockHeightPx < 80
                              ? daysCount === 1
                                ? 2
                                : 1
                              : daysCount === 1
                                ? 4
                                : 2;
                        const visibleTags = tags.slice(0, maxTags);
                        const overflowCount = Math.max(
                          0,
                          tags.length - visibleTags.length
                        );

                        return (
                          <div
                            key={session.id}
                            style={{
                              top: `${topPx + 1}px`,
                              height: `${blockHeightPx}px`,
                              left: `calc(${leftPct}% + 2px)`,
                              width: `calc(${widthPct}% - 4px)`,
                              backgroundColor: isCancelled
                                ? undefined
                                : blockBg,
                              color: isCancelled
                                ? undefined
                                : useDarkText
                                  ? '#18181b'
                                  : '#ffffff',
                            }}
                            className={`absolute z-10 overflow-hidden rounded-xl transition-opacity ${
                              isCancelled
                                ? 'border border-dashed border-zinc-300 bg-zinc-100/95 text-zinc-500'
                                : resolved.isSubstitute && !resolved.organization
                                  ? 'ring-1 ring-inset ring-amber-300'
                                  : 'ring-1 ring-inset ring-black/15'
                            }`}
                          >
                            <button
                              type="button"
                              onClick={() => onSelectSession(session)}
                              aria-label={`${displayName}${orgName ? `（${orgName}）` : ''} ${session.startTime}–${session.endTime}`}
                              className={`flex h-full w-full flex-col overflow-hidden rounded-xl p-1.5 text-left hover:opacity-90 focus-visible:z-30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-violet-700 ${
                                onOpenSessionMenu ? 'pr-7' : ''
                              }`}
                            >
                              <div className="flex min-w-0 items-baseline gap-1.5">
                                <span
                                  className={`truncate text-xs font-bold leading-tight ${
                                    isCancelled ? 'line-through' : ''
                                  }`}
                                >
                                  {displayName}
                                </span>
                                {daysCount === 1 && (
                                  <span className="shrink-0 text-[10px] tabular-nums opacity-80">
                                    {session.startTime}–{session.endTime}
                                  </span>
                                )}
                              </div>

                              {(orgName || resolved.isSubstitute) &&
                                blockHeightPx >= 40 && (
                                  <div className="mt-0.5 flex flex-wrap items-center gap-1 text-[10px] leading-tight">
                                    {orgName && (
                                      <span className="truncate opacity-85">
                                        {orgName}
                                      </span>
                                    )}
                                    {resolved.isSubstitute && (
                                      <SubstituteBadge compact />
                                    )}
                                  </div>
                                )}

                              {!isCancelled &&
                                blockHeightPx >= 56 &&
                                (hasProgress ? (
                                  <p className="mt-0.5 truncate text-[10px] font-medium opacity-90">
                                    進度：{progressText}
                                  </p>
                                ) : ended ? (
                                  <p className="mt-0.5 truncate text-[10px] italic opacity-65">
                                    尚未記錄
                                  </p>
                                ) : null)}

                              {tags.length > 0 && blockHeightPx >= 46 && (
                                <div className="mt-auto flex flex-wrap items-center gap-1 pt-1">
                                  {visibleTags.map((tag) => (
                                    <span
                                      key={tag.key}
                                      className={`max-w-full truncate rounded-md px-1.5 py-0.5 text-[10px] font-medium leading-none shadow-xs ${tag.bgClass}`}
                                    >
                                      {tag.label}
                                    </span>
                                  ))}
                                  {overflowCount > 0 && (
                                    <span className="rounded-md bg-white/90 px-1.5 py-0.5 text-[10px] font-semibold leading-none text-zinc-700 tabular-nums">
                                      +{overflowCount}
                                    </span>
                                  )}
                                </div>
                              )}
                            </button>

                            {onOpenSessionMenu && (
                              <SessionMenuButton
                                compact
                                onClick={() => onOpenSessionMenu(session)}
                                ariaLabel={`更多操作：${displayName}`}
                                className={`absolute right-0.5 top-0.5 z-20 ${
                                  useDarkText
                                    ? 'text-zinc-700/80 hover:bg-black/10 hover:text-zinc-900'
                                    : 'text-white/85 hover:bg-white/20 hover:text-white'
                                }`}
                              />
                            )}
                          </div>
                        );
                      })}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {daysCount === 7 && (
        <div
          aria-label="格狀圖標記圖例"
          className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 px-2 text-[11px] text-zinc-500"
        >
          <span className="inline-flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-sky-500" aria-hidden="true" />
            <span>進度</span>
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-violet-600" aria-hidden="true" />
            <span>待辦</span>
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-amber-400" aria-hidden="true" />
            <span>提醒</span>
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-emerald-500" aria-hidden="true" />
            <span>作業</span>
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-pink-500" aria-hidden="true" />
            <span>考試</span>
          </span>
        </div>
      )}
    </div>
  );
}
