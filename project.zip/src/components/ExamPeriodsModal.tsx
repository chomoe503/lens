import { CalendarRange, ChevronDown, ChevronLeft, Layers, Plus } from 'lucide-react';
import { useMemo, useState } from 'react';
import { db } from '../db/database';
import type {
  AcademicYear,
  ClassSession,
  Course,
  ExamPeriod,
  Organization,
} from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import { formatSlashDateWithWeekday, toDateKey } from '../utils/date';
import {
  computeCourseCountdownRows,
  diffDateKeys,
  EXAM_KIND_LABELS,
  getExamDisplayTitle,
  getExamPeriodStatus,
  getExamTargetDate,
} from '../utils/examCountdown';
import { useLiveQuery } from '../utils/useLiveQuery';
import { BatchExamPeriodsModal } from './BatchExamPeriodsModal';
import { ExamPeriodFormModal } from './ExamPeriodFormModal';

interface ExamPeriodsModalProps {
  open: boolean;
  onClose: () => void;
}

export function ExamPeriodsModal({ open, onClose }: ExamPeriodsModalProps) {
  const examPeriods = useLiveQuery(
    async (): Promise<ExamPeriod[]> =>
      open ? db.examPeriods.toArray() : [],
    [open]
  );
  const organizations = useLiveQuery(
    async (): Promise<Organization[]> =>
      open ? db.organizations.orderBy('createdAt').toArray() : [],
    [open]
  );
  const courses = useLiveQuery(
    async (): Promise<Course[]> => (open ? db.courses.toArray() : []),
    [open]
  );
  const sessions = useLiveQuery(
    async (): Promise<ClassSession[]> => (open ? db.sessions.toArray() : []),
    [open]
  );
  const academicYears = useLiveQuery(
    async (): Promise<AcademicYear[]> =>
      open ? db.academicYears.orderBy('startDate').reverse().toArray() : [],
    [open]
  );

  const [formOpen, setFormOpen] = useState(false);
  const [editingPeriod, setEditingPeriod] = useState<ExamPeriod | null>(null);
  const [batchOpen, setBatchOpen] = useState(false);
  const [endedExpanded, setEndedExpanded] = useState(false);
  const [expandedCourseCardIds, setExpandedCourseCardIds] = useState<
    Record<string, boolean>
  >({});

  useBackLayer({
    active: open,
    zLayer: 40,
    onBack: onClose,
  });

  const now = new Date();
  const todayKey = toDateKey(now);

  const orgMap = useMemo(() => {
    const map = new Map<string, Organization>();
    for (const o of organizations ?? []) map.set(o.id, o);
    return map;
  }, [organizations]);

  const courseMap = useMemo(() => {
    const map = new Map<string, Course>();
    for (const c of courses ?? []) map.set(c.id, c);
    return map;
  }, [courses]);

  const sections = useMemo(() => {
    const ongoing: ExamPeriod[] = [];
    const upcoming: ExamPeriod[] = [];
    const ended: ExamPeriod[] = [];

    for (const period of examPeriods ?? []) {
      const status = getExamPeriodStatus(period, todayKey);
      if (status === 'ongoing') {
        ongoing.push(period);
      } else if (status === 'upcoming') {
        upcoming.push(period);
      } else {
        ended.push(period);
      }
    }

    ongoing.sort((a, b) => a.startDate.localeCompare(b.startDate));
    upcoming.sort((a, b) => a.startDate.localeCompare(b.startDate));
    ended.sort((a, b) => {
      const endDiff = b.endDate.localeCompare(a.endDate);
      if (endDiff !== 0) return endDiff;
      return b.startDate.localeCompare(a.startDate);
    });

    return { ongoing, upcoming, ended };
  }, [examPeriods, todayKey]);

  if (!open) return null;

  const isLoading =
    examPeriods === undefined ||
    organizations === undefined ||
    courses === undefined ||
    sessions === undefined ||
    academicYears === undefined;

  const toggleCardExpand = (periodId: string) => {
    setExpandedCourseCardIds((prev) => ({
      ...prev,
      [periodId]: !prev[periodId],
    }));
  };

  const renderPeriodCard = (period: ExamPeriod, isEnded: boolean) => {
    const org = period.organizationId
      ? orgMap.get(period.organizationId)
      : undefined;
    const school =
      org && period.studentSchoolId
        ? org.studentSchools?.find((s) => s.id === period.studentSchoolId)
        : undefined;
    const displayTitle = getExamDisplayTitle(period, organizations ?? []);
    const orgDisplay = org
      ? school
        ? `${org.name}・${school.name}`
        : org.name
      : '不指定單位（跨校）';
    const dotColor = org?.color ?? '#CDB8FF';
    const targetDate = getExamTargetDate(period);
    const status = getExamPeriodStatus(period, todayKey);
    const daysLeft = diffDateKeys(todayKey, targetDate);

    const statusLabel =
      status === 'ended'
        ? '已結束'
        : status === 'ongoing'
          ? '進行中'
          : `還有 ${Math.max(0, daysLeft)} 天`;

    const statusBadgeClass =
      status === 'ended'
        ? 'bg-zinc-100 text-zinc-500'
        : status === 'ongoing'
          ? 'bg-[#FCE7F3] text-pink-900 font-semibold'
          : 'bg-[#EDE6FF] text-violet-950 font-semibold';

    const dateRangeText =
      period.startDate === period.endDate
        ? formatSlashDateWithWeekday(period.startDate)
        : `${formatSlashDateWithWeekday(period.startDate)}–${formatSlashDateWithWeekday(
            period.endDate
          )}`;

    const courseRows = isEnded
      ? []
      : computeCourseCountdownRows({
          period,
          sessions: sessions ?? [],
          courses: courses ?? [],
          now,
        });

    const isExpanded = Boolean(expandedCourseCardIds[period.id]);
    const shouldCollapseCourses = courseRows.length > 4 && !isExpanded;
    const visibleCourseRows = shouldCollapseCourses
      ? courseRows.slice(0, 3)
      : courseRows;

    return (
      <div
        key={period.id}
        className={`overflow-hidden rounded-2xl border ${
          isEnded
            ? 'border-zinc-200/80 bg-zinc-50/60'
            : 'border-zinc-200 bg-white'
        }`}
      >
        <button
          type="button"
          onClick={() => {
            setEditingPeriod(period);
            setFormOpen(true);
          }}
          className="w-full px-4 py-3.5 text-left transition-colors hover:bg-zinc-50/80 active:bg-zinc-100/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-violet-600"
        >
          <div className="flex items-start justify-between gap-2">
            <div className="flex min-w-0 flex-1 items-center gap-2">
              <span
                aria-hidden="true"
                style={{ backgroundColor: dotColor }}
                className="h-3.5 w-3.5 shrink-0 rounded-full ring-1 ring-inset ring-black/15"
              />
              <span
                className={`truncate text-base font-bold ${
                  isEnded ? 'text-zinc-600' : 'text-zinc-900'
                }`}
              >
                {displayTitle}
              </span>
              <span className="shrink-0 rounded-md bg-zinc-100 px-1.5 py-0.5 text-[11px] font-medium text-zinc-600">
                {EXAM_KIND_LABELS[period.kind]}
              </span>
            </div>

            <span
              className={`shrink-0 rounded-lg px-2 py-0.5 text-xs tabular-nums ${statusBadgeClass}`}
            >
              {statusLabel}
            </span>
          </div>

          <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 pl-[22px] text-xs text-zinc-600 tabular-nums">
            <span>{orgDisplay}</span>
            <span aria-hidden="true" className="text-zinc-300">
              ·
            </span>
            <span className="font-medium text-zinc-700">{dateRangeText}</span>
          </div>

          {period.subjectDate && (
            <p className="mt-1 pl-[22px] text-xs font-medium text-violet-800 tabular-nums">
              理化 {formatSlashDateWithWeekday(period.subjectDate)}
              {period.subjectNote ? ` ${period.subjectNote}` : ''}
            </p>
          )}

          {period.scope && (
            <p className="mt-1 truncate pl-[22px] text-xs text-zinc-500">
              範圍：{period.scope}
            </p>
          )}
        </button>

        {!isEnded && courseRows.length > 0 && (
          <div className="border-t border-zinc-100 bg-zinc-50/50 px-4 py-2.5">
            <p className="mb-1.5 text-[11px] font-semibold text-zinc-500">
              各班倒數
            </p>
            <div className="space-y-1">
              {visibleCourseRows.map((row) => {
                const course = courseMap.get(row.courseId);
                return (
                  <div
                    key={row.courseId}
                    className="flex items-center justify-between gap-2 text-xs tabular-nums"
                  >
                    <span className="truncate font-medium text-zinc-800">
                      {course?.name ?? '未知班級'}
                    </span>
                    {row.sessionsLeft === 0 ? (
                      <span className="shrink-0 text-zinc-400">沒有課了</span>
                    ) : row.sessionsLeft === 1 ? (
                      <span className="shrink-0 rounded-md bg-[#FCE7F3] px-2 py-0.5 font-semibold text-pink-800">
                        考前最後一堂
                      </span>
                    ) : (
                      <span className="shrink-0 font-medium text-zinc-700">
                        還剩 {row.sessionsLeft} 堂
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            {courseRows.length > 4 && (
              <button
                type="button"
                onClick={() => toggleCardExpand(period.id)}
                className="mt-2 flex min-h-[36px] w-full items-center justify-center rounded-xl border border-zinc-200 bg-white px-3 text-xs font-medium text-violet-700 transition-colors hover:bg-violet-50 tabular-nums"
              >
                {isExpanded ? '收合班級清單' : `展開全部 ${courseRows.length} 班`}
              </button>
            )}
          </div>
        )}
      </div>
    );
  };

  const totalCount = (examPeriods ?? []).length;

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="exam-periods-title"
        className="fixed inset-0 z-40 flex flex-col bg-[var(--bg-canvas)]"
      >
        <header className="sticky top-0 z-10 border-b border-violet-200/70 bg-white/95 backdrop-blur-md">
          <div className="mx-auto flex h-12 w-full max-w-2xl items-center justify-between gap-2 px-2">
            <button
              type="button"
              onClick={onClose}
              className="flex min-h-[44px] shrink-0 items-center gap-1 rounded-xl px-2.5 text-sm font-medium text-zinc-700 transition-colors hover:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
            >
              <ChevronLeft size={18} aria-hidden="true" />
              <span>返回</span>
            </button>

            <h2
              id="exam-periods-title"
              className="truncate text-base font-semibold text-zinc-900"
            >
              考試時程
            </h2>

            <div className="w-[68px] shrink-0" aria-hidden="true" />
          </div>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
          <div className="mx-auto w-full max-w-2xl space-y-4 px-4 py-4 pb-[calc(2rem+env(safe-area-inset-bottom)+var(--kb-inset,0px))]">
            {/* 頂部操作列 */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setEditingPeriod(null);
                  setFormOpen(true);
                }}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-3 py-2 text-sm font-semibold text-white transition-colors hover:bg-violet-700"
              >
                <Plus size={16} aria-hidden="true" />
                <span>新增考試期間</span>
              </button>
              <button
                type="button"
                onClick={() => setBatchOpen(true)}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-violet-300 bg-[#F2ECFF] px-3 py-2 text-sm font-semibold text-zinc-900 transition-colors hover:bg-[#e8ddff]"
              >
                <Layers size={15} aria-hidden="true" />
                <span>批次新增</span>
              </button>
            </div>

            {isLoading ? (
              <div className="rounded-2xl border border-zinc-200 bg-white p-8 text-center text-sm text-zinc-500">
                載入中…
              </div>
            ) : totalCount === 0 ? (
              <div className="rounded-2xl border border-zinc-200 bg-white px-5 py-10 text-center">
                <CalendarRange
                  size={24}
                  className="mx-auto text-zinc-400"
                  aria-hidden="true"
                />
                <h3 className="mt-2.5 text-base font-semibold text-zinc-900">
                  尚未建立考試期間
                </h3>
                <p className="mt-1 text-xs text-zinc-500">
                  建立各校段考、期末考或模考時程後，課表會自動計算考前倒數堂數。
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setEditingPeriod(null);
                    setFormOpen(true);
                  }}
                  className="mt-4 inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-5 text-sm font-semibold text-white transition-colors hover:bg-violet-700"
                >
                  <Plus size={16} aria-hidden="true" />
                  <span>新增</span>
                </button>
              </div>
            ) : (
              <>
                {sections.ongoing.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="px-1 text-xs font-semibold text-pink-800">
                      進行中（{sections.ongoing.length}）
                    </h3>
                    <div className="space-y-2.5">
                      {sections.ongoing.map((p) => renderPeriodCard(p, false))}
                    </div>
                  </div>
                )}

                {sections.upcoming.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="px-1 text-xs font-semibold text-zinc-600">
                      即將到來（{sections.upcoming.length}）
                    </h3>
                    <div className="space-y-2.5">
                      {sections.upcoming.map((p) => renderPeriodCard(p, false))}
                    </div>
                  </div>
                )}

                {sections.ongoing.length === 0 &&
                  sections.upcoming.length === 0 && (
                    <div className="rounded-2xl border border-zinc-200 bg-white px-5 py-6 text-center text-sm text-zinc-500">
                      目前沒有進行中或即將到來的考試期間。
                    </div>
                  )}

                {sections.ended.length > 0 && (
                  <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white">
                    <button
                      type="button"
                      aria-expanded={endedExpanded}
                      onClick={() => setEndedExpanded((prev) => !prev)}
                      className="flex min-h-[48px] w-full items-center justify-between gap-3 px-4 py-2.5 text-left transition-colors hover:bg-zinc-50"
                    >
                      <span className="text-xs font-semibold text-zinc-600 tabular-nums">
                        已結束（{sections.ended.length}）
                      </span>
                      <ChevronDown
                        size={17}
                        aria-hidden="true"
                        className={`shrink-0 text-zinc-400 transition-transform duration-150 ${
                          endedExpanded ? 'rotate-180' : ''
                        }`}
                      />
                    </button>

                    {endedExpanded && (
                      <div className="space-y-2.5 border-t border-zinc-100 p-3">
                        {sections.ended.map((p) => renderPeriodCard(p, true))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      <ExamPeriodFormModal
        open={formOpen}
        examPeriod={editingPeriod}
        organizations={organizations ?? []}
        courses={courses ?? []}
        academicYears={academicYears ?? []}
        onClose={() => setFormOpen(false)}
      />

      <BatchExamPeriodsModal
        open={batchOpen}
        organizations={organizations ?? []}
        onClose={() => setBatchOpen(false)}
      />
    </>
  );
}
