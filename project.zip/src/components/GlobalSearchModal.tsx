import { ArrowUpDown, ChevronLeft, ChevronRight, Search, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { db } from '../db/database';
import type {
  AcademicYear,
  ClassSession,
  Course,
  Exam,
  Homework,
  Organization,
} from '../db/types';
import { formatSlashDateWithWeekday } from '../utils/date';
import {
  runOfflineSearch,
  type SearchCategoryFilter,
  type SearchResultItem,
  type SearchResultType,
  type SearchSortOrder,
} from '../utils/search';
import { useBackLayer } from '../utils/backNavigation';
import { useLiveQuery } from '../utils/useLiveQuery';
import { SubstituteBadge } from './SubstituteBadge';

interface GlobalSearchModalProps {
  open: boolean;
  onClose: () => void;
  onSelectResult: (item: SearchResultItem) => void;
}

const CATEGORY_OPTIONS: Array<{ value: SearchCategoryFilter; label: string }> = [
  { value: 'all', label: '全部' },
  { value: 'course', label: '課程' },
  { value: 'session', label: '場次' },
  { value: 'exam', label: '考試' },
  { value: 'homework', label: '作業' },
];

const TYPE_LABELS: Record<SearchResultType, string> = {
  course: '課程',
  session: '場次',
  exam: '考試',
  homework: '作業',
};

const TYPE_ACCENTS: Record<SearchResultType, string> = {
  course: 'text-violet-700',
  session: 'text-sky-700',
  exam: 'text-rose-700',
  homework: 'text-amber-700',
};

function renderHighlightedText(text: string, rawQuery: string): ReactNode {
  const tokens = rawQuery
    .trim()
    .toLowerCase()
    .split(/\s+/)
    .filter((t) => t.length > 0);
  if (tokens.length === 0) return text;

  const escaped = tokens
    .sort((a, b) => b.length - a.length)
    .map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  const regex = new RegExp(`(${escaped.join('|')})`, 'gi');
  const parts = text.split(regex);

  return parts.map((part, idx) => {
    const isMatch = tokens.some((t) => part.toLowerCase() === t);
    return isMatch ? (
      <mark
        key={idx}
        className="rounded bg-[#EDE6FF] px-0.5 font-semibold text-zinc-900"
      >
        {part}
      </mark>
    ) : (
      <span key={idx}>{part}</span>
    );
  });
}

export function GlobalSearchModal({
  open,
  onClose,
  onSelectResult,
}: GlobalSearchModalProps) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<SearchCategoryFilter>('all');
  const [sortOrder, setSortOrder] = useState<SearchSortOrder>('desc');

  const courses = useLiveQuery(
    async (): Promise<Course[]> => (open ? db.courses.toArray() : []),
    [open]
  );
  const organizations = useLiveQuery(
    async (): Promise<Organization[]> =>
      open ? db.organizations.toArray() : [],
    [open]
  );
  const academicYears = useLiveQuery(
    async (): Promise<AcademicYear[]> =>
      open ? db.academicYears.toArray() : [],
    [open]
  );
  const sessions = useLiveQuery(
    async (): Promise<ClassSession[]> => (open ? db.sessions.toArray() : []),
    [open]
  );
  const exams = useLiveQuery(
    async (): Promise<Exam[]> => (open ? db.exams.toArray() : []),
    [open]
  );
  const homeworks = useLiveQuery(
    async (): Promise<Homework[]> => (open ? db.homeworks.toArray() : []),
    [open]
  );

  useEffect(() => {
    if (!open) return;
    const timer = window.setTimeout(() => {
      inputRef.current?.focus();
    }, 60);
    return () => window.clearTimeout(timer);
  }, [open]);

  useBackLayer({
    active: open,
    zLayer: 35,
    onBack: onClose,
  });

  const dataset = useMemo(
    () => ({
      courses: courses ?? [],
      organizations: organizations ?? [],
      academicYears: academicYears ?? [],
      sessions: sessions ?? [],
      exams: exams ?? [],
      homeworks: homeworks ?? [],
    }),
    [courses, organizations, academicYears, sessions, exams, homeworks]
  );

  const allMatches = useMemo(
    () =>
      runOfflineSearch(query, dataset, {
        category: 'all',
        sortOrder,
      }),
    [query, dataset, sortOrder]
  );

  const countsByCategory = useMemo(() => {
    const counts: Record<SearchCategoryFilter, number> = {
      all: allMatches.length,
      course: 0,
      session: 0,
      exam: 0,
      homework: 0,
    };
    for (const item of allMatches) {
      counts[item.type] += 1;
    }
    return counts;
  }, [allMatches]);

  const visibleResults = useMemo(() => {
    if (category === 'all') return allMatches;
    return allMatches.filter((item) => item.type === category);
  }, [allMatches, category]);

  if (!open) {
    return null;
  }

  const trimmedQuery = query.trim();
  const isLoading =
    courses === undefined ||
    organizations === undefined ||
    academicYears === undefined ||
    sessions === undefined ||
    exams === undefined ||
    homeworks === undefined;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="全域離線搜尋"
      className="fixed inset-0 z-[35] flex flex-col bg-[var(--bg-canvas)]"
    >
      {/* 頂部搜尋列 */}
      <header className="shrink-0 border-b border-violet-200/70 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex w-full max-w-2xl items-center gap-1.5 px-2 py-2">
          <button
            type="button"
            onClick={onClose}
            aria-label="關閉搜尋"
            className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl text-zinc-700 transition-colors hover:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
          >
            <ChevronLeft size={20} aria-hidden="true" />
          </button>

          <div className="relative flex min-w-0 flex-1 items-center">
            <Search
              size={17}
              aria-hidden="true"
              className="pointer-events-none absolute left-3 text-zinc-400"
            />
            <input
              ref={inputRef}
              type="search"
              inputMode="search"
              enterKeyHint="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="搜尋課程、進度、備註、作業或考試…"
              aria-label="搜尋關鍵字"
              className="min-h-[44px] w-full rounded-xl border border-violet-200 bg-zinc-50/70 py-2 pl-9 pr-10 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:bg-white focus:outline-none focus:ring-2 focus:ring-violet-600/20"
            />
            {query.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  setQuery('');
                  inputRef.current?.focus();
                }}
                aria-label="清除搜尋文字"
                className="absolute right-0.5 flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-400 hover:text-zinc-700"
              >
                <X size={17} aria-hidden="true" />
              </button>
            )}
          </div>
        </div>

        {/* 分類篩選列 */}
        <div className="mx-auto flex w-full max-w-2xl items-center gap-1.5 overflow-x-auto px-4 pb-2.5 pt-0.5">
          {CATEGORY_OPTIONS.map((opt) => {
            const active = category === opt.value;
            const count = countsByCategory[opt.value];
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => setCategory(opt.value)}
                className={`flex min-h-[44px] shrink-0 items-center justify-center gap-1 rounded-xl border px-3 text-xs font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'border-violet-600 bg-[#CDB8FF] font-semibold text-zinc-900'
                    : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                }`}
              >
                <span>{opt.label}</span>
                {trimmedQuery.length > 0 && (
                  <span className="tabular-nums opacity-75">({count})</span>
                )}
              </button>
            );
          })}
        </div>
      </header>

      {/* 搜尋結果區域 */}
      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
        <div className="mx-auto w-full max-w-2xl space-y-3 px-4 py-4 pb-[calc(2rem+env(safe-area-inset-bottom)+var(--kb-inset,0px))]">
          {trimmedQuery.length === 0 ? (
            <div className="rounded-2xl border border-zinc-200 bg-white px-5 py-8 text-center">
              <Search
                size={24}
                aria-hidden="true"
                className="mx-auto text-zinc-400"
              />
              <h2 className="mt-2.5 text-base font-semibold text-zinc-900">
                離線搜尋課程與教學紀錄
              </h2>
              <p className="mt-1.5 text-xs leading-relaxed text-zinc-500">
                可搜尋課程名稱、場次的進度與備註、作業與考試的名稱及備註；離線時也能即時使用。
              </p>
            </div>
          ) : isLoading ? (
            <div className="rounded-2xl border border-zinc-200 bg-white p-8 text-center text-sm text-zinc-500">
              搜尋本機資料中…
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between gap-2 px-1">
                <p className="text-xs font-medium text-zinc-600 tabular-nums">
                  共 {visibleResults.length} 筆符合結果
                </p>
                <button
                  type="button"
                  onClick={() =>
                    setSortOrder((prev) => (prev === 'desc' ? 'asc' : 'desc'))
                  }
                  className="flex min-h-[44px] items-center gap-1.5 rounded-xl px-2.5 text-xs font-medium text-violet-700 hover:bg-violet-50 whitespace-nowrap"
                >
                  <ArrowUpDown size={14} aria-hidden="true" />
                  <span>
                    日期：{sortOrder === 'desc' ? '由新到舊' : '由舊到新'}
                  </span>
                </button>
              </div>

              {visibleResults.length === 0 ? (
                <div className="rounded-2xl border border-zinc-200 bg-white px-5 py-8 text-center">
                  <p className="text-sm font-medium text-zinc-800">
                    找不到符合「{trimmedQuery}」的資料
                  </p>
                  <p className="mt-1 text-xs text-zinc-500">
                    試試看其他關鍵字，或切換上方的資料分類。
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {visibleResults.map((item) => (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => onSelectResult(item)}
                      className="flex min-h-[68px] w-full items-center justify-between gap-3 rounded-2xl border border-zinc-200 bg-white px-4 py-3 text-left transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
                    >
                      <div className="min-w-0 flex-1 space-y-1">
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs tabular-nums">
                          <span
                            className={`font-semibold ${TYPE_ACCENTS[item.type]}`}
                          >
                            {TYPE_LABELS[item.type]}
                          </span>
                          <span aria-hidden="true" className="text-zinc-300">
                            ·
                          </span>
                          <span className="font-medium text-zinc-700">
                            {item.type === 'homework' && item.homework
                              ? item.homework.dueDate
                                ? `繳交 ${formatSlashDateWithWeekday(item.homework.dueDate)}`
                                : `派出 ${formatSlashDateWithWeekday(item.homework.assignedDate)}`
                              : item.type === 'course'
                                ? `最近 ${formatSlashDateWithWeekday(item.sortDate)}`
                                : formatSlashDateWithWeekday(item.sortDate)}
                          </span>
                          {item.statusLabel && (
                            <>
                              <span aria-hidden="true" className="text-zinc-300">
                                ·
                              </span>
                              <span className="text-zinc-600">
                                {item.statusLabel}
                              </span>
                            </>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          <span
                            aria-hidden="true"
                            style={{ backgroundColor: item.color }}
                            className="h-3.5 w-3.5 shrink-0 rounded-sm ring-1 ring-inset ring-black/15"
                          />
                          <span className="truncate text-base font-semibold text-zinc-900">
                            {renderHighlightedText(item.title, query)}
                          </span>
                        </div>

                        {item.isSubstitute ? (
                          <div className="flex flex-wrap items-center gap-1.5 pl-[22px] text-xs text-zinc-500">
                            <span>{item.orgName ?? '未指定單位'}</span>
                            <SubstituteBadge />
                            {item.substituteFor && (
                              <span className="text-zinc-700">
                                （代 {renderHighlightedText(item.substituteFor, query)}）
                              </span>
                            )}
                            {item.session && (
                              <span className="tabular-nums">
                                · {item.session.startTime}–{item.session.endTime}
                              </span>
                            )}
                          </div>
                        ) : (
                          <p className="truncate pl-[22px] text-xs text-zinc-500">
                            {item.subtitle}
                          </p>
                        )}

                        {item.matchedFields.length > 0 && (
                          <div className="space-y-0.5 pl-[22px] pt-0.5">
                            {item.matchedFields.map((field, idx) => (
                              <p
                                key={idx}
                                className="line-clamp-2 text-xs leading-relaxed text-zinc-700"
                              >
                                <span className="font-medium text-zinc-500">
                                  {field.label}：
                                </span>
                                {renderHighlightedText(field.text, query)}
                              </p>
                            ))}
                          </div>
                        )}
                      </div>

                      <ChevronRight
                        size={18}
                        aria-hidden="true"
                        className="shrink-0 text-zinc-400"
                      />
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
