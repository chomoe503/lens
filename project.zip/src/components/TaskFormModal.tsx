import { Bell, Check, CheckSquare, Search, Trash2, X } from 'lucide-react';
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { db } from '../db/database';
import type {
  AcademicYear,
  ClassSession,
  Course,
  Organization,
  TaskItem,
  TaskType,
} from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import {
  formatSlashDate,
  formatSlashDateWithWeekday,
  parseDateKey,
  toDateKey,
  WEEKDAY_LABELS,
} from '../utils/date';
import { createId } from '../utils/id';
import {
  isSessionCancelled,
  isSubstituteSession,
  resolveSessionDisplay,
} from '../utils/sessionDisplay';
import { pushUndoCustomAction } from '../utils/undoStore';
import { useLiveQuery } from '../utils/useLiveQuery';
import { ConfirmDialog } from './ConfirmDialog';
import { SubstituteBadge } from './SubstituteBadge';

interface TaskFormModalProps {
  open: boolean;
  task: TaskItem | null;
  courses: Course[];
  sessions: ClassSession[];
  organizations?: Organization[];
  defaultCourseId?: string;
  defaultSessionId?: string;
  defaultDate?: string;
  onClose: () => void;
}

type CreateTargetMode = 'course' | 'session' | 'none';

const SUBSTITUTE_TARGET_VALUE = '__substitute__';
const SESSION_FILTER_SUBSTITUTE = '__substitute_filter__';

function addDaysToDateKey(dateKey: string, deltaDays: number): string {
  const d = parseDateKey(dateKey);
  d.setDate(d.getDate() + deltaDays);
  return toDateKey(d);
}

function formatSessionGroupHeader(dateKey: string): string {
  const d = parseDateKey(dateKey);
  return `${WEEKDAY_LABELS[d.getDay()]} ${formatSlashDate(dateKey)}`;
}

function normalizeIdList(ids: string[]): string[] {
  return [...ids].sort();
}

export function TaskFormModal({
  open,
  task,
  courses,
  sessions,
  organizations = [],
  defaultCourseId = '',
  defaultSessionId = '',
  defaultDate = '',
  onClose,
}: TaskFormModalProps) {
  const isEditing = task !== null;

  const academicYears = useLiveQuery(
    async (): Promise<AcademicYear[]> =>
      open && !isEditing ? db.academicYears.toArray() : [],
    [open, isEditing]
  );

  const liveSessions = useLiveQuery(
    async (): Promise<ClassSession[] | null> =>
      open && !isEditing ? db.sessions.toArray() : null,
    [open, isEditing]
  );

  const effectiveSessions = liveSessions ?? sessions;

  const [title, setTitle] = useState('');
  const [type, setType] = useState<TaskType>('todo');
  const [dueDate, setDueDate] = useState('');
  const [dueTime, setDueTime] = useState('');
  const [dateTouched, setDateTouched] = useState(false);

  // Edit mode (single-select) state
  const [targetValue, setTargetValue] = useState('');
  const [sessionId, setSessionId] = useState('');

  // Create mode (multi-select) state
  const [createTargetMode, setCreateTargetMode] =
    useState<CreateTargetMode>('none');
  const [selectedCourseIds, setSelectedCourseIds] = useState<string[]>([]);
  const [selectedSessionIds, setSelectedSessionIds] = useState<string[]>([]);
  const [courseSearch, setCourseSearch] = useState('');
  const [showArchivedCourses, setShowArchivedCourses] = useState(false);
  const [sessionCourseFilter, setSessionCourseFilter] = useState<string>('all');
  const [sessionDaysLimit, setSessionDaysLimit] = useState(14);

  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);
  const [initialSnapshot, setInitialSnapshot] = useState('');

  const todayKey = toDateKey(new Date());

  const orgMap = useMemo(() => {
    const map = new Map<string, Organization>();
    for (const o of organizations) map.set(o.id, o);
    return map;
  }, [organizations]);

  const yearMap = useMemo(() => {
    const map = new Map<string, AcademicYear>();
    for (const y of academicYears ?? []) map.set(y.id, y);
    return map;
  }, [academicYears]);

  const regularCourses = useMemo(
    () =>
      courses
        .filter((c) => !c.isSystem)
        .sort((a, b) => a.name.localeCompare(b.name, 'zh-Hant')),
    [courses]
  );

  const sessionMap = useMemo(() => {
    const map = new Map<string, ClassSession>();
    for (const s of effectiveSessions) map.set(s.id, s);
    return map;
  }, [effectiveSessions]);

  const courseMap = useMemo(() => {
    const map = new Map<string, Course>();
    for (const c of courses) map.set(c.id, c);
    return map;
  }, [courses]);

  // Edit mode lists (unchanged)
  const substituteSessions = useMemo(() => {
    return sessions
      .filter((s) => isSubstituteSession(s) && !isSessionCancelled(s))
      .sort((a, b) => {
        const dateDiff = b.date.localeCompare(a.date);
        if (dateDiff !== 0) return dateDiff;
        return b.startTime.localeCompare(a.startTime);
      })
      .slice(0, 30);
  }, [sessions]);

  const courseSessionsForEdit = useMemo(() => {
    if (!targetValue || targetValue === SUBSTITUTE_TARGET_VALUE) return [];
    const list = sessions.filter(
      (s) =>
        s.courseId === targetValue &&
        !isSubstituteSession(s) &&
        !isSessionCancelled(s)
    );
    const upcoming = list
      .filter((s) => s.date >= todayKey)
      .sort((a, b) => {
        const dateDiff = a.date.localeCompare(b.date);
        if (dateDiff !== 0) return dateDiff;
        return a.startTime.localeCompare(b.startTime);
      });
    const past = list
      .filter((s) => s.date < todayKey)
      .sort((a, b) => {
        const dateDiff = b.date.localeCompare(a.date);
        if (dateDiff !== 0) return dateDiff;
        return b.startTime.localeCompare(a.startTime);
      })
      .slice(0, 10);
    return [...upcoming, ...past];
  }, [sessions, targetValue, todayKey]);

  // Create mode: filtered courses list
  const visibleCoursesForCreate = useMemo(() => {
    const query = courseSearch.trim().toLowerCase();
    return regularCourses.filter((c) => {
      if (!showArchivedCourses) {
        const year = yearMap.get(c.academicYearId);
        if (year?.archived && !selectedCourseIds.includes(c.id)) {
          return false;
        }
      }
      if (!query) return true;
      const orgName = orgMap.get(c.organizationId)?.name ?? '';
      return (
        c.name.toLowerCase().includes(query) ||
        orgName.toLowerCase().includes(query)
      );
    });
  }, [
    regularCourses,
    showArchivedCourses,
    yearMap,
    selectedCourseIds,
    courseSearch,
    orgMap,
  ]);

  // Create mode: sessions within window (plus any pre-selected session outside window)
  const sessionWindowEndKey = useMemo(
    () => addDaysToDateKey(todayKey, sessionDaysLimit - 1),
    [todayKey, sessionDaysLimit]
  );

  const visibleSessionGroups = useMemo(() => {
    const selectedSet = new Set(selectedSessionIds);
    const filtered = effectiveSessions
      .filter((s) => {
        if (isSessionCancelled(s)) return false;

        const isPreselected = selectedSet.has(s.id);
        const inWindow = s.date >= todayKey && s.date <= sessionWindowEndKey;
        if (!inWindow && !isPreselected) return false;

        if (sessionCourseFilter === SESSION_FILTER_SUBSTITUTE) {
          return isSubstituteSession(s);
        }
        if (sessionCourseFilter !== 'all') {
          return !isSubstituteSession(s) && s.courseId === sessionCourseFilter;
        }
        return true;
      })
      .sort((a, b) => {
        const dateDiff = a.date.localeCompare(b.date);
        if (dateDiff !== 0) return dateDiff;
        const startDiff = a.startTime.localeCompare(b.startTime);
        if (startDiff !== 0) return startDiff;
        return a.createdAt - b.createdAt;
      });

    const groups: Array<{ dateKey: string; sessions: ClassSession[] }> = [];
    let currentGroup: { dateKey: string; sessions: ClassSession[] } | null =
      null;

    for (const s of filtered) {
      if (!currentGroup || currentGroup.dateKey !== s.date) {
        currentGroup = { dateKey: s.date, sessions: [s] };
        groups.push(currentGroup);
      } else {
        currentGroup.sessions.push(s);
      }
    }

    return groups;
  }, [
    effectiveSessions,
    selectedSessionIds,
    todayKey,
    sessionWindowEndKey,
    sessionCourseFilter,
  ]);

  const hasSubstituteInWindow = useMemo(
    () =>
      effectiveSessions.some(
        (s) =>
          !isSessionCancelled(s) &&
          isSubstituteSession(s) &&
          s.date >= todayKey &&
          s.date <= sessionWindowEndKey
      ),
    [effectiveSessions, todayKey, sessionWindowEndKey]
  );

  useEffect(() => {
    if (!open) return;

    if (task) {
      const initTitle = task.title;
      const initType = task.type;
      const initSessionId = task.sessionId ?? '';
      const matchedSession = initSessionId
        ? sessions.find((s) => s.id === initSessionId)
        : undefined;
      const initTarget =
        matchedSession && isSubstituteSession(matchedSession)
          ? SUBSTITUTE_TARGET_VALUE
          : (task.courseId ?? matchedSession?.courseId ?? '');
      const initDueDate = task.dueDate ?? '';
      const initDueTime = task.dueTime ?? '';

      setTitle(initTitle);
      setType(initType);
      setTargetValue(initTarget);
      setSessionId(initSessionId);
      setDueDate(initDueDate);
      setDueTime(initDueTime);
      setDateTouched(true);
      setError(null);
      setDeleteConfirmOpen(false);
      setDiscardConfirmOpen(false);
      setInitialSnapshot(
        JSON.stringify({
          mode: 'edit',
          title: initTitle,
          type: initType,
          targetValue: initTarget,
          sessionId: initSessionId,
          dueDate: initDueDate,
          dueTime: initDueTime,
        })
      );
      return;
    }

    // Create mode initialization
    let initMode: CreateTargetMode = 'none';
    let initCourseIds: string[] = [];
    let initSessionIds: string[] = [];

    if (defaultSessionId) {
      initMode = 'session';
      initSessionIds = [defaultSessionId];
    } else if (defaultCourseId) {
      initMode = 'course';
      initCourseIds = [defaultCourseId];
    }

    const initDueDate = initMode === 'none' ? defaultDate : '';

    setTitle('');
    setType('todo');
    setCreateTargetMode(initMode);
    setSelectedCourseIds(initCourseIds);
    setSelectedSessionIds(initSessionIds);
    setCourseSearch('');
    setShowArchivedCourses(false);
    setSessionCourseFilter('all');
    setSessionDaysLimit(14);
    setDueDate(initDueDate);
    setDueTime('');
    setDateTouched(false);
    setError(null);
    setDeleteConfirmOpen(false);
    setDiscardConfirmOpen(false);
    setInitialSnapshot(
      JSON.stringify({
        mode: 'create',
        title: '',
        type: 'todo',
        createTargetMode: initMode,
        selectedCourseIds: normalizeIdList(initCourseIds),
        selectedSessionIds: normalizeIdList(initSessionIds),
        dueDate: initDueDate,
        dueTime: '',
      })
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, task, defaultCourseId, defaultSessionId, defaultDate]);

  const isDirty = useMemo(() => {
    if (!open || !initialSnapshot) return false;
    if (isEditing) {
      return (
        JSON.stringify({
          mode: 'edit',
          title,
          type,
          targetValue,
          sessionId,
          dueDate,
          dueTime,
        }) !== initialSnapshot
      );
    }
    return (
      JSON.stringify({
        mode: 'create',
        title,
        type,
        createTargetMode,
        selectedCourseIds: normalizeIdList(selectedCourseIds),
        selectedSessionIds: normalizeIdList(selectedSessionIds),
        dueDate,
        dueTime,
      }) !== initialSnapshot
    );
  }, [
    open,
    initialSnapshot,
    isEditing,
    title,
    type,
    targetValue,
    sessionId,
    createTargetMode,
    selectedCourseIds,
    selectedSessionIds,
    dueDate,
    dueTime,
  ]);

  const handleRequestClose = () => {
    if (isSaving || isDeleting) return;
    if (isDirty) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: open,
    zLayer: 70,
    onBack: handleRequestClose,
  });

  if (!open) return null;

  // Edit mode handlers (unchanged)
  const handleTargetChange = (nextTarget: string) => {
    setTargetValue(nextTarget);
    if (nextTarget === SUBSTITUTE_TARGET_VALUE) {
      const firstSub = substituteSessions[0]?.id ?? '';
      setSessionId(firstSub);
      return;
    }
    setSessionId('');
  };

  const handleSessionChange = (nextSessionId: string) => {
    setSessionId(nextSessionId);
  };

  // Create mode handlers
  const handleSwitchCreateMode = (nextMode: CreateTargetMode) => {
    if (nextMode === createTargetMode) return;
    setCreateTargetMode(nextMode);
    setSelectedCourseIds([]);
    setSelectedSessionIds([]);
    setError(null);
    if (!dateTouched) {
      setDueDate(nextMode === 'none' ? defaultDate : '');
    }
  };

  const toggleCourseSelection = (courseId: string) => {
    setError(null);
    setSelectedCourseIds((prev) =>
      prev.includes(courseId)
        ? prev.filter((id) => id !== courseId)
        : [...prev, courseId]
    );
  };

  const handleSelectAllVisibleCourses = () => {
    setError(null);
    setSelectedCourseIds((prev) => {
      const set = new Set(prev);
      for (const c of visibleCoursesForCreate) {
        set.add(c.id);
      }
      return Array.from(set);
    });
  };

  const toggleSessionSelection = (id: string) => {
    setError(null);
    setSelectedSessionIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAllDaySessions = (daySessions: ClassSession[]) => {
    setError(null);
    const dayIds = daySessions.map((s) => s.id);
    setSelectedSessionIds((prev) => {
      const set = new Set(prev);
      const allSelected = dayIds.every((id) => set.has(id));
      if (allSelected) {
        for (const id of dayIds) set.delete(id);
      } else {
        for (const id of dayIds) set.add(id);
      }
      return Array.from(set);
    });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const trimmedTitle = title.trim();
    if (!trimmedTitle) {
      setError('請輸入任務標題');
      return;
    }

    if (task) {
      if (targetValue === SUBSTITUTE_TARGET_VALUE && !sessionId) {
        setError('請選擇要掛上的代課／臨時場次，或改為不指定班級');
        return;
      }

      setIsSaving(true);
      setError(null);
      try {
        const now = Date.now();
        const isSubstituteTarget = targetValue === SUBSTITUTE_TARGET_VALUE;
        const resolvedCourseId = isSubstituteTarget
          ? undefined
          : targetValue || undefined;
        const resolvedSessionId = sessionId || undefined;

        const record: TaskItem = {
          id: task.id,
          title: trimmedTitle,
          type,
          courseId: resolvedCourseId,
          sessionId: resolvedSessionId,
          dueDate: dueDate || undefined,
          dueTime: dueTime || undefined,
          done: type === 'todo' ? task.done : false,
          doneAt: type === 'todo' && task.done ? (task.doneAt ?? now) : undefined,
          createdAt: task.createdAt,
          updatedAt: now,
        };

        await db.tasks.put(record);
        onClose();
      } catch (err) {
        setError(err instanceof Error ? err.message : '儲存任務失敗');
      } finally {
        setIsSaving(false);
      }
      return;
    }

    // Create mode validation & batch insert inside a single transaction
    if (
      (createTargetMode === 'course' && selectedCourseIds.length === 0) ||
      (createTargetMode === 'session' && selectedSessionIds.length === 0)
    ) {
      setError('請至少勾選一個班級／場次，或改成「不指定」');
      return;
    }

    setIsSaving(true);
    setError(null);
    try {
      const now = Date.now();
      let records: TaskItem[] = [];

      if (createTargetMode === 'course') {
        records = selectedCourseIds.map((cId, idx) => ({
          id: createId(),
          title: trimmedTitle,
          type,
          courseId: cId,
          sessionId: undefined,
          dueDate: dueDate || undefined,
          dueTime: dueTime || undefined,
          done: false,
          createdAt: now + idx,
          updatedAt: now + idx,
        }));
      } else if (createTargetMode === 'session') {
        records = selectedSessionIds.map((sId, idx) => {
          const matchedSession = sessionMap.get(sId);
          const resolvedCourseId =
            matchedSession && !isSubstituteSession(matchedSession)
              ? matchedSession.courseId
              : undefined;
          return {
            id: createId(),
            title: trimmedTitle,
            type,
            courseId: resolvedCourseId,
            sessionId: sId,
            dueDate: dueDate || undefined,
            dueTime: dueTime || undefined,
            done: false,
            createdAt: now + idx,
            updatedAt: now + idx,
          };
        });
      } else {
        records = [
          {
            id: createId(),
            title: trimmedTitle,
            type,
            courseId: undefined,
            sessionId: undefined,
            dueDate: dueDate || undefined,
            dueTime: dueTime || undefined,
            done: false,
            createdAt: now,
            updatedAt: now,
          },
        ];
      }

      await db.transaction('rw', db.tasks, async () => {
        await db.tasks.bulkAdd(records);
      });

      if (records.length > 1) {
        const createdIds = records.map((r) => r.id);
        pushUndoCustomAction(`已建立 ${records.length} 個任務`, async () => {
          await db.tasks.bulkDelete(createdIds);
        });
      }

      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : '建立任務失敗');
    } finally {
      setIsSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!task) return;
    setIsDeleting(true);
    try {
      await db.tasks.delete(task.id);
      setDeleteConfirmOpen(false);
      onClose();
    } finally {
      setIsDeleting(false);
    }
  };

  const createSelectionCount =
    createTargetMode === 'course'
      ? selectedCourseIds.length
      : createTargetMode === 'session'
        ? selectedSessionIds.length
        : 1;

  const submitButtonLabel = isSaving
    ? '儲存中…'
    : isEditing
      ? '儲存變更'
      : createTargetMode !== 'none' && createSelectionCount > 1
        ? `建立 ${createSelectionCount} 個任務`
        : '儲存';

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="task-form-title"
        className="fixed inset-0 z-[70] flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
        onClick={(e) => {
          if (e.target === e.currentTarget) {
            handleRequestClose();
          }
        }}
      >
        <div className="flex max-h-[92dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 px-5 py-3.5">
            <h2
              id="task-form-title"
              className="text-base font-semibold text-zinc-900"
            >
              {isEditing ? '編輯任務' : '新增任務'}
            </h2>
            <button
              type="button"
              onClick={handleRequestClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
            >
              <X size={20} />
            </button>
          </div>

          <form
            onSubmit={handleSubmit}
            className="flex min-h-0 flex-1 flex-col overflow-hidden"
          >
            <div className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-5">
              {error && (
                <div
                  role="alert"
                  className="rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-medium text-rose-700"
                >
                  {error}
                </div>
              )}

              <div>
                <label
                  htmlFor="task-title-input"
                  className="block text-xs font-medium text-zinc-700"
                >
                  標題 <span className="text-rose-600">*</span>
                </label>
                <input
                  id="task-title-input"
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="例如：影印單元評量、帶實驗器材、收簽名回條"
                  autoFocus={!isEditing}
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              <div>
                <span className="block text-xs font-medium text-zinc-700">
                  類型
                </span>
                <div className="mt-1.5 grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setType('todo')}
                    className={`flex min-h-[44px] items-center justify-center gap-2 rounded-xl border px-3 text-sm font-medium transition-colors ${
                      type === 'todo'
                        ? 'border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                        : 'border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-50'
                    }`}
                  >
                    <CheckSquare size={16} aria-hidden="true" />
                    <span>待辦（可勾選）</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setType('reminder')}
                    className={`flex min-h-[44px] items-center justify-center gap-2 rounded-xl border px-3 text-sm font-medium transition-colors ${
                      type === 'reminder'
                        ? 'border-amber-500 bg-[#FEF3C7] font-semibold text-amber-950'
                        : 'border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-50'
                    }`}
                  >
                    <Bell size={16} aria-hidden="true" />
                    <span>提醒（純文字）</span>
                  </button>
                </div>
              </div>

              {/* 掛在哪：編輯維持單選；新增支援多選 */}
              {isEditing ? (
                <>
                  <div>
                    <label
                      htmlFor="task-target-course"
                      className="block text-xs font-medium text-zinc-700"
                    >
                      掛在哪（選填）
                    </label>
                    <select
                      id="task-target-course"
                      value={targetValue}
                      onChange={(e) => handleTargetChange(e.target.value)}
                      className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                    >
                      <option value="">不指定班級／場次（依日期顯示）</option>
                      {regularCourses.map((c) => {
                        const orgName = orgMap.get(c.organizationId)?.name;
                        return (
                          <option key={c.id} value={c.id}>
                            {c.name}
                            {orgName ? `（${orgName}）` : ''}
                          </option>
                        );
                      })}
                      {substituteSessions.length > 0 && (
                        <option value={SUBSTITUTE_TARGET_VALUE}>
                          代課／臨時場次
                        </option>
                      )}
                    </select>
                    {targetValue &&
                      targetValue !== SUBSTITUTE_TARGET_VALUE &&
                      !sessionId && (
                        <p className="mt-1 text-xs text-zinc-500">
                          只選班級時，會自動跟隨該班級的下一堂課，直到完成打勾為止。
                        </p>
                      )}
                  </div>

                  {targetValue === SUBSTITUTE_TARGET_VALUE && (
                    <div>
                      <label
                        htmlFor="task-substitute-session"
                        className="block text-xs font-medium text-zinc-700"
                      >
                        指定代課／臨時場次
                      </label>
                      <select
                        id="task-substitute-session"
                        value={sessionId}
                        onChange={(e) => handleSessionChange(e.target.value)}
                        className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                      >
                        {substituteSessions.map((s) => (
                          <option key={s.id} value={s.id}>
                            {formatSlashDateWithWeekday(s.date)} {s.startTime} ·{' '}
                            {s.title}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {targetValue && targetValue !== SUBSTITUTE_TARGET_VALUE && (
                    <div>
                      <label
                        htmlFor="task-target-session"
                        className="block text-xs font-medium text-zinc-700"
                      >
                        指定場次（選填）
                      </label>
                      <select
                        id="task-target-session"
                        value={sessionId}
                        onChange={(e) => handleSessionChange(e.target.value)}
                        className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                      >
                        <option value="">
                          不指定場次（自動跟隨下一堂課）
                        </option>
                        {courseSessionsForEdit.map((s) => (
                          <option key={s.id} value={s.id}>
                            {formatSlashDateWithWeekday(s.date)} {s.startTime}–
                            {s.endTime}
                            {s.periodLabel ? `（${s.periodLabel}）` : ''}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </>
              ) : (
                <div className="space-y-2.5">
                  <span className="block text-xs font-medium text-zinc-700">
                    掛在哪
                  </span>

                  <div
                    role="tablist"
                    aria-label="選擇任務掛載方式"
                    className="grid grid-cols-3 gap-1 rounded-2xl border border-violet-200/80 bg-zinc-50 p-1"
                  >
                    {(
                      [
                        { value: 'course', label: '整個班級' },
                        { value: 'session', label: '指定場次' },
                        { value: 'none', label: '不指定' },
                      ] as const
                    ).map((opt) => {
                      const active = createTargetMode === opt.value;
                      return (
                        <button
                          key={opt.value}
                          type="button"
                          role="tab"
                          aria-selected={active}
                          onClick={() => handleSwitchCreateMode(opt.value)}
                          className={`flex min-h-[44px] items-center justify-center rounded-xl px-2 text-xs font-medium transition-colors sm:text-sm ${
                            active
                              ? 'bg-[#CDB8FF] font-semibold text-zinc-900 shadow-xs'
                              : 'text-zinc-600 hover:text-zinc-900'
                          }`}
                        >
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>

                  {/* 模式 1：整個班級（可多選） */}
                  {createTargetMode === 'course' && (
                    <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white">
                      <div className="space-y-2 border-b border-zinc-100 bg-zinc-50/70 p-2.5">
                        <div className="relative">
                          <Search
                            size={15}
                            aria-hidden="true"
                            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400"
                          />
                          <input
                            type="search"
                            value={courseSearch}
                            onChange={(e) => setCourseSearch(e.target.value)}
                            placeholder="搜尋班級或單位名稱…"
                            aria-label="搜尋班級"
                            className="min-h-[44px] w-full rounded-xl border border-zinc-200 bg-white pl-9 pr-3 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                          />
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="text-xs font-semibold text-violet-800 tabular-nums">
                            已選 {selectedCourseIds.length} 個班級
                          </span>

                          <div className="flex flex-wrap items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() =>
                                setShowArchivedCourses((prev) => !prev)
                              }
                              aria-pressed={showArchivedCourses}
                              className={`flex min-h-[36px] items-center rounded-lg border px-2.5 text-xs font-medium transition-colors ${
                                showArchivedCourses
                                  ? 'border-violet-500 bg-[#EDE6FF] font-semibold text-zinc-900'
                                  : 'border-zinc-200 bg-white text-zinc-600 hover:bg-zinc-50'
                              }`}
                            >
                              顯示全部
                            </button>
                            <button
                              type="button"
                              disabled={visibleCoursesForCreate.length === 0}
                              onClick={handleSelectAllVisibleCourses}
                              className="flex min-h-[36px] items-center rounded-lg border border-zinc-200 bg-white px-2.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-50 disabled:opacity-50"
                            >
                              全選
                            </button>
                            <button
                              type="button"
                              disabled={selectedCourseIds.length === 0}
                              onClick={() => setSelectedCourseIds([])}
                              className="flex min-h-[36px] items-center rounded-lg border border-zinc-200 bg-white px-2.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-50 disabled:opacity-50"
                            >
                              清除
                            </button>
                          </div>
                        </div>
                      </div>

                      <div className="max-h-[40dvh] divide-y divide-zinc-100 overflow-y-auto overscroll-contain">
                        {visibleCoursesForCreate.length === 0 ? (
                          <p className="px-4 py-6 text-center text-xs text-zinc-500">
                            {regularCourses.length === 0
                              ? '目前尚未建立班級課程'
                              : '沒有符合條件的班級'}
                          </p>
                        ) : (
                          visibleCoursesForCreate.map((c) => {
                            const checked = selectedCourseIds.includes(c.id);
                            const org = orgMap.get(c.organizationId);
                            const dotColor = org?.color ?? c.color;
                            const year = yearMap.get(c.academicYearId);
                            return (
                              <button
                                key={c.id}
                                type="button"
                                role="checkbox"
                                aria-checked={checked}
                                onClick={() => toggleCourseSelection(c.id)}
                                className={`flex min-h-[48px] w-full items-center gap-2.5 px-3 py-2 text-left transition-colors ${
                                  checked
                                    ? 'bg-[#F2ECFF]/65'
                                    : 'hover:bg-zinc-50 active:bg-zinc-100'
                                }`}
                              >
                                <span
                                  aria-hidden="true"
                                  className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-colors ${
                                    checked
                                      ? 'border-violet-700 bg-violet-700 text-white'
                                      : 'border-zinc-300 bg-white text-transparent'
                                  }`}
                                >
                                  <Check size={13} strokeWidth={2.75} />
                                </span>

                                <span
                                  aria-hidden="true"
                                  style={{ backgroundColor: dotColor }}
                                  className="h-3 w-3 shrink-0 rounded-full ring-1 ring-inset ring-black/15"
                                />

                                <div className="min-w-0 flex-1">
                                  <p className="truncate text-sm font-medium text-zinc-900">
                                    {c.name}
                                  </p>
                                  <p className="truncate text-xs text-zinc-500">
                                    {org?.name ?? '未指定單位'}
                                    {year?.archived ? ` · ${year.name}（已封存）` : ''}
                                  </p>
                                </div>
                              </button>
                            );
                          })
                        )}
                      </div>
                    </div>
                  )}

                  {/* 模式 2：指定場次（可多選） */}
                  {createTargetMode === 'session' && (
                    <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white">
                      <div className="space-y-2 border-b border-zinc-100 bg-zinc-50/70 p-2.5">
                        <select
                          aria-label="依班級篩選場次"
                          value={sessionCourseFilter}
                          onChange={(e) =>
                            setSessionCourseFilter(e.target.value)
                          }
                          className="min-h-[44px] w-full rounded-xl border border-zinc-200 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                        >
                          <option value="all">全部班級</option>
                          {regularCourses.map((c) => {
                            const orgName = orgMap.get(c.organizationId)?.name;
                            return (
                              <option key={c.id} value={c.id}>
                                {c.name}
                                {orgName ? `（${orgName}）` : ''}
                              </option>
                            );
                          })}
                          {hasSubstituteInWindow && (
                            <option value={SESSION_FILTER_SUBSTITUTE}>
                              代課／臨時
                            </option>
                          )}
                        </select>

                        <div className="flex items-center justify-between gap-2 px-0.5">
                          <span className="text-xs font-semibold text-violet-800 tabular-nums">
                            已選 {selectedSessionIds.length} 堂
                          </span>
                          {selectedSessionIds.length > 0 && (
                            <button
                              type="button"
                              onClick={() => setSelectedSessionIds([])}
                              className="flex min-h-[36px] items-center rounded-lg border border-zinc-200 bg-white px-2.5 text-xs font-medium text-zinc-700 hover:bg-zinc-50"
                            >
                              清除
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="max-h-[40dvh] overflow-y-auto overscroll-contain">
                        {visibleSessionGroups.length === 0 ? (
                          <p className="px-4 py-6 text-center text-xs text-zinc-500">
                            今天起 {sessionDaysLimit} 天內沒有符合的未取消場次
                          </p>
                        ) : (
                          <div className="divide-y divide-zinc-100">
                            {visibleSessionGroups.map((group) => {
                              const allDaySelected = group.sessions.every((s) =>
                                selectedSessionIds.includes(s.id)
                              );
                              return (
                                <div key={group.dateKey}>
                                  <div className="sticky top-0 z-10 flex items-center justify-between gap-2 border-b border-zinc-100 bg-zinc-50/95 px-3 py-1.5 backdrop-blur-xs">
                                    <span className="text-xs font-semibold text-zinc-800 tabular-nums">
                                      {formatSessionGroupHeader(group.dateKey)}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        handleSelectAllDaySessions(
                                          group.sessions
                                        )
                                      }
                                      className={`flex min-h-[34px] items-center rounded-lg border px-2.5 text-xs font-medium transition-colors ${
                                        allDaySelected
                                          ? 'border-violet-500 bg-[#EDE6FF] font-semibold text-zinc-900'
                                          : 'border-zinc-200 bg-white text-violet-700 hover:bg-violet-50'
                                      }`}
                                    >
                                      這天全選
                                    </button>
                                  </div>

                                  <div className="divide-y divide-zinc-100">
                                    {group.sessions.map((s) => {
                                      const checked =
                                        selectedSessionIds.includes(s.id);
                                      const resolved = resolveSessionDisplay(
                                        s,
                                        courseMap,
                                        orgMap
                                      );
                                      return (
                                        <button
                                          key={s.id}
                                          type="button"
                                          role="checkbox"
                                          aria-checked={checked}
                                          onClick={() =>
                                            toggleSessionSelection(s.id)
                                          }
                                          className={`flex min-h-[48px] w-full items-center gap-2.5 px-3 py-2 text-left transition-colors ${
                                            checked
                                              ? 'bg-[#F2ECFF]/65'
                                              : 'hover:bg-zinc-50 active:bg-zinc-100'
                                          }`}
                                        >
                                          <span
                                            aria-hidden="true"
                                            className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-colors ${
                                              checked
                                                ? 'border-violet-700 bg-violet-700 text-white'
                                                : 'border-zinc-300 bg-white text-transparent'
                                            }`}
                                          >
                                            <Check
                                              size={13}
                                              strokeWidth={2.75}
                                            />
                                          </span>

                                          <span className="shrink-0 text-xs font-semibold text-zinc-700 tabular-nums">
                                            {s.startTime}–{s.endTime}
                                          </span>

                                          <div className="min-w-0 flex-1">
                                            <div className="flex items-center gap-1.5">
                                              <span className="truncate text-sm font-medium text-zinc-900">
                                                {resolved.title}
                                              </span>
                                              {resolved.isSubstitute && (
                                                <SubstituteBadge compact />
                                              )}
                                            </div>
                                            <p className="truncate text-xs text-zinc-500">
                                              {resolved.orgName}
                                            </p>
                                          </div>
                                        </button>
                                      );
                                    })}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}

                        <div className="border-t border-zinc-100 bg-zinc-50/50 p-2">
                          <button
                            type="button"
                            onClick={() =>
                              setSessionDaysLimit((prev) => prev + 14)
                            }
                            className="flex min-h-[44px] w-full items-center justify-center rounded-xl border border-violet-200 bg-[#F2ECFF]/70 px-3 text-xs font-semibold text-violet-900 transition-colors hover:bg-[#EDE6FF]"
                          >
                            再顯示 14 天
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <label
                      htmlFor="task-due-date"
                      className="block text-xs font-medium text-zinc-700"
                    >
                      日期（選填）
                    </label>
                    {dueDate && (
                      <button
                        type="button"
                        onClick={() => {
                          setDateTouched(true);
                          setDueDate('');
                        }}
                        className="text-xs font-medium text-violet-700 hover:underline"
                      >
                        清除
                      </button>
                    )}
                  </div>
                  <input
                    id="task-due-date"
                    type="date"
                    value={dueDate}
                    onChange={(e) => {
                      setDateTouched(true);
                      setDueDate(e.target.value);
                    }}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between gap-2">
                    <label
                      htmlFor="task-due-time"
                      className="block text-xs font-medium text-zinc-700"
                    >
                      時間（選填）
                    </label>
                    {dueTime && (
                      <button
                        type="button"
                        onClick={() => setDueTime('')}
                        className="text-xs font-medium text-violet-700 hover:underline"
                      >
                        清除
                      </button>
                    )}
                  </div>
                  <input
                    id="task-due-time"
                    type="time"
                    value={dueTime}
                    onChange={(e) => setDueTime(e.target.value)}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>
              </div>
            </div>

            {/* 固定底部操作列，表單捲動時仍清楚可見 */}
            <div className="shrink-0 border-t border-zinc-100 bg-white px-5 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
              <div className="flex items-center gap-2">
                {task && (
                  <button
                    type="button"
                    onClick={() => setDeleteConfirmOpen(true)}
                    aria-label="刪除任務"
                    className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-rose-200 bg-white px-3 text-rose-600 transition-colors hover:bg-rose-50"
                  >
                    <Trash2 size={18} aria-hidden="true" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleRequestClose}
                  className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm font-medium text-zinc-700 hover:bg-zinc-50"
                >
                  取消
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl bg-violet-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-violet-700 disabled:opacity-60"
                >
                  {submitButtonLabel}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>

      <ConfirmDialog
        open={deleteConfirmOpen}
        title="刪除任務"
        description={`確定要刪除「${task?.title ?? ''}」嗎？刪除後無法復原。`}
        confirmLabel="確認刪除"
        isSubmitting={isDeleting}
        onCancel={() => setDeleteConfirmOpen(false)}
        onConfirm={() => {
          void handleConfirmDelete();
        }}
      />

      <ConfirmDialog
        open={discardConfirmOpen}
        title="放棄未儲存的內容？"
        description="任務內容有尚未儲存的修改，確定要放棄並關閉嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardConfirmOpen(false)}
        onConfirm={() => {
          setDiscardConfirmOpen(false);
          onClose();
        }}
      />
    </>
  );
}
