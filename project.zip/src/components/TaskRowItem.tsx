import { Bell, Check } from 'lucide-react';
import { toggleTaskDone } from '../db/repositories';
import type { TaskItem } from '../db/types';

interface TaskRowItemProps {
  task: TaskItem;
  metaText?: string;
  onEdit?: (task: TaskItem) => void;
  compact?: boolean;
}

export function TaskRowItem({
  task,
  metaText,
  onEdit,
  compact = false,
}: TaskRowItemProps) {
  const isTodo = task.type === 'todo';
  const isDone = isTodo && task.done;

  const titleContent = (
    <div className="min-w-0 flex-1">
      <p
        className={`${compact ? 'text-xs' : 'text-sm'} leading-snug ${
          isDone
            ? 'text-zinc-400 line-through'
            : 'font-medium text-zinc-800'
        }`}
      >
        {task.title}
      </p>
      {(metaText || task.dueTime) && (
        <p
          className={`mt-0.5 truncate text-[11px] tabular-nums ${
            isDone ? 'text-zinc-400 line-through' : 'text-zinc-500'
          }`}
        >
          {task.dueTime ? `${task.dueTime}` : ''}
          {task.dueTime && metaText ? ' · ' : ''}
          {metaText ?? ''}
        </p>
      )}
    </div>
  );

  return (
    <div className="flex min-h-[44px] items-center gap-1">
      {isTodo ? (
        <button
          type="button"
          role="checkbox"
          aria-checked={isDone}
          aria-label={`${isDone ? '取消完成' : '標記完成'}：${task.title}`}
          onClick={(e) => {
            e.stopPropagation();
            void toggleTaskDone(task);
          }}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl transition-colors hover:bg-violet-50 active:bg-violet-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
        >
          <span
            aria-hidden="true"
            className={`flex h-5 w-5 items-center justify-center rounded-md border transition-colors ${
              isDone
                ? 'border-zinc-300 bg-zinc-200 text-zinc-500'
                : 'border-violet-400 bg-white text-transparent hover:border-violet-600'
            }`}
          >
            <Check size={13} strokeWidth={2.75} />
          </span>
        </button>
      ) : (
        <span
          aria-label="提醒"
          className="flex h-11 w-11 shrink-0 items-center justify-center text-amber-600"
        >
          <Bell size={16} aria-hidden="true" />
        </span>
      )}

      {onEdit ? (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onEdit(task);
          }}
          className="flex min-h-[44px] min-w-0 flex-1 items-center rounded-xl px-1.5 py-1.5 text-left transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
        >
          {titleContent}
        </button>
      ) : (
        <div className="flex min-h-[44px] min-w-0 flex-1 items-center px-1.5 py-1.5">
          {titleContent}
        </div>
      )}
    </div>
  );
}
