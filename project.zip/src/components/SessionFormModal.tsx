import { AlertTriangle, History, Trash2, X } from 'lucide-react';
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { db } from '../db/database';
import {
  deleteMultipleSessions,
  ensureSubstituteSystemCourseForDate,
  findOverlappingSessions,
  getLastCourseSessionTime,
} from '../db/repositories';
import type {
  ClassSession,
  Course,
  Organization,
  Period,
  SessionKind,
} from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import {
  addMinutesToTime,
  formatSlashDate,
  timeToMinutes,
  toDateKey,
} from '../utils/date';
import { createId } from '../utils/id';
import { isSessionCancelled, resolveSessionDisplay } from '../utils/sessionDisplay';
import {
  getSubstituteShortcuts,
  recordSubstituteShortcuts,
} from '../utils/substituteHistory';
import { useLiveQuery } from '../utils/useLiveQuery';
import { ConfirmDialog } from './ConfirmDialog';
import { DurationSelector } from './DurationSelector';
import { PeriodMultiSelector } from './PeriodMultiSelector';

export type SessionFormMode = 'regular' | 'substitute';

interface SessionFormModalProps {
  open: boolean;
  session: ClassSession | null;
  courses: Course[];
  organizations: Organization[];
  defaultMode?: SessionFormMode;
  defaultCourseId?: string;
  defaultDate?: string;
  defaultKind?: SessionKind;
  defaultMakeupForSessionId?: string;
  defaultStartReschedule?: boolean;
  onClose: () => void;
}

const KIND_OPTIONS: Array<{ value: Exclude<SessionKind, 'substitute'>; label: string }> = [
  { value: 'regular', label: '正常' },
  { value: 'makeup', label: '補課' },
  { value: 'extra', label: '加課' },
];

export function SessionFormModal({
  open,
  session,
  courses,
  organizations,
  defaultMode = 'regular',
  defaultCourseId,
  defaultDate,
  defaultKind = 'regular',
  defaultMakeupForSessionId,
  defaultStartReschedule = false,
  onClose,
}: SessionFormModalProps) {
  const regularCourses = useMemo(
    () => courses.filter((c) => !c.isSystem),
    [courses]
  );

  const [sessionMode, setSessionMode] = useState<SessionFormMode>('regular');
  const [courseId, setCourseId] = useState('');

  // Substitute-specific fields
  const [subOrgId, setSubOrgId] = useState('');
  const [subTitle, setSubTitle] = useState('');
  const [subFor, setSubFor] = useState('');

  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('19:00');
  const [endTime, setEndTime] = useState('19:50');
  const [customDuration, setCustomDuration] = useState('50');
  const [periodLabel, setPeriodLabel] = useState<string | undefined>(undefined);
  const [selectedPeriodIds, setSelectedPeriodIds] = useState<string[]>([]);

  const [kind, setKind] = useState<Exclude<SessionKind, 'substitute'>>('regular');
  const [makeupForSessionId, setMakeupForSessionId] = useState('');

  const [isRescheduling, setIsRescheduling] = useState(false);
  const [originalDate, setOriginalDate] = useState<string | undefined>(undefined);
  const [originalStartTime, setOriginalStartTime] = useState<string | undefined>(
    undefined
  );
  const [originalEndTime, setOriginalEndTime] = useState<string | undefined>(
    undefined
  );

  const [location, setLocation] = useState('');
  const [progress, setProgress] = useState('');
  const [homework, setHomework] = useState('');
  const [note, setNote] = useState('');

  const [historyHint, setHistoryHint] = useState<string | null>(null);
  const [overlapWarnings, setOverlapWarnings] = useState<ClassSession[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);
  const [initialSnapshot, setInitialSnapshot] = useState<string | null>(null);

  const selectedCourse = useMemo(
    () => regularCourses.find((c) => c.id === courseId),
    [regularCourses, courseId]
  );

  const activePeriodOrgId =
    sessionMode === 'substitute'
      ? subOrgId || undefined
      : selectedCourse?.organizationId || undefined;

  const periods = useLiveQuery(async (): Promise<Period[]> => {
    if (!activePeriodOrgId) return [];
    const list = await db.periods
      .where('organizationId')
      .equals(activePeriodOrgId)
      .toArray();
    return list.sort((a, b) => a.startTime.localeCompare(b.startTime));
  }, [activePeriodOrgId]);

  const cancelledSessions = useLiveQuery(async () => {
    const all = await db.sessions.where('status').equals('cancelled').toArray();
    return all.sort((a, b) => b.date.localeCompare(a.date));
  }, []);

  const substituteSessionsForShortcuts = useLiveQuery(
    async (): Promise<ClassSession[]> => {
      if (!open) return [];
      return db.sessions.where('kind').equals('substitute').toArray();
    },
    [open]
  );

  const { recentTitles, recentTeachers } = useMemo(
    () => getSubstituteShortcuts(substituteSessionsForShortcuts ?? []),
    [substituteSessionsForShortcuts]
  );

  const orgMap = useMemo(() => {
    const map = new Map<string, Organization>();
    for (const o of organizations) map.set(o.id, o);
    return map;
  }, [organizations]);

  const courseMap = useMemo(() => {
    const map = new Map<string, Course>();
    for (const c of courses) map.set(c.id, c);
    return map;
  }, [courses]);

  useEffect(() => {
    if (!open) return;

    if (session) {
      const isSub = session.kind === 'substitute';
      const diff =
        session.startTime && session.endTime && session.startTime < session.endTime
          ? timeToMinutes(session.endTime) - timeToMinutes(session.startTime)
          : 0;
      setSessionMode(isSub ? 'substitute' : 'regular');
      setCourseId(
        isSub
          ? regularCourses[0]?.id ?? ''
          : (session.courseId ?? regularCourses[0]?.id ?? '')
      );
      setSubOrgId(isSub ? (session.organizationId ?? '') : '');
      setSubTitle(isSub ? session.title : '');
      setSubFor(isSub ? (session.substituteFor ?? '') : '');
      setDate(session.date);
      setStartTime(session.startTime);
      setEndTime(session.endTime);
      setCustomDuration(diff > 0 ? String(diff) : '');
      const startReschedule = Boolean(defaultStartReschedule);
      const initOrigDate =
        session.originalDate ?? (startReschedule ? session.date : undefined);
      const initOrigStart =
        session.originalStartTime ??
        (startReschedule ? session.startTime : undefined);
      const initOrigEnd =
        session.originalEndTime ??
        (startReschedule ? session.endTime : undefined);

      setPeriodLabel(session.periodLabel);
      setSelectedPeriodIds([]);
      setKind(
        session.kind === 'makeup' || session.kind === 'extra'
          ? session.kind
          : 'regular'
      );
      setMakeupForSessionId(session.makeupForSessionId ?? '');
      setIsRescheduling(startReschedule);
      setOriginalDate(initOrigDate);
      setOriginalStartTime(initOrigStart);
      setOriginalEndTime(initOrigEnd);
      setLocation(session.location ?? '');
      setProgress(session.progress ?? '');
      setHomework(session.homework ?? '');
      setNote(session.note ?? '');

      setInitialSnapshot(
        JSON.stringify({
          sessionMode: isSub ? 'substitute' : 'regular',
          courseId: isSub
            ? regularCourses[0]?.id ?? ''
            : (session.courseId ?? regularCourses[0]?.id ?? ''),
          subOrgId: isSub ? (session.organizationId ?? '') : '',
          subTitle: isSub ? session.title : '',
          subFor: isSub ? (session.substituteFor ?? '') : '',
          date: session.date,
          startTime: session.startTime,
          endTime: session.endTime,
          periodLabel: session.periodLabel ?? '',
          kind:
            session.kind === 'makeup' || session.kind === 'extra'
              ? session.kind
              : 'regular',
          makeupForSessionId: session.makeupForSessionId ?? '',
          isRescheduling: startReschedule,
          originalDate: initOrigDate ?? '',
          originalStartTime: initOrigStart ?? '',
          originalEndTime: initOrigEnd ?? '',
          location: session.location ?? '',
          progress: session.progress ?? '',
          homework: session.homework ?? '',
          note: session.note ?? '',
        })
      );
    } else {
      const targetMode: SessionFormMode =
        defaultKind === 'substitute' ? 'substitute' : defaultMode;
      const targetCourseId =
        (defaultCourseId &&
        regularCourses.some((c) => c.id === defaultCourseId)
          ? defaultCourseId
          : regularCourses[0]?.id) || '';
      const targetCourse = regularCourses.find((c) => c.id === targetCourseId);
      const duration =
        targetMode === 'substitute'
          ? 50
          : (targetCourse?.defaultDurationMinutes ?? 50);
      const defaultStart = '19:00';
      const initDate = defaultDate || toDateKey(new Date());
      const initEnd = addMinutesToTime(defaultStart, duration);
      const initKind: Exclude<SessionKind, 'substitute'> =
        defaultKind === 'makeup' || defaultKind === 'extra'
          ? defaultKind
          : 'regular';
      const initMakeup = defaultMakeupForSessionId ?? '';

      setSessionMode(targetMode);
      setCourseId(targetCourseId);
      setSubOrgId('');
      setSubTitle('');
      setSubFor('');
      setDate(initDate);
      setStartTime(defaultStart);
      setEndTime(initEnd);
      setCustomDuration(String(duration));
      setPeriodLabel(undefined);
      setSelectedPeriodIds([]);
      setKind(initKind);
      setMakeupForSessionId(initMakeup);
      setIsRescheduling(false);
      setOriginalDate(undefined);
      setOriginalStartTime(undefined);
      setOriginalEndTime(undefined);
      setLocation('');
      setProgress('');
      setHomework('');
      setNote('');

      setInitialSnapshot(
        JSON.stringify({
          sessionMode: targetMode,
          courseId: targetCourseId,
          subOrgId: '',
          subTitle: '',
          subFor: '',
          date: initDate,
          startTime: defaultStart,
          endTime: initEnd,
          periodLabel: '',
          kind: initKind,
          makeupForSessionId: initMakeup,
          isRescheduling: false,
          originalDate: '',
          originalStartTime: '',
          originalEndTime: '',
          location: '',
          progress: '',
          homework: '',
          note: '',
        })
      );
    }

    setHistoryHint(null);
    setError(null);
    setDeleteConfirmOpen(false);
    setDiscardConfirmOpen(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, session?.id, defaultMode, defaultCourseId, defaultKind, defaultDate, defaultMakeupForSessionId, defaultStartReschedule]);

  const isEditingCancelled = Boolean(session && isSessionCancelled(session));

  // Live overlap check (never blocks save)
  useEffect(() => {
    if (!open || !date || !startTime || !endTime || isEditingCancelled) {
      setOverlapWarnings([]);
      return;
    }

    let cancelled = false;
    void findOverlappingSessions(date, startTime, endTime, session?.id).then(
      (hits) => {
        if (!cancelled) {
          setOverlapWarnings(hits);
        }
      }
    );

    return () => {
      cancelled = true;
    };
  }, [open, date, startTime, endTime, isEditingCancelled, session?.id]);

  const isDirty =
    initialSnapshot !== null &&
    JSON.stringify({
      sessionMode,
      courseId,
      subOrgId,
      subTitle,
      subFor,
      date,
      startTime,
      endTime,
      periodLabel: periodLabel ?? '',
      kind,
      makeupForSessionId,
      isRescheduling,
      originalDate: originalDate ?? '',
      originalStartTime: originalStartTime ?? '',
      originalEndTime: originalEndTime ?? '',
      location,
      progress,
      homework,
      note,
    }) !== initialSnapshot;

  const handleRequestClose = () => {
    if (isSaving) return;
    if (isDirty) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: open,
    zLayer: 55,
    onBack: handleRequestClose,
  });

  if (!open) {
    return null;
  }

  const syncCustomDurationFromRange = (nextStart: string, nextEnd: string) => {
    if (nextStart && nextEnd && nextStart < nextEnd) {
      const diff = timeToMinutes(nextEnd) - timeToMinutes(nextStart);
      setCustomDuration(diff > 0 ? String(diff) : '');
    } else {
      setCustomDuration('');
    }
  };

  const handleSwitchMode = (nextMode: SessionFormMode) => {
    if (nextMode === sessionMode) return;
    setSessionMode(nextMode);
    setSelectedPeriodIds([]);
    setPeriodLabel(undefined);
    setHistoryHint(null);
    if (nextMode === 'regular' && !courseId && regularCourses[0]) {
      setCourseId(regularCourses[0].id);
    }
    if (error) setError(null);
  };

  const handleApplyDuration = (mins: number) => {
    setCustomDuration(String(mins));
    if (startTime) {
      setEndTime(addMinutesToTime(startTime, mins));
    }
    setPeriodLabel(undefined);
    setSelectedPeriodIds([]);
    if (error) setError(null);
  };

  const handleCustomDurationChange = (val: string) => {
    setCustomDuration(val);
    const parsed = Number.parseInt(val, 10);
    if (Number.isFinite(parsed) && parsed > 0 && parsed <= 720 && startTime) {
      setEndTime(addMinutesToTime(startTime, parsed));
    }
    setPeriodLabel(undefined);
    setSelectedPeriodIds([]);
    if (error) setError(null);
  };

  const handleUseLastTime = async () => {
    if (!courseId) {
      setHistoryHint('請先選擇課程');
      return;
    }
    const last = await getLastCourseSessionTime(courseId, session?.id);
    if (!last) {
      setHistoryHint('這門課目前還沒有歷史場次紀錄');
      return;
    }
    setStartTime(last.startTime);
    setEndTime(last.endTime);
    syncCustomDurationFromRange(last.startTime, last.endTime);
    setPeriodLabel(last.periodLabel);
    setSelectedPeriodIds([]);
    setHistoryHint(`已帶入上次時間 ${last.startTime}–${last.endTime}`);
    if (error) setError(null);
  };

  const handlePeriodSelectionChange = (
    selection: {
      selectedPeriodIds: string[];
      startTime: string;
      endTime: string;
      periodLabel?: string;
    } | null
  ) => {
    if (!selection) {
      setSelectedPeriodIds([]);
      setPeriodLabel(undefined);
      return;
    }
    setSelectedPeriodIds(selection.selectedPeriodIds);
    setStartTime(selection.startTime);
    setEndTime(selection.endTime);
    syncCustomDurationFromRange(selection.startTime, selection.endTime);
    setPeriodLabel(selection.periodLabel);
    if (error) setError(null);
  };

  const handleStartReschedule = () => {
    if (!session) return;
    setIsRescheduling(true);
    if (!originalDate) {
      setOriginalDate(session.date);
      setOriginalStartTime(session.startTime);
      setOriginalEndTime(session.endTime);
    }
  };

  const handleCancelReschedule = () => {
    if (!session) return;
    setIsRescheduling(false);
    setDate(session.date);
    setStartTime(session.startTime);
    setEndTime(session.endTime);
    syncCustomDurationFromRange(session.startTime, session.endTime);
    setOriginalDate(session.originalDate);
    setOriginalStartTime(session.originalStartTime);
    setOriginalEndTime(session.originalEndTime);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (sessionMode === 'regular') {
      if (!courseId) {
        setError('請選擇課程');
        return;
      }
    } else {
      if (!subTitle.trim()) {
        setError('請填寫班級／課名');
        return;
      }
    }
    if (!date) {
      setError('請選擇日期');
      return;
    }
    if (!startTime || !endTime || startTime >= endTime) {
      setError('結束時間必須晚於開始時間');
      return;
    }

    setIsSaving(true);
    try {
      const now = Date.now();
      const preservedStatus = session?.status ?? 'scheduled';
      const preservedCancelReason =
        session && isSessionCancelled(session) ? session.cancelReason : undefined;

      // Preserve original scheduled time if rescheduling or already rescheduled
      let finalOrigDate = originalDate;
      let finalOrigStart = originalStartTime;
      let finalOrigEnd = originalEndTime;

      if (session && isRescheduling && !finalOrigDate) {
        finalOrigDate = session.date;
        finalOrigStart = session.startTime;
        finalOrigEnd = session.endTime;
      }

      if (sessionMode === 'substitute') {
        const systemCourse = await ensureSubstituteSystemCourseForDate(date);
        const trimmedTitle = subTitle.trim();
        const trimmedSubFor = subFor.trim() || undefined;

        const record: ClassSession = {
          id: session?.id ?? createId(),
          courseId: systemCourse.id,
          organizationId: subOrgId || undefined,
          title: trimmedTitle,
          substituteFor: trimmedSubFor,
          date,
          startTime,
          endTime,
          periodLabel,
          status: preservedStatus,
          kind: 'substitute',
          cancelReason: preservedCancelReason,
          makeupForSessionId: undefined,
          originalDate: finalOrigDate,
          originalStartTime: finalOrigStart,
          originalEndTime: finalOrigEnd,
          batchId: session?.batchId,
          location: location.trim() || undefined,
          progress: progress.trim() || undefined,
          homework: homework.trim() || undefined,
          note: note.trim() || undefined,
          createdAt: session?.createdAt ?? now,
          updatedAt: now,
        };

        await db.sessions.put(record);
        recordSubstituteShortcuts(trimmedTitle, trimmedSubFor);
        onClose();
        return;
      }

      const targetCourse = regularCourses.find((c) => c.id === courseId);
      const record: ClassSession = {
        id: session?.id ?? createId(),
        courseId,
        organizationId: undefined,
        title: targetCourse?.name ?? session?.title ?? '課程場次',
        substituteFor: undefined,
        date,
        startTime,
        endTime,
        periodLabel,
        status: preservedStatus,
        kind,
        cancelReason: preservedCancelReason,
        makeupForSessionId:
          kind === 'makeup' ? makeupForSessionId || undefined : undefined,
        originalDate: finalOrigDate,
        originalStartTime: finalOrigStart,
        originalEndTime: finalOrigEnd,
        batchId: session?.batchId,
        location: location.trim() || undefined,
        progress: progress.trim() || undefined,
        homework: homework.trim() || undefined,
        note: note.trim() || undefined,
        createdAt: session?.createdAt ?? now,
        updatedAt: now,
      };

      await db.sessions.put(record);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const handleConfirmDeleteSingle = async () => {
    if (!session) return;
    setIsSaving(true);
    try {
      await deleteMultipleSessions([session.id]);
      setDeleteConfirmOpen(false);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="session-modal-title"
        className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
      >
        <div className="flex max-h-[90dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 bg-white px-4 py-3">
            <h2 id="session-modal-title" className="text-base font-semibold text-zinc-900">
              {session
                ? sessionMode === 'substitute'
                  ? '編輯代課／臨時場次'
                  : '編輯場次'
                : sessionMode === 'substitute'
                  ? '新增代課／臨時場次'
                  : '新增場次'}
            </h2>
            <button
              type="button"
              onClick={handleRequestClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
            >
              <X size={20} />
            </button>
          </div>

          <form
            onSubmit={(e) => void handleSubmit(e)}
            className="flex min-h-0 flex-1 flex-col"
          >
            <div className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-4 scroll-mb-6">
              {/* 最上方類型切換：一般課（預設）／代課／臨時 */}
              <div
                role="tablist"
                aria-label="場次類型"
                className="grid grid-cols-2 gap-1.5 rounded-2xl border border-zinc-200 bg-zinc-50 p-1"
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={sessionMode === 'regular'}
                  onClick={() => handleSwitchMode('regular')}
                  className={`flex min-h-[44px] items-center justify-center rounded-xl text-sm font-medium transition-colors ${
                    sessionMode === 'regular'
                      ? 'bg-[#CDB8FF] font-semibold text-zinc-900 shadow-xs'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  一般課
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={sessionMode === 'substitute'}
                  onClick={() => handleSwitchMode('substitute')}
                  className={`flex min-h-[44px] items-center justify-center rounded-xl text-sm font-medium transition-colors ${
                    sessionMode === 'substitute'
                      ? 'bg-[#FEF3C7] font-semibold text-amber-950 ring-1 ring-inset ring-amber-300 shadow-xs'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  代課／臨時
                </button>
              </div>

              {sessionMode === 'regular' ? (
                <div>
                  <label
                    htmlFor="session-course-select"
                    className="block text-sm font-medium text-zinc-800"
                  >
                    課程 <span className="text-rose-600">*</span>
                  </label>
                  <select
                    id="session-course-select"
                    value={courseId}
                    onChange={(e) => {
                      setCourseId(e.target.value);
                      setSelectedPeriodIds([]);
                      setPeriodLabel(undefined);
                      setHistoryHint(null);
                      if (error) setError(null);
                    }}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  >
                    {regularCourses.length === 0 ? (
                      <option value="">尚無課程，可改切上方「代課／臨時」</option>
                    ) : (
                      regularCourses.map((c) => {
                        const org = orgMap.get(c.organizationId);
                        return (
                          <option key={c.id} value={c.id}>
                            {c.name}
                            {org ? `（${org.name}）` : ''}
                          </option>
                        );
                      })
                    )}
                  </select>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <label
                      htmlFor="session-sub-org-select"
                      className="block text-sm font-medium text-zinc-800"
                    >
                      單位（選填）
                    </label>
                    <select
                      id="session-sub-org-select"
                      value={subOrgId}
                      onChange={(e) => {
                        setSubOrgId(e.target.value);
                        setSelectedPeriodIds([]);
                        setPeriodLabel(undefined);
                        if (error) setError(null);
                      }}
                      className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                    >
                      <option value="">不指定</option>
                      {organizations.map((org) => (
                        <option key={org.id} value={org.id}>
                          {org.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="session-sub-title-input"
                      className="block text-sm font-medium text-zinc-800"
                    >
                      班級／課名 <span className="text-rose-600">*</span>
                    </label>
                    <input
                      id="session-sub-title-input"
                      type="text"
                      value={subTitle}
                      onChange={(e) => {
                        setSubTitle(e.target.value);
                        if (error) setError(null);
                      }}
                      placeholder="例如：國一C班 體育"
                      className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                    />
                    {recentTitles.length > 0 && (
                      <div className="mt-2">
                        <span className="block text-xs font-medium text-zinc-500">
                          最近使用過的班級／課名
                        </span>
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {recentTitles.map((item) => {
                            const active = subTitle.trim() === item;
                            return (
                              <button
                                key={item}
                                type="button"
                                onClick={() => {
                                  setSubTitle(item);
                                  if (error) setError(null);
                                }}
                                className={`flex min-h-[44px] max-w-full items-center rounded-xl border px-3 py-1.5 text-xs font-medium transition-colors ${
                                  active
                                    ? 'border-amber-500 bg-[#FEF3C7] font-semibold text-amber-950'
                                    : 'border-zinc-200 bg-zinc-50 text-zinc-800 hover:bg-zinc-100'
                                }`}
                              >
                                <span className="truncate">{item}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="session-sub-for-input"
                      className="block text-sm font-medium text-zinc-800"
                    >
                      代誰的課（選填）
                    </label>
                    <input
                      id="session-sub-for-input"
                      type="text"
                      value={subFor}
                      onChange={(e) => setSubFor(e.target.value)}
                      placeholder="例如：陳老師"
                      className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                    />
                    {recentTeachers.length > 0 && (
                      <div className="mt-2">
                        <span className="block text-xs font-medium text-zinc-500">
                          最近代課對象
                        </span>
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {recentTeachers.map((teacher) => {
                            const active = subFor.trim() === teacher;
                            return (
                              <button
                                key={teacher}
                                type="button"
                                onClick={() => setSubFor(teacher)}
                                className={`flex min-h-[44px] max-w-full items-center rounded-xl border px-3 py-1.5 text-xs font-medium transition-colors ${
                                  active
                                    ? 'border-amber-500 bg-[#FEF3C7] font-semibold text-amber-950'
                                    : 'border-zinc-200 bg-zinc-50 text-zinc-800 hover:bg-zinc-100'
                                }`}
                              >
                                <span className="truncate">{teacher}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {session && (
                <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-zinc-200 bg-zinc-50/70 px-3 py-2.5">
                  <div className="text-xs text-zinc-600">
                    {originalDate && originalStartTime ? (
                      <span className="font-medium text-violet-800">
                        調課：原定 {formatSlashDate(originalDate)} {originalStartTime}
                      </span>
                    ) : (
                      <span>需要改到其他日期或時間？</span>
                    )}
                  </div>
                  {!isRescheduling ? (
                    <button
                      type="button"
                      onClick={handleStartReschedule}
                      className="flex min-h-[44px] items-center justify-center rounded-xl border border-violet-300 bg-[#F2ECFF] px-3 text-xs font-semibold text-zinc-900 hover:bg-[#e8ddff]"
                    >
                      改期（調課）
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleCancelReschedule}
                      className="flex min-h-[44px] items-center justify-center rounded-xl border border-zinc-200 bg-white px-3 text-xs font-medium text-zinc-700 hover:bg-zinc-50"
                    >
                      取消改期
                    </button>
                  )}
                </div>
              )}

              <div>
                <label
                  htmlFor="session-date-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  {isRescheduling ? '新上課日期' : '日期'}{' '}
                  <span className="text-rose-600">*</span>
                </label>
                <input
                  id="session-date-input"
                  type="date"
                  value={date}
                  onChange={(e) => {
                    setDate(e.target.value);
                    if (error) setError(null);
                  }}
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              <div className="space-y-2.5">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div className="min-w-0">
                    <label
                      htmlFor="session-start-input"
                      className="block text-sm font-medium text-zinc-800"
                    >
                      開始時間 <span className="text-rose-600">*</span>
                    </label>
                    <input
                      id="session-start-input"
                      type="time"
                      value={startTime}
                      onChange={(e) => {
                        const nextStart = e.target.value;
                        setStartTime(nextStart);
                        syncCustomDurationFromRange(nextStart, endTime);
                        setPeriodLabel(undefined);
                        setSelectedPeriodIds([]);
                        if (error) setError(null);
                      }}
                      className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                    />
                  </div>
                  <div className="min-w-0">
                    <label
                      htmlFor="session-end-input"
                      className="block text-sm font-medium text-zinc-800"
                    >
                      結束時間 <span className="text-rose-600">*</span>
                    </label>
                    <input
                      id="session-end-input"
                      type="time"
                      value={endTime}
                      onChange={(e) => {
                        const nextEnd = e.target.value;
                        setEndTime(nextEnd);
                        syncCustomDurationFromRange(startTime, nextEnd);
                        setPeriodLabel(undefined);
                        setSelectedPeriodIds([]);
                        if (error) setError(null);
                      }}
                      className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                    />
                  </div>
                </div>

                {/* Shortcut (a): Duration buttons + custom minutes */}
                <DurationSelector
                  label="快捷時長（依開始時間推算結束時間）"
                  activeMinutes={
                    startTime && endTime && startTime < endTime
                      ? timeToMinutes(endTime) - timeToMinutes(startTime)
                      : null
                  }
                  customValue={customDuration}
                  onSelectPreset={handleApplyDuration}
                  onCustomChange={handleCustomDurationChange}
                />

                {/* Shortcut (b): Use last session time (一般課才顯示) */}
                {sessionMode === 'regular' && (
                  <div>
                    <button
                      type="button"
                      onClick={() => {
                        void handleUseLastTime();
                      }}
                      className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl border border-violet-200 bg-[#F2ECFF]/70 px-3 text-xs font-semibold text-zinc-900 transition-colors hover:bg-[#F2ECFF]"
                    >
                      <History size={14} aria-hidden="true" />
                      <span>沿用這門課上次的時間</span>
                    </button>
                    {historyHint && (
                      <p className="mt-1 text-xs text-zinc-600">{historyHint}</p>
                    )}
                  </div>
                )}

                {/* Shortcut (c): Organization periods multi-select */}
                {periods && periods.length > 0 && activePeriodOrgId && (
                  <PeriodMultiSelector
                    organizationName={orgMap.get(activePeriodOrgId)?.name}
                    periods={periods}
                    selectedPeriodIds={selectedPeriodIds}
                    periodLabel={periodLabel}
                    onChange={handlePeriodSelectionChange}
                  />
                )}
              </div>

              {overlapWarnings.length > 0 && (
                <div
                  role="status"
                  className="rounded-xl border border-amber-300 bg-amber-50 p-3 text-xs leading-relaxed text-amber-950"
                >
                  <div className="flex items-start gap-2">
                    <AlertTriangle
                      size={16}
                      className="mt-0.5 shrink-0 text-amber-700"
                      aria-hidden="true"
                    />
                    <div className="space-y-1">
                      <p className="font-semibold">
                        時間重疊警示（不阻擋儲存，仍可建立）
                      </p>
                      <ul className="space-y-0.5">
                        {overlapWarnings.map((w) => {
                          const resolved = resolveSessionDisplay(
                            w,
                            courseMap,
                            orgMap
                          );
                          return (
                            <li key={w.id} className="tabular-nums">
                              與 {w.startTime}–{w.endTime} {resolved.title}
                              {resolved.organization
                                ? `（${resolved.organization.name}）`
                                : ''}
                              {resolved.isSubstitute ? '［代課］' : ''} 重疊
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {isEditingCancelled && session && (
                <div className="rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 py-2.5 text-xs text-zinc-600">
                  此場次目前已取消
                  {session.cancelReason ? `（原因：${session.cancelReason}）` : ''}
                  ，若需恢復上課可於場次卡片或場次頁「⋯」選單點選「恢復」。
                </div>
              )}

              {sessionMode === 'regular' && (
                <>
                  <div>
                    <span className="block text-sm font-medium text-zinc-800">種類</span>
                    <div className="mt-1.5 grid grid-cols-3 gap-2">
                      {KIND_OPTIONS.map((opt) => {
                        const active = kind === opt.value;
                        return (
                          <button
                            key={opt.value}
                            type="button"
                            onClick={() => setKind(opt.value)}
                            className={`flex min-h-[44px] items-center justify-center rounded-xl border text-sm font-medium transition-colors ${
                              active
                                ? 'border-violet-600 bg-[#F2ECFF] text-zinc-900 font-semibold'
                                : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {kind === 'makeup' && (
                    <div>
                      <label
                        htmlFor="session-makeup-link"
                        className="block text-sm font-medium text-zinc-800"
                      >
                        對應已取消場次（選填）
                      </label>
                      <select
                        id="session-makeup-link"
                        value={makeupForSessionId}
                        onChange={(e) => setMakeupForSessionId(e.target.value)}
                        className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                      >
                        <option value="">不指定（或尚無已取消場次）</option>
                        {(cancelledSessions ?? []).map((cs) => {
                          const resolved = resolveSessionDisplay(
                            cs,
                            courseMap,
                            orgMap
                          );
                          return (
                            <option key={cs.id} value={cs.id}>
                              {formatSlashDate(cs.date)} {cs.startTime} ·{' '}
                              {resolved.title}
                              {cs.cancelReason ? `（${cs.cancelReason}）` : ''}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                  )}
                </>
              )}

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="session-location-input"
                    className="block text-sm font-medium text-zinc-800"
                  >
                    地點（選填）
                  </label>
                  <input
                    id="session-location-input"
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="例如：操場、302教室"
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>
                <div>
                  <label
                    htmlFor="session-progress-input"
                    className="block text-sm font-medium text-zinc-800"
                  >
                    {sessionMode === 'substitute'
                      ? '進度／內容（選填）'
                      : '進度（選填）'}
                  </label>
                  <input
                    id="session-progress-input"
                    type="text"
                    value={progress}
                    onChange={(e) => setProgress(e.target.value)}
                    placeholder={
                      sessionMode === 'substitute'
                        ? '例如：代看自習、籃球基本運球'
                        : '例如：第3章 浮力 p.42–48'
                    }
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="session-homework-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  作業（選填）
                </label>
                <input
                  id="session-homework-input"
                  type="text"
                  value={homework}
                  onChange={(e) => setHomework(e.target.value)}
                  placeholder="例如：講義習題 1–15 題"
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              <div>
                <label
                  htmlFor="session-note-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  備註（選填）
                </label>
                <textarea
                  id="session-note-input"
                  rows={2}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="課堂事項或備忘"
                  className="mt-1.5 w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              {error && (
                <p className="text-xs font-medium text-rose-600">{error}</p>
              )}

              {session && (
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => setDeleteConfirmOpen(true)}
                    disabled={isSaving}
                    className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl border border-rose-200 bg-white px-4 py-2.5 text-sm font-medium text-rose-600 transition-colors hover:bg-rose-50 disabled:opacity-60"
                  >
                    <Trash2 size={16} aria-hidden="true" />
                    <span>刪除此場次</span>
                  </button>
                </div>
              )}
            </div>

            <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
              <button
                type="submit"
                disabled={isSaving}
                className="flex min-h-[44px] w-full items-center justify-center rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-violet-700 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2"
              >
                {isSaving ? '儲存中…' : session ? '儲存場次' : '建立場次'}
              </button>
            </div>
          </form>
        </div>
      </div>

      <ConfirmDialog
        open={deleteConfirmOpen}
        title="刪除場次"
        description={
          session
            ? `確定要刪除 ${formatSlashDate(session.date)} ${session.startTime} 的場次嗎？`
            : ''
        }
        confirmLabel="確認刪除"
        isSubmitting={isSaving}
        onCancel={() => setDeleteConfirmOpen(false)}
        onConfirm={() => {
          void handleConfirmDeleteSingle();
        }}
      />

      <ConfirmDialog
        open={discardConfirmOpen}
        title="放棄未儲存的內容？"
        description="目前有尚未儲存的修改，確定要放棄並返回嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardConfirmOpen(false)}
        onConfirm={() => {
          setDiscardConfirmOpen(false);
          onClose();
        }}
      />
    </>
  );
}
