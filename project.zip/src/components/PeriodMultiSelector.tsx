import type { Period } from '../db/types';

export interface PeriodSelectionResult {
  selectedPeriodIds: string[];
  startTime: string;
  endTime: string;
  periodLabel?: string;
}

interface PeriodMultiSelectorProps {
  organizationName?: string;
  periods: Period[];
  selectedPeriodIds: string[];
  periodLabel?: string;
  onChange: (result: PeriodSelectionResult | null) => void;
}

export function PeriodMultiSelector({
  organizationName,
  periods,
  selectedPeriodIds,
  periodLabel,
  onChange,
}: PeriodMultiSelectorProps) {
  if (periods.length === 0) {
    return null;
  }

  const handleTogglePeriod = (periodIndex: number) => {
    let nextIndices: number[];
    const currentIndices = selectedPeriodIds
      .map((id) => periods.findIndex((p) => p.id === id))
      .filter((idx) => idx !== -1)
      .sort((a, b) => a - b);

    if (currentIndices.length === 0) {
      nextIndices = [periodIndex];
    } else {
      const minIdx = currentIndices[0];
      const maxIdx = currentIndices[currentIndices.length - 1];

      if (currentIndices.includes(periodIndex)) {
        if (currentIndices.length === 1) {
          nextIndices = [];
        } else if (periodIndex === minIdx) {
          nextIndices = currentIndices.slice(1);
        } else if (periodIndex === maxIdx) {
          nextIndices = currentIndices.slice(0, -1);
        } else {
          nextIndices = [periodIndex];
        }
      } else if (periodIndex === minIdx - 1) {
        nextIndices = [periodIndex, ...currentIndices];
      } else if (periodIndex === maxIdx + 1) {
        nextIndices = [...currentIndices, periodIndex];
      } else {
        // Non-adjacent tap starts a new selection from the clicked period
        nextIndices = [periodIndex];
      }
    }

    if (nextIndices.length === 0) {
      onChange(null);
      return;
    }

    const chosen = nextIndices.map((i) => periods[i]);
    const nextLabel =
      chosen.length === 1
        ? chosen[0].name
        : `${chosen[0].name}–${chosen[chosen.length - 1].name}`;

    onChange({
      selectedPeriodIds: chosen.map((p) => p.id),
      startTime: chosen[0].startTime,
      endTime: chosen[chosen.length - 1].endTime,
      periodLabel: nextLabel,
    });
  };

  return (
    <div className="space-y-1.5 rounded-xl border border-zinc-200 bg-zinc-50/50 p-3">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-medium text-zinc-700">
          {organizationName ?? '單位'}節次表（可連選連續節次）
        </span>
        {periodLabel && (
          <span className="text-xs font-semibold text-violet-700">
            {periodLabel}
          </span>
        )}
      </div>
      <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
        {periods.map((p, index) => {
          const active = selectedPeriodIds.includes(p.id);
          return (
            <button
              key={p.id}
              type="button"
              aria-pressed={active}
              onClick={() => handleTogglePeriod(index)}
              className={`flex min-h-[44px] flex-col items-start justify-center rounded-xl px-2.5 py-1.5 text-left transition-colors ${
                active
                  ? 'border-2 border-violet-600 bg-[#EDE6FF] text-zinc-900'
                  : 'border border-zinc-200 bg-white text-zinc-800 hover:bg-zinc-50'
              }`}
            >
              <span className="text-xs font-semibold">{p.name}</span>
              <span className="text-[11px] text-zinc-600 tabular-nums">
                {p.startTime}–{p.endTime}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
