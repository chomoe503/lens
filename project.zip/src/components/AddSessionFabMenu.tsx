import { CalendarPlus, Plus, UserCheck, X } from 'lucide-react';
import { useState } from 'react';
import { useBackLayer } from '../utils/backNavigation';
import { useIsKeyboardActive } from '../utils/useKeyboardAware';

interface AddSessionFabMenuProps {
  onSelectRegular: () => void;
  onSelectSubstitute: () => void;
}

export function AddSessionFabMenu({
  onSelectRegular,
  onSelectSubstitute,
}: AddSessionFabMenuProps) {
  const isKeyboardActive = useIsKeyboardActive();
  const [expanded, setExpanded] = useState(false);

  useBackLayer({
    active: expanded && !isKeyboardActive,
    zLayer: 20,
    onBack: () => setExpanded(false),
  });

  if (isKeyboardActive) {
    return null;
  }

  return (
    <>
      {expanded && (
        <button
          type="button"
          aria-label="關閉新增選單"
          onClick={() => setExpanded(false)}
          className="fixed inset-0 z-20 bg-black/20 backdrop-blur-[1px]"
        />
      )}

      <div className="pointer-events-none fixed inset-x-0 bottom-[calc(var(--bottom-nav-height)+env(safe-area-inset-bottom)+1rem)] z-20">
        <div className="mx-auto flex w-full max-w-2xl flex-col items-end gap-2.5 px-4">
          {expanded && (
            <div
              role="menu"
              aria-label="新增場次類型"
              className="pointer-events-auto flex flex-col items-end gap-2"
            >
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  setExpanded(false);
                  onSelectSubstitute();
                }}
                className="flex min-h-[44px] items-center gap-2.5 rounded-2xl border border-amber-300 bg-[#FEF3C7] px-4 py-2.5 text-sm font-semibold text-amber-950 shadow-lg transition-transform duration-150 hover:bg-amber-100 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-600 whitespace-nowrap"
              >
                <UserCheck size={17} aria-hidden="true" />
                <span>臨時代課</span>
              </button>

              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  setExpanded(false);
                  onSelectRegular();
                }}
                className="flex min-h-[44px] items-center gap-2.5 rounded-2xl border border-violet-200 bg-white px-4 py-2.5 text-sm font-semibold text-zinc-900 shadow-lg transition-transform duration-150 hover:bg-violet-50 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 whitespace-nowrap"
              >
                <CalendarPlus size={17} className="text-violet-700" aria-hidden="true" />
                <span>新增場次</span>
              </button>
            </div>
          )}

          <button
            type="button"
            aria-expanded={expanded}
            aria-haspopup="menu"
            aria-label={expanded ? '收合新增選單' : '新增場次或臨時代課'}
            onClick={() => setExpanded((prev) => !prev)}
            className={`pointer-events-auto flex h-14 w-14 items-center justify-center rounded-2xl text-white shadow-lg transition-all duration-150 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2 ${
              expanded
                ? 'bg-zinc-800 hover:bg-zinc-900 shadow-zinc-900/20'
                : 'bg-violet-600 hover:bg-violet-700 shadow-violet-900/20'
            }`}
          >
            {expanded ? (
              <X size={24} strokeWidth={2.25} aria-hidden="true" />
            ) : (
              <Plus size={24} strokeWidth={2.25} aria-hidden="true" />
            )}
          </button>
        </div>
      </div>
    </>
  );
}
