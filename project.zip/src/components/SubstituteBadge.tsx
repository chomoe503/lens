interface SubstituteBadgeProps {
  compact?: boolean;
}

export function SubstituteBadge({ compact = false }: SubstituteBadgeProps) {
  return (
    <span
      className={`inline-flex shrink-0 items-center rounded-md bg-[#FEF3C7] font-semibold leading-none text-amber-950 ring-1 ring-inset ring-amber-300/80 ${
        compact ? 'px-1 py-0.5 text-[10px]' : 'px-1.5 py-0.5 text-[11px]'
      }`}
    >
      代課
    </span>
  );
}
