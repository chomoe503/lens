import { Check, Plus, Trash2, X } from 'lucide-react';
import { useEffect, useMemo, useState, type FormEvent, type KeyboardEvent } from 'react';
import { db } from '../db/database';
import {
  deleteOrganizationCascade,
  getOrganizationDeleteSummary,
  getRemovedStudentSchoolsSummary,
  saveOrganizationWithPeriods,
} from '../db/repositories';
import type {
  Organization,
  OrganizationType,
  Period,
  StudentSchool,
} from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import { DEFAULT_ORG_COLOR, ORGANIZATION_TYPE_LABELS } from '../utils/colors';
import { createId } from '../utils/id';
import { validatePeriodsList } from '../utils/periodSchedule';
import { ColorPickerGrid } from './ColorPickerGrid';
import { ConfirmDialog } from './ConfirmDialog';
import { PeriodScheduleEditor } from './PeriodScheduleEditor';

interface OrganizationFormModalProps {
  open: boolean;
  organization: Organization | null;
  onClose: () => void;
  onSaved?: (savedId: string) => void;
}

const ORG_TYPES: OrganizationType[] = ['school', 'cram_school', 'other'];
const MAX_SCHOOL_NAME_CHARS = 10;

function limitSchoolNameLength(raw: string): string {
  return Array.from(raw.trim()).slice(0, MAX_SCHOOL_NAME_CHARS).join('');
}

export function OrganizationFormModal({
  open,
  organization,
  onClose,
  onSaved,
}: OrganizationFormModalProps) {
  const [name, setName] = useState('');
  const [type, setType] = useState<OrganizationType>('school');
  const [color, setColor] = useState<string>(DEFAULT_ORG_COLOR);
  const [periods, setPeriods] = useState<Period[]>([]);
  const [studentSchools, setStudentSchools] = useState<StudentSchool[]>([]);
  const [schoolInput, setSchoolInput] = useState('');
  const [schoolHint, setSchoolHint] = useState<string | null>(null);
  const [editingSchoolId, setEditingSchoolId] = useState<string | null>(null);
  const [editingSchoolName, setEditingSchoolName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteSummary, setDeleteSummary] = useState<{
    courseCount: number;
    sessionCount: number;
    imageCount: number;
    examPeriodCount: number;
  } | null>(null);
  const [removeSchoolDialog, setRemoveSchoolDialog] = useState<{
    removedNames: string[];
    removedIds: string[];
    examPeriodCount: number;
    courseCount: number;
  } | null>(null);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);
  const [initialSnapshot, setInitialSnapshot] = useState<string | null>(null);

  const periodErrors = useMemo(() => validatePeriodsList(periods), [periods]);

  useEffect(() => {
    if (!open) return;

    let cancelled = false;
    setInitialSnapshot(null);

    if (organization) {
      const initSchools = (organization.studentSchools ?? []).map((s) => ({
        ...s,
      }));
      setName(organization.name);
      setType(organization.type);
      setColor(organization.color);
      setStudentSchools(initSchools);
      void db.periods
        .where('organizationId')
        .equals(organization.id)
        .toArray()
        .then((rows) => {
          if (cancelled) return;
          rows.sort((a, b) => a.startTime.localeCompare(b.startTime));
          setPeriods(rows);
          setInitialSnapshot(
            JSON.stringify({
              name: organization.name,
              type: organization.type,
              color: organization.color,
              periods: rows,
              studentSchools: initSchools,
            })
          );
        });
    } else {
      setName('');
      setType('school');
      setColor(DEFAULT_ORG_COLOR);
      setPeriods([]);
      setStudentSchools([]);
      setInitialSnapshot(
        JSON.stringify({
          name: '',
          type: 'school',
          color: DEFAULT_ORG_COLOR,
          periods: [],
          studentSchools: [],
        })
      );
    }

    setSchoolInput('');
    setSchoolHint(null);
    setEditingSchoolId(null);
    setEditingSchoolName('');
    setError(null);
    setDeleteDialogOpen(false);
    setDeleteSummary(null);
    setRemoveSchoolDialog(null);
    setDiscardConfirmOpen(false);

    return () => {
      cancelled = true;
    };
  }, [open, organization]);

  const isDirty =
    initialSnapshot !== null &&
    JSON.stringify({ name, type, color, periods, studentSchools }) !==
      initialSnapshot;

  const handleRequestClose = () => {
    if (isSaving) return;
    if (isDirty) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: open,
    zLayer: 55,
    onBack: handleRequestClose,
  });

  if (!open) {
    return null;
  }

  const showStudentSchoolsSection =
    type !== 'school' || studentSchools.length > 0;

  const mergeSchoolInput = (
    currentSchools: StudentSchool[],
    rawInput: string
  ): {
    nextSchools: StudentSchool[];
    addedCount: number;
    skipped: string[];
  } => {
    const rawTokens = rawInput
      .split(/[\s、,，]+/)
      .map((t) => limitSchoolNameLength(t))
      .filter((t) => t.length > 0);

    if (rawTokens.length === 0) {
      return { nextSchools: currentSchools, addedCount: 0, skipped: [] };
    }

    const existingKeys = new Set(
      currentSchools.map((s) => s.name.trim().toLowerCase())
    );
    const added: StudentSchool[] = [];
    const skipped: string[] = [];

    for (const token of rawTokens) {
      const key = token.toLowerCase();
      if (existingKeys.has(key)) {
        skipped.push(token);
        continue;
      }
      existingKeys.add(key);
      added.push({
        id: createId(),
        name: token,
      });
    }

    return {
      nextSchools:
        added.length > 0 ? [...currentSchools, ...added] : currentSchools,
      addedCount: added.length,
      skipped,
    };
  };

  const applyPendingSchoolInput = (): StudentSchool[] => {
    const { nextSchools, addedCount, skipped } = mergeSchoolInput(
      studentSchools,
      schoolInput
    );
    if (addedCount > 0) {
      setStudentSchools(nextSchools);
    }
    setSchoolInput('');
    if (skipped.length > 0) {
      setSchoolHint(`已略過重複的學校名稱：${skipped.join('、')}`);
    } else {
      setSchoolHint(null);
    }
    return nextSchools;
  };

  const handleAddSchools = () => {
    applyPendingSchoolInput();
  };

  const handleSchoolInputKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddSchools();
    }
  };

  const handleCommitInlineEdit = () => {
    if (!editingSchoolId) return;
    const nextName = limitSchoolNameLength(editingSchoolName);
    if (!nextName) {
      setEditingSchoolId(null);
      setEditingSchoolName('');
      return;
    }

    const duplicate = studentSchools.some(
      (s) =>
        s.id !== editingSchoolId &&
        s.name.trim().toLowerCase() === nextName.toLowerCase()
    );
    if (duplicate) {
      setSchoolHint(`「${nextName}」已存在，未變更名稱`);
      setEditingSchoolId(null);
      setEditingSchoolName('');
      return;
    }

    setStudentSchools((prev) =>
      prev.map((s) =>
        s.id === editingSchoolId ? { ...s, name: nextName } : s
      )
    );
    setSchoolHint(null);
    setEditingSchoolId(null);
    setEditingSchoolName('');
  };

  const handleRemoveDraftSchool = (schoolId: string) => {
    setStudentSchools((prev) => prev.filter((s) => s.id !== schoolId));
    if (editingSchoolId === schoolId) {
      setEditingSchoolId(null);
      setEditingSchoolName('');
    }
    setSchoolHint(null);
  };

  const performSave = async (
    removedIds: string[],
    schoolsOverride?: StudentSchool[]
  ) => {
    const trimmedName = name.trim();
    setIsSaving(true);
    try {
      const now = Date.now();
      const id = organization?.id ?? createId();
      const sortedPeriods = [...periods]
        .map((p) => ({ ...p, name: p.name.trim() }))
        .sort((a, b) => a.startTime.localeCompare(b.startTime));

      const schoolsSource = schoolsOverride ?? studentSchools;
      const normalizedSchools =
        schoolsSource.length > 0
          ? schoolsSource.map((s) => ({
              id: s.id,
              name: limitSchoolNameLength(s.name),
            }))
          : undefined;

      await saveOrganizationWithPeriods(
        {
          id,
          name: trimmedName,
          type,
          color,
          studentSchools: normalizedSchools,
          createdAt: organization?.createdAt ?? now,
          updatedAt: now,
        },
        sortedPeriods,
        removedIds
      );
      onSaved?.(id);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    if (!trimmedName) {
      setError('請輸入單位名稱');
      return;
    }
    if (periodErrors.size > 0) {
      setError('節次表有錯誤或時間重疊的項目，請先修正後再儲存');
      return;
    }

    const effectiveSchools =
      showStudentSchoolsSection && schoolInput.trim().length > 0
        ? applyPendingSchoolInput()
        : studentSchools;

    if (organization) {
      const origSchools = organization.studentSchools ?? [];
      const draftIdSet = new Set(effectiveSchools.map((s) => s.id));
      const removed = origSchools.filter((s) => !draftIdSet.has(s.id));

      if (removed.length > 0) {
        const removedIds = removed.map((s) => s.id);
        const summary = await getRemovedStudentSchoolsSummary(
          organization.id,
          removedIds
        );
        setRemoveSchoolDialog({
          removedNames: removed.map((s) => s.name),
          removedIds,
          examPeriodCount: summary.examPeriodCount,
          courseCount: summary.courseCount,
        });
        return;
      }
    }

    await performSave([], effectiveSchools);
  };

  const handleOpenDelete = async () => {
    if (!organization) return;
    const summary = await getOrganizationDeleteSummary(organization.id);
    setDeleteSummary(summary);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!organization) return;
    setIsSaving(true);
    try {
      await deleteOrganizationCascade(organization.id);
      setDeleteDialogOpen(false);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const deleteDescription = organization
    ? `確定要刪除單位「${organization.name}」嗎？這將會連同底下的 ${
        deleteSummary?.courseCount ?? 0
      } 門課程、${deleteSummary?.sessionCount ?? 0} 筆場次、${
        deleteSummary?.examPeriodCount ?? 0
      } 筆考試期間與 ${
        deleteSummary?.imageCount ?? 0
      } 張圖片一併刪除，且無法復原。`
    : '';

  const removeSchoolDescription = removeSchoolDialog
    ? `移除「${removeSchoolDialog.removedNames.join('、')}」會一併刪除 ${
        removeSchoolDialog.examPeriodCount
      } 筆考試期間，並從 ${
        removeSchoolDialog.courseCount
      } 個班級的「學生就讀學校」移除。確定要儲存變更嗎？`
    : '';

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="org-modal-title"
        className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
      >
        <div className="flex max-h-[90dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 bg-white px-4 py-3">
            <h2 id="org-modal-title" className="text-base font-semibold text-zinc-900">
              {organization ? '編輯單位' : '新增單位'}
            </h2>
            <button
              type="button"
              onClick={handleRequestClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
            >
              <X size={20} />
            </button>
          </div>

          <form
            noValidate
            onSubmit={(e) => void handleSubmit(e)}
            className="flex min-h-0 flex-1 flex-col"
          >
            <div className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-4 scroll-mb-6">
              <div>
                <label
                  htmlFor="org-name-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  單位名稱 <span className="text-rose-600">*</span>
                </label>
                <input
                  id="org-name-input"
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="例如：明德國中、文華補習班"
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
                {error && (
                  <p className="mt-1.5 text-xs font-medium text-rose-600">{error}</p>
                )}
              </div>

              <div>
                <span className="block text-sm font-medium text-zinc-800">類型</span>
                <div className="mt-1.5 grid grid-cols-3 gap-2">
                  {ORG_TYPES.map((t) => {
                    const selected = type === t;
                    return (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setType(t)}
                        className={`flex min-h-[44px] items-center justify-center rounded-xl border px-3 text-sm font-medium transition-colors ${
                          selected
                            ? 'border-violet-600 bg-[#F2ECFF] text-zinc-900 font-semibold'
                            : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                        }`}
                      >
                        {ORGANIZATION_TYPE_LABELS[t]}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <span className="mb-2 block text-sm font-medium text-zinc-800">
                  代表色
                </span>
                <ColorPickerGrid value={color} onChange={setColor} />
              </div>

              {showStudentSchoolsSection && (
                <div className="space-y-2.5 rounded-2xl border border-zinc-200 bg-zinc-50/60 p-3.5">
                  <div>
                    <h3 className="text-sm font-semibold text-zinc-900">
                      學生就讀學校
                    </h3>
                    <p className="mt-0.5 text-xs leading-relaxed text-zinc-500">
                      補習班學生就讀的學校，用來分別設定各校的考試時間。名稱建議簡短（例如「國昌」），因為會顯示在倒數標籤上。
                    </p>
                  </div>

                  {studentSchools.length > 0 && (
                    <div className="divide-y divide-zinc-100 overflow-hidden rounded-xl border border-zinc-200 bg-white">
                      {studentSchools.map((school) => {
                        const isEditingRow = editingSchoolId === school.id;
                        return (
                          <div
                            key={school.id}
                            className="flex min-h-[44px] items-center justify-between gap-2 px-3 py-1.5"
                          >
                            {isEditingRow ? (
                              <div className="flex min-w-0 flex-1 items-center gap-1.5">
                                <input
                                  type="text"
                                  autoFocus
                                  maxLength={MAX_SCHOOL_NAME_CHARS}
                                  value={editingSchoolName}
                                  onChange={(e) =>
                                    setEditingSchoolName(e.target.value)
                                  }
                                  onBlur={handleCommitInlineEdit}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      handleCommitInlineEdit();
                                    } else if (e.key === 'Escape') {
                                      e.preventDefault();
                                      setEditingSchoolId(null);
                                      setEditingSchoolName('');
                                    }
                                  }}
                                  aria-label={`編輯學校名稱 ${school.name}`}
                                  className="min-h-[38px] min-w-0 flex-1 rounded-lg border border-violet-500 bg-white px-2.5 text-base text-zinc-900 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                                />
                                <button
                                  type="button"
                                  onMouseDown={(e) => e.preventDefault()}
                                  onClick={handleCommitInlineEdit}
                                  aria-label="確認名稱"
                                  className="flex min-h-[38px] min-w-[38px] shrink-0 items-center justify-center rounded-lg bg-[#EDE6FF] text-violet-900 hover:bg-[#e1d5ff]"
                                >
                                  <Check size={16} aria-hidden="true" />
                                </button>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingSchoolId(school.id);
                                  setEditingSchoolName(school.name);
                                }}
                                title="點一下可修改名稱"
                                className="flex min-h-[38px] min-w-0 flex-1 items-center rounded-lg px-1 text-left text-sm font-medium text-zinc-900 transition-colors hover:bg-zinc-50"
                              >
                                <span className="truncate">{school.name}</span>
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => handleRemoveDraftSchool(school.id)}
                              aria-label={`移除學校「${school.name}」`}
                              className="flex min-h-[40px] min-w-[40px] shrink-0 items-center justify-center rounded-lg text-zinc-400 transition-colors hover:bg-rose-50 hover:text-rose-600"
                            >
                              <Trash2 size={16} aria-hidden="true" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={schoolInput}
                      onChange={(e) => {
                        setSchoolInput(e.target.value);
                        if (schoolHint) setSchoolHint(null);
                      }}
                      onKeyDown={handleSchoolInputKeyDown}
                      placeholder="例如：國昌、右昌、高科實中"
                      aria-label="新增學生就讀學校"
                      className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                    />
                    <button
                      type="button"
                      onClick={handleAddSchools}
                      className="flex min-h-[44px] shrink-0 items-center justify-center gap-1 rounded-xl border border-violet-300 bg-[#EDE6FF] px-3.5 text-sm font-semibold text-zinc-900 transition-colors hover:bg-[#e1d5ff] whitespace-nowrap"
                    >
                      <Plus size={15} aria-hidden="true" />
                      <span>新增</span>
                    </button>
                  </div>

                  {schoolHint && (
                    <p className="text-xs font-medium text-amber-800">
                      {schoolHint}
                    </p>
                  )}
                </div>
              )}

              <PeriodScheduleEditor
                organizationId={organization?.id ?? ''}
                periods={periods}
                periodErrors={periodErrors}
                onChangePeriods={(next) => {
                  setPeriods(next);
                  if (error) setError(null);
                }}
              />

              {organization && (
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      void handleOpenDelete();
                    }}
                    disabled={isSaving}
                    className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl border border-rose-200 bg-white px-4 py-2.5 text-sm font-medium text-rose-600 transition-colors hover:bg-rose-50 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-600"
                  >
                    <Trash2 size={16} aria-hidden="true" />
                    <span>刪除單位</span>
                  </button>
                </div>
              )}
            </div>

            <div className="shrink-0 space-y-2 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
              {periodErrors.size > 0 && (
                <p className="text-center text-xs font-medium text-rose-600">
                  節次表有 {periodErrors.size} 筆錯誤或重疊，請修正後再儲存
                </p>
              )}
              <button
                type="submit"
                disabled={isSaving || periodErrors.size > 0}
                className="flex min-h-[44px] w-full items-center justify-center rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-violet-700 disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2"
              >
                {isSaving ? '儲存中…' : organization ? '儲存變更' : '建立單位'}
              </button>
            </div>
          </form>
        </div>
      </div>

      <ConfirmDialog
        open={deleteDialogOpen}
        title="刪除任課單位"
        description={deleteDescription}
        confirmLabel="確認刪除"
        isSubmitting={isSaving}
        onCancel={() => setDeleteDialogOpen(false)}
        onConfirm={() => {
          void handleConfirmDelete();
        }}
      />

      <ConfirmDialog
        open={removeSchoolDialog !== null}
        title="移除學生就讀學校"
        description={removeSchoolDescription}
        confirmLabel="確認儲存"
        isSubmitting={isSaving}
        onCancel={() => setRemoveSchoolDialog(null)}
        onConfirm={() => {
          const ids = removeSchoolDialog?.removedIds ?? [];
          setRemoveSchoolDialog(null);
          void performSave(ids);
        }}
      />

      <ConfirmDialog
        open={discardConfirmOpen}
        title="放棄未儲存的內容？"
        description="目前有尚未儲存的修改，確定要放棄並返回嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardConfirmOpen(false)}
        onConfirm={() => {
          setDiscardConfirmOpen(false);
          onClose();
        }}
      />
    </>
  );
}
