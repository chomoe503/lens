import {
  Ban,
  CalendarClock,
  MoreHorizontal,
  RotateCcw,
  Trash2,
  X,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { db } from '../db/database';
import { deleteMultipleSessions } from '../db/repositories';
import type { ClassSession, Course, Organization } from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import { formatSlashDateWithWeekday } from '../utils/date';
import { isSessionCancelled, resolveSessionDisplay } from '../utils/sessionDisplay';
import { pushUndoAction } from '../utils/undoStore';
import { ConfirmDialog } from './ConfirmDialog';
import { SessionFormModal } from './SessionFormModal';

const CANCEL_PRESET_REASONS = ['放假', '考試', '活動', '請假'] as const;

export function CancelledBadge() {
  return (
    <span className="inline-flex shrink-0 items-center rounded-md border border-zinc-200 bg-zinc-100 px-1.5 py-0.5 text-[11px] font-medium leading-none text-zinc-600 whitespace-nowrap">
      已取消
    </span>
  );
}

interface SessionMenuButtonProps {
  onClick: () => void;
  ariaLabel?: string;
  compact?: boolean;
  className?: string;
}

export function SessionMenuButton({
  onClick,
  ariaLabel = '場次操作選單',
  compact = false,
  className = '',
}: SessionMenuButtonProps) {
  return (
    <button
      type="button"
      aria-label={ariaLabel}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      className={
        compact
          ? `flex h-7 w-7 shrink-0 items-center justify-center rounded-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 ${className}`
          : `flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 active:bg-zinc-200/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 ${className}`
      }
    >
      <MoreHorizontal size={compact ? 14 : 18} aria-hidden="true" />
    </button>
  );
}

interface CancelSessionDialogProps {
  session: ClassSession | null;
  displayTitle: string;
  onClose: () => void;
}

function CancelSessionDialog({
  session,
  displayTitle,
  onClose,
}: CancelSessionDialogProps) {
  const [reason, setReason] = useState('');
  const [otherSelected, setOtherSelected] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!session) return;
    const existing = session.cancelReason?.trim() ?? '';
    setReason(existing);
    setOtherSelected(
      Boolean(
        existing &&
          !(CANCEL_PRESET_REASONS as readonly string[]).includes(existing)
      )
    );
    setIsSubmitting(false);
  }, [session?.id, session?.cancelReason]);

  useBackLayer({
    active: session !== null,
    zLayer: 65,
    onBack: () => {
      if (!isSubmitting) onClose();
    },
  });

  if (!session) return null;

  const handleSelectPreset = (preset: string) => {
    setOtherSelected(false);
    setReason((prev) => (prev.trim() === preset ? '' : preset));
  };

  const handleSelectOther = () => {
    setOtherSelected(true);
    setReason((prev) =>
      (CANCEL_PRESET_REASONS as readonly string[]).includes(prev.trim())
        ? ''
        : prev
    );
    window.setTimeout(() => {
      inputRef.current?.focus();
    }, 30);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const trimmed = reason.trim();
      await db.sessions.update(session.id, {
        status: 'cancelled',
        cancelReason: trimmed || undefined,
        updatedAt: Date.now(),
      });
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="cancel-session-dialog-title"
      className="fixed inset-0 z-[65] flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
    >
      <div className="flex max-h-[85dvh] w-full max-w-md flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 px-4 py-3">
          <h3
            id="cancel-session-dialog-title"
            className="text-base font-semibold text-zinc-900"
          >
            取消這堂課
          </h3>
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            aria-label="關閉"
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
          >
            <X size={20} />
          </button>
        </div>

        <form
          onSubmit={(e) => void handleSubmit(e)}
          className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-4 pb-[calc(1rem+env(safe-area-inset-bottom))]"
        >
          <div className="rounded-xl bg-zinc-50 px-3.5 py-2.5">
            <p className="truncate text-sm font-semibold text-zinc-900">
              {displayTitle}
            </p>
            <p className="mt-0.5 text-xs text-zinc-500 tabular-nums">
              {formatSlashDateWithWeekday(session.date)} {session.startTime}–
              {session.endTime}
            </p>
          </div>

          <div>
            <span className="block text-sm font-medium text-zinc-800">
              取消原因（選填）
            </span>
            <div className="mt-2 grid grid-cols-5 gap-1.5">
              {CANCEL_PRESET_REASONS.map((preset) => {
                const active = !otherSelected && reason.trim() === preset;
                return (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => handleSelectPreset(preset)}
                    className={`flex min-h-[44px] items-center justify-center rounded-xl border px-1 text-xs font-medium transition-colors ${
                      active
                        ? 'border-2 border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                        : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                    }`}
                  >
                    {preset}
                  </button>
                );
              })}
              <button
                type="button"
                onClick={handleSelectOther}
                className={`flex min-h-[44px] items-center justify-center rounded-xl border px-1 text-xs font-medium transition-colors ${
                  otherSelected
                    ? 'border-2 border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                    : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                }`}
              >
                其他
              </button>
            </div>
          </div>

          <div>
            <label
              htmlFor="cancel-reason-input"
              className="block text-xs font-medium text-zinc-600"
            >
              詳細說明（選填）
            </label>
            <input
              ref={inputRef}
              id="cancel-reason-input"
              type="text"
              value={reason}
              onChange={(e) => {
                const val = e.target.value;
                setReason(val);
                if (
                  val.trim() !== '' &&
                  !(CANCEL_PRESET_REASONS as readonly string[]).includes(
                    val.trim()
                  )
                ) {
                  setOtherSelected(true);
                }
              }}
              placeholder="例如：國定假日、校外教學、公假"
              className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
            />
          </div>

          <div className="flex items-center gap-2.5 pt-1">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl border border-zinc-200 bg-white px-4 text-sm font-medium text-zinc-700 hover:bg-zinc-50 disabled:opacity-60"
            >
              返回
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl bg-rose-600 px-4 text-sm font-medium text-white transition-colors hover:bg-rose-700 disabled:opacity-60"
            >
              {isSubmitting ? '處理中…' : '確認取消'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

interface SessionActionMenuModalProps {
  session: ClassSession | null;
  displayTitle: string;
  orgName: string;
  onClose: () => void;
  onReschedule: (session: ClassSession) => void;
  onCancelSession: (session: ClassSession) => void;
  onRestoreSession: (session: ClassSession) => void;
  onDeleteSession: (session: ClassSession) => void;
}

function SessionActionMenuModal({
  session,
  displayTitle,
  orgName,
  onClose,
  onReschedule,
  onCancelSession,
  onRestoreSession,
  onDeleteSession,
}: SessionActionMenuModalProps) {
  useBackLayer({
    active: session !== null,
    zLayer: 62,
    onBack: onClose,
  });

  if (!session) return null;

  const cancelled = isSessionCancelled(session);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="session-action-menu-title"
      onClick={onClose}
      className="fixed inset-0 z-[62] flex items-end justify-center bg-black/45 backdrop-blur-xs sm:items-center sm:p-4"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-t-3xl bg-white pb-[calc(1rem+env(safe-area-inset-bottom))] shadow-xl sm:rounded-2xl sm:pb-4"
      >
        <div className="flex items-start justify-between gap-2 border-b border-zinc-100 px-4 py-3.5">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h3
                id="session-action-menu-title"
                className={`truncate text-base font-semibold ${
                  cancelled ? 'text-zinc-400 line-through' : 'text-zinc-900'
                }`}
              >
                {displayTitle}
              </h3>
              {cancelled && <CancelledBadge />}
            </div>
            <p className="mt-0.5 text-xs text-zinc-500 tabular-nums">
              {orgName} · {formatSlashDateWithWeekday(session.date)}{' '}
              {session.startTime}–{session.endTime}
            </p>
            {cancelled && session.cancelReason && (
              <p className="mt-0.5 text-xs text-zinc-500">
                取消原因：{session.cancelReason}
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="關閉選單"
            className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
          >
            <X size={20} />
          </button>
        </div>

        <div className="space-y-1.5 p-3">
          <button
            type="button"
            onClick={() => onReschedule(session)}
            className="flex min-h-[48px] w-full items-center gap-3 rounded-xl px-3.5 text-left text-sm font-medium text-zinc-900 transition-colors hover:bg-zinc-100 active:bg-zinc-200/70"
          >
            <CalendarClock
              size={18}
              className="shrink-0 text-violet-700"
              aria-hidden="true"
            />
            <span>改期</span>
          </button>

          {!cancelled ? (
            <button
              type="button"
              onClick={() => onCancelSession(session)}
              className="flex min-h-[48px] w-full items-center gap-3 rounded-xl px-3.5 text-left text-sm font-medium text-zinc-900 transition-colors hover:bg-zinc-100 active:bg-zinc-200/70"
            >
              <Ban
                size={18}
                className="shrink-0 text-amber-700"
                aria-hidden="true"
              />
              <span>取消這堂</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onRestoreSession(session)}
              className="flex min-h-[48px] w-full items-center gap-3 rounded-xl px-3.5 text-left text-sm font-medium text-emerald-700 transition-colors hover:bg-emerald-50 active:bg-emerald-100/70"
            >
              <RotateCcw
                size={18}
                className="shrink-0 text-emerald-700"
                aria-hidden="true"
              />
              <span>恢復</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => onDeleteSession(session)}
            className="flex min-h-[48px] w-full items-center gap-3 rounded-xl px-3.5 text-left text-sm font-medium text-rose-600 transition-colors hover:bg-rose-50 active:bg-rose-100/70"
          >
            <Trash2
              size={18}
              className="shrink-0 text-rose-600"
              aria-hidden="true"
            />
            <span>刪除</span>
          </button>
        </div>
      </div>
    </div>
  );
}

interface UseSessionQuickActionsOptions {
  courses: Course[];
  organizations: Organization[];
  onSessionDeleted?: (sessionId: string) => void;
}

export function useSessionQuickActions({
  courses,
  organizations,
  onSessionDeleted,
}: UseSessionQuickActionsOptions) {
  const [menuSession, setMenuSession] = useState<ClassSession | null>(null);
  const [rescheduleSession, setRescheduleSession] =
    useState<ClassSession | null>(null);
  const [cancelTarget, setCancelTarget] = useState<ClassSession | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ClassSession | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const openSessionMenu = (session: ClassSession) => {
    setMenuSession(session);
  };

  return {
    openSessionMenu,
    quickActionsProps: {
      courses,
      organizations,
      menuSession,
      rescheduleSession,
      cancelTarget,
      deleteTarget,
      isDeleting,
      setMenuSession,
      setRescheduleSession,
      setCancelTarget,
      setDeleteTarget,
      setIsDeleting,
      onSessionDeleted,
    },
  };
}

interface SessionQuickActionsHostProps {
  courses: Course[];
  organizations: Organization[];
  menuSession: ClassSession | null;
  rescheduleSession: ClassSession | null;
  cancelTarget: ClassSession | null;
  deleteTarget: ClassSession | null;
  isDeleting: boolean;
  setMenuSession: (s: ClassSession | null) => void;
  setRescheduleSession: (s: ClassSession | null) => void;
  setCancelTarget: (s: ClassSession | null) => void;
  setDeleteTarget: (s: ClassSession | null) => void;
  setIsDeleting: (v: boolean) => void;
  onSessionDeleted?: (sessionId: string) => void;
}

export function SessionQuickActionsHost({
  courses,
  organizations,
  menuSession,
  rescheduleSession,
  cancelTarget,
  deleteTarget,
  isDeleting,
  setMenuSession,
  setRescheduleSession,
  setCancelTarget,
  setDeleteTarget,
  setIsDeleting,
  onSessionDeleted,
}: SessionQuickActionsHostProps) {
  const courseMap = useMemo(
    () => new Map(courses.map((c) => [c.id, c])),
    [courses]
  );
  const orgMap = useMemo(
    () => new Map(organizations.map((o) => [o.id, o])),
    [organizations]
  );

  const menuResolved = menuSession
    ? resolveSessionDisplay(menuSession, courseMap, orgMap)
    : null;
  const cancelResolved = cancelTarget
    ? resolveSessionDisplay(cancelTarget, courseMap, orgMap)
    : null;
  const deleteResolved = deleteTarget
    ? resolveSessionDisplay(deleteTarget, courseMap, orgMap)
    : null;

  const handleRestoreSession = async (session: ClassSession) => {
    setMenuSession(null);
    await db.sessions.update(session.id, {
      status: 'scheduled',
      cancelReason: undefined,
      updatedAt: Date.now(),
    });
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    const deletedId = deleteTarget.id;
    setIsDeleting(true);
    try {
      const backup = await deleteMultipleSessions([deletedId]);
      pushUndoAction('已刪除 1 堂場次', backup);
      setDeleteTarget(null);
      onSessionDeleted?.(deletedId);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <>
      <SessionActionMenuModal
        session={menuSession}
        displayTitle={menuResolved?.title ?? ''}
        orgName={menuResolved?.orgName ?? ''}
        onClose={() => setMenuSession(null)}
        onReschedule={(s) => {
          setMenuSession(null);
          setRescheduleSession(s);
        }}
        onCancelSession={(s) => {
          setMenuSession(null);
          setCancelTarget(s);
        }}
        onRestoreSession={(s) => {
          void handleRestoreSession(s);
        }}
        onDeleteSession={(s) => {
          setMenuSession(null);
          setDeleteTarget(s);
        }}
      />

      <CancelSessionDialog
        session={cancelTarget}
        displayTitle={cancelResolved?.title ?? ''}
        onClose={() => setCancelTarget(null)}
      />

      <SessionFormModal
        open={rescheduleSession !== null}
        session={rescheduleSession}
        courses={courses}
        organizations={organizations}
        defaultStartReschedule
        onClose={() => setRescheduleSession(null)}
      />

      <ConfirmDialog
        open={deleteTarget !== null}
        title="刪除場次"
        description={
          deleteTarget
            ? `確定要刪除「${deleteResolved?.title ?? ''}」${formatSlashDateWithWeekday(deleteTarget.date)} ${deleteTarget.startTime} 的場次嗎？刪除後 12 秒內可復原。`
            : ''
        }
        confirmLabel="確認刪除"
        isSubmitting={isDeleting}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          void handleConfirmDelete();
        }}
      />
    </>
  );
}
