import { Plus, Trash2, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { db } from '../db/database';
import type { ExamPeriod, ExamPeriodKind, Organization } from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import { EXAM_KIND_LABELS } from '../utils/examCountdown';
import { createId } from '../utils/id';
import { pushUndoCustomAction } from '../utils/undoStore';
import { useLiveQuery } from '../utils/useLiveQuery';
import { ConfirmDialog } from './ConfirmDialog';

interface BatchExamPeriodsModalProps {
  open: boolean;
  organizations: Organization[];
  onClose: () => void;
}

interface BatchExamRow {
  rowKey: string;
  title: string;
  kind: ExamPeriodKind;
  startDate: string;
  endDate: string;
  endDiverged: boolean;
  subjectDate: string;
}

interface SchoolExamDraft {
  schoolId: string;
  startDate: string;
  endDate: string;
  endDiverged: boolean;
  subjectDate: string;
  existingPeriodId?: string;
  initialStartDate: string;
  initialEndDate: string;
  initialSubjectDate: string;
}

type RoundPresetKey =
  | '第一次段考'
  | '第二次段考'
  | '第三次段考'
  | '期末考'
  | '模考'
  | 'custom';

const ROUND_PRESETS: Array<{
  key: RoundPresetKey;
  label: string;
  kind?: ExamPeriodKind;
}> = [
  { key: '第一次段考', label: '第一次段考', kind: 'midterm' },
  { key: '第二次段考', label: '第二次段考', kind: 'midterm' },
  { key: '第三次段考', label: '第三次段考', kind: 'midterm' },
  { key: '期末考', label: '期末考', kind: 'final' },
  { key: '模考', label: '模考', kind: 'mock' },
  { key: 'custom', label: '自訂' },
];

function createInitialRows(): BatchExamRow[] {
  return [
    {
      rowKey: createId(),
      title: '第一次段考',
      kind: 'midterm',
      startDate: '',
      endDate: '',
      endDiverged: false,
      subjectDate: '',
    },
    {
      rowKey: createId(),
      title: '第二次段考',
      kind: 'midterm',
      startDate: '',
      endDate: '',
      endDiverged: false,
      subjectDate: '',
    },
    {
      rowKey: createId(),
      title: '期末考',
      kind: 'final',
      startDate: '',
      endDate: '',
      endDiverged: false,
      subjectDate: '',
    },
  ];
}

export function BatchExamPeriodsModal({
  open,
  organizations,
  onClose,
}: BatchExamPeriodsModalProps) {
  const existingPeriods = useLiveQuery(
    async (): Promise<ExamPeriod[]> => (open ? db.examPeriods.toArray() : []),
    [open]
  );

  const [organizationId, setOrganizationId] = useState('');
  const [rows, setRows] = useState<BatchExamRow[]>([]);

  // 依學校模式狀態
  const [roundPreset, setRoundPreset] = useState<RoundPresetKey>('第一次段考');
  const [customTitle, setCustomTitle] = useState('');
  const [customKind, setCustomKind] = useState<ExamPeriodKind>('midterm');
  const [schoolDrafts, setSchoolDrafts] = useState<
    Record<string, SchoolExamDraft>
  >({});
  const lastSyncKeyRef = useRef<string>('');

  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);

  useEffect(() => {
    if (!open) {
      lastSyncKeyRef.current = '';
      return;
    }
    setOrganizationId(organizations[0]?.id ?? '');
    setRows(createInitialRows());
    setRoundPreset('第一次段考');
    setCustomTitle('');
    setCustomKind('midterm');
    setSchoolDrafts({});
    lastSyncKeyRef.current = '';
    setError(null);
    setDiscardConfirmOpen(false);
  }, [open, organizations]);

  const selectedOrg = useMemo(
    () => organizations.find((o) => o.id === organizationId),
    [organizations, organizationId]
  );
  const orgSchools = selectedOrg?.studentSchools ?? [];
  const isSchoolMode = orgSchools.length > 0;

  const effectiveRoundTitle =
    roundPreset === 'custom' ? customTitle.trim() : roundPreset;
  const effectiveRoundKind: ExamPeriodKind =
    roundPreset === 'custom'
      ? customKind
      : (ROUND_PRESETS.find((p) => p.key === roundPreset)?.kind ?? 'midterm');

  useEffect(() => {
    if (!open || !isSchoolMode || existingPeriods === undefined) return;
    const syncKey = `${organizationId}__${effectiveRoundTitle}`;
    if (lastSyncKeyRef.current === syncKey) return;
    lastSyncKeyRef.current = syncKey;

    const nextDrafts: Record<string, SchoolExamDraft> = {};
    for (const school of orgSchools) {
      const matched = effectiveRoundTitle
        ? existingPeriods.find(
            (p) =>
              p.organizationId === organizationId &&
              p.studentSchoolId === school.id &&
              p.title.trim() === effectiveRoundTitle
          )
        : undefined;

      const initStart = matched?.startDate ?? '';
      const initEnd = matched?.endDate ?? '';
      const initSubject = matched?.subjectDate ?? '';

      nextDrafts[school.id] = {
        schoolId: school.id,
        startDate: initStart,
        endDate: initEnd,
        endDiverged: Boolean(matched && matched.endDate !== matched.startDate),
        subjectDate: initSubject,
        existingPeriodId: matched?.id,
        initialStartDate: initStart,
        initialEndDate: initEnd,
        initialSubjectDate: initSubject,
      };
    }
    setSchoolDrafts(nextDrafts);
  }, [
    open,
    isSchoolMode,
    organizationId,
    effectiveRoundTitle,
    existingPeriods,
    orgSchools,
  ]);

  const hasAnyInput = useMemo(() => {
    if (isSchoolMode) {
      return Object.values(schoolDrafts).some(
        (d) =>
          d.startDate !== d.initialStartDate ||
          d.endDate !== d.initialEndDate ||
          d.subjectDate !== d.initialSubjectDate
      );
    }
    return rows.some(
      (r) => r.startDate !== '' || r.endDate !== '' || r.subjectDate !== ''
    );
  }, [isSchoolMode, schoolDrafts, rows]);

  const handleRequestClose = () => {
    if (isSaving) return;
    if (hasAnyInput) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: open,
    zLayer: 65,
    onBack: handleRequestClose,
  });

  if (!open) return null;

  const updateRow = (
    rowKey: string,
    updater: (prev: BatchExamRow) => BatchExamRow
  ) => {
    if (error) setError(null);
    setRows((prev) =>
      prev.map((row) => (row.rowKey === rowKey ? updater(row) : row))
    );
  };

  const updateSchoolDraft = (
    schoolId: string,
    updater: (prev: SchoolExamDraft) => SchoolExamDraft
  ) => {
    if (error) setError(null);
    setSchoolDrafts((prev) => {
      const current = prev[schoolId] ?? {
        schoolId,
        startDate: '',
        endDate: '',
        endDiverged: false,
        subjectDate: '',
        initialStartDate: '',
        initialEndDate: '',
        initialSubjectDate: '',
      };
      return {
        ...prev,
        [schoolId]: updater(current),
      };
    });
  };

  const handleAddRow = () => {
    setRows((prev) => [
      ...prev,
      {
        rowKey: createId(),
        title: '',
        kind: 'midterm',
        startDate: '',
        endDate: '',
        endDiverged: false,
        subjectDate: '',
      },
    ]);
  };

  const handleRemoveRow = (rowKey: string) => {
    if (error) setError(null);
    setRows((prev) => prev.filter((r) => r.rowKey !== rowKey));
  };

  const handleSubmitSchoolMode = async () => {
    if (!effectiveRoundTitle) {
      setError('請輸入這輪考試的名稱');
      return;
    }

    const activeCards = orgSchools
      .map((school) => ({
        school,
        draft: schoolDrafts[school.id],
      }))
      .filter((item) => item.draft && item.draft.startDate.trim() !== '');

    if (activeCards.length === 0) {
      setError('請至少填寫一間學校的開始日期');
      return;
    }

    for (const { school, draft } of activeCards) {
      const effectiveEnd = draft.endDate || draft.startDate;
      if (effectiveEnd < draft.startDate) {
        setError(`「${school.name}」的結束日期不可早於開始日期`);
        return;
      }
      if (
        draft.subjectDate &&
        (draft.subjectDate < draft.startDate ||
          draft.subjectDate > effectiveEnd)
      ) {
        setError(
          `「${school.name}」的理化考試日必須介於開始～結束日期之間`
        );
        return;
      }
    }

    setIsSaving(true);
    setError(null);
    try {
      const now = Date.now();
      const existingMap = new Map(
        (existingPeriods ?? []).map((p) => [p.id, p])
      );
      const toCreate: ExamPeriod[] = [];
      const toUpdate: ExamPeriod[] = [];

      activeCards.forEach(({ school, draft }, idx) => {
        const effectiveEnd = draft.endDate || draft.startDate;
        const existing = draft.existingPeriodId
          ? existingMap.get(draft.existingPeriodId)
          : undefined;

        if (existing) {
          toUpdate.push({
            ...existing,
            kind: effectiveRoundKind,
            startDate: draft.startDate,
            endDate: effectiveEnd,
            subjectDate: draft.subjectDate || undefined,
            updatedAt: now + idx,
          });
        } else {
          toCreate.push({
            id: createId(),
            organizationId,
            studentSchoolId: school.id,
            title: effectiveRoundTitle,
            kind: effectiveRoundKind,
            startDate: draft.startDate,
            endDate: effectiveEnd,
            subjectDate: draft.subjectDate || undefined,
            appliesToAll: true,
            courseIds: [],
            createdAt: now + idx,
            updatedAt: now + idx,
          });
        }
      });

      await db.transaction('rw', db.examPeriods, async () => {
        if (toUpdate.length > 0) {
          await db.examPeriods.bulkPut(toUpdate);
        }
        if (toCreate.length > 0) {
          await db.examPeriods.bulkAdd(toCreate);
        }
      });

      if (toCreate.length > 0) {
        const createdIds = toCreate.map((r) => r.id);
        pushUndoCustomAction(
          `已建立 ${toCreate.length} 筆考試期間`,
          async () => {
            await db.examPeriods.bulkDelete(createdIds);
          }
        );
      }

      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : '批次建立失敗');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!organizationId) {
      setError('請先選擇單位');
      return;
    }

    if (isSchoolMode) {
      await handleSubmitSchoolMode();
      return;
    }

    const activeRows = rows.filter((r) => r.startDate.trim() !== '');
    if (activeRows.length === 0) {
      setError('請至少填寫一列的開始日期');
      return;
    }

    for (let i = 0; i < activeRows.length; i += 1) {
      const r = activeRows[i];
      const trimmedTitle = r.title.trim();
      if (!trimmedTitle) {
        setError(`第 ${i + 1} 筆有填開始日期，請填寫考試名稱`);
        return;
      }
      const effectiveEnd = r.endDate || r.startDate;
      if (effectiveEnd < r.startDate) {
        setError(`「${trimmedTitle}」的結束日期不可早於開始日期`);
        return;
      }
      if (
        r.subjectDate &&
        (r.subjectDate < r.startDate || r.subjectDate > effectiveEnd)
      ) {
        setError(`「${trimmedTitle}」的理化考試日必須介於開始～結束日期之間`);
        return;
      }
    }

    setIsSaving(true);
    setError(null);
    try {
      const now = Date.now();
      const records: ExamPeriod[] = activeRows.map((r, idx) => ({
        id: createId(),
        organizationId,
        title: r.title.trim(),
        kind: r.kind,
        startDate: r.startDate,
        endDate: r.endDate || r.startDate,
        subjectDate: r.subjectDate || undefined,
        appliesToAll: true,
        courseIds: [],
        createdAt: now + idx,
        updatedAt: now + idx,
      }));

      await db.transaction('rw', db.examPeriods, async () => {
        await db.examPeriods.bulkAdd(records);
      });

      const createdIds = records.map((r) => r.id);
      pushUndoCustomAction(
        `已建立 ${records.length} 筆考試期間`,
        async () => {
          await db.examPeriods.bulkDelete(createdIds);
        }
      );

      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : '批次建立失敗');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="batch-exam-title"
        className="fixed inset-0 z-[65] flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
        onClick={(e) => {
          if (e.target === e.currentTarget) {
            handleRequestClose();
          }
        }}
      >
        <div className="flex max-h-[92dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 px-5 py-3.5">
            <h2
              id="batch-exam-title"
              className="text-base font-semibold text-zinc-900"
            >
              批次新增學期考試表
            </h2>
            <button
              type="button"
              onClick={handleRequestClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
            >
              <X size={20} />
            </button>
          </div>

          <form
            noValidate
            onSubmit={(e) => void handleSubmit(e)}
            className="flex min-h-0 flex-1 flex-col overflow-hidden"
          >
            <div className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-5">
              {error && (
                <div
                  role="alert"
                  className="rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-medium text-rose-700"
                >
                  {error}
                </div>
              )}

              <div>
                <label
                  htmlFor="batch-exam-org"
                  className="block text-xs font-medium text-zinc-700"
                >
                  適用單位 <span className="text-rose-600">*</span>
                </label>
                <select
                  id="batch-exam-org"
                  value={organizationId}
                  onChange={(e) => {
                    setOrganizationId(e.target.value);
                    lastSyncKeyRef.current = '';
                    if (error) setError(null);
                  }}
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                >
                  {organizations.length === 0 ? (
                    <option value="">尚無任課單位，請先新增單位</option>
                  ) : (
                    organizations.map((org) => (
                      <option key={org.id} value={org.id}>
                        {org.name}
                      </option>
                    ))
                  )}
                </select>
                <p className="mt-1 text-xs text-zinc-500">
                  {isSchoolMode
                    ? '依學生就讀學校批次設定這一輪考試；未填開始日期的學校會自動略過。'
                    : '建立後會套用該單位全部班級；未填開始日期的列會自動略過。'}
                </p>
              </div>

              {isSchoolMode ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <span className="block text-xs font-medium text-zinc-700">
                      這一輪考試
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {ROUND_PRESETS.map((preset) => {
                        const active = roundPreset === preset.key;
                        return (
                          <button
                            key={preset.key}
                            type="button"
                            onClick={() => {
                              setRoundPreset(preset.key);
                              if (error) setError(null);
                            }}
                            className={`min-h-[38px] rounded-xl border px-3 text-xs font-medium transition-colors ${
                              active
                                ? 'border-violet-600 bg-[#CDB8FF] font-semibold text-zinc-900'
                                : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                            }`}
                          >
                            {preset.label}
                          </button>
                        );
                      })}
                    </div>

                    {roundPreset === 'custom' && (
                      <div className="flex items-center gap-2 pt-1">
                        <input
                          type="text"
                          value={customTitle}
                          onChange={(e) => {
                            setCustomTitle(e.target.value);
                            if (error) setError(null);
                          }}
                          placeholder="輸入考試名稱（例如：複習考）"
                          aria-label="自訂考試名稱"
                          className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                        />
                        <select
                          aria-label="自訂考試類型"
                          value={customKind}
                          onChange={(e) =>
                            setCustomKind(e.target.value as ExamPeriodKind)
                          }
                          className="min-h-[44px] shrink-0 rounded-xl border border-zinc-300 bg-white px-2.5 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                        >
                          {(Object.keys(EXAM_KIND_LABELS) as ExamPeriodKind[]).map(
                            (k) => (
                              <option key={k} value={k}>
                                {EXAM_KIND_LABELS[k]}
                              </option>
                            )
                          )}
                        </select>
                      </div>
                    )}
                  </div>

                  <div className="space-y-3">
                    {orgSchools.map((school) => {
                      const draft = schoolDrafts[school.id] ?? {
                        schoolId: school.id,
                        startDate: '',
                        endDate: '',
                        endDiverged: false,
                        subjectDate: '',
                        initialStartDate: '',
                        initialEndDate: '',
                        initialSubjectDate: '',
                      };

                      return (
                        <div
                          key={school.id}
                          className="space-y-2.5 rounded-2xl border border-zinc-200 bg-zinc-50/60 p-3.5"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span className="text-sm font-bold text-zinc-900">
                              {school.name}
                            </span>
                            {draft.existingPeriodId && (
                              <span className="text-[11px] font-medium text-violet-700">
                                {draft.startDate === ''
                                  ? '要刪除請到考試時程頁'
                                  : '已存在，儲存會更新日期'}
                              </span>
                            )}
                          </div>

                          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                            <div>
                              <label className="block text-[11px] font-medium text-zinc-600">
                                開始日期
                              </label>
                              <input
                                type="date"
                                value={draft.startDate}
                                onChange={(e) => {
                                  const nextStart = e.target.value;
                                  updateSchoolDraft(school.id, (prev) => ({
                                    ...prev,
                                    startDate: nextStart,
                                    endDate: !nextStart
                                      ? ''
                                      : !prev.endDiverged ||
                                          !prev.endDate ||
                                          prev.endDate < nextStart
                                        ? nextStart
                                        : prev.endDate,
                                  }));
                                }}
                                className="mt-1 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-2.5 py-1.5 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-[11px] font-medium text-zinc-600">
                                結束日期
                              </label>
                              <input
                                type="date"
                                min={draft.startDate || undefined}
                                value={draft.endDate}
                                onChange={(e) => {
                                  const nextEnd = e.target.value;
                                  updateSchoolDraft(school.id, (prev) => ({
                                    ...prev,
                                    endDate: nextEnd,
                                    endDiverged: nextEnd !== prev.startDate,
                                  }));
                                }}
                                className="mt-1 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-2.5 py-1.5 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <div className="flex items-center justify-between gap-1">
                                <label className="block text-[11px] font-medium text-zinc-600">
                                  理化考試日（選填）
                                </label>
                                {draft.subjectDate && (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      updateSchoolDraft(school.id, (prev) => ({
                                        ...prev,
                                        subjectDate: '',
                                      }))
                                    }
                                    className="text-[11px] font-medium text-violet-700 hover:underline"
                                  >
                                    清除
                                  </button>
                                )}
                              </div>
                              <input
                                type="date"
                                min={draft.startDate || undefined}
                                max={
                                  draft.endDate || draft.startDate || undefined
                                }
                                value={draft.subjectDate}
                                onChange={(e) =>
                                  updateSchoolDraft(school.id, (prev) => ({
                                    ...prev,
                                    subjectDate: e.target.value,
                                  }))
                                }
                                className="mt-1 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-2.5 py-1.5 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                              />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  {rows.map((row, idx) => (
                    <div
                      key={row.rowKey}
                      className="space-y-2.5 rounded-2xl border border-zinc-200 bg-zinc-50/60 p-3.5"
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          aria-label={`第 ${idx + 1} 列考試名稱`}
                          value={row.title}
                          onChange={(e) =>
                            updateRow(row.rowKey, (prev) => ({
                              ...prev,
                              title: e.target.value,
                            }))
                          }
                          placeholder="考試名稱"
                          className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                        />

                        <select
                          aria-label={`第 ${idx + 1} 列類型`}
                          value={row.kind}
                          onChange={(e) =>
                            updateRow(row.rowKey, (prev) => ({
                              ...prev,
                              kind: e.target.value as ExamPeriodKind,
                            }))
                          }
                          className="min-h-[44px] shrink-0 rounded-xl border border-zinc-300 bg-white px-2.5 py-2 text-base text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                        >
                          {(Object.keys(EXAM_KIND_LABELS) as ExamPeriodKind[]).map(
                            (k) => (
                              <option key={k} value={k}>
                                {EXAM_KIND_LABELS[k]}
                              </option>
                            )
                          )}
                        </select>

                        <button
                          type="button"
                          onClick={() => handleRemoveRow(row.rowKey)}
                          aria-label={`刪除第 ${idx + 1} 列`}
                          className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl border border-rose-200 bg-white text-rose-600 hover:bg-rose-50"
                        >
                          <Trash2 size={16} aria-hidden="true" />
                        </button>
                      </div>

                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                        <div>
                          <label className="block text-[11px] font-medium text-zinc-600">
                            開始日期
                          </label>
                          <input
                            type="date"
                            value={row.startDate}
                            onChange={(e) => {
                              const nextStart = e.target.value;
                              updateRow(row.rowKey, (prev) => ({
                                ...prev,
                                startDate: nextStart,
                                endDate:
                                  !prev.endDiverged ||
                                  !prev.endDate ||
                                  prev.endDate < nextStart
                                    ? nextStart
                                    : prev.endDate,
                              }));
                            }}
                            className="mt-1 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-2.5 py-1.5 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-medium text-zinc-600">
                            結束日期
                          </label>
                          <input
                            type="date"
                            min={row.startDate || undefined}
                            value={row.endDate}
                            onChange={(e) => {
                              const nextEnd = e.target.value;
                              updateRow(row.rowKey, (prev) => ({
                                ...prev,
                                endDate: nextEnd,
                                endDiverged: nextEnd !== prev.startDate,
                              }));
                            }}
                            className="mt-1 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-2.5 py-1.5 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                          />
                        </div>

                        <div>
                          <div className="flex items-center justify-between gap-1">
                            <label className="block text-[11px] font-medium text-zinc-600">
                              理化考試日（選填）
                            </label>
                            {row.subjectDate && (
                              <button
                                type="button"
                                onClick={() =>
                                  updateRow(row.rowKey, (prev) => ({
                                    ...prev,
                                    subjectDate: '',
                                  }))
                                }
                                className="text-[11px] font-medium text-violet-700 hover:underline"
                              >
                                清除
                              </button>
                            )}
                          </div>
                          <input
                            type="date"
                            min={row.startDate || undefined}
                            max={row.endDate || row.startDate || undefined}
                            value={row.subjectDate}
                            onChange={(e) =>
                              updateRow(row.rowKey, (prev) => ({
                                ...prev,
                                subjectDate: e.target.value,
                              }))
                            }
                            className="mt-1 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-2.5 py-1.5 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  ))}

                  <button
                    type="button"
                    onClick={handleAddRow}
                    className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl border border-dashed border-violet-300 bg-[#F2ECFF]/50 px-4 text-xs font-semibold text-violet-900 transition-colors hover:bg-[#EDE6FF]"
                  >
                    <Plus size={15} aria-hidden="true" />
                    <span>新增一列</span>
                  </button>
                </div>
              )}
            </div>

            <div className="shrink-0 border-t border-zinc-100 bg-white px-5 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleRequestClose}
                  className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm font-medium text-zinc-700 hover:bg-zinc-50"
                >
                  取消
                </button>
                <button
                  type="submit"
                  disabled={isSaving || organizations.length === 0}
                  className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl bg-violet-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-violet-700 disabled:opacity-60"
                >
                  {isSaving
                    ? '儲存中…'
                    : isSchoolMode
                      ? '儲存考試時程'
                      : '批次建立'}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>

      <ConfirmDialog
        open={discardConfirmOpen}
        title="放棄未儲存的內容？"
        description="批次考試表已有輸入日期，確定要放棄並關閉嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardConfirmOpen(false)}
        onConfirm={() => {
          setDiscardConfirmOpen(false);
          onClose();
        }}
      />
    </>
  );
}
