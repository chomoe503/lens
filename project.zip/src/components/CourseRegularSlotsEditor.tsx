import { Pencil, Plus, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import type {
  CourseRegularSlot,
  Organization,
  Period,
  WeekdayNumber,
} from '../db/types';
import {
  addMinutesToTime,
  timeToMinutes,
  WEEKDAY_LABELS,
  WEEKDAY_ORDER_MON_FIRST,
} from '../utils/date';
import { createId } from '../utils/id';
import { DurationSelector } from './DurationSelector';
import { PeriodMultiSelector, type PeriodSelectionResult } from './PeriodMultiSelector';

interface CourseRegularSlotsEditorProps {
  organization?: Organization;
  orgPeriods: Period[];
  defaultDurationMinutes: number;
  slots: CourseRegularSlot[];
  onChangeSlots: (nextSlots: CourseRegularSlot[]) => void;
}

const WEEKDAY_SHORT_LABELS: Record<WeekdayNumber, string> = {
  1: '一',
  2: '二',
  3: '三',
  4: '四',
  5: '五',
  6: '六',
  0: '日',
};

function sortSlots(list: CourseRegularSlot[]): CourseRegularSlot[] {
  return [...list].sort((a, b) => {
    const orderA = a.weekday === 0 ? 7 : a.weekday;
    const orderB = b.weekday === 0 ? 7 : b.weekday;
    if (orderA !== orderB) return orderA - orderB;
    return a.startTime.localeCompare(b.startTime);
  });
}

function findMatchingPeriodRange(
  periods: Period[],
  startTime: string,
  endTime: string,
  periodLabel?: string
): string[] {
  if (periods.length === 0) return [];
  for (let i = 0; i < periods.length; i++) {
    if (periods[i].startTime !== startTime) continue;
    for (let j = i; j < periods.length; j++) {
      if (periods[j].endTime !== endTime) continue;
      const label =
        i === j ? periods[i].name : `${periods[i].name}–${periods[j].name}`;
      if (!periodLabel || label === periodLabel) {
        return periods.slice(i, j + 1).map((p) => p.id);
      }
    }
  }
  return [];
}

export function CourseRegularSlotsEditor({
  organization,
  orgPeriods,
  defaultDurationMinutes,
  slots,
  onChangeSlots,
}: CourseRegularSlotsEditorProps) {
  const hasPeriods = orgPeriods.length > 0;

  const [editingSlotId, setEditingSlotId] = useState<string | null>(null);
  const [selectedWeekdays, setSelectedWeekdays] = useState<WeekdayNumber[]>([]);
  const [timeInputMode, setTimeInputMode] = useState<'period' | 'custom'>(
    hasPeriods ? 'period' : 'custom'
  );

  // Period selection state
  const [selectedPeriodIds, setSelectedPeriodIds] = useState<string[]>([]);
  const [slotPeriodLabel, setSlotPeriodLabel] = useState<string | undefined>(
    undefined
  );

  // Start/End & custom duration state
  const safeDefaultDur =
    Number.isFinite(defaultDurationMinutes) && defaultDurationMinutes > 0
      ? defaultDurationMinutes
      : 50;
  const [slotStart, setSlotStart] = useState('19:00');
  const [slotEnd, setSlotEnd] = useState(() =>
    addMinutesToTime('19:00', safeDefaultDur)
  );
  const [slotCustomDuration, setSlotCustomDuration] = useState(() =>
    String(safeDefaultDur)
  );
  const [slotError, setSlotError] = useState<string | null>(null);

  // Sync mode when organization or its periods change
  useEffect(() => {
    setSelectedPeriodIds([]);
    setSlotPeriodLabel(undefined);
    if (!editingSlotId) {
      setTimeInputMode(hasPeriods ? 'period' : 'custom');
    } else if (!hasPeriods) {
      setTimeInputMode('custom');
    }
  }, [organization?.id, hasPeriods, editingSlotId]);

  const toggleWeekday = (day: WeekdayNumber) => {
    setSelectedWeekdays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
    if (slotError) setSlotError(null);
  };

  const syncCustomDurationFromRange = (nextStart: string, nextEnd: string) => {
    if (nextStart && nextEnd && nextStart < nextEnd) {
      const diff = timeToMinutes(nextEnd) - timeToMinutes(nextStart);
      setSlotCustomDuration(diff > 0 ? String(diff) : '');
    } else {
      setSlotCustomDuration('');
    }
  };

  const handlePeriodSelectionChange = (result: PeriodSelectionResult | null) => {
    if (!result) {
      setSelectedPeriodIds([]);
      setSlotPeriodLabel(undefined);
      return;
    }
    setSelectedPeriodIds(result.selectedPeriodIds);
    setSlotStart(result.startTime);
    setSlotEnd(result.endTime);
    setSlotPeriodLabel(result.periodLabel);
    syncCustomDurationFromRange(result.startTime, result.endTime);
    if (slotError) setSlotError(null);
  };

  const resetEditorDraft = () => {
    setEditingSlotId(null);
    setSelectedWeekdays([]);
    setSelectedPeriodIds([]);
    setSlotPeriodLabel(undefined);
    setTimeInputMode(hasPeriods ? 'period' : 'custom');
    setSlotStart('19:00');
    setSlotEnd(addMinutesToTime('19:00', safeDefaultDur));
    setSlotCustomDuration(String(safeDefaultDur));
    setSlotError(null);
  };

  const handleEditSlot = (slot: CourseRegularSlot) => {
    setEditingSlotId(slot.id);
    setSelectedWeekdays([slot.weekday]);
    setSlotStart(slot.startTime);
    setSlotEnd(slot.endTime);
    setSlotPeriodLabel(slot.periodLabel);
    syncCustomDurationFromRange(slot.startTime, slot.endTime);

    if (hasPeriods) {
      const matched = findMatchingPeriodRange(
        orgPeriods,
        slot.startTime,
        slot.endTime,
        slot.periodLabel
      );
      if (matched.length > 0) {
        setTimeInputMode('period');
        setSelectedPeriodIds(matched);
      } else if (slot.periodLabel) {
        setTimeInputMode('custom');
        setSelectedPeriodIds([]);
      } else {
        setTimeInputMode('custom');
        setSelectedPeriodIds([]);
      }
    } else {
      setTimeInputMode('custom');
      setSelectedPeriodIds([]);
    }
    setSlotError(null);
  };

  const handleRemoveSlot = (slotId: string) => {
    onChangeSlots(slots.filter((s) => s.id !== slotId));
    if (editingSlotId === slotId) {
      resetEditorDraft();
    }
  };

  const handleAddOrUpdateSlots = () => {
    if (selectedWeekdays.length === 0) {
      setSlotError('請至少選擇一天星期');
      return;
    }
    if (hasPeriods && timeInputMode === 'period' && selectedPeriodIds.length === 0) {
      setSlotError('請先選擇節次，或切換至「自訂時間」');
      return;
    }
    if (!slotStart || !slotEnd || slotStart >= slotEnd) {
      setSlotError('結束時間必須晚於開始時間');
      return;
    }

    const orderedDays = WEEKDAY_ORDER_MON_FIRST.filter((d) =>
      selectedWeekdays.includes(d)
    );
    const activePeriodLabel =
      hasPeriods && timeInputMode === 'period' ? slotPeriodLabel : undefined;

    if (editingSlotId) {
      const [firstDay, ...extraDays] = orderedDays;
      const updated = slots.map((s) =>
        s.id === editingSlotId
          ? {
              ...s,
              weekday: firstDay,
              startTime: slotStart,
              endTime: slotEnd,
              periodLabel: activePeriodLabel,
            }
          : s
      );
      const extras: CourseRegularSlot[] = extraDays.map((day) => ({
        id: createId(),
        weekday: day,
        startTime: slotStart,
        endTime: slotEnd,
        periodLabel: activePeriodLabel,
      }));
      onChangeSlots(sortSlots([...updated, ...extras]));
      resetEditorDraft();
      return;
    }

    const newEntries: CourseRegularSlot[] = orderedDays.map((day) => ({
      id: createId(),
      weekday: day,
      startTime: slotStart,
      endTime: slotEnd,
      periodLabel: activePeriodLabel,
    }));

    onChangeSlots(sortSlots([...slots, ...newEntries]));
    setSelectedWeekdays([]);
    setSelectedPeriodIds([]);
    setSlotPeriodLabel(undefined);
    setSlotError(null);
  };

  return (
    <div className="border-t border-zinc-100 pt-4">
      <span className="block text-sm font-medium text-zinc-800">
        每週固定時段（常用時段，選填）
      </span>
      <p className="mt-0.5 text-xs text-zinc-500">
        可複選星期與選擇節次或自訂時間；不同星期有不同時段時可重複加入。之後單位調整節次表不會改動已存的時段。
      </p>

      {slots.length > 0 && (
        <div className="mt-2.5 divide-y divide-zinc-100 rounded-xl border border-zinc-200 bg-zinc-50/40">
          {slots.map((slot) => {
            const isEditing = editingSlotId === slot.id;
            return (
              <div
                key={slot.id}
                className={`flex items-center justify-between gap-2 px-3 py-1.5 ${
                  isEditing ? 'bg-[#EDE6FF]/50' : ''
                }`}
              >
                <span className="min-w-0 flex-1 truncate text-sm font-medium text-zinc-900 tabular-nums">
                  {WEEKDAY_LABELS[slot.weekday]}
                  {slot.periodLabel ? ` ${slot.periodLabel}` : ''} {slot.startTime}–
                  {slot.endTime}
                </span>
                <div className="flex shrink-0 items-center gap-0.5">
                  <button
                    type="button"
                    onClick={() => handleEditSlot(slot)}
                    aria-label={`修改 ${WEEKDAY_LABELS[slot.weekday]} ${slot.startTime}`}
                    className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg text-zinc-600 hover:bg-zinc-100"
                  >
                    <Pencil size={15} />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRemoveSlot(slot.id)}
                    aria-label={`移除 ${WEEKDAY_LABELS[slot.weekday]} ${slot.startTime}`}
                    className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg text-rose-600 hover:bg-rose-50"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="mt-2.5 space-y-3 rounded-2xl border border-zinc-200 bg-zinc-50/60 p-2.5 sm:p-3">
        {/* 1. 星期：週一到週日七個圓形按鈕（可多選） */}
        <div>
          <span className="block text-xs font-medium text-zinc-700">
            1. 選擇星期（可多選）
          </span>
          <div className="mt-1.5 grid grid-cols-7 gap-1">
            {WEEKDAY_ORDER_MON_FIRST.map((day) => {
              const active = selectedWeekdays.includes(day);
              return (
                <button
                  key={day}
                  type="button"
                  aria-label={WEEKDAY_LABELS[day]}
                  aria-pressed={active}
                  onClick={() => toggleWeekday(day)}
                  className={`flex h-11 w-full max-w-[44px] justify-self-center items-center justify-center rounded-full text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 ${
                    active
                      ? 'border-2 border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                      : 'border border-zinc-300 bg-white font-medium text-zinc-700 hover:bg-zinc-50'
                  }`}
                >
                  {WEEKDAY_SHORT_LABELS[day]}
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. 時間：單位節次表（若有）或自訂時間切換 */}
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-zinc-700">
              2. 設定上課時間
            </span>
          </div>

          {hasPeriods && (
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                aria-pressed={timeInputMode === 'period'}
                onClick={() => {
                  setTimeInputMode('period');
                  if (slotError) setSlotError(null);
                }}
                className={`flex min-h-[44px] items-center justify-center rounded-xl px-3 text-xs transition-colors ${
                  timeInputMode === 'period'
                    ? 'border-2 border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                    : 'border border-zinc-200 bg-white font-medium text-zinc-700 hover:bg-zinc-50'
                }`}
              >
                依節次選擇
              </button>
              <button
                type="button"
                aria-pressed={timeInputMode === 'custom'}
                onClick={() => {
                  setTimeInputMode('custom');
                  setSelectedPeriodIds([]);
                  setSlotPeriodLabel(undefined);
                  if (slotError) setSlotError(null);
                }}
                className={`flex min-h-[44px] items-center justify-center rounded-xl px-3 text-xs transition-colors ${
                  timeInputMode === 'custom'
                    ? 'border-2 border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                    : 'border border-zinc-200 bg-white font-medium text-zinc-700 hover:bg-zinc-50'
                }`}
              >
                自訂時間
              </button>
            </div>
          )}

          {hasPeriods && timeInputMode === 'period' ? (
            <div className="space-y-1.5">
              <PeriodMultiSelector
                organizationName={organization?.name}
                periods={orgPeriods}
                selectedPeriodIds={selectedPeriodIds}
                periodLabel={slotPeriodLabel}
                onChange={handlePeriodSelectionChange}
              />
              {selectedPeriodIds.length > 0 && (
                <p className="text-xs font-medium text-violet-800 tabular-nums">
                  已帶入：{slotPeriodLabel}（{slotStart}–{slotEnd}）
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-2.5">
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                <div className="min-w-0">
                  <label
                    htmlFor="regular-slot-start"
                    className="block text-[11px] font-medium text-zinc-600"
                  >
                    開始時間
                  </label>
                  <input
                    id="regular-slot-start"
                    type="time"
                    value={slotStart}
                    onChange={(e) => {
                      const nextStart = e.target.value;
                      setSlotStart(nextStart);
                      syncCustomDurationFromRange(nextStart, slotEnd);
                      if (slotError) setSlotError(null);
                    }}
                    className="mt-1 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                  />
                </div>
                <div className="min-w-0">
                  <label
                    htmlFor="regular-slot-end"
                    className="block text-[11px] font-medium text-zinc-600"
                  >
                    結束時間
                  </label>
                  <input
                    id="regular-slot-end"
                    type="time"
                    value={slotEnd}
                    onChange={(e) => {
                      const nextEnd = e.target.value;
                      setSlotEnd(nextEnd);
                      syncCustomDurationFromRange(slotStart, nextEnd);
                      if (slotError) setSlotError(null);
                    }}
                    className="mt-1 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none"
                  />
                </div>
              </div>

              <DurationSelector
                label="快捷時長（依開始時間推算結束時間）"
                activeMinutes={
                  slotStart && slotEnd && slotStart < slotEnd
                    ? timeToMinutes(slotEnd) - timeToMinutes(slotStart)
                    : null
                }
                customValue={slotCustomDuration}
                onSelectPreset={(mins) => {
                  setSlotCustomDuration(String(mins));
                  if (slotStart) {
                    setSlotEnd(addMinutesToTime(slotStart, mins));
                  }
                  if (slotError) setSlotError(null);
                }}
                onCustomChange={(val) => {
                  setSlotCustomDuration(val);
                  const parsed = Number.parseInt(val, 10);
                  if (
                    Number.isFinite(parsed) &&
                    parsed > 0 &&
                    parsed <= 720 &&
                    slotStart
                  ) {
                    setSlotEnd(addMinutesToTime(slotStart, parsed));
                  }
                  if (slotError) setSlotError(null);
                }}
              />
            </div>
          )}
        </div>

        {slotError && (
          <p className="text-xs font-medium text-rose-600">{slotError}</p>
        )}

        <div className="flex items-center gap-2">
          {editingSlotId && (
            <button
              type="button"
              onClick={resetEditorDraft}
              className="flex min-h-[44px] items-center justify-center rounded-xl border border-zinc-200 bg-white px-3 text-xs font-medium text-zinc-700 hover:bg-zinc-50"
            >
              取消修改
            </button>
          )}
          <button
            type="button"
            onClick={handleAddOrUpdateSlots}
            className="flex min-h-[44px] flex-1 items-center justify-center gap-1 rounded-xl border-2 border-violet-600 bg-[#EDE6FF] px-3 py-2 text-xs font-semibold text-zinc-900 transition-colors hover:bg-[#e1d6ff]"
          >
            <Plus size={15} aria-hidden="true" />
            <span>{editingSlotId ? '儲存此筆修改' : '加入'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
