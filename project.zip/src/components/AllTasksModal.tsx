import { ChevronDown, ChevronLeft, ListChecks, Plus } from 'lucide-react';
import { useMemo, useState } from 'react';
import { db } from '../db/database';
import type {
  ClassSession,
  Course,
  Organization,
  TaskItem,
} from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import { formatSlashDateWithWeekday, toDateKey } from '../utils/date';
import { isSessionCancelled, isSubstituteSession } from '../utils/sessionDisplay';
import { getEffectiveTaskDate, placeTasks } from '../utils/taskPlacement';
import { useLiveQuery } from '../utils/useLiveQuery';
import { TaskFormModal } from './TaskFormModal';
import { TaskRowItem } from './TaskRowItem';

interface AllTasksModalProps {
  open: boolean;
  onClose: () => void;
}

export function AllTasksModal({ open, onClose }: AllTasksModalProps) {
  const tasks = useLiveQuery(
    async () => (open ? db.tasks.toArray() : []),
    [open]
  );
  const sessions = useLiveQuery(
    async () => (open ? db.sessions.toArray() : []),
    [open]
  );
  const courses = useLiveQuery(
    async () => (open ? db.courses.toArray() : []),
    [open]
  );
  const organizations = useLiveQuery(
    async () => (open ? db.organizations.toArray() : []),
    [open]
  );

  const [formOpen, setFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskItem | null>(null);
  const [completedExpanded, setCompletedExpanded] = useState(false);

  useBackLayer({
    active: open,
    zLayer: 40,
    onBack: onClose,
  });

  const now = new Date();
  const todayKey = toDateKey(now);

  const courseMap = useMemo(() => {
    const map = new Map<string, Course>();
    for (const c of courses ?? []) map.set(c.id, c);
    return map;
  }, [courses]);

  const sessionMap = useMemo(() => {
    const map = new Map<string, ClassSession>();
    for (const s of sessions ?? []) map.set(s.id, s);
    return map;
  }, [sessions]);

  const placement = useMemo(
    () =>
      placeTasks({
        tasks: tasks ?? [],
        sessions: sessions ?? [],
        now,
      }),
    [tasks, sessions, todayKey, now.getHours(), now.getMinutes()]
  );

  const getTaskMeta = (task: TaskItem): string | undefined => {
    const parts: string[] = [];
    const placedSessionId = placement.sessionIdByTaskId[task.id];
    const directSession = task.sessionId
      ? sessionMap.get(task.sessionId)
      : undefined;
    const effectiveDate = getEffectiveTaskDate(
      task,
      sessionMap,
      placement.nextSessionIdByCourseId
    );

    if (directSession && isSubstituteSession(directSession) && !isSessionCancelled(directSession)) {
      parts.push(`代課 · ${directSession.title}`);
    } else if (task.courseId) {
      const course = courseMap.get(task.courseId);
      if (course) {
        parts.push(course.name);
      }
    }

    if (effectiveDate) {
      parts.push(formatSlashDateWithWeekday(effectiveDate));
    } else if (task.courseId && !placedSessionId) {
      parts.push('尚無後續課堂');
    }

    return parts.length > 0 ? parts.join(' · ') : undefined;
  };

  const grouped = useMemo(() => {
    const overdue: TaskItem[] = [];
    const today: TaskItem[] = [];
    const upcoming: TaskItem[] = [];
    const noDate: TaskItem[] = [];
    const completed: TaskItem[] = [];

    for (const task of tasks ?? []) {
      if (task.done) {
        completed.push(task);
        continue;
      }

      const effectiveDate = getEffectiveTaskDate(
        task,
        sessionMap,
        placement.nextSessionIdByCourseId
      );

      if (!effectiveDate) {
        noDate.push(task);
      } else if (effectiveDate < todayKey) {
        overdue.push(task);
      } else if (effectiveDate === todayKey) {
        today.push(task);
      } else {
        upcoming.push(task);
      }
    }

    const sortActive = (a: TaskItem, b: TaskItem) => {
      const dateA =
        getEffectiveTaskDate(a, sessionMap, placement.nextSessionIdByCourseId) ??
        '';
      const dateB =
        getEffectiveTaskDate(b, sessionMap, placement.nextSessionIdByCourseId) ??
        '';
      const dateDiff = dateA.localeCompare(dateB);
      if (dateDiff !== 0) return dateDiff;
      if (a.dueTime && b.dueTime) {
        const timeDiff = a.dueTime.localeCompare(b.dueTime);
        if (timeDiff !== 0) return timeDiff;
      } else if (a.dueTime || b.dueTime) {
        return a.dueTime ? -1 : 1;
      }
      return a.createdAt - b.createdAt;
    };

    overdue.sort(sortActive);
    today.sort(sortActive);
    upcoming.sort(sortActive);
    noDate.sort((a, b) => a.createdAt - b.createdAt);
    completed.sort((a, b) => (b.doneAt ?? b.updatedAt) - (a.doneAt ?? a.updatedAt));

    return { overdue, today, upcoming, noDate, completed };
  }, [tasks, sessionMap, placement.nextSessionIdByCourseId, todayKey]);

  if (!open) return null;

  const isLoading =
    tasks === undefined ||
    sessions === undefined ||
    courses === undefined ||
    organizations === undefined;

  const activeTotal =
    grouped.overdue.length +
    grouped.today.length +
    grouped.upcoming.length +
    grouped.noDate.length;

  const renderGroup = (
    label: string,
    items: TaskItem[],
    options?: { isOverdue?: boolean }
  ) => {
    if (items.length === 0) return null;
    return (
      <div
        className={`overflow-hidden rounded-2xl border ${
          options?.isOverdue
            ? 'border-rose-200/90 bg-[#FFF5F7]'
            : 'border-zinc-200 bg-white'
        }`}
      >
        <div
          className={`flex items-center justify-between border-b px-4 py-2.5 ${
            options?.isOverdue
              ? 'border-rose-200/70 bg-rose-100/40'
              : 'border-zinc-100 bg-zinc-50/70'
          }`}
        >
          <h3
            className={`text-xs font-semibold ${
              options?.isOverdue ? 'text-rose-900' : 'text-zinc-800'
            }`}
          >
            {label}
          </h3>
          <span
            className={`text-xs font-medium tabular-nums ${
              options?.isOverdue ? 'text-rose-700' : 'text-zinc-500'
            }`}
          >
            {items.length} 筆
          </span>
        </div>
        <div
          className={`divide-y px-2 py-1 ${
            options?.isOverdue ? 'divide-rose-200/60' : 'divide-zinc-100'
          }`}
        >
          {items.map((item) => (
            <TaskRowItem
              key={item.id}
              task={item}
              metaText={getTaskMeta(item)}
              onEdit={(t) => {
                setEditingTask(t);
                setFormOpen(true);
              }}
            />
          ))}
        </div>
      </div>
    );
  };

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="all-tasks-title"
        className="fixed inset-0 z-40 flex flex-col bg-[var(--bg-canvas)]"
      >
        <header className="sticky top-0 z-10 border-b border-violet-200/70 bg-white/95 backdrop-blur-md">
          <div className="mx-auto flex h-12 w-full max-w-2xl items-center justify-between gap-2 px-2">
            <button
              type="button"
              onClick={onClose}
              className="flex min-h-[44px] shrink-0 items-center gap-1 rounded-xl px-2.5 text-sm font-medium text-zinc-700 transition-colors hover:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
            >
              <ChevronLeft size={18} aria-hidden="true" />
              <span>返回</span>
            </button>

            <h2
              id="all-tasks-title"
              className="truncate text-base font-semibold text-zinc-900"
            >
              全部任務
            </h2>

            <button
              type="button"
              onClick={() => {
                setEditingTask(null);
                setFormOpen(true);
              }}
              className="flex min-h-[44px] shrink-0 items-center gap-1 rounded-xl px-2.5 text-xs font-semibold text-violet-700 transition-colors hover:bg-violet-50 whitespace-nowrap"
            >
              <Plus size={15} aria-hidden="true" />
              <span>新增任務</span>
            </button>
          </div>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
          <div className="mx-auto w-full max-w-2xl space-y-3.5 px-4 py-4 pb-[calc(2rem+env(safe-area-inset-bottom)+var(--kb-inset,0px))]">
            {isLoading ? (
              <div className="rounded-2xl border border-zinc-200 bg-white p-8 text-center text-sm text-zinc-500">
                載入中…
              </div>
            ) : activeTotal === 0 && grouped.completed.length === 0 ? (
              <div className="rounded-2xl border border-zinc-200 bg-white px-5 py-10 text-center">
                <ListChecks
                  size={24}
                  className="mx-auto text-zinc-400"
                  aria-hidden="true"
                />
                <h3 className="mt-2.5 text-base font-semibold text-zinc-900">
                  目前沒有任務或提醒
                </h3>
                <p className="mt-1 text-xs text-zinc-500">
                  點右上角「新增任務」，可建立可勾選待辦或純文字提醒，也可掛到特定班級或場次。
                </p>
              </div>
            ) : (
              <>
                {activeTotal === 0 && (
                  <div className="rounded-2xl border border-zinc-200 bg-white px-5 py-6 text-center text-sm text-zinc-600">
                    目前沒有待辦或未來的提醒，做得很好！
                  </div>
                )}

                {renderGroup('逾期', grouped.overdue, { isOverdue: true })}
                {renderGroup('今天', grouped.today)}
                {renderGroup('之後', grouped.upcoming)}
                {renderGroup('無日期', grouped.noDate)}

                {grouped.completed.length > 0 && (
                  <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white">
                    <button
                      type="button"
                      aria-expanded={completedExpanded}
                      onClick={() => setCompletedExpanded((prev) => !prev)}
                      className="flex min-h-[48px] w-full items-center justify-between gap-3 px-4 py-2.5 text-left transition-colors hover:bg-zinc-50"
                    >
                      <span className="text-xs font-semibold text-zinc-600 tabular-nums">
                        已完成（{grouped.completed.length}）
                      </span>
                      <ChevronDown
                        size={17}
                        aria-hidden="true"
                        className={`shrink-0 text-zinc-400 transition-transform duration-150 ${
                          completedExpanded ? 'rotate-180' : ''
                        }`}
                      />
                    </button>
                    {completedExpanded && (
                      <div className="divide-y divide-zinc-100 border-t border-zinc-100 px-2 py-1">
                        {grouped.completed.map((item) => (
                          <TaskRowItem
                            key={item.id}
                            task={item}
                            metaText={getTaskMeta(item)}
                            onEdit={(t) => {
                              setEditingTask(t);
                              setFormOpen(true);
                            }}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      <TaskFormModal
        open={formOpen}
        task={editingTask}
        courses={courses ?? []}
        sessions={sessions ?? []}
        organizations={organizations ?? []}
        onClose={() => setFormOpen(false)}
      />
    </>
  );
}
