import { Archive, Pencil, Plus, Trash2, X } from 'lucide-react';
import { useEffect, useState, type FormEvent } from 'react';
import { db } from '../db/database';
import {
  deleteAcademicYearCascade,
  getAcademicYearDeleteSummary,
} from '../db/repositories';
import type { AcademicYear } from '../db/types';
import { getCurrentTaiwanAcademicYearTemplate } from '../utils/academicYear';
import { useBackLayer } from '../utils/backNavigation';
import { createId } from '../utils/id';
import { useLiveQuery } from '../utils/useLiveQuery';
import { ConfirmDialog } from './ConfirmDialog';

interface AcademicYearManagerModalProps {
  open: boolean;
  selectedYearId: string;
  onSelectYear: (yearId: string) => void;
  onClose: () => void;
}

export function AcademicYearManagerModal({
  open,
  selectedYearId,
  onSelectYear,
  onClose,
}: AcademicYearManagerModalProps) {
  const years = useLiveQuery(
    () => db.academicYears.orderBy('startDate').reverse().toArray(),
    []
  );

  const [editingYear, setEditingYear] = useState<AcademicYear | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const [name, setName] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [archived, setArchived] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<AcademicYear | null>(null);
  const [deleteSummary, setDeleteSummary] = useState<{
    courseCount: number;
    sessionCount: number;
    imageCount: number;
  } | null>(null);
  const [formInitialSnapshot, setFormInitialSnapshot] = useState<string | null>(
    null
  );
  const [discardTarget, setDiscardTarget] = useState<'list' | 'close' | null>(
    null
  );

  useEffect(() => {
    if (!open) return;
    setIsCreating(false);
    setEditingYear(null);
    setError(null);
    setDeleteTarget(null);
    setDeleteSummary(null);
    setFormInitialSnapshot(null);
    setDiscardTarget(null);
  }, [open]);

  const showForm = isCreating || editingYear !== null;
  const isFormDirty =
    showForm &&
    formInitialSnapshot !== null &&
    JSON.stringify({ name, startDate, endDate, archived }) !==
      formInitialSnapshot;

  const cancelForm = () => {
    setIsCreating(false);
    setEditingYear(null);
    setError(null);
    setFormInitialSnapshot(null);
  };

  const handleBack = () => {
    if (isSaving) return;
    if (showForm) {
      if (isFormDirty) {
        setDiscardTarget('list');
        return;
      }
      cancelForm();
      return;
    }
    onClose();
  };

  const handleRequestCloseModal = () => {
    if (isSaving) return;
    if (showForm && isFormDirty) {
      setDiscardTarget('close');
      return;
    }
    onClose();
  };

  useBackLayer({
    active: open,
    zLayer: 55,
    onBack: handleBack,
  });

  if (!open) {
    return null;
  }

  const startCreate = () => {
    const tpl = getCurrentTaiwanAcademicYearTemplate(new Date());
    setEditingYear(null);
    setIsCreating(true);
    setName(tpl.name);
    setStartDate(tpl.startDate);
    setEndDate(tpl.endDate);
    setArchived(false);
    setError(null);
    setFormInitialSnapshot(
      JSON.stringify({
        name: tpl.name,
        startDate: tpl.startDate,
        endDate: tpl.endDate,
        archived: false,
      })
    );
  };

  const startEdit = (year: AcademicYear) => {
    setIsCreating(false);
    setEditingYear(year);
    setName(year.name);
    setStartDate(year.startDate);
    setEndDate(year.endDate);
    setArchived(year.archived);
    setError(null);
    setFormInitialSnapshot(
      JSON.stringify({
        name: year.name,
        startDate: year.startDate,
        endDate: year.endDate,
        archived: year.archived,
      })
    );
  };

  const handleSaveForm = async (e: FormEvent) => {
    e.preventDefault();
    const trimmedName = name.trim();
    if (!trimmedName) {
      setError('請輸入學年名稱');
      return;
    }
    if (!startDate || !endDate) {
      setError('請選擇起迄日期');
      return;
    }
    if (startDate > endDate) {
      setError('起日不可晚於迄日');
      return;
    }

    setIsSaving(true);
    try {
      const now = Date.now();
      const id = editingYear?.id ?? createId();
      await db.academicYears.put({
        id,
        name: trimmedName,
        startDate,
        endDate,
        archived,
        createdAt: editingYear?.createdAt ?? now,
        updatedAt: now,
      });
      if (!editingYear) {
        onSelectYear(id);
      }
      cancelForm();
    } finally {
      setIsSaving(false);
    }
  };

  const handleRequestDelete = async (year: AcademicYear) => {
    const summary = await getAcademicYearDeleteSummary(year.id);
    setDeleteSummary(summary);
    setDeleteTarget(year);
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setIsSaving(true);
    try {
      await deleteAcademicYearCascade(deleteTarget.id);
      if (selectedYearId === deleteTarget.id && years) {
        const remaining = years.find((y) => y.id !== deleteTarget.id);
        if (remaining) {
          onSelectYear(remaining.id);
        }
      }
      setDeleteTarget(null);
      if (editingYear?.id === deleteTarget.id) {
        cancelForm();
      }
    } finally {
      setIsSaving(false);
    }
  };

  const canDeleteYear = (years?.length ?? 0) > 1;

  const deleteDescription = deleteTarget
    ? `確定要刪除學年「${deleteTarget.name}」嗎？這將會連同底下的 ${
        deleteSummary?.courseCount ?? 0
      } 門課程、${deleteSummary?.sessionCount ?? 0} 筆場次與 ${
        deleteSummary?.imageCount ?? 0
      } 張圖片一併刪除，且無法復原。`
    : '';

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="year-manager-title"
        className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
      >
        <div className="flex max-h-[90dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 bg-white px-4 py-3">
            <h2 id="year-manager-title" className="text-base font-semibold text-zinc-900">
              {showForm ? (editingYear ? '編輯學年' : '新增學年') : '學年管理'}
            </h2>
            <button
              type="button"
              onClick={handleRequestCloseModal}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
            >
              <X size={20} />
            </button>
          </div>

          {showForm ? (
            <form
              onSubmit={(e) => void handleSaveForm(e)}
              className="flex min-h-0 flex-1 flex-col"
            >
              <div className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-4 scroll-mb-6">
                <div>
                  <label
                    htmlFor="year-name-input"
                    className="block text-sm font-medium text-zinc-800"
                  >
                    學年名稱 <span className="text-rose-600">*</span>
                  </label>
                  <input
                    id="year-name-input"
                    type="text"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (error) setError(null);
                    }}
                    placeholder="例如：115 學年度上學期"
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="year-start-input"
                      className="block text-sm font-medium text-zinc-800"
                    >
                      起日
                    </label>
                    <input
                      id="year-start-input"
                      type="date"
                      value={startDate}
                      onChange={(e) => {
                        setStartDate(e.target.value);
                        if (error) setError(null);
                      }}
                      className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="year-end-input"
                      className="block text-sm font-medium text-zinc-800"
                    >
                      迄日
                    </label>
                    <input
                      id="year-end-input"
                      type="date"
                      value={endDate}
                      onChange={(e) => {
                        setEndDate(e.target.value);
                        if (error) setError(null);
                      }}
                      className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                    />
                  </div>
                </div>

                <label className="flex min-h-[44px] cursor-pointer items-center justify-between rounded-xl border border-zinc-200 px-3.5 py-2">
                  <span className="flex items-center gap-2 text-sm font-medium text-zinc-800">
                    <Archive size={16} className="text-zinc-500" aria-hidden="true" />
                    <span>已歸檔學年</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={archived}
                    onChange={(e) => setArchived(e.target.checked)}
                    className="h-5 w-5 rounded border-zinc-300 text-violet-600 focus:ring-violet-600"
                  />
                </label>

                {error && (
                  <p className="text-xs font-medium text-rose-600">{error}</p>
                )}
              </div>

              <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handleBack}
                    disabled={isSaving}
                    className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm font-medium text-zinc-700 hover:bg-zinc-50"
                  >
                    返回列表
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl bg-violet-600 px-4 py-2 text-sm font-medium text-white hover:bg-violet-700 disabled:opacity-60"
                  >
                    {isSaving ? '儲存中…' : '儲存學年'}
                  </button>
                </div>
              </div>
            </form>
          ) : (
            <div className="flex min-h-0 flex-1 flex-col">
              <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-4">
                <div className="divide-y divide-zinc-100 rounded-2xl border border-zinc-200 bg-white">
                  {years === undefined ? (
                    <p className="p-4 text-center text-sm text-zinc-500">載入中…</p>
                  ) : years.length === 0 ? (
                    <p className="p-4 text-center text-sm text-zinc-500">尚無學年資料</p>
                  ) : (
                    years.map((year) => {
                      const isCurrentSelected = year.id === selectedYearId;
                      return (
                        <div
                          key={year.id}
                          className="flex items-center justify-between gap-2 px-3.5 py-2.5"
                        >
                          <button
                            type="button"
                            onClick={() => {
                              onSelectYear(year.id);
                              onClose();
                            }}
                            className="flex min-h-[44px] min-w-0 flex-1 flex-col items-start justify-center text-left"
                          >
                            <span className="truncate text-sm font-semibold text-zinc-900">
                              {year.name}
                              {isCurrentSelected ? (
                                <span className="ml-2 text-xs font-medium text-violet-700">
                                  目前檢視
                                </span>
                              ) : null}
                            </span>
                            <span className="mt-0.5 text-xs text-zinc-500 tabular-nums">
                              {year.startDate} ~ {year.endDate}
                              {year.archived ? ' · 已歸檔' : ''}
                            </span>
                          </button>

                          <div className="flex shrink-0 items-center gap-1">
                            <button
                              type="button"
                              onClick={() => startEdit(year)}
                              aria-label={`編輯 ${year.name}`}
                              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-600 hover:bg-zinc-100 hover:text-zinc-900"
                            >
                              <Pencil size={17} />
                            </button>
                            {canDeleteYear && (
                              <button
                                type="button"
                                onClick={() => {
                                  void handleRequestDelete(year);
                                }}
                                aria-label={`刪除 ${year.name}`}
                                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-rose-600 hover:bg-rose-50"
                              >
                                <Trash2 size={17} />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
                <button
                  type="button"
                  onClick={startCreate}
                  className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-violet-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2"
                >
                  <Plus size={18} aria-hidden="true" />
                  <span>新增學年</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <ConfirmDialog
        open={deleteTarget !== null}
        title="刪除學年"
        description={deleteDescription}
        confirmLabel="確認刪除"
        isSubmitting={isSaving}
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          void handleConfirmDelete();
        }}
      />

      <ConfirmDialog
        open={discardTarget !== null}
        title="放棄未儲存的內容？"
        description="目前有尚未儲存的修改，確定要放棄並返回嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardTarget(null)}
        onConfirm={() => {
          const target = discardTarget;
          setDiscardTarget(null);
          cancelForm();
          if (target === 'close') {
            onClose();
          }
        }}
      />
    </>
  );
}
