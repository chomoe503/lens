import {
  BookOpen,
  CalendarRange,
  ClipboardCheck,
  ExternalLink,
  Plus,
  X,
} from 'lucide-react';
import { useMemo } from 'react';
import type {
  ClassSession,
  Course,
  Exam,
  ExamPeriod,
  Homework,
  Organization,
  TaskItem,
} from '../db/types';
import { useBackLayer } from '../utils/backNavigation';
import { formatSlashDate, formatSlashDateWithWeekday } from '../utils/date';
import {
  getExamDisplayTitle,
  type SessionCountdown,
} from '../utils/examCountdown';
import { isSessionCancelled, resolveSessionDisplay } from '../utils/sessionDisplay';
import { hasSessionEnded, type PlacedTaskEntry } from '../utils/taskPlacement';
import { HOMEWORK_STATUS_OPTIONS } from './HomeworkFormModal';
import { CancelledBadge, SessionMenuButton } from './SessionQuickActions';
import { SubstituteBadge } from './SubstituteBadge';
import { TaskRowItem } from './TaskRowItem';

interface WeekGridDetailSheetProps {
  session: ClassSession | null;
  unattachedDate: string | null;
  courseMap: Map<string, Course>;
  orgMap: Map<string, Organization>;
  sessionTasks: PlacedTaskEntry[];
  unattachedTasks: TaskItem[];
  dayCourseHomeworks: Homework[];
  dayCourseExams: Exam[];
  countdown?: SessionCountdown;
  activeExamPeriods?: ExamPeriod[];
  onClose: () => void;
  onOpenFullSession: (session: ClassSession) => void;
  onOpenSessionMenu?: (session: ClassSession) => void;
  onAddTaskForSession: (session: ClassSession) => void;
  onAddTaskForDate: (dateKey: string) => void;
  onEditTask: (task: TaskItem) => void;
}

export function WeekGridDetailSheet({
  session,
  unattachedDate,
  courseMap,
  orgMap,
  sessionTasks,
  unattachedTasks,
  dayCourseHomeworks,
  dayCourseExams,
  countdown,
  activeExamPeriods = [],
  onClose,
  onOpenFullSession,
  onOpenSessionMenu,
  onAddTaskForSession,
  onAddTaskForDate,
  onEditTask,
}: WeekGridDetailSheetProps) {
  const open = session !== null || unattachedDate !== null;

  const organizationsList = useMemo(
    () => Array.from(orgMap.values()),
    [orgMap]
  );

  useBackLayer({
    active: open,
    zLayer: 45,
    onBack: onClose,
  });

  if (!open) return null;

  if (unattachedDate && !session) {
    return (
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="grid-sheet-unattached-title"
        className="fixed inset-0 z-[45] flex items-end justify-center bg-black/45 backdrop-blur-xs sm:items-center sm:p-4"
        onClick={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
      >
        <div className="flex max-h-[82dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between gap-2 border-b border-zinc-100 px-5 py-3.5">
            <div className="min-w-0">
              <h2
                id="grid-sheet-unattached-title"
                className="truncate text-base font-semibold text-zinc-900"
              >
                {formatSlashDateWithWeekday(unattachedDate)} · 其他任務
              </h2>
              <p className="text-xs text-zinc-500">沒掛在課堂上的待辦與提醒</p>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
            >
              <X size={20} />
            </button>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-3">
            {unattachedTasks.length === 0 ? (
              <p className="py-6 text-center text-sm text-zinc-500">
                這天目前沒有其他任務
              </p>
            ) : (
              <div className="divide-y divide-zinc-100">
                {unattachedTasks.map((t) => (
                  <TaskRowItem
                    key={t.id}
                    task={t}
                    onEdit={(target) => onEditTask(target)}
                  />
                ))}
              </div>
            )}
          </div>

          <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
            <button
              type="button"
              onClick={() => onAddTaskForDate(unattachedDate)}
              className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-violet-700"
            >
              <Plus size={16} aria-hidden="true" />
              <span>新增任務</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!session) return null;

  const resolved = resolveSessionDisplay(session, courseMap, orgMap);
  const isCancelled = isSessionCancelled(session);
  const ended = hasSessionEnded(session, new Date());
  const progressText = session.progress?.trim() ?? '';
  const activeGridTasks = sessionTasks.filter((entry) => !entry.task.done);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="grid-sheet-session-title"
      className="fixed inset-0 z-[45] flex items-end justify-center bg-black/45 backdrop-blur-xs sm:items-center sm:p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="flex max-h-[86dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
        {/* 頂部資訊 */}
        <div className="flex shrink-0 items-start justify-between gap-2 border-b border-zinc-100 px-5 py-3.5">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span
                aria-hidden="true"
                style={{ backgroundColor: resolved.color }}
                className={`h-4 w-4 shrink-0 rounded-sm ring-1 ring-inset ring-black/15 ${
                  isCancelled ? 'opacity-45' : ''
                }`}
              />
              <h2
                id="grid-sheet-session-title"
                className={`truncate text-base font-bold ${
                  isCancelled ? 'text-zinc-400 line-through' : 'text-zinc-900'
                }`}
              >
                {resolved.title}
              </h2>
              {isCancelled && <CancelledBadge />}
            </div>

            <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 pl-[24px] text-xs text-zinc-500 tabular-nums">
              <span>{resolved.orgName}</span>
              {resolved.isSubstitute && <SubstituteBadge />}
              {resolved.substituteFor && (
                <span className="text-zinc-700">（代 {resolved.substituteFor}）</span>
              )}
              <span aria-hidden="true" className="text-zinc-300">
                ·
              </span>
              <span className="font-medium text-zinc-700">
                {formatSlashDateWithWeekday(session.date)} {session.startTime}–
                {session.endTime}
              </span>
              {session.periodLabel && <span>· {session.periodLabel}</span>}
            </div>

            {session.originalDate && session.originalStartTime && (
              <p className="mt-0.5 pl-[24px] text-xs font-medium text-violet-700 tabular-nums">
                調課（原定 {formatSlashDate(session.originalDate)}{' '}
                {session.originalStartTime}）
              </p>
            )}
          </div>

          <div className="flex shrink-0 items-center gap-1">
            {onOpenSessionMenu && (
              <SessionMenuButton
                onClick={() => onOpenSessionMenu(session)}
                ariaLabel={`更多操作：${resolved.title}`}
              />
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* 內容區 */}
        <div className="min-h-0 flex-1 space-y-3.5 overflow-y-auto overscroll-contain px-5 py-4">
          {/* 進度 */}
          <div className="rounded-2xl border border-zinc-200/80 bg-zinc-50/70 px-3.5 py-2.5">
            <p className="text-[11px] font-semibold text-zinc-500">上課進度</p>
            {progressText ? (
              <p className="mt-1 text-sm text-zinc-900">{progressText}</p>
            ) : (
              <p className="mt-1 text-xs text-zinc-400">
                {!isCancelled && ended ? '尚未記錄' : '尚未填寫上課進度'}
              </p>
            )}
          </div>

          {/* 考試期間與考前倒數 */}
          {!isCancelled && (activeExamPeriods.length > 0 || countdown) && (
            <div className="space-y-1.5">
              {activeExamPeriods.length > 0 && (
                <div className="flex items-center gap-2 rounded-2xl border border-pink-200 bg-[#FFF5F9] px-3.5 py-2.5 text-xs font-semibold text-pink-950">
                  <CalendarRange
                    size={15}
                    className="shrink-0 text-pink-700"
                    aria-hidden="true"
                  />
                  <span className="min-w-0 flex-1">
                    考試期間：
                    {activeExamPeriods
                      .map((p) => getExamDisplayTitle(p, organizationsList))
                      .join('、')}
                  </span>
                </div>
              )}

              {countdown && (
                <div
                  className={`space-y-1.5 rounded-2xl border px-3.5 py-2.5 text-xs tabular-nums ${
                    countdown.isLast
                      ? 'border-pink-200 bg-[#FCE7F3] font-semibold text-pink-950'
                      : 'border-orange-200 bg-[#FFF3E0] font-medium text-orange-950'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <CalendarRange
                      size={15}
                      className={`shrink-0 ${
                        countdown.isLast ? 'text-pink-700' : 'text-orange-700'
                      }`}
                      aria-hidden="true"
                    />
                    <span className="min-w-0 flex-1">
                      {countdown.isLast
                        ? `考試倒數：${countdown.title}（${formatSlashDate(
                            countdown.targetDate
                          )}），考前最後一堂`
                        : `考試倒數：${countdown.title}（${formatSlashDate(
                            countdown.targetDate
                          )}），這堂之後還剩 ${countdown.sessionsLeft - 1} 堂，還有 ${
                            countdown.daysLeft
                          } 天`}
                    </span>
                  </div>

                  {countdown.later.length > 0 && (
                    <div className="space-y-1 border-t border-black/10 pl-[23px] pt-1.5 text-[11px] font-normal opacity-90">
                      {countdown.later.slice(0, 4).map((item) => (
                        <p key={item.examPeriodId}>
                          之後：{item.title}（{formatSlashDate(item.targetDate)}
                          ），
                          {item.isLast
                            ? '考前最後一堂'
                            : `這堂之後還剩 ${item.sessionsLeft - 1} 堂，還有 ${
                                item.daysLeft
                              } 天`}
                        </p>
                      ))}
                      {countdown.later.length > 4 && (
                        <p className="opacity-75">
                          …另有 {countdown.later.length - 4} 個
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* 任務與提醒 */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between px-0.5">
              <h3 className="text-xs font-semibold text-zinc-700">
                任務與提醒（{activeGridTasks.length}）
              </h3>
            </div>

            {activeGridTasks.length === 0 ? (
              <p className="rounded-xl border border-zinc-200/70 bg-white px-3.5 py-2.5 text-xs text-zinc-400">
                這堂課目前沒有待辦或提醒
              </p>
            ) : (
              <div className="divide-y divide-zinc-100 rounded-2xl border border-zinc-200 bg-white px-2 py-0.5">
                {activeGridTasks.map((entry) => (
                  <TaskRowItem
                    key={entry.task.id}
                    task={entry.task}
                    metaText={
                      entry.origin === 'course_next' ? '跟隨班級下堂課' : undefined
                    }
                    onEdit={(target) => onEditTask(target)}
                  />
                ))}
              </div>
            )}
          </div>

          {/* 當日作業與考試 */}
          {(dayCourseHomeworks.length > 0 || dayCourseExams.length > 0) && (
            <div className="space-y-2 rounded-2xl border border-zinc-200 bg-white p-3.5">
              {dayCourseHomeworks.map((hw) => {
                const statusLabel =
                  HOMEWORK_STATUS_OPTIONS.find((opt) => opt.value === hw.status)
                    ?.label ?? hw.status;
                return (
                  <div
                    key={hw.id}
                    className="flex items-center gap-2 text-xs text-emerald-950"
                  >
                    <BookOpen
                      size={15}
                      className="shrink-0 text-emerald-700"
                      aria-hidden="true"
                    />
                    <span className="min-w-0 flex-1 font-medium">
                      作業繳交：{hw.title}
                    </span>
                    <span className="shrink-0 text-[11px] font-semibold text-emerald-700">
                      {statusLabel}
                    </span>
                  </div>
                );
              })}

              {dayCourseExams.map((exam) => (
                <div
                  key={exam.id}
                  className="flex items-center gap-2 text-xs text-pink-950 tabular-nums"
                >
                  <ClipboardCheck
                    size={15}
                    className="shrink-0 text-pink-700"
                    aria-hidden="true"
                  />
                  <span className="min-w-0 flex-1 font-medium">
                    考試：{exam.title}
                    {exam.examType ? `（${exam.examType}）` : ''}
                    {exam.time ? ` · ${exam.time}` : ''}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 底部操作按鈕 */}
        <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => onAddTaskForSession(session)}
              className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-violet-300 bg-[#F2ECFF] px-3 text-sm font-semibold text-zinc-900 transition-colors hover:bg-[#e8ddff]"
            >
              <Plus size={16} aria-hidden="true" />
              <span>新增任務</span>
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenFullSession(session);
              }}
              className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-violet-600 px-3 text-sm font-semibold text-white transition-colors hover:bg-violet-700"
            >
              <ExternalLink size={15} aria-hidden="true" />
              <span>開啟場次頁</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
