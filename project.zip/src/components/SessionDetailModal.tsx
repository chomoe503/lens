import {
  CheckCircle2,
  ChevronLeft,
  Clock,
  MapPin,
  Pencil,
  Plus,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { db } from '../db/database';
import type {
  ClassSession,
  Course,
  Homework,
  Organization,
  StoredImage,
  TaskItem,
} from '../db/types';
import { formatSlashDate, formatSlashDateWithWeekday } from '../utils/date';
import { createId } from '../utils/id';
import type { CompressedImageResult } from '../utils/imageCompression';
import { useBackLayer } from '../utils/backNavigation';
import { isSessionCancelled, isSubstituteSession } from '../utils/sessionDisplay';
import { placeTasks } from '../utils/taskPlacement';
import { useLiveQuery } from '../utils/useLiveQuery';
import { ConfirmDialog } from './ConfirmDialog';
import { HOMEWORK_STATUS_OPTIONS, HomeworkFormModal } from './HomeworkFormModal';
import { PhotoGallerySection, type DisplayImageItem } from './PhotoGallerySection';
import { SessionFormModal } from './SessionFormModal';
import {
  CancelledBadge,
  SessionMenuButton,
  SessionQuickActionsHost,
  useSessionQuickActions,
} from './SessionQuickActions';
import { SubstituteBadge } from './SubstituteBadge';
import { TaskFormModal } from './TaskFormModal';
import { TaskRowItem } from './TaskRowItem';

interface SessionDetailModalProps {
  session: ClassSession | null;
  course?: Course;
  organization?: Organization;
  allCourses: Course[];
  allOrganizations: Organization[];
  onClose: () => void;
}

const HOMEWORK_STATUS_STYLES: Record<Homework['status'], string> = {
  uncollected: 'text-amber-700 font-semibold',
  collected: 'text-violet-700 font-semibold',
  graded: 'text-emerald-700 font-semibold',
};

function getHomeworkStatusLabel(status: Homework['status']): string {
  return (
    HOMEWORK_STATUS_OPTIONS.find((opt) => opt.value === status)?.label ?? status
  );
}

export function SessionDetailModal({
  session,
  course,
  organization,
  allCourses,
  allOrganizations,
  onClose,
}: SessionDetailModalProps) {
  const sessionImages = useLiveQuery(async (): Promise<StoredImage[]> => {
    if (!session) return [];
    const rows = await db.images.where('sessionId').equals(session.id).toArray();
    return rows.sort((a, b) => a.createdAt - b.createdAt);
  }, [session?.id]);

  const sessionHomeworks = useLiveQuery(async (): Promise<Homework[]> => {
    if (!session) return [];
    const rows = await db.homeworks.where('sessionId').equals(session.id).toArray();
    return rows.sort((a, b) => b.createdAt - a.createdAt);
  }, [session?.id]);

  const linkedCancelledSession = useLiveQuery(async () => {
    if (!session?.makeupForSessionId) return undefined;
    return db.sessions.get(session.makeupForSessionId);
  }, [session?.makeupForSessionId]);

  const allTasks = useLiveQuery(async (): Promise<TaskItem[]> => {
    if (!session) return [];
    return db.tasks.toArray();
  }, [session?.id]);

  const allSessions = useLiveQuery(async (): Promise<ClassSession[]> => {
    if (!session) return [];
    return db.sessions.toArray();
  }, [session?.id]);

  const [progress, setProgress] = useState('');
  const [note, setNote] = useState('');
  const [isSavingText, setIsSavingText] = useState(false);
  const [savedToast, setSavedToast] = useState(false);

  const [editModalOpen, setEditModalOpen] = useState(false);
  const [homeworkModalOpen, setHomeworkModalOpen] = useState(false);
  const [editingHomework, setEditingHomework] = useState<Homework | null>(null);
  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskItem | null>(null);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);

  const sessionTaskEntries = useMemo(() => {
    if (!session || !allTasks || !allSessions) return [];
    const placement = placeTasks({
      tasks: allTasks,
      sessions: allSessions,
      now: new Date(),
    });
    return placement.tasksBySessionId[session.id] ?? [];
  }, [session, allTasks, allSessions]);

  const { openSessionMenu, quickActionsProps } = useSessionQuickActions({
    courses: allCourses,
    organizations: allOrganizations,
    onSessionDeleted: () => onClose(),
  });

  useEffect(() => {
    if (!session) return;
    setProgress(session.progress ?? '');
    setNote(session.note ?? '');
    setSavedToast(false);
    setDiscardConfirmOpen(false);
  }, [session?.id, session?.progress, session?.note]);

  const hasTextChanges = Boolean(
    session &&
      (progress !== (session.progress ?? '') || note !== (session.note ?? ''))
  );

  const handleRequestClose = () => {
    if (isSavingText) return;
    if (hasTextChanges) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: session !== null,
    zLayer: 50,
    onBack: handleRequestClose,
  });

  if (!session) {
    return null;
  }

  const isSub = isSubstituteSession(session);
  const resolvedOrg = isSub
    ? session.organizationId
      ? allOrganizations.find((o) => o.id === session.organizationId)
      : undefined
    : (organization ??
      (session.organizationId
        ? allOrganizations.find((o) => o.id === session.organizationId)
        : undefined));

  const displayName = isSub ? session.title : (course?.name ?? session.title);
  const displayColor = isSub
    ? (resolvedOrg?.color ?? '#FDE68A')
    : (course?.color ?? resolvedOrg?.color ?? '#CDB8FF');
  const isCancelled = isSessionCancelled(session);

  const handleSaveProgressAndNote = async () => {
    setIsSavingText(true);
    try {
      await db.sessions.update(session.id, {
        progress: progress.trim() || undefined,
        note: note.trim() || undefined,
        updatedAt: Date.now(),
      });
      setSavedToast(true);
      window.setTimeout(() => setSavedToast(false), 2500);
    } finally {
      setIsSavingText(false);
    }
  };

  const handleAddPhotos = async (results: CompressedImageResult[]) => {
    const now = Date.now();
    const records: StoredImage[] = results.map((res, idx) => ({
      id: createId(),
      sessionId: session.id,
      courseId: session.courseId,
      fileName: res.fileName,
      mimeType: res.mimeType,
      blob: res.blob,
      thumbnailBlob: res.thumbnailBlob,
      createdAt: now + idx,
    }));
    await db.images.bulkPut(records);
  };

  const handleDeletePhoto = async (image: DisplayImageItem) => {
    await db.images.delete(image.id);
  };

  const resolvedCourseId = session.courseId ?? course?.id ?? '';

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="session-detail-title"
        className="fixed inset-0 z-50 flex flex-col bg-[var(--bg-canvas)]"
      >
        <header className="sticky top-0 z-10 border-b border-violet-200/70 bg-white/95 backdrop-blur-md">
          <div className="mx-auto flex h-12 w-full max-w-2xl items-center justify-between gap-2 px-2">
            <button
              type="button"
              onClick={handleRequestClose}
              className="flex min-h-[44px] shrink-0 items-center gap-1 rounded-xl px-2.5 text-sm font-medium text-zinc-700 transition-colors hover:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
            >
              <ChevronLeft size={18} aria-hidden="true" />
              <span>返回</span>
            </button>

            <div className="flex min-w-0 items-center gap-2">
              <span
                aria-hidden="true"
                style={{ backgroundColor: displayColor }}
                className="h-3.5 w-3.5 shrink-0 rounded-sm ring-1 ring-inset ring-black/15"
              />
              <h2
                id="session-detail-title"
                className="truncate text-base font-semibold text-zinc-900"
              >
                {displayName}
              </h2>
            </div>

            <button
              type="button"
              onClick={() => setEditModalOpen(true)}
              className="flex min-h-[44px] shrink-0 items-center gap-1 rounded-xl px-2.5 text-xs font-medium text-violet-700 transition-colors hover:bg-violet-50 whitespace-nowrap"
            >
              <Pencil size={14} aria-hidden="true" />
              <span>編輯場次</span>
            </button>
          </div>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
          <div className="mx-auto w-full max-w-2xl space-y-4 px-4 py-4 pb-[calc(2rem+env(safe-area-inset-bottom)+var(--kb-inset,0px))]">
            {/* 課程、時間與調課紀錄 */}
            <div className="space-y-3 rounded-2xl border border-zinc-200 bg-white p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2.5">
                    <span
                      aria-hidden="true"
                      style={{ backgroundColor: displayColor }}
                      className={`h-4 w-4 shrink-0 rounded-sm ring-1 ring-inset ring-black/15 ${
                        isCancelled ? 'opacity-45' : ''
                      }`}
                    />
                    <h3
                      className={`truncate text-lg font-bold ${
                        isCancelled
                          ? 'text-zinc-400 line-through'
                          : 'text-zinc-900'
                      }`}
                    >
                      {displayName}
                    </h3>
                    {isCancelled && <CancelledBadge />}
                  </div>
                  <div className="mt-0.5 flex flex-wrap items-center gap-1.5 pl-[26px] text-xs text-zinc-500">
                    <span>{resolvedOrg?.name ?? '未指定單位'}</span>
                    {isSub && <SubstituteBadge />}
                    {isSub && session.substituteFor?.trim() && (
                      <span className="text-zinc-700">
                        （代 {session.substituteFor.trim()}）
                      </span>
                    )}
                    {session.kind === 'makeup'
                      ? linkedCancelledSession
                        ? `· 補課（補 ${formatSlashDate(linkedCancelledSession.date)}）`
                        : '· 補課'
                      : session.kind === 'extra'
                        ? '· 加課'
                        : ''}
                  </div>
                </div>

                <SessionMenuButton
                  onClick={() => openSessionMenu(session)}
                  ariaLabel="場次操作（改期、取消、恢復、刪除）"
                />
              </div>

              <div className="space-y-1.5 border-t border-zinc-100 pt-3 text-sm text-zinc-800">
                <div className="flex items-center gap-2 tabular-nums">
                  <Clock size={15} className="shrink-0 text-zinc-400" aria-hidden="true" />
                  <span className={isCancelled ? 'text-zinc-400 line-through' : 'font-medium'}>
                    {formatSlashDateWithWeekday(session.date)} {session.startTime}–
                    {session.endTime}
                  </span>
                  {session.periodLabel && (
                    <span className="text-xs text-zinc-500">
                      （{session.periodLabel}）
                    </span>
                  )}
                </div>

                {session.originalDate && session.originalStartTime && (
                  <p className="pl-[23px] text-xs font-medium text-violet-700 tabular-nums">
                    調課紀錄：原定 {formatSlashDateWithWeekday(session.originalDate)}{' '}
                    {session.originalStartTime}
                    {session.originalEndTime ? `–${session.originalEndTime}` : ''}
                  </p>
                )}

                {session.location && (
                  <div className="flex items-center gap-2 text-xs text-zinc-600">
                    <MapPin size={14} className="shrink-0 text-zinc-400" aria-hidden="true" />
                    <span>{session.location}</span>
                  </div>
                )}

                {isCancelled && (
                  <p className="pl-[23px] text-xs text-zinc-500">
                    此場次已取消
                    {session.cancelReason ? ` · 原因：${session.cancelReason}` : ''}
                  </p>
                )}
              </div>
            </div>

            {/* 進度與備註 */}
            <div className="space-y-3 rounded-2xl border border-zinc-200 bg-white p-4">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-zinc-900">
                  上課進度與備註
                </h3>
                {savedToast && (
                  <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700">
                    <CheckCircle2 size={14} aria-hidden="true" />
                    <span>已儲存</span>
                  </span>
                )}
              </div>

              <div>
                <label
                  htmlFor="session-detail-progress"
                  className="block text-xs font-medium text-zinc-600"
                >
                  上課進度
                </label>
                <input
                  id="session-detail-progress"
                  type="text"
                  value={progress}
                  onChange={(e) => setProgress(e.target.value)}
                  placeholder="例如：第 3 章 浮力原理 p.42–48、完成例題 1–4"
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              <div>
                <label
                  htmlFor="session-detail-note"
                  className="block text-xs font-medium text-zinc-600"
                >
                  場次備註
                </label>
                <textarea
                  id="session-detail-note"
                  rows={3}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="記錄課堂反應、學生疑問、缺席名單或下次銜接重點"
                  className="mt-1.5 w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              {session.homework && (
                <p className="rounded-xl bg-zinc-50 px-3 py-2 text-xs text-zinc-600">
                  場次文字備忘：{session.homework}
                </p>
              )}

              <button
                type="button"
                disabled={isSavingText || !hasTextChanges}
                onClick={() => {
                  void handleSaveProgressAndNote();
                }}
                className="flex min-h-[44px] w-full items-center justify-center rounded-xl bg-violet-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-violet-700 disabled:bg-zinc-200 disabled:text-zinc-500"
              >
                {isSavingText
                  ? '儲存中…'
                  : hasTextChanges
                    ? '儲存進度與備註'
                    : '進度與備註已同步'}
              </button>
            </div>

            {/* 本場次任務與提醒 */}
            <div className="space-y-3 rounded-2xl border border-zinc-200 bg-white p-4">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-semibold text-zinc-900">
                    本場次任務與提醒
                  </h3>
                  <p className="text-xs text-zinc-500">
                    {isSub
                      ? '可為這堂代課記錄待辦事項或提醒'
                      : '可勾選待辦或新增只顯示文字的課堂提醒'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setEditingTask(null);
                    setTaskModalOpen(true);
                  }}
                  className="flex min-h-[44px] shrink-0 items-center justify-center gap-1 rounded-xl border border-violet-300 bg-[#F2ECFF] px-3 text-xs font-semibold text-zinc-900 transition-colors hover:bg-[#e8ddff] whitespace-nowrap"
                >
                  <Plus size={15} aria-hidden="true" />
                  <span>新增任務</span>
                </button>
              </div>

              {allTasks === undefined ? (
                <p className="py-2 text-center text-xs text-zinc-500">載入中…</p>
              ) : sessionTaskEntries.length === 0 ? (
                <p className="rounded-xl bg-zinc-50 px-3 py-3 text-center text-xs text-zinc-500">
                  此場次目前沒有任務或提醒
                </p>
              ) : (
                <div className="divide-y divide-zinc-100 rounded-xl border border-zinc-200 px-2 py-0.5">
                  {sessionTaskEntries.map((entry) => (
                    <TaskRowItem
                      key={entry.task.id}
                      task={entry.task}
                      metaText={
                        entry.origin === 'course_next' ? '跟隨班級下堂課' : undefined
                      }
                      onEdit={(target) => {
                        setEditingTask(target);
                        setTaskModalOpen(true);
                      }}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* 此場次派出的作業 */}
            <div className="space-y-3 rounded-2xl border border-zinc-200 bg-white p-4">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-semibold text-zinc-900">
                    本場次派出作業
                  </h3>
                  <p className="text-xs text-zinc-500">
                    派出後會同步顯示於該課程的「作業」分頁
                  </p>
                </div>
                {resolvedCourseId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingHomework(null);
                      setHomeworkModalOpen(true);
                    }}
                    className="flex min-h-[44px] shrink-0 items-center justify-center gap-1 rounded-xl border border-violet-300 bg-[#F2ECFF] px-3 text-xs font-semibold text-zinc-900 transition-colors hover:bg-[#e8ddff] whitespace-nowrap"
                  >
                    <Plus size={15} aria-hidden="true" />
                    <span>新增作業</span>
                  </button>
                )}
              </div>

              {sessionHomeworks === undefined ? (
                <p className="py-2 text-center text-xs text-zinc-500">載入中…</p>
              ) : sessionHomeworks.length === 0 ? (
                <p className="rounded-xl bg-zinc-50 px-3 py-3 text-center text-xs text-zinc-500">
                  本場次尚未派出作業
                </p>
              ) : (
                <div className="divide-y divide-zinc-100 rounded-xl border border-zinc-200">
                  {sessionHomeworks.map((hw) => (
                    <button
                      key={hw.id}
                      type="button"
                      onClick={() => {
                        setEditingHomework(hw);
                        setHomeworkModalOpen(true);
                      }}
                      className="flex min-h-[52px] w-full items-center justify-between gap-3 px-3.5 py-2.5 text-left transition-colors hover:bg-zinc-50"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-zinc-900">
                          {hw.title}
                        </p>
                        <p className="mt-0.5 text-xs text-zinc-500 tabular-nums">
                          {hw.dueDate
                            ? `繳交日：${formatSlashDateWithWeekday(hw.dueDate)}`
                            : '未設定繳交日'}
                          {hw.note ? ` · ${hw.note}` : ''}
                        </p>
                      </div>
                      <span
                        className={`shrink-0 text-xs ${HOMEWORK_STATUS_STYLES[hw.status]}`}
                      >
                        {getHomeworkStatusLabel(hw.status)}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* 照片紀錄（拍照或選相簿，多張，縮圖列表，點開放大，可刪除） */}
            <div className="rounded-2xl border border-zinc-200 bg-white p-4">
              <PhotoGallerySection
                title="課堂照片（板書／筆記）"
                images={sessionImages ?? []}
                onAddCompressedImages={handleAddPhotos}
                onDeleteImage={handleDeletePhoto}
              />
            </div>
          </div>
        </div>
      </div>

      <SessionFormModal
        open={editModalOpen}
        session={session}
        courses={allCourses}
        organizations={allOrganizations}
        onClose={() => setEditModalOpen(false)}
      />

      {resolvedCourseId && (
        <HomeworkFormModal
          open={homeworkModalOpen}
          homework={editingHomework}
          courseId={resolvedCourseId}
          defaultSessionId={session.id}
          defaultAssignedDate={session.date}
          onClose={() => setHomeworkModalOpen(false)}
        />
      )}

      <TaskFormModal
        open={taskModalOpen}
        task={editingTask}
        courses={allCourses}
        sessions={allSessions ?? [session]}
        organizations={allOrganizations}
        defaultCourseId={isSub ? '' : resolvedCourseId}
        defaultSessionId={session.id}
        onClose={() => setTaskModalOpen(false)}
      />

      <ConfirmDialog
        open={discardConfirmOpen}
        title="放棄未儲存的內容？"
        description="上課進度或場次備註有尚未儲存的修改，確定要放棄並返回嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardConfirmOpen(false)}
        onConfirm={() => {
          setDiscardConfirmOpen(false);
          onClose();
        }}
      />
      <SessionQuickActionsHost {...quickActionsProps} />
    </>
  );
}
