import { useBackLayer } from '../utils/backNavigation';

interface ConfirmDialogProps {
  open: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
  isSubmitting?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = '確定刪除',
  cancelLabel = '取消',
  danger = true,
  isSubmitting = false,
  onConfirm,
  onCancel,
}: ConfirmDialogProps) {
  useBackLayer({
    active: open,
    zLayer: 80,
    onBack: () => {
      if (!isSubmitting) {
        onCancel();
      }
    },
  });

  if (!open) {
    return null;
  }

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="confirm-dialog-title"
      aria-describedby="confirm-dialog-desc"
      className="fixed inset-0 z-[80] flex items-end justify-center bg-black/50 p-0 backdrop-blur-xs sm:items-center sm:p-4"
    >
      <div className="w-full max-w-md rounded-t-3xl bg-white p-5 pb-[calc(1.25rem+env(safe-area-inset-bottom))] shadow-xl sm:rounded-2xl sm:pb-5">
        <h3
          id="confirm-dialog-title"
          className="text-base font-semibold text-zinc-900"
        >
          {title}
        </h3>
        <p
          id="confirm-dialog-desc"
          className="mt-2 text-sm leading-relaxed text-zinc-600"
        >
          {description}
        </p>

        <div className="mt-5 flex items-center gap-2.5">
          <button
            type="button"
            onClick={onCancel}
            disabled={isSubmitting}
            className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm font-medium text-zinc-700 transition-colors hover:bg-zinc-50 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={isSubmitting}
            className={`flex min-h-[44px] flex-1 items-center justify-center rounded-xl px-4 py-2 text-sm font-medium text-white transition-colors disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 ${
              danger
                ? 'bg-rose-600 hover:bg-rose-700 focus-visible:ring-rose-600'
                : 'bg-violet-600 hover:bg-violet-700 focus-visible:ring-violet-600'
            }`}
          >
            {isSubmitting ? '處理中…' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
