import { Trash2, X } from 'lucide-react';
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { db } from '../db/database';
import { deleteExamWithImages } from '../db/repositories';
import type { Exam, StoredImage } from '../db/types';
import { toDateKey } from '../utils/date';
import { createId } from '../utils/id';
import type { CompressedImageResult } from '../utils/imageCompression';
import { useBackLayer } from '../utils/backNavigation';
import { useLiveQuery } from '../utils/useLiveQuery';
import { ConfirmDialog } from './ConfirmDialog';
import { PhotoGallerySection, type DisplayImageItem } from './PhotoGallerySection';

interface ExamFormModalProps {
  open: boolean;
  exam: Exam | null;
  courseId: string;
  onClose: () => void;
}

const EXAM_TYPE_PRESETS = ['小考', '平時考', '段考', '模擬考'] as const;

export function ExamFormModal({
  open,
  exam,
  courseId,
  onClose,
}: ExamFormModalProps) {
  const existingImages = useLiveQuery(async (): Promise<StoredImage[]> => {
    if (!open || !exam) return [];
    const list = await db.images.where('examId').equals(exam.id).toArray();
    return list.sort((a, b) => a.createdAt - b.createdAt);
  }, [open, exam?.id]);

  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [timeMode, setTimeMode] = useState<'time' | 'text'>('time');
  const [examType, setExamType] = useState('');
  const [scope, setScope] = useState('');
  const [note, setNote] = useState('');

  const [addedPhotos, setAddedPhotos] = useState<
    Array<{ id: string; result: CompressedImageResult; createdAt: number }>
  >([]);
  const [removedExistingIds, setRemovedExistingIds] = useState<string[]>([]);

  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [discardConfirmOpen, setDiscardConfirmOpen] = useState(false);
  const [initialSnapshot, setInitialSnapshot] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;

    if (exam) {
      const existingTime = exam.time ?? '';
      setTitle(exam.title);
      setDate(exam.date);
      setTime(existingTime);
      setTimeMode(
        !existingTime || /^\d{2}:\d{2}$/.test(existingTime) ? 'time' : 'text'
      );
      setExamType(exam.examType ?? '');
      setScope(exam.scope ?? '');
      setNote(exam.note ?? '');
      setInitialSnapshot(
        JSON.stringify({
          title: exam.title,
          date: exam.date,
          time: existingTime,
          examType: exam.examType ?? '',
          scope: exam.scope ?? '',
          note: exam.note ?? '',
        })
      );
    } else {
      const today = toDateKey(new Date());
      setTitle('');
      setDate(today);
      setTime('');
      setTimeMode('time');
      setExamType('小考');
      setScope('');
      setNote('');
      setInitialSnapshot(
        JSON.stringify({
          title: '',
          date: today,
          time: '',
          examType: '小考',
          scope: '',
          note: '',
        })
      );
    }
    setAddedPhotos([]);
    setRemovedExistingIds([]);
    setError(null);
    setDeleteConfirmOpen(false);
    setDiscardConfirmOpen(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, exam?.id]);

  const isDirty =
    initialSnapshot !== null &&
    (addedPhotos.length > 0 ||
      removedExistingIds.length > 0 ||
      JSON.stringify({ title, date, time, examType, scope, note }) !==
        initialSnapshot);

  const handleRequestClose = () => {
    if (isSaving) return;
    if (isDirty) {
      setDiscardConfirmOpen(true);
      return;
    }
    onClose();
  };

  useBackLayer({
    active: open,
    zLayer: 60,
    onBack: handleRequestClose,
  });

  const displayImages = useMemo<DisplayImageItem[]>(() => {
    const keptExisting = (existingImages ?? [])
      .filter((img) => !removedExistingIds.includes(img.id))
      .map((img) => ({
        id: img.id,
        fileName: img.fileName,
        blob: img.blob,
        thumbnailBlob: img.thumbnailBlob,
      }));
    const staged = addedPhotos.map((item) => ({
      id: item.id,
      fileName: item.result.fileName,
      blob: item.result.blob,
      thumbnailBlob: item.result.thumbnailBlob,
    }));
    return [...keptExisting, ...staged];
  }, [existingImages, removedExistingIds, addedPhotos]);

  if (!open) {
    return null;
  }

  const handleAddCompressedImages = (results: CompressedImageResult[]) => {
    const now = Date.now();
    setAddedPhotos((prev) => [
      ...prev,
      ...results.map((result, idx) => ({
        id: createId(),
        result,
        createdAt: now + idx,
      })),
    ]);
  };

  const handleDeleteImage = (image: DisplayImageItem) => {
    const isStaged = addedPhotos.some((p) => p.id === image.id);
    if (isStaged) {
      setAddedPhotos((prev) => prev.filter((p) => p.id !== image.id));
    } else {
      setRemovedExistingIds((prev) =>
        prev.includes(image.id) ? prev : [...prev, image.id]
      );
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const trimmedTitle = title.trim();
    if (!trimmedTitle) {
      setError('請輸入考試名稱');
      return;
    }
    if (!date) {
      setError('請選擇考試日期');
      return;
    }

    setIsSaving(true);
    try {
      const now = Date.now();
      const targetExamId = exam?.id ?? createId();
      const targetCourseId = exam?.courseId ?? courseId;

      const examRecord: Exam = {
        id: targetExamId,
        courseId: targetCourseId,
        title: trimmedTitle,
        date,
        time: time.trim() || undefined,
        examType: examType.trim() || undefined,
        scope: scope.trim() || undefined,
        note: note.trim() || undefined,
        createdAt: exam?.createdAt ?? now,
        updatedAt: now,
      };

      const newImageRecords: StoredImage[] = addedPhotos.map((item) => ({
        id: item.id,
        courseId: targetCourseId,
        examId: targetExamId,
        fileName: item.result.fileName,
        mimeType: item.result.mimeType,
        blob: item.result.blob,
        thumbnailBlob: item.result.thumbnailBlob,
        createdAt: item.createdAt,
      }));

      await db.transaction('rw', [db.exams, db.images], async () => {
        await db.exams.put(examRecord);
        if (removedExistingIds.length > 0) {
          await db.images.bulkDelete(removedExistingIds);
        }
        if (newImageRecords.length > 0) {
          await db.images.bulkPut(newImageRecords);
        }
      });

      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!exam) return;
    setIsSaving(true);
    try {
      await deleteExamWithImages(exam.id);
      setDeleteConfirmOpen(false);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="exam-modal-title"
        className="fixed inset-0 z-[60] flex items-end justify-center bg-black/50 pb-[var(--kb-inset,0px)] backdrop-blur-xs sm:items-center sm:p-4"
      >
        <div className="flex max-h-[90dvh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-xl sm:rounded-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-zinc-100 px-4 py-3">
            <h2
              id="exam-modal-title"
              className="text-base font-semibold text-zinc-900"
            >
              {exam ? '編輯考試' : '新增考試'}
            </h2>
            <button
              type="button"
              onClick={handleRequestClose}
              aria-label="關閉"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
            >
              <X size={20} />
            </button>
          </div>

          <form
            onSubmit={(e) => void handleSubmit(e)}
            noValidate
            className="flex min-h-0 flex-1 flex-col"
          >
            <div className="min-h-0 flex-1 space-y-4 overflow-y-auto overscroll-contain p-4">
              <div>
                <label
                  htmlFor="exam-title-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  考試名稱 <span className="text-rose-600">*</span>
                </label>
                <input
                  id="exam-title-input"
                  type="text"
                  value={title}
                  onChange={(e) => {
                    setTitle(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="例如：第一次段考、牛頓定律小考"
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="min-w-0">
                  <label
                    htmlFor="exam-date-input"
                    className="block text-sm font-medium text-zinc-800"
                  >
                    日期 <span className="text-rose-600">*</span>
                  </label>
                  <input
                    id="exam-date-input"
                    type="date"
                    value={date}
                    onChange={(e) => {
                      setDate(e.target.value);
                      if (error) setError(null);
                    }}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>

                <div className="min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <label
                      htmlFor="exam-time-input"
                      className="block text-sm font-medium text-zinc-800"
                    >
                      時間（選填）
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        if (timeMode === 'time') {
                          setTimeMode('text');
                        } else {
                          if (time && !/^\d{2}:\d{2}$/.test(time)) {
                            setTime('');
                          }
                          setTimeMode('time');
                        }
                      }}
                      className="text-xs font-medium text-violet-700 hover:underline whitespace-nowrap"
                    >
                      {timeMode === 'time' ? '改填節次／文字' : '改用時間選擇'}
                    </button>
                  </div>
                  <input
                    id="exam-time-input"
                    type={timeMode === 'time' ? 'time' : 'text'}
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    placeholder={timeMode === 'text' ? '例如：08:30–09:15 或 第1節' : undefined}
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3 py-2 text-base text-zinc-900 placeholder:text-zinc-400 tabular-nums focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                  />
                </div>
              </div>

              <div>
                <span className="block text-sm font-medium text-zinc-800">
                  類型（選填）
                </span>
                <div className="mt-1.5 grid grid-cols-4 gap-1.5">
                  {EXAM_TYPE_PRESETS.map((preset) => {
                    const active = examType === preset;
                    return (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setExamType(active ? '' : preset)}
                        className={`flex min-h-[44px] items-center justify-center rounded-xl border text-xs font-medium transition-colors ${
                          active
                            ? 'border-2 border-violet-600 bg-[#EDE6FF] font-semibold text-zinc-900'
                            : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                        }`}
                      >
                        {preset}
                      </button>
                    );
                  })}
                </div>
                <input
                  type="text"
                  aria-label="考試類型"
                  value={examType}
                  onChange={(e) => setExamType(e.target.value)}
                  placeholder="或自行輸入類型"
                  className="mt-2 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              <div>
                <label
                  htmlFor="exam-scope-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  考試範圍（選填）
                </label>
                <input
                  id="exam-scope-input"
                  type="text"
                  value={scope}
                  onChange={(e) => setScope(e.target.value)}
                  placeholder="例如：第 1 章～第 3 章 p.1–62"
                  className="mt-1.5 min-h-[44px] w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              <div>
                <label
                  htmlFor="exam-note-input"
                  className="block text-sm font-medium text-zinc-800"
                >
                  備註（選填）
                </label>
                <textarea
                  id="exam-note-input"
                  rows={2}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="考卷重點、班級成績或補考提醒"
                  className="mt-1.5 w-full rounded-xl border border-zinc-300 bg-white px-3.5 py-2 text-base text-zinc-900 placeholder:text-zinc-400 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                />
              </div>

              <div className="rounded-2xl border border-zinc-200 bg-zinc-50/60 p-3.5">
                <PhotoGallerySection
                  title="考卷／重點照片"
                  images={displayImages}
                  onAddCompressedImages={handleAddCompressedImages}
                  onDeleteImage={handleDeleteImage}
                />
              </div>

              {error && (
                <p role="alert" className="text-xs font-medium text-rose-600">
                  {error}
                </p>
              )}

              {exam && (
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => setDeleteConfirmOpen(true)}
                    disabled={isSaving}
                    className="flex min-h-[44px] w-full items-center justify-center gap-1.5 rounded-xl border border-rose-200 bg-white px-4 py-2.5 text-sm font-medium text-rose-600 transition-colors hover:bg-rose-50 disabled:opacity-60"
                  >
                    <Trash2 size={16} aria-hidden="true" />
                    <span>刪除此考試</span>
                  </button>
                </div>
              )}
            </div>

            <div className="shrink-0 border-t border-zinc-100 bg-white px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
              <button
                type="submit"
                disabled={isSaving}
                className="flex min-h-[44px] w-full items-center justify-center rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-violet-700 disabled:opacity-60"
              >
                {isSaving ? '儲存中…' : exam ? '儲存變更' : '建立考試'}
              </button>
            </div>
          </form>
        </div>
      </div>

      <ConfirmDialog
        open={deleteConfirmOpen}
        title="刪除考試"
        description={
          exam ? `確定要刪除考試「${exam.title}」及其相關照片嗎？` : ''
        }
        confirmLabel="確認刪除"
        isSubmitting={isSaving}
        onCancel={() => setDeleteConfirmOpen(false)}
        onConfirm={() => {
          void handleConfirmDelete();
        }}
      />

      <ConfirmDialog
        open={discardConfirmOpen}
        title="放棄未儲存的內容？"
        description="目前有尚未儲存的修改，確定要放棄並返回嗎？"
        confirmLabel="放棄變更"
        cancelLabel="繼續編輯"
        danger
        onCancel={() => setDiscardConfirmOpen(false)}
        onConfirm={() => {
          setDiscardConfirmOpen(false);
          onClose();
        }}
      />
    </>
  );
}
