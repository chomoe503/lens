import { RotateCcw, X } from 'lucide-react';
import { useUndoBanner } from '../utils/undoStore';

export function UndoBanner() {
  const { entry, undo, dismiss } = useUndoBanner();

  if (!entry) {
    return null;
  }

  return (
    <div
      role="status"
      aria-live="polite"
      className="pointer-events-none fixed inset-x-0 bottom-[calc(var(--bottom-nav-height)+env(safe-area-inset-bottom)+1rem)] z-[60] px-4"
    >
      <div className="pointer-events-auto mx-auto flex w-full max-w-2xl items-center justify-between gap-2 rounded-2xl border border-zinc-800 bg-zinc-900 px-3.5 py-2 text-white shadow-xl">
        <p className="min-w-0 flex-1 truncate text-sm font-medium">
          {entry.message}
        </p>

        <div className="flex shrink-0 items-center gap-1">
          <button
            type="button"
            onClick={() => {
              void undo();
            }}
            className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-[#CDB8FF] px-3.5 py-2 text-sm font-semibold text-zinc-900 transition-colors hover:bg-[#bfa4ff] active:scale-95 whitespace-nowrap"
          >
            <RotateCcw size={15} aria-hidden="true" />
            <span>復原 ({entry.remainingSeconds}s)</span>
          </button>
          <button
            type="button"
            onClick={dismiss}
            aria-label="關閉復原提示"
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-zinc-400 hover:bg-zinc-800 hover:text-white"
          >
            <X size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
