import { CalendarCog, CheckSquare, ChevronRight, Plus, Trash2 } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { AcademicYearManagerModal } from '../components/AcademicYearManagerModal';
import { BatchGenerateSessionsModal } from '../components/BatchGenerateSessionsModal';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { CourseDetailModal } from '../components/CourseDetailModal';
import { CourseFormModal } from '../components/CourseFormModal';
import { OrganizationFormModal } from '../components/OrganizationFormModal';
import { SessionDetailModal } from '../components/SessionDetailModal';
import { SessionFormModal } from '../components/SessionFormModal';
import { SessionListItem } from '../components/SessionListItem';
import {
  SessionQuickActionsHost,
  useSessionQuickActions,
} from '../components/SessionQuickActions';
import { db } from '../db/database';
import { deleteMultipleSessions } from '../db/repositories';
import type { ClassSession, Course, Organization } from '../db/types';
import { ORGANIZATION_TYPE_LABELS } from '../utils/colors';
import { compareCoursesByGrade } from '../utils/courseSort';
import { doTimeRangesOverlap, WEEKDAY_LABELS } from '../utils/date';
import {
  isSessionCancelled,
  resolveSessionDisplay,
  resolveSessionOrgId,
} from '../utils/sessionDisplay';
import { pushUndoAction } from '../utils/undoStore';
import { useIsKeyboardActive } from '../utils/useKeyboardAware';
import { useLiveQuery } from '../utils/useLiveQuery';

type CoursesPageViewMode = 'courses' | 'sessions';

export function CoursesPage() {
  const isKeyboardActive = useIsKeyboardActive();
  const academicYears = useLiveQuery(
    () => db.academicYears.orderBy('startDate').reverse().toArray(),
    []
  );
  const organizations = useLiveQuery(
    () => db.organizations.orderBy('createdAt').toArray(),
    []
  );
  const courses = useLiveQuery(() => db.courses.toArray(), []);
  const allSessions = useLiveQuery(() => db.sessions.toArray(), []);

  const [viewMode, setViewMode] = useState<CoursesPageViewMode>('courses');
  const [selectedYearId, setSelectedYearId] = useState<string>('');
  const [selectedOrgId, setSelectedOrgId] = useState<string>('all');

  const [yearModalOpen, setYearModalOpen] = useState(false);
  const [detailCourseId, setDetailCourseId] = useState<string | null>(null);
  const [courseModalOpen, setCourseModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [orgModalOpen, setOrgModalOpen] = useState(false);
  const [batchPromptCourse, setBatchPromptCourse] = useState<Course | null>(null);
  const [batchModalCourse, setBatchModalCourse] = useState<Course | null>(null);

  // Session tab states
  const [sessionModalOpen, setSessionModalOpen] = useState(false);
  const [detailSessionId, setDetailSessionId] = useState<string | null>(null);
  const [editingSession, setEditingSession] = useState<ClassSession | null>(null);
  const [makeupTargetSession, setMakeupTargetSession] =
    useState<ClassSession | null>(null);
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedSessionIds, setSelectedSessionIds] = useState<string[]>([]);
  const [multiDeleteConfirmOpen, setMultiDeleteConfirmOpen] = useState(false);
  const [isDeletingMultiple, setIsDeletingMultiple] = useState(false);

  const { openSessionMenu, quickActionsProps } = useSessionQuickActions({
    courses: courses ?? [],
    organizations: organizations ?? [],
    onSessionDeleted: (deletedId) => {
      if (detailSessionId === deletedId) {
        setDetailSessionId(null);
      }
      setSelectedSessionIds((prev) => prev.filter((id) => id !== deletedId));
    },
  });

  useEffect(() => {
    if (!academicYears || academicYears.length === 0) return;
    const exists = academicYears.some((y) => y.id === selectedYearId);
    if (!selectedYearId || !exists) {
      const preferred =
        academicYears.find((y) => !y.archived) ?? academicYears[0];
      setSelectedYearId(preferred.id);
    }
  }, [academicYears, selectedYearId]);

  useEffect(() => {
    if (selectedOrgId === 'all' || !organizations) return;
    if (!organizations.some((o) => o.id === selectedOrgId)) {
      setSelectedOrgId('all');
    }
  }, [organizations, selectedOrgId]);

  const orgMap = useMemo(() => {
    const map = new Map<string, Organization>();
    for (const org of organizations ?? []) {
      map.set(org.id, org);
    }
    return map;
  }, [organizations]);

  const courseMap = useMemo(() => {
    const map = new Map<string, Course>();
    for (const c of courses ?? []) {
      map.set(c.id, c);
    }
    return map;
  }, [courses]);

  const yearMap = useMemo(() => {
    const map = new Map((academicYears ?? []).map((y) => [y.id, y]));
    return map;
  }, [academicYears]);

  const detailCourse = detailCourseId ? (courseMap.get(detailCourseId) ?? null) : null;

  const groupedCourses = useMemo(() => {
    if (!courses || !organizations || !selectedYearId) return [];

    const filtered = courses.filter((c) => {
      if (c.isSystem) return false;
      if (c.academicYearId !== selectedYearId) return false;
      if (selectedOrgId !== 'all' && c.organizationId !== selectedOrgId) {
        return false;
      }
      return true;
    });

    const groups: Array<{
      organization: Organization;
      courses: Course[];
    }> = [];

    for (const org of organizations) {
      if (selectedOrgId !== 'all' && org.id !== selectedOrgId) continue;
      const orgCourses = filtered
        .filter((c) => c.organizationId === org.id)
        .sort(compareCoursesByGrade);
      if (orgCourses.length > 0) {
        groups.push({ organization: org, courses: orgCourses });
      }
    }

    const orphanCourses = filtered
      .filter((c) => !orgMap.has(c.organizationId))
      .sort(compareCoursesByGrade);

    if (orphanCourses.length > 0) {
      groups.push({
        organization: {
          id: 'unassigned',
          name: '未指定單位',
          type: 'other',
          color: '#CDB8FF',
          createdAt: 0,
          updatedAt: 0,
        },
        courses: orphanCourses,
      });
    }

    return groups;
  }, [courses, organizations, selectedYearId, selectedOrgId, orgMap]);

  const sessionMap = useMemo(() => {
    const map = new Map<string, ClassSession>();
    for (const s of allSessions ?? []) map.set(s.id, s);
    return map;
  }, [allSessions]);

  const overlappingSessionIds = useMemo(() => {
    const ids = new Set<string>();
    const active = (allSessions ?? []).filter((s) => !isSessionCancelled(s));
    const byDate = new Map<string, ClassSession[]>();
    for (const s of active) {
      const arr = byDate.get(s.date) ?? [];
      arr.push(s);
      byDate.set(s.date, arr);
    }
    for (const dayList of byDate.values()) {
      for (let i = 0; i < dayList.length; i++) {
        for (let j = i + 1; j < dayList.length; j++) {
          if (
            doTimeRangesOverlap(
              dayList[i].startTime,
              dayList[i].endTime,
              dayList[j].startTime,
              dayList[j].endTime
            )
          ) {
            ids.add(dayList[i].id);
            ids.add(dayList[j].id);
          }
        }
      }
    }
    return ids;
  }, [allSessions]);

  const filteredSessions = useMemo(() => {
    if (!allSessions) return [];
    return allSessions
      .filter((s) => {
        const course = s.courseId ? courseMap.get(s.courseId) : undefined;
        if (selectedYearId && course && course.academicYearId !== selectedYearId) {
          return false;
        }
        if (
          selectedOrgId !== 'all' &&
          resolveSessionOrgId(s, courseMap) !== selectedOrgId
        ) {
          return false;
        }
        return true;
      })
      .sort((a, b) => {
        const dateDiff = a.date.localeCompare(b.date);
        if (dateDiff !== 0) return dateDiff;
        return a.startTime.localeCompare(b.startTime);
      });
  }, [allSessions, courseMap, selectedYearId, selectedOrgId]);

  const coursesInSelectedYear = useMemo(
    () =>
      (courses ?? []).filter(
        (c) => !c.isSystem && (!selectedYearId || c.academicYearId === selectedYearId)
      ),
    [courses, selectedYearId]
  );

  const handleOpenCreateCourse = () => {
    setEditingCourse(null);
    setCourseModalOpen(true);
  };

  const handleOpenCreateSession = () => {
    setEditingSession(null);
    setMakeupTargetSession(null);
    setSessionModalOpen(true);
  };

  const handleTapSession = (session: ClassSession) => {
    if (selectionMode) {
      setSelectedSessionIds((prev) =>
        prev.includes(session.id)
          ? prev.filter((id) => id !== session.id)
          : [...prev, session.id]
      );
      return;
    }
    setDetailSessionId(session.id);
  };

  const handleLongPressSession = (session: ClassSession) => {
    setSelectionMode(true);
    setSelectedSessionIds((prev) =>
      prev.includes(session.id) ? prev : [...prev, session.id]
    );
  };

  const handleConfirmMultiDelete = async () => {
    if (selectedSessionIds.length === 0) return;
    setIsDeletingMultiple(true);
    try {
      const count = selectedSessionIds.length;
      const backup = await deleteMultipleSessions(selectedSessionIds);
      pushUndoAction(`已刪除 ${count} 堂場次`, backup);
      setMultiDeleteConfirmOpen(false);
      setSelectionMode(false);
      setSelectedSessionIds([]);
    } finally {
      setIsDeletingMultiple(false);
    }
  };

  const isLoading =
    academicYears === undefined ||
    organizations === undefined ||
    courses === undefined ||
    allSessions === undefined;

  return (
    <section aria-label="課程頁面" className="space-y-4 px-4 pb-20 pt-4">
      <div className="space-y-2.5">
        <div
          role="tablist"
          aria-label="檢視模式"
          className="grid grid-cols-2 gap-1 rounded-2xl border border-violet-200/80 bg-white p-1"
        >
          <button
            type="button"
            role="tab"
            aria-selected={viewMode === 'courses'}
            onClick={() => {
              setViewMode('courses');
              setSelectionMode(false);
              setSelectedSessionIds([]);
            }}
            className={`flex min-h-[44px] items-center justify-center rounded-xl text-sm font-medium transition-colors ${
              viewMode === 'courses'
                ? 'bg-[#CDB8FF] font-semibold text-zinc-900'
                : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            課程班級
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={viewMode === 'sessions'}
            onClick={() => setViewMode('sessions')}
            className={`flex min-h-[44px] items-center justify-center rounded-xl text-sm font-medium transition-colors ${
              viewMode === 'sessions'
                ? 'bg-[#CDB8FF] font-semibold text-zinc-900'
                : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            場次列表
          </button>
        </div>

        <div className="flex items-center gap-2">
          <div className="min-w-0 flex-1">
            <label htmlFor="courses-year-select" className="sr-only">
              選擇學年
            </label>
            <select
              id="courses-year-select"
              value={selectedYearId}
              onChange={(e) => setSelectedYearId(e.target.value)}
              className="min-h-[44px] w-full rounded-xl border border-violet-200/80 bg-white px-3.5 py-2 text-base font-semibold text-zinc-900 focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
            >
              {(academicYears ?? []).map((year) => (
                <option key={year.id} value={year.id}>
                  {year.name}
                  {year.archived ? '（已歸檔）' : ''}
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={() => setYearModalOpen(true)}
            className="flex min-h-[44px] shrink-0 items-center justify-center gap-1.5 rounded-xl border border-violet-200/80 bg-white px-3.5 py-2 text-sm font-medium text-zinc-700 transition-colors hover:bg-violet-50/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 whitespace-nowrap"
          >
            <CalendarCog size={16} aria-hidden="true" />
            <span>管理學年</span>
          </button>
        </div>

        {(organizations ?? []).length > 0 && (
          <div
            role="tablist"
            aria-label="依單位篩選"
            className="flex items-center gap-1.5 overflow-x-auto pb-0.5"
          >
            <button
              type="button"
              role="tab"
              aria-selected={selectedOrgId === 'all'}
              onClick={() => setSelectedOrgId('all')}
              className={`flex min-h-[44px] shrink-0 items-center justify-center rounded-xl border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap ${
                selectedOrgId === 'all'
                  ? 'border-violet-600 bg-[#CDB8FF] text-zinc-900 font-semibold'
                  : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
              }`}
            >
              全部單位
            </button>
            {(organizations ?? []).map((org) => {
              const active = selectedOrgId === org.id;
              return (
                <button
                  key={org.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setSelectedOrgId(org.id)}
                  className={`flex min-h-[44px] shrink-0 items-center justify-center gap-2 rounded-xl border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap ${
                    active
                      ? 'border-violet-600 bg-[#CDB8FF] text-zinc-900 font-semibold'
                      : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                  }`}
                >
                  <span
                    aria-hidden="true"
                    style={{ backgroundColor: org.color }}
                    className="h-3 w-3 shrink-0 rounded-sm ring-1 ring-inset ring-black/15"
                  />
                  <span>{org.name}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {isLoading ? (
        <div className="rounded-2xl border border-zinc-200 bg-white p-8 text-center text-sm text-zinc-500">
          載入中…
        </div>
      ) : viewMode === 'courses' ? (
        (organizations ?? []).length === 0 ? (
          <div className="rounded-2xl border border-zinc-200 bg-white p-6 text-center">
            <p className="text-sm font-medium text-zinc-800">尚未建立任課單位</p>
            <p className="mt-1.5 text-sm leading-relaxed text-zinc-500">
              先到『更多』新增任課單位（學校或補習班）
            </p>
          </div>
        ) : groupedCourses.length === 0 ? (
          <div className="rounded-2xl border border-zinc-200 bg-white p-8 text-center">
            <p className="text-sm font-medium text-zinc-800">尚無課程</p>
            <p className="mt-1.5 text-sm leading-relaxed text-zinc-500">
              點右下角 + 新增第一個班級
            </p>
          </div>
        ) : (
          <div className="space-y-5">
            {groupedCourses.map(({ organization, courses: orgCourses }) => (
              <div key={organization.id} className="space-y-2">
                <div className="flex items-center gap-2 px-1">
                  <span
                    aria-hidden="true"
                    style={{ backgroundColor: organization.color }}
                    className="h-3.5 w-3.5 shrink-0 rounded-sm ring-1 ring-inset ring-black/15"
                  />
                  <h2 className="text-sm font-semibold text-zinc-900">
                    {organization.name}
                  </h2>
                  <span className="text-xs text-zinc-500">
                    · {ORGANIZATION_TYPE_LABELS[organization.type]}
                  </span>
                </div>

                <div className="space-y-2">
                  {orgCourses.map((course) => {
                    const slots = course.regularSlots ?? [];
                    return (
                      <button
                        key={course.id}
                        type="button"
                        onClick={() => setDetailCourseId(course.id)}
                        className="flex min-h-[68px] w-full items-center justify-between gap-3 rounded-2xl border border-zinc-200 bg-white px-4 py-3 text-left transition-colors duration-150 hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2.5">
                            <span
                              aria-hidden="true"
                              style={{ backgroundColor: course.color }}
                              className="h-3.5 w-3.5 shrink-0 rounded-sm ring-1 ring-inset ring-black/15"
                            />
                            <span className="truncate text-lg font-semibold leading-snug text-zinc-900">
                              {course.name}
                            </span>
                          </div>
                          <p className="mt-0.5 truncate pl-6 text-xs text-zinc-500">
                            {organization.name}
                          </p>
                          {slots.length > 0 && (
                            <p className="mt-1 truncate pl-6 text-xs text-zinc-600 tabular-nums">
                              {slots
                                .map(
                                  (s) =>
                                    `${WEEKDAY_LABELS[s.weekday]}${s.periodLabel ? ` ${s.periodLabel}` : ''} ${s.startTime}–${s.endTime}`
                                )
                                .join(' · ')}
                            </p>
                          )}
                        </div>
                        <ChevronRight
                          size={18}
                          aria-hidden="true"
                          className="shrink-0 text-zinc-400"
                        />
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2 px-1">
            <p className="text-xs font-medium text-zinc-600 tabular-nums">
              共 {filteredSessions.length} 堂場次
              {filteredSessions.length > 0 ? '（長按可多選刪除）' : ''}
            </p>
            {filteredSessions.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  if (selectionMode) {
                    setSelectionMode(false);
                    setSelectedSessionIds([]);
                  } else {
                    setSelectionMode(true);
                  }
                }}
                className="flex min-h-[44px] items-center justify-center gap-1 rounded-xl px-2.5 text-xs font-medium text-violet-700 hover:bg-violet-50"
              >
                <CheckSquare size={15} aria-hidden="true" />
                <span>{selectionMode ? '取消多選' : '多選'}</span>
              </button>
            )}
          </div>

          {filteredSessions.length === 0 ? (
            <div className="rounded-2xl border border-zinc-200 bg-white p-8 text-center">
              <p className="text-sm font-medium text-zinc-800">尚無場次</p>
              <p className="mt-1.5 text-sm leading-relaxed text-zinc-500">
                {coursesInSelectedYear.length === 0
                  ? '可先新增課程班級，或點右下角 + 直接建立「代課／臨時」場次'
                  : '點右下角 + 新增單堂場次，或進入課程依常用時段整批產生'}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredSessions.map((session) => {
                const resolved = resolveSessionDisplay(
                  session,
                  courseMap,
                  orgMap
                );
                return (
                  <SessionListItem
                    key={session.id}
                    session={session}
                    course={resolved.course}
                    organization={resolved.organization}
                    linkedCancelledSession={
                      session.makeupForSessionId
                        ? sessionMap.get(session.makeupForSessionId)
                        : undefined
                    }
                    hasOverlap={overlappingSessionIds.has(session.id)}
                    showCourseHeader
                    selectionMode={selectionMode}
                    selected={selectedSessionIds.includes(session.id)}
                    onTap={handleTapSession}
                    onLongPress={handleLongPressSession}
                    onOpenMenu={openSessionMenu}
                    onCreateMakeup={(cancelled) => {
                      setEditingSession(null);
                      setMakeupTargetSession(cancelled);
                      setSessionModalOpen(true);
                    }}
                  />
                );
              })}
            </div>
          )}
        </div>
      )}

      {isKeyboardActive ? null : selectionMode && viewMode === 'sessions' ? (
        <div className="fixed inset-x-0 bottom-[calc(var(--bottom-nav-height)+env(safe-area-inset-bottom)+0.75rem)] z-30 px-4">
          <div className="mx-auto flex w-full max-w-2xl items-center gap-2 rounded-2xl border border-zinc-200 bg-white p-2.5 shadow-xl">
            <button
              type="button"
              onClick={() => {
                const allIds = filteredSessions.map((s) => s.id);
                setSelectedSessionIds(
                  selectedSessionIds.length === allIds.length ? [] : allIds
                );
              }}
              className="flex min-h-[44px] items-center justify-center rounded-xl border border-zinc-200 bg-white px-3 text-xs font-medium text-zinc-700 hover:bg-zinc-50 whitespace-nowrap"
            >
              {selectedSessionIds.length === filteredSessions.length
                ? '取消全選'
                : '全選'}
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectionMode(false);
                setSelectedSessionIds([]);
              }}
              className="flex min-h-[44px] items-center justify-center rounded-xl border border-zinc-200 bg-white px-3 text-xs font-medium text-zinc-700 hover:bg-zinc-50 whitespace-nowrap"
            >
              取消
            </button>
            <button
              type="button"
              disabled={selectedSessionIds.length === 0}
              onClick={() => setMultiDeleteConfirmOpen(true)}
              className="flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-rose-600 px-3 py-2 text-sm font-medium text-white transition-colors hover:bg-rose-700 disabled:opacity-50 whitespace-nowrap"
            >
              <Trash2 size={16} aria-hidden="true" />
              <span>刪除所選（{selectedSessionIds.length}）</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="pointer-events-none fixed inset-x-0 bottom-[calc(var(--bottom-nav-height)+env(safe-area-inset-bottom)+1rem)] z-20">
          <div className="mx-auto flex w-full max-w-2xl justify-end px-4">
            <button
              type="button"
              onClick={
                viewMode === 'courses'
                  ? handleOpenCreateCourse
                  : handleOpenCreateSession
              }
              aria-label={viewMode === 'courses' ? '新增課程' : '新增場次'}
              className="pointer-events-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-violet-600 text-white shadow-lg shadow-violet-900/20 transition-transform duration-150 hover:bg-violet-700 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2"
            >
              <Plus size={24} strokeWidth={2.25} aria-hidden="true" />
            </button>
          </div>
        </div>
      )}

      <AcademicYearManagerModal
        open={yearModalOpen}
        selectedYearId={selectedYearId}
        onSelectYear={setSelectedYearId}
        onClose={() => setYearModalOpen(false)}
      />

      <CourseDetailModal
        open={detailCourse !== null}
        course={detailCourse}
        organization={
          detailCourse ? orgMap.get(detailCourse.organizationId) : undefined
        }
        academicYear={
          detailCourse ? yearMap.get(detailCourse.academicYearId) : undefined
        }
        allCourses={courses ?? []}
        allOrganizations={organizations ?? []}
        onClose={() => setDetailCourseId(null)}
        onEditCourse={(c) => {
          setEditingCourse(c);
          setCourseModalOpen(true);
        }}
      />

      <CourseFormModal
        open={courseModalOpen}
        course={editingCourse}
        academicYears={academicYears ?? []}
        organizations={organizations ?? []}
        defaultAcademicYearId={selectedYearId}
        defaultOrganizationId={
          selectedOrgId !== 'all' ? selectedOrgId : undefined
        }
        onClose={() => setCourseModalOpen(false)}
        onSaved={(savedCourse) => {
          if ((savedCourse.regularSlots?.length ?? 0) > 0) {
            setBatchPromptCourse(savedCourse);
          }
        }}
        onOpenNewOrganization={() => setOrgModalOpen(true)}
      />

      <OrganizationFormModal
        open={orgModalOpen}
        organization={null}
        onClose={() => setOrgModalOpen(false)}
      />

      <SessionFormModal
        open={sessionModalOpen}
        session={editingSession}
        courses={courses ?? []}
        organizations={organizations ?? []}
        defaultCourseId={
          makeupTargetSession?.courseId ?? coursesInSelectedYear[0]?.id
        }
        defaultKind={makeupTargetSession ? 'makeup' : 'regular'}
        defaultMakeupForSessionId={makeupTargetSession?.id}
        onClose={() => setSessionModalOpen(false)}
      />

      {(() => {
        const activeDetailSession = detailSessionId
          ? (sessionMap.get(detailSessionId) ?? null)
          : null;
        const activeResolved = activeDetailSession
          ? resolveSessionDisplay(activeDetailSession, courseMap, orgMap)
          : null;
        return (
          <SessionDetailModal
            session={activeDetailSession}
            course={activeResolved?.course}
            organization={activeResolved?.organization}
            allCourses={courses ?? []}
            allOrganizations={organizations ?? []}
            onClose={() => setDetailSessionId(null)}
          />
        );
      })()}

      {batchModalCourse && (
        <BatchGenerateSessionsModal
          open
          course={batchModalCourse}
          academicYear={yearMap.get(batchModalCourse.academicYearId)}
          preferFullAcademicYear
          onClose={() => setBatchModalCourse(null)}
        />
      )}

      <ConfirmDialog
        open={batchPromptCourse !== null}
        title="依常用時段產生本學期場次"
        description={
          batchPromptCourse
            ? `已儲存「${batchPromptCourse.name}」。要現在依常用時段產生本學期的場次嗎？`
            : ''
        }
        confirmLabel="是"
        cancelLabel="否，稍後"
        danger={false}
        onCancel={() => setBatchPromptCourse(null)}
        onConfirm={() => {
          const target = batchPromptCourse;
          setBatchPromptCourse(null);
          if (target) {
            setBatchModalCourse(target);
          }
        }}
      />

      <ConfirmDialog
        open={multiDeleteConfirmOpen}
        title="刪除多筆場次"
        description={`確定要刪除所選的 ${selectedSessionIds.length} 堂場次嗎？刪除後 12 秒內可點擊「復原」。`}
        confirmLabel={`刪除 ${selectedSessionIds.length} 堂`}
        isSubmitting={isDeletingMultiple}
        onCancel={() => setMultiDeleteConfirmOpen(false)}
        onConfirm={() => {
          void handleConfirmMultiDelete();
        }}
      />
      <SessionQuickActionsHost {...quickActionsProps} />
    </section>
  );
}
