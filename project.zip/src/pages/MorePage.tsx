import { CalendarCog, CalendarRange, ChevronDown, ChevronRight, Clock, ListChecks, Plus, Undo2, UserCheck } from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { AcademicYearManagerModal } from '../components/AcademicYearManagerModal';
import { AllTasksModal } from '../components/AllTasksModal';
import { BackupRestoreSection } from '../components/BackupRestoreSection';
import { BatchRescheduleModal } from '../components/BatchRescheduleModal';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { ExamPeriodsModal } from '../components/ExamPeriodsModal';
import { OrganizationFormModal } from '../components/OrganizationFormModal';
import { PWAInstallButton } from '../components/PWAInstallButton';
import {
  getSubstituteSessionsForYear,
  pickCurrentAcademicYearId,
  SubstituteRecordsModal,
} from '../components/SubstituteRecordsModal';
import { db } from '../db/database';
import { reclaimSessionBatch } from '../db/repositories';
import type { Organization, SessionBatch } from '../db/types';
import { ORGANIZATION_TYPE_LABELS } from '../utils/colors';
import { formatTimestamp, toDateKey } from '../utils/date';
import {
  formatDurationSummary,
  getSessionDurationMinutes,
  isSessionCancelled,
} from '../utils/sessionDisplay';
import {
  formatBytes,
  getStorageStatus,
  requestPersistentStorage,
  type StorageStatus,
} from '../utils/storage';
import { placeTasks } from '../utils/taskPlacement';
import { pushUndoAction } from '../utils/undoStore';
import { useLiveQuery } from '../utils/useLiveQuery';
import { isNativeApp } from '../utils/platform';
import { usePWAInstall } from '../utils/usePWAInstall';

const MORE_COLLAPSE_STORAGE_KEY = 'course-assistant:more-sections:v1';

interface MoreSectionCollapseState {
  batchesExpanded: boolean;
  diagnosticsExpanded: boolean;
}

const DEFAULT_COLLAPSE_STATE: MoreSectionCollapseState = {
  batchesExpanded: false,
  diagnosticsExpanded: false,
};

function loadMoreCollapseState(): MoreSectionCollapseState {
  if (typeof window === 'undefined') return DEFAULT_COLLAPSE_STATE;
  try {
    const raw = window.localStorage.getItem(MORE_COLLAPSE_STORAGE_KEY);
    if (!raw) return DEFAULT_COLLAPSE_STATE;
    const parsed = JSON.parse(raw) as Partial<MoreSectionCollapseState> | null;
    if (!parsed || typeof parsed !== 'object') return DEFAULT_COLLAPSE_STATE;
    return {
      batchesExpanded:
        typeof parsed.batchesExpanded === 'boolean'
          ? parsed.batchesExpanded
          : false,
      diagnosticsExpanded:
        typeof parsed.diagnosticsExpanded === 'boolean'
          ? parsed.diagnosticsExpanded
          : false,
    };
  } catch {
    return DEFAULT_COLLAPSE_STATE;
  }
}

function saveMoreCollapseState(state: MoreSectionCollapseState) {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(MORE_COLLAPSE_STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota or private browsing write errors
  }
}

interface InstallDiagnostics {
  swSupported: boolean;
  swRegistered: boolean;
  swControlled: boolean;
  inIframe: boolean;
  isStandalone: boolean;
  origin: string;
}

async function readInstallDiagnostics(): Promise<InstallDiagnostics> {
  const swSupported = typeof navigator !== 'undefined' && 'serviceWorker' in navigator;
  let swRegistered = false;
  if (swSupported) {
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      swRegistered = Boolean(registration);
    } catch {
      swRegistered = false;
    }
  }

  const swControlled = swSupported && Boolean(navigator.serviceWorker.controller);

  let inIframe = false;
  try {
    inIframe = window.self !== window.top;
  } catch {
    inIframe = true;
  }

  const isStandalone =
    typeof window !== 'undefined' &&
    window.matchMedia('(display-mode: standalone)').matches;

  const origin = typeof window !== 'undefined' ? window.location.origin : '';

  return {
    swSupported,
    swRegistered,
    swControlled,
    inIframe,
    isStandalone,
    origin,
  };
}

export function MorePage() {
  const organizations = useLiveQuery(
    () => db.organizations.orderBy('createdAt').toArray(),
    []
  );
  const academicYears = useLiveQuery(
    () => db.academicYears.orderBy('startDate').reverse().toArray(),
    []
  );
  const batches = useLiveQuery(
    () => db.sessionBatches.orderBy('createdAt').reverse().toArray(),
    []
  );
  const allCourses = useLiveQuery(() => db.courses.toArray(), []);
  const allSessions = useLiveQuery(() => db.sessions.toArray(), []);
  const allTasks = useLiveQuery(() => db.tasks.toArray(), []);
  const examPeriods = useLiveQuery(() => db.examPeriods.toArray(), []);

  const [orgModalOpen, setOrgModalOpen] = useState(false);
  const [editingOrg, setEditingOrg] = useState<Organization | null>(null);
  const [yearModalOpen, setYearModalOpen] = useState(false);
  const [substituteModalOpen, setSubstituteModalOpen] = useState(false);
  const [allTasksModalOpen, setAllTasksModalOpen] = useState(false);
  const [examPeriodsModalOpen, setExamPeriodsModalOpen] = useState(false);
  const [selectedYearId, setSelectedYearId] = useState('');

  const [rescheduleBatch, setRescheduleBatch] = useState<SessionBatch | null>(
    null
  );
  const [reclaimTarget, setReclaimTarget] = useState<SessionBatch | null>(null);
  const [isReclaiming, setIsReclaiming] = useState(false);
  const [batchFeedback, setBatchFeedback] = useState<string | null>(null);

  const [storageStatus, setStorageStatus] = useState<StorageStatus | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [persistFeedback, setPersistFeedback] = useState<{
    granted: boolean;
    message: string;
  } | null>(null);

  const [diagnostics, setDiagnostics] = useState<InstallDiagnostics | null>(null);
  const { hasReceivedInstallPrompt } = usePWAInstall();

  const [collapseState, setCollapseState] = useState<MoreSectionCollapseState>(
    () => loadMoreCollapseState()
  );
  const [showAllBatches, setShowAllBatches] = useState(false);

  const toggleSection = (key: keyof MoreSectionCollapseState) => {
    setCollapseState((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      saveMoreCollapseState(next);
      return next;
    });
  };

  useEffect(() => {
    if (!academicYears || academicYears.length === 0) return;
    if (!selectedYearId || !academicYears.some((y) => y.id === selectedYearId)) {
      const preferred =
        academicYears.find((y) => !y.archived) ?? academicYears[0];
      setSelectedYearId(preferred.id);
    }
  }, [academicYears, selectedYearId]);

  const batchRemainingCountMap = useMemo(() => {
    const map = new Map<string, number>();
    for (const s of allSessions ?? []) {
      if (s.batchId) {
        map.set(s.batchId, (map.get(s.batchId) ?? 0) + 1);
      }
    }
    return map;
  }, [allSessions]);

  const currentYearSubSummary = useMemo(() => {
    const years = academicYears ?? [];
    const currentYearId = pickCurrentAcademicYearId(years);
    const currentYear = years.find((y) => y.id === currentYearId);
    const courseMap = new Map((allCourses ?? []).map((c) => [c.id, c]));
    const yearSubs = getSubstituteSessionsForYear(
      allSessions ?? [],
      currentYear,
      courseMap
    ).filter((s) => !isSessionCancelled(s));
    let totalMinutes = 0;
    for (const s of yearSubs) {
      totalMinutes += getSessionDurationMinutes(s);
    }
    return {
      yearName: currentYear?.name ?? '本學年',
      count: yearSubs.length,
      totalMinutes,
    };
  }, [academicYears, allCourses, allSessions]);

  const taskSummary = useMemo(() => {
    const list = allTasks ?? [];
    const activeCount = list.filter((t) => !t.done).length;
    const placement = placeTasks({
      tasks: list,
      sessions: allSessions ?? [],
      now: new Date(),
    });
    return {
      activeCount,
      overdueCount: placement.overdueTodos.length,
      totalCount: list.length,
    };
  }, [allTasks, allSessions]);

  const upcomingExamCount = useMemo(() => {
    const todayKey = toDateKey(new Date());
    return (examPeriods ?? []).filter((p) => p.endDate >= todayKey).length;
  }, [examPeriods]);

  const loadStorageStatus = useCallback(async () => {
    setIsRefreshing(true);
    try {
      const status = await getStorageStatus();
      setStorageStatus(status);
    } finally {
      setIsRefreshing(false);
    }
  }, []);

  const loadDiagnostics = useCallback(async () => {
    const info = await readInstallDiagnostics();
    setDiagnostics(info);
  }, []);

  useEffect(() => {
    void loadStorageStatus();
    void loadDiagnostics();

    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
      const handleControllerChange = () => {
        void loadDiagnostics();
      };
      navigator.serviceWorker.addEventListener('controllerchange', handleControllerChange);
      return () => {
        navigator.serviceWorker.removeEventListener('controllerchange', handleControllerChange);
      };
    }
    return undefined;
  }, [loadStorageStatus, loadDiagnostics]);

  const handleRequestPersist = async () => {
    setIsRefreshing(true);
    try {
      const granted = await requestPersistentStorage();
      const status = await getStorageStatus();
      setStorageStatus(status);

      if (granted) {
        setPersistFeedback({
          granted: true,
          message: '已啟用持久儲存',
        });
      } else {
        setPersistFeedback({
          granted: false,
          message:
            'Chrome 暫時沒有同意（這是瀏覽器自動判斷，不會跳視窗）。把本站加入書籤或安裝成 App、多使用幾天後再試。資料仍保存在本機，請定期用備份功能匯出。',
        });
      }
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleConfirmReclaim = async () => {
    if (!reclaimTarget) return;
    setIsReclaiming(true);
    try {
      const result = await reclaimSessionBatch(reclaimTarget.id);
      if (result.keptCount > 0) {
        setBatchFeedback(
          `已收回「${reclaimTarget.courseName}」${result.deletedCount} 堂空白場次，保留了 ${result.keptCount} 堂已有紀錄（進度、備註、作業或照片）的場次。`
        );
      } else {
        setBatchFeedback(
          `已一鍵收回「${reclaimTarget.courseName}」共 ${result.deletedCount} 堂場次。`
        );
      }
      if (result.deletedCount > 0) {
        pushUndoAction(
          `已收回 ${result.deletedCount} 堂場次`,
          result.backup
        );
      }
      setReclaimTarget(null);
    } finally {
      setIsReclaiming(false);
    }
  };

  const persistenceLabel = (() => {
    if (!storageStatus) return '檢查中…';
    if (!storageStatus.supported || storageStatus.persisted === null) {
      return '此瀏覽器不支援';
    }
    return storageStatus.persisted ? '已啟用持久儲存' : '尚未啟用持久儲存';
  })();

  const usageLabel = (() => {
    if (!storageStatus) return '計算中…';
    if (!storageStatus.supported || storageStatus.usageBytes === null) {
      return '無法取得';
    }
    return formatBytes(storageStatus.usageBytes);
  })();

  const quotaLabel =
    storageStatus?.supported && storageStatus.quotaBytes !== null
      ? formatBytes(storageStatus.quotaBytes)
      : null;

  return (
    <section aria-label="更多頁面" className="space-y-4 px-4 py-5">
      <div className="rounded-2xl border border-zinc-200 bg-white">
        <button
          type="button"
          onClick={() => setExamPeriodsModalOpen(true)}
          className="flex min-h-[56px] w-full items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
        >
          <div className="flex min-w-0 items-center gap-3">
            <CalendarRange size={18} className="shrink-0 text-pink-600" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-semibold text-zinc-900">考試時程</p>
              <p className="truncate text-xs text-zinc-500 tabular-nums">
                {upcomingExamCount} 個即將到來
              </p>
            </div>
          </div>
          <ChevronRight size={17} aria-hidden="true" className="shrink-0 text-zinc-400" />
        </button>
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white">
        <button
          type="button"
          onClick={() => setAllTasksModalOpen(true)}
          className="flex min-h-[56px] w-full items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
        >
          <div className="flex min-w-0 items-center gap-3">
            <ListChecks size={18} className="shrink-0 text-violet-700" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-semibold text-zinc-900">全部任務</p>
              <p className="truncate text-xs text-zinc-500 tabular-nums">
                {taskSummary.totalCount === 0
                  ? '集中管理所有待辦與提醒（依逾期、今天、之後、無日期分組）'
                  : `未完成 ${taskSummary.activeCount} 筆${
                      taskSummary.overdueCount > 0
                        ? ` · 逾期 ${taskSummary.overdueCount} 筆`
                        : ''
                    }`}
              </p>
            </div>
          </div>
          <ChevronRight size={17} aria-hidden="true" className="shrink-0 text-zinc-400" />
        </button>
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white">
        <div className="flex items-center justify-between gap-3 border-b border-zinc-100 px-4 py-2.5">
          <h2 className="text-sm font-semibold text-zinc-900">任課單位</h2>
          <button
            type="button"
            onClick={() => {
              setEditingOrg(null);
              setOrgModalOpen(true);
            }}
            className="flex min-h-[44px] items-center justify-center gap-1 rounded-xl px-3 text-xs font-medium text-violet-700 transition-colors hover:bg-violet-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 whitespace-nowrap"
          >
            <Plus size={15} aria-hidden="true" />
            <span>新增單位</span>
          </button>
        </div>

        <div className="divide-y divide-zinc-100">
          {organizations === undefined ? (
            <p className="px-4 py-4 text-center text-sm text-zinc-500">載入中…</p>
          ) : organizations.length === 0 ? (
            <p className="px-4 py-4 text-center text-sm text-zinc-500">
              尚無任課單位，請點右上角新增。
            </p>
          ) : (
            organizations.map((org) => (
              <button
                key={org.id}
                type="button"
                onClick={() => {
                  setEditingOrg(org);
                  setOrgModalOpen(true);
                }}
                className="flex min-h-[52px] w-full items-center justify-between gap-3 px-4 py-3 text-left transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-violet-600"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <span
                    aria-hidden="true"
                    style={{ backgroundColor: org.color }}
                    className="h-4 w-4 shrink-0 rounded-sm ring-1 ring-inset ring-black/15"
                  />
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-zinc-900">
                      {org.name}
                    </p>
                    <p className="text-xs text-zinc-500">
                      {ORGANIZATION_TYPE_LABELS[org.type]}
                    </p>
                  </div>
                </div>
                <ChevronRight
                  size={17}
                  aria-hidden="true"
                  className="shrink-0 text-zinc-400"
                />
              </button>
            ))
          )}
        </div>
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white">
        <button
          type="button"
          onClick={() => setYearModalOpen(true)}
          className="flex min-h-[56px] w-full items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
        >
          <div className="flex min-w-0 items-center gap-3">
            <CalendarCog size={18} className="shrink-0 text-zinc-600" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-semibold text-zinc-900">學年管理</p>
              <p className="truncate text-xs text-zinc-500">
                共 {(academicYears ?? []).length} 筆學年設定（新增、編輯、歸檔或刪除）
              </p>
            </div>
          </div>
          <ChevronRight size={17} aria-hidden="true" className="shrink-0 text-zinc-400" />
        </button>
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white">
        <button
          type="button"
          onClick={() => setSubstituteModalOpen(true)}
          className="flex min-h-[56px] w-full items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
        >
          <div className="flex min-w-0 items-center gap-3">
            <UserCheck size={18} className="shrink-0 text-amber-700" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-semibold text-zinc-900">
                代課／臨時紀錄
              </p>
              <p className="truncate text-xs text-zinc-500 tabular-nums">
                {currentYearSubSummary.yearName}累計 {currentYearSubSummary.count} 堂 ·{' '}
                {formatDurationSummary(currentYearSubSummary.totalMinutes)}
              </p>
            </div>
          </div>
          <ChevronRight size={17} aria-hidden="true" className="shrink-0 text-zinc-400" />
        </button>
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white">
        <button
          type="button"
          aria-expanded={collapseState.batchesExpanded}
          onClick={() => toggleSection('batchesExpanded')}
          className="flex min-h-[52px] w-full items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
        >
          <div className="min-w-0">
            <h2 className="text-sm font-semibold text-zinc-900 tabular-nums">
              批次（共 {(batches ?? []).length} 批）
            </h2>
            <p className="mt-0.5 text-xs text-zinc-500">
              可檢視整批產生紀錄、整批改時間，或一鍵收回空白場次。
            </p>
          </div>
          <ChevronDown
            size={18}
            aria-hidden="true"
            className={`shrink-0 text-zinc-500 transition-transform duration-150 ${
              collapseState.batchesExpanded ? 'rotate-180' : ''
            }`}
          />
        </button>

        {batchFeedback && (
          <div
            role="status"
            aria-live="polite"
            className="border-t border-zinc-100 bg-violet-50/70 px-4 py-2.5 text-xs leading-relaxed text-zinc-800"
          >
            {batchFeedback}
          </div>
        )}

        {collapseState.batchesExpanded && (
          <div className="divide-y divide-zinc-100 border-t border-zinc-100">
            {batches === undefined ? (
              <p className="px-4 py-4 text-center text-sm text-zinc-500">載入中…</p>
            ) : batches.length === 0 ? (
              <p className="px-4 py-4 text-center text-sm text-zinc-500">
                尚無批次產生紀錄。
              </p>
            ) : (
              <>
                {(showAllBatches ? batches : batches.slice(0, 5)).map((batch) => {
                  const remaining = batchRemainingCountMap.get(batch.id) ?? 0;
                  return (
                    <div key={batch.id} className="space-y-2.5 px-4 py-3.5">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-zinc-900">
                            {batch.courseName}
                          </p>
                          <p className="mt-0.5 text-xs text-zinc-500 tabular-nums">
                            建立於 {formatTimestamp(batch.createdAt)} · 區間{' '}
                            {batch.startDate} ~ {batch.endDate}
                          </p>
                          {batch.slotSummary && (
                            <p className="mt-0.5 truncate text-xs text-zinc-500 tabular-nums">
                              {batch.slotSummary}
                            </p>
                          )}
                        </div>
                        <span className="shrink-0 text-xs font-semibold text-violet-700 tabular-nums">
                          現存 {remaining} / {batch.totalCount} 堂
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          disabled={remaining === 0}
                          onClick={() => setRescheduleBatch(batch)}
                          className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-zinc-200 bg-white px-3 text-xs font-medium text-zinc-800 transition-colors hover:bg-zinc-50 disabled:opacity-50"
                        >
                          <Clock size={14} aria-hidden="true" />
                          <span>整批改時間</span>
                        </button>
                        <button
                          type="button"
                          disabled={remaining === 0}
                          onClick={() => setReclaimTarget(batch)}
                          className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-rose-200 bg-white px-3 text-xs font-medium text-rose-600 transition-colors hover:bg-rose-50 disabled:opacity-50"
                        >
                          <Undo2 size={14} aria-hidden="true" />
                          <span>一鍵收回整批</span>
                        </button>
                      </div>
                    </div>
                  );
                })}

                {batches.length > 5 && (
                  <div className="px-4 py-2.5">
                    <button
                      type="button"
                      onClick={() => setShowAllBatches((prev) => !prev)}
                      className="flex min-h-[44px] w-full items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50/70 px-4 text-xs font-semibold text-violet-700 transition-colors hover:bg-violet-50 tabular-nums"
                    >
                      {showAllBatches
                        ? '只顯示最近 5 批'
                        : `顯示更多（還有 ${batches.length - 5} 批）`}
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>

      <BackupRestoreSection />

      {!isNativeApp && (
        <>
      <PWAInstallButton />

      <div className="rounded-2xl border border-zinc-200 bg-white">
        <div className="border-b border-zinc-100 px-4 py-3">
          <h2 className="text-sm font-semibold text-zinc-900">儲存狀態</h2>
        </div>

        <dl className="divide-y divide-zinc-100">
          <div className="flex items-center justify-between gap-4 px-4 py-3.5">
            <dt className="text-sm text-zinc-600">持久儲存</dt>
            <dd
              className={`text-sm font-medium ${
                storageStatus?.persisted
                  ? 'text-emerald-700'
                  : 'text-zinc-900'
              }`}
            >
              {persistenceLabel}
            </dd>
          </div>

          <div className="flex items-center justify-between gap-4 px-4 py-3.5">
            <dt className="text-sm text-zinc-600">已用空間</dt>
            <dd className="text-sm font-medium text-zinc-900 tabular-nums">
              {usageLabel}
              {quotaLabel ? (
                <span className="ml-1.5 text-xs font-normal text-zinc-500">
                  / {quotaLabel}
                </span>
              ) : null}
            </dd>
          </div>
        </dl>

        {persistFeedback && (
          <div
            role="status"
            aria-live="polite"
            className={`border-t border-zinc-100 px-4 py-3 text-xs leading-relaxed ${
              persistFeedback.granted
                ? 'bg-emerald-50/70 text-emerald-800'
                : 'bg-amber-50/80 text-amber-900'
            }`}
          >
            {persistFeedback.message}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2 border-t border-zinc-100 px-4 py-3">
          {storageStatus?.supported && storageStatus.persisted === false && (
            <button
              type="button"
              onClick={() => {
                void handleRequestPersist();
              }}
              disabled={isRefreshing}
              className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl bg-violet-600 px-4 py-2 text-sm font-medium text-white transition-colors duration-150 hover:bg-violet-700 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2 whitespace-nowrap"
            >
              要求持久儲存
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              void loadStorageStatus();
            }}
            disabled={isRefreshing}
            className="flex min-h-[44px] flex-1 items-center justify-center rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm font-medium text-zinc-700 transition-colors duration-150 hover:bg-zinc-50 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 whitespace-nowrap"
          >
            {isRefreshing ? '檢查中…' : '重新整理'}
          </button>
        </div>
      </div>

      <div className="rounded-2xl border border-zinc-200 bg-white">
        <button
          type="button"
          aria-expanded={collapseState.diagnosticsExpanded}
          onClick={() => toggleSection('diagnosticsExpanded')}
          className="flex min-h-[52px] w-full items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
        >
          <h2 className="text-sm font-semibold text-zinc-900">安裝診斷</h2>
          <ChevronDown
            size={18}
            aria-hidden="true"
            className={`shrink-0 text-zinc-500 transition-transform duration-150 ${
              collapseState.diagnosticsExpanded ? 'rotate-180' : ''
            }`}
          />
        </button>

        {collapseState.diagnosticsExpanded && (
          <div className="border-t border-zinc-100">
            <dl className="divide-y divide-zinc-100 text-sm">
              <div className="flex items-center justify-between gap-4 px-4 py-3">
                <dt className="text-zinc-600">Service Worker 已註冊</dt>
                <dd className="font-medium text-zinc-900 whitespace-nowrap">
                  {diagnostics === null
                    ? '檢查中…'
                    : !diagnostics.swSupported
                      ? '不支援'
                      : diagnostics.swRegistered
                        ? '是'
                        : '否'}
                </dd>
              </div>

              <div className="flex items-center justify-between gap-4 px-4 py-3">
                <dt className="text-zinc-600">頁面受 Service Worker 控制</dt>
                <dd className="font-medium text-zinc-900 whitespace-nowrap">
                  {diagnostics === null
                    ? '檢查中…'
                    : !diagnostics.swSupported
                      ? '不支援'
                      : diagnostics.swControlled
                        ? '是'
                        : '否'}
                </dd>
              </div>

              <div className="flex items-center justify-between gap-4 px-4 py-3">
                <dt className="text-zinc-600">位於 iframe 內</dt>
                <dd className="font-medium text-zinc-900 whitespace-nowrap">
                  {diagnostics === null ? '檢查中…' : diagnostics.inIframe ? '是' : '否'}
                </dd>
              </div>

              <div className="flex items-center justify-between gap-4 px-4 py-3">
                <dt className="text-zinc-600">Standalone 模式</dt>
                <dd className="font-medium text-zinc-900 whitespace-nowrap">
                  {diagnostics === null ? '檢查中…' : diagnostics.isStandalone ? '是' : '否'}
                </dd>
              </div>

              <div className="flex items-start justify-between gap-4 px-4 py-3">
                <dt className="shrink-0 text-zinc-600">目前來源（origin）</dt>
                <dd className="break-all text-right font-mono text-xs text-zinc-900">
                  {diagnostics === null ? '檢查中…' : diagnostics.origin || '無法取得'}
                </dd>
              </div>

              <div className="flex items-center justify-between gap-4 px-4 py-3">
                <dt className="text-zinc-600">收到過 beforeinstallprompt</dt>
                <dd className="font-medium text-zinc-900 whitespace-nowrap">
                  {hasReceivedInstallPrompt ? '是' : '否'}
                </dd>
              </div>
            </dl>

            <div className="border-t border-zinc-100 px-4 py-3">
              <button
                type="button"
                onClick={() => {
                  void loadDiagnostics();
                }}
                className="flex min-h-[44px] w-full items-center justify-center rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm font-medium text-zinc-700 transition-colors hover:bg-zinc-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 whitespace-nowrap"
              >
                重新檢測
              </button>
            </div>
          </div>
        )}
      </div>
        </>
      )}

      <OrganizationFormModal
        open={orgModalOpen}
        organization={editingOrg}
        onClose={() => setOrgModalOpen(false)}
      />

      <AcademicYearManagerModal
        open={yearModalOpen}
        selectedYearId={selectedYearId}
        onSelectYear={setSelectedYearId}
        onClose={() => setYearModalOpen(false)}
      />

      <BatchRescheduleModal
        open={rescheduleBatch !== null}
        batch={rescheduleBatch}
        onClose={() => setRescheduleBatch(null)}
        onCompleted={(count) => {
          setBatchFeedback(`已成功更新 ${count} 堂場次的上課時間（未刪除任何資料）。`);
        }}
      />

      <ConfirmDialog
        open={reclaimTarget !== null}
        title="一鍵收回整批場次"
        description={
          reclaimTarget
            ? `確定要收回「${reclaimTarget.courseName}」此批次的場次嗎？僅會刪除尚未填寫任何進度、備註、作業或照片的空白場次；已有紀錄的場次會完整保留。`
            : ''
        }
        confirmLabel="確認收回"
        isSubmitting={isReclaiming}
        onCancel={() => setReclaimTarget(null)}
        onConfirm={() => {
          void handleConfirmReclaim();
        }}
      />

      <SubstituteRecordsModal
        open={substituteModalOpen}
        onClose={() => setSubstituteModalOpen(false)}
      />

      <AllTasksModal
        open={allTasksModalOpen}
        onClose={() => setAllTasksModalOpen(false)}
      />

      <ExamPeriodsModal
        open={examPeriodsModalOpen}
        onClose={() => setExamPeriodsModalOpen(false)}
      />
    </section>
  );
}
