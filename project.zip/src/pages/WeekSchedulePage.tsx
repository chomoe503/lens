import {
  BookOpen,
  CalendarDays,
  CalendarRange,
  ChevronLeft,
  ChevronRight,
  ClipboardCheck,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { AddSessionFabMenu } from '../components/AddSessionFabMenu';
import { ExamPeriodFormModal } from '../components/ExamPeriodFormModal';
import { HOMEWORK_STATUS_OPTIONS } from '../components/HomeworkFormModal';
import { SessionDetailModal } from '../components/SessionDetailModal';
import {
  SessionFormModal,
  type SessionFormMode,
} from '../components/SessionFormModal';
import {
  CancelledBadge,
  SessionMenuButton,
  SessionQuickActionsHost,
  useSessionQuickActions,
} from '../components/SessionQuickActions';
import { SubstituteBadge } from '../components/SubstituteBadge';
import { TaskFormModal } from '../components/TaskFormModal';
import { TaskRowItem } from '../components/TaskRowItem';
import { WeekGridDetailSheet } from '../components/WeekGridDetailSheet';
import { WeekScheduleGrid } from '../components/WeekScheduleGrid';
import { db } from '../db/database';
import {
  DEFAULT_SETTINGS_ID,
  saveWeekGridDaysSetting,
} from '../db/repositories';
import type {
  ClassSession,
  Course,
  Exam,
  ExamPeriod,
  Homework,
  Organization,
  TaskItem,
  WeekGridDays,
} from '../db/types';
import {
  formatSlashDate,
  getWeekDates,
  parseDateKey,
  toDateKey,
  WEEKDAY_LABELS,
} from '../utils/date';
import {
  computeSessionCountdowns,
  getExamDisplayTitle,
  resolveExamCourseIds,
} from '../utils/examCountdown';
import {
  isSessionCancelled,
  isSubstituteSession,
  resolveSessionDisplay,
  resolveSessionOrgId,
} from '../utils/sessionDisplay';
import { placeTasks } from '../utils/taskPlacement';
import { useLiveQuery } from '../utils/useLiveQuery';

type WeekViewMode = 'list' | 'grid';

const GRID_DAYS_OPTIONS: Array<{ value: WeekGridDays; label: string }> = [
  { value: 1, label: '1 天' },
  { value: 3, label: '3 天' },
  { value: 7, label: '7 天' },
];

function shiftDateKeyByDays(dateKey: string, deltaDays: number): string {
  const date = parseDateKey(dateKey);
  date.setDate(date.getDate() + deltaDays);
  return toDateKey(date);
}

function getConsecutiveDates(anchorDateKey: string, count: number): Date[] {
  const anchor = parseDateKey(anchorDateKey);
  return Array.from({ length: count }, (_, idx) => {
    const next = new Date(anchor);
    next.setDate(anchor.getDate() + idx);
    return next;
  });
}

export function WeekSchedulePage() {
  const sessions = useLiveQuery(() => db.sessions.toArray(), []);
  const courses = useLiveQuery(() => db.courses.toArray(), []);
  const organizations = useLiveQuery(
    () => db.organizations.orderBy('createdAt').toArray(),
    []
  );
  const exams = useLiveQuery(() => db.exams.toArray(), []);
  const homeworks = useLiveQuery(() => db.homeworks.toArray(), []);
  const tasks = useLiveQuery(() => db.tasks.toArray(), []);
  const examPeriods = useLiveQuery(() => db.examPeriods.toArray(), []);
  const academicYears = useLiveQuery(
    () => db.academicYears.orderBy('startDate').reverse().toArray(),
    []
  );
  const settings = useLiveQuery(() => db.settings.get(DEFAULT_SETTINGS_ID), []);

  const now = new Date();
  const todayKey = toDateKey(now);
  const [selectedDateKey, setSelectedDateKey] = useState<string>(todayKey);
  const [selectedOrgId, setSelectedOrgId] = useState<string>('all');
  const [viewMode, setViewMode] = useState<WeekViewMode>('list');
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [createMode, setCreateMode] = useState<SessionFormMode>('regular');

  const [gridSheetSessionId, setGridSheetSessionId] = useState<string | null>(
    null
  );
  const [gridSheetUnattachedDate, setGridSheetUnattachedDate] = useState<
    string | null
  >(null);

  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskItem | null>(null);
  const [taskDefaultCourseId, setTaskDefaultCourseId] = useState('');
  const [taskDefaultSessionId, setTaskDefaultSessionId] = useState('');
  const [taskDefaultDate, setTaskDefaultDate] = useState('');

  const [examFormOpen, setExamFormOpen] = useState(false);
  const [editingExamPeriod, setEditingExamPeriod] = useState<ExamPeriod | null>(
    null
  );

  const gridDays: WeekGridDays = settings?.weekGridDays ?? 7;

  const { openSessionMenu, quickActionsProps } = useSessionQuickActions({
    courses: courses ?? [],
    organizations: organizations ?? [],
    onSessionDeleted: (deletedId) => {
      if (activeSessionId === deletedId) {
        setActiveSessionId(null);
      }
      if (gridSheetSessionId === deletedId) {
        setGridSheetSessionId(null);
      }
    },
  });

  useEffect(() => {
    if (selectedOrgId === 'all' || !organizations) return;
    if (!organizations.some((o) => o.id === selectedOrgId)) {
      setSelectedOrgId('all');
    }
  }, [organizations, selectedOrgId]);

  const courseMap = useMemo(() => {
    const map = new Map<string, Course>();
    for (const c of courses ?? []) map.set(c.id, c);
    return map;
  }, [courses]);

  const orgMap = useMemo(() => {
    const map = new Map<string, Organization>();
    for (const o of organizations ?? []) map.set(o.id, o);
    return map;
  }, [organizations]);

  const sessionMap = useMemo(() => {
    const map = new Map<string, ClassSession>();
    for (const s of sessions ?? []) map.set(s.id, s);
    return map;
  }, [sessions]);

  const weekDates = useMemo(
    () => getWeekDates(parseDateKey(selectedDateKey)),
    [selectedDateKey]
  );

  const displayDates = useMemo(() => {
    if (viewMode === 'list' || gridDays === 7) {
      return weekDates;
    }
    return getConsecutiveDates(selectedDateKey, gridDays);
  }, [viewMode, gridDays, weekDates, selectedDateKey]);

  const rangeStartKey = toDateKey(displayDates[0]);
  const rangeEndKey = toDateKey(displayDates[displayDates.length - 1]);

  const currentWeekStartKey = useMemo(
    () => toDateKey(getWeekDates(new Date())[0]),
    []
  );
  const isAtTodayPeriod =
    viewMode === 'grid' && gridDays !== 7
      ? todayKey >= rangeStartKey && todayKey <= rangeEndKey
      : rangeStartKey === currentWeekStartKey;

  const placement = useMemo(
    () =>
      placeTasks({
        tasks: tasks ?? [],
        sessions: sessions ?? [],
        now,
      }),
    [tasks, sessions, todayKey, now.getHours(), now.getMinutes()]
  );

  const countdownBySessionId = useMemo(
    () =>
      computeSessionCountdowns({
        examPeriods: examPeriods ?? [],
        sessions: sessions ?? [],
        courses: courses ?? [],
        organizations: organizations ?? [],
      }),
    [examPeriods, sessions, courses, organizations]
  );

  const filteredExamPeriods = useMemo(() => {
    const list = examPeriods ?? [];
    if (selectedOrgId === 'all') return list;
    return list.filter((period) => {
      if (period.organizationId === selectedOrgId) return true;
      const applicableCourseIds = resolveExamCourseIds(period, courses ?? []);
      for (const id of applicableCourseIds) {
        if (courseMap.get(id)?.organizationId === selectedOrgId) {
          return true;
        }
      }
      return false;
    });
  }, [examPeriods, selectedOrgId, courses, courseMap]);

  const filteredOtherTasksByDate = useMemo(() => {
    const result: Record<string, TaskItem[]> = {};
    for (const [dateKey, list] of Object.entries(placement.otherTasksByDate)) {
      const filtered = list.filter((t) => {
        if (selectedOrgId === 'all' || !t.courseId) return true;
        return courseMap.get(t.courseId)?.organizationId === selectedOrgId;
      });
      if (filtered.length > 0) {
        result[dateKey] = filtered;
      }
    }
    return result;
  }, [placement.otherTasksByDate, selectedOrgId, courseMap]);

  const filteredRangeSessions = useMemo(() => {
    if (!sessions) return [];
    return sessions
      .filter((s) => {
        if (s.date < rangeStartKey || s.date > rangeEndKey) return false;
        if (selectedOrgId !== 'all') {
          if (resolveSessionOrgId(s, courseMap) !== selectedOrgId) {
            return false;
          }
        }
        return true;
      })
      .sort((a, b) => {
        const dateDiff = a.date.localeCompare(b.date);
        if (dateDiff !== 0) return dateDiff;
        const startDiff = a.startTime.localeCompare(b.startTime);
        if (startDiff !== 0) return startDiff;
        return a.createdAt - b.createdAt;
      });
  }, [sessions, rangeStartKey, rangeEndKey, selectedOrgId, courseMap]);

  const homeworksByCourseDate = useMemo(() => {
    const map = new Map<string, Homework[]>();
    for (const hw of homeworks ?? []) {
      if (!hw.dueDate) continue;
      const key = `${hw.courseId}__${hw.dueDate}`;
      const arr = map.get(key) ?? [];
      arr.push(hw);
      map.set(key, arr);
    }
    return map;
  }, [homeworks]);

  const examsByCourseDate = useMemo(() => {
    const map = new Map<string, Exam[]>();
    for (const exam of exams ?? []) {
      const key = `${exam.courseId}__${exam.date}`;
      const arr = map.get(key) ?? [];
      arr.push(exam);
      map.set(key, arr);
    }
    return map;
  }, [exams]);

  const weekExamsByDate = useMemo(() => {
    const map = new Map<string, Exam[]>();
    for (const exam of exams ?? []) {
      if (exam.date < rangeStartKey || exam.date > rangeEndKey) continue;
      if (selectedOrgId !== 'all') {
        const course = courseMap.get(exam.courseId);
        if (!course || course.organizationId !== selectedOrgId) continue;
      }
      const arr = map.get(exam.date) ?? [];
      arr.push(exam);
      map.set(exam.date, arr);
    }
    return map;
  }, [exams, rangeStartKey, rangeEndKey, selectedOrgId, courseMap]);

  const weekHomeworksDueByDate = useMemo(() => {
    const map = new Map<string, Homework[]>();
    for (const hw of homeworks ?? []) {
      if (!hw.dueDate) continue;
      if (hw.dueDate < rangeStartKey || hw.dueDate > rangeEndKey) continue;
      if (selectedOrgId !== 'all') {
        const course = courseMap.get(hw.courseId);
        if (!course || course.organizationId !== selectedOrgId) continue;
      }
      const arr = map.get(hw.dueDate) ?? [];
      arr.push(hw);
      map.set(hw.dueDate, arr);
    }
    return map;
  }, [homeworks, rangeStartKey, rangeEndKey, selectedOrgId, courseMap]);

  const weekSubjectExamsByDate = useMemo(() => {
    const map = new Map<string, ExamPeriod[]>();
    for (const period of filteredExamPeriods) {
      if (!period.subjectDate) continue;
      if (period.subjectDate < rangeStartKey || period.subjectDate > rangeEndKey) {
        continue;
      }
      const arr = map.get(period.subjectDate) ?? [];
      arr.push(period);
      map.set(period.subjectDate, arr);
    }
    return map;
  }, [filteredExamPeriods, rangeStartKey, rangeEndKey]);

  const dayGroups = useMemo(() => {
    const byDate = new Map<string, ClassSession[]>();
    for (const s of filteredRangeSessions) {
      const arr = byDate.get(s.date) ?? [];
      arr.push(s);
      byDate.set(s.date, arr);
    }

    return weekDates
      .map((date) => {
        const dateKey = toDateKey(date);
        return {
          date,
          dateKey,
          sessions: byDate.get(dateKey) ?? [],
          exams: weekExamsByDate.get(dateKey) ?? [],
          homeworksDue: weekHomeworksDueByDate.get(dateKey) ?? [],
          otherTasks: filteredOtherTasksByDate[dateKey] ?? [],
          subjectExamPeriods: weekSubjectExamsByDate.get(dateKey) ?? [],
        };
      })
      .filter(
        (group) =>
          group.sessions.length > 0 ||
          group.exams.length > 0 ||
          group.homeworksDue.length > 0 ||
          group.otherTasks.length > 0 ||
          group.subjectExamPeriods.length > 0
      );
  }, [
    weekDates,
    filteredRangeSessions,
    weekExamsByDate,
    weekHomeworksDueByDate,
    filteredOtherTasksByDate,
    weekSubjectExamsByDate,
  ]);

  const isLoading =
    sessions === undefined ||
    courses === undefined ||
    organizations === undefined ||
    exams === undefined ||
    homeworks === undefined ||
    tasks === undefined ||
    examPeriods === undefined;

  const activeSession = activeSessionId
    ? (sessionMap.get(activeSessionId) ?? null)
    : null;
  const activeResolved = activeSession
    ? resolveSessionDisplay(activeSession, courseMap, orgMap)
    : null;

  const gridSheetSession = gridSheetSessionId
    ? (sessionMap.get(gridSheetSessionId) ?? null)
    : null;

  const gridSheetHomeworks = useMemo(() => {
    if (
      !gridSheetSession ||
      isSubstituteSession(gridSheetSession) ||
      isSessionCancelled(gridSheetSession) ||
      !gridSheetSession.courseId
    ) {
      return [];
    }
    return (
      homeworksByCourseDate.get(
        `${gridSheetSession.courseId}__${gridSheetSession.date}`
      ) ?? []
    );
  }, [gridSheetSession, homeworksByCourseDate]);

  const gridSheetExams = useMemo(() => {
    if (
      !gridSheetSession ||
      isSubstituteSession(gridSheetSession) ||
      isSessionCancelled(gridSheetSession) ||
      !gridSheetSession.courseId
    ) {
      return [];
    }
    return (
      examsByCourseDate.get(
        `${gridSheetSession.courseId}__${gridSheetSession.date}`
      ) ?? []
    );
  }, [gridSheetSession, examsByCourseDate]);

  const gridSheetActiveExamPeriods = useMemo(() => {
    if (
      !gridSheetSession ||
      isSubstituteSession(gridSheetSession) ||
      isSessionCancelled(gridSheetSession) ||
      !gridSheetSession.courseId
    ) {
      return [];
    }
    return (examPeriods ?? []).filter((period) => {
      if (
        period.startDate > gridSheetSession.date ||
        period.endDate < gridSheetSession.date
      ) {
        return false;
      }
      return resolveExamCourseIds(period, courses ?? []).has(
        gridSheetSession.courseId!
      );
    });
  }, [gridSheetSession, examPeriods, courses]);

  const defaultCreateDate =
    todayKey >= rangeStartKey && todayKey <= rangeEndKey
      ? todayKey
      : selectedDateKey;

  const stepDays = viewMode === 'grid' ? gridDays : 7;

  const headerRangeLabel = (() => {
    if (viewMode === 'grid' && gridDays === 1) {
      const w = WEEKDAY_LABELS[displayDates[0].getDay()].replace('週', '');
      return `${formatSlashDate(rangeStartKey)}（${w}）`;
    }
    const startW = WEEKDAY_LABELS[displayDates[0].getDay()].replace('週', '');
    const endW = WEEKDAY_LABELS[
      displayDates[displayDates.length - 1].getDay()
    ].replace('週', '');
    return `${formatSlashDate(rangeStartKey)}（${startW}）– ${formatSlashDate(
      rangeEndKey
    )}（${endW}）`;
  })();

  const handleOpenNewTaskForSession = (session: ClassSession) => {
    setEditingTask(null);
    setTaskDefaultCourseId(
      isSubstituteSession(session) ? '' : (session.courseId ?? '')
    );
    setTaskDefaultSessionId(session.id);
    setTaskDefaultDate('');
    setTaskModalOpen(true);
  };

  const handleOpenNewTaskForDate = (dateKey: string) => {
    setEditingTask(null);
    setTaskDefaultCourseId('');
    setTaskDefaultSessionId('');
    setTaskDefaultDate(dateKey);
    setTaskModalOpen(true);
  };

  const handleEditTask = (task: TaskItem) => {
    setEditingTask(task);
    setTaskDefaultCourseId('');
    setTaskDefaultSessionId('');
    setTaskDefaultDate('');
    setTaskModalOpen(true);
  };

  return (
    <section aria-label="週課表頁面" className="space-y-3.5 px-4 py-4">
      {/* 週次／區間導覽與日期選擇 */}
      <div className="space-y-2.5 rounded-2xl border border-zinc-200 bg-white p-3">
        <div className="flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() =>
              setSelectedDateKey((prev) => shiftDateKeyByDays(prev, -stepDays))
            }
            aria-label={stepDays === 7 ? '上一週' : `往前 ${stepDays} 天`}
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-zinc-200 bg-white text-zinc-700 transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
          >
            <ChevronLeft size={18} aria-hidden="true" />
          </button>

          <div className="min-w-0 flex-1 text-center">
            <p className="text-sm font-semibold text-zinc-900 tabular-nums">
              {headerRangeLabel}
            </p>
            <p className="mt-0.5 text-xs text-zinc-500 tabular-nums">
              {parseDateKey(rangeStartKey).getFullYear()} 年 · 共{' '}
              {filteredRangeSessions.length} 堂場次
            </p>
          </div>

          <button
            type="button"
            onClick={() =>
              setSelectedDateKey((prev) => shiftDateKeyByDays(prev, stepDays))
            }
            aria-label={stepDays === 7 ? '下一週' : `往後 ${stepDays} 天`}
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-zinc-200 bg-white text-zinc-700 transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
          >
            <ChevronRight size={18} aria-hidden="true" />
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <label
            htmlFor="week-picker-date"
            className="flex min-h-[44px] min-w-[210px] flex-1 items-center gap-2 rounded-xl border border-zinc-200 bg-zinc-50/70 px-3 text-xs text-zinc-600"
          >
            <CalendarDays
              size={15}
              className="shrink-0 text-zinc-500"
              aria-hidden="true"
            />
            <span className="shrink-0 whitespace-nowrap">指定日期</span>
            <input
              id="week-picker-date"
              type="date"
              value={selectedDateKey}
              onChange={(e) => {
                if (e.target.value) {
                  setSelectedDateKey(e.target.value);
                }
              }}
              className="min-w-0 flex-1 bg-transparent text-right text-base font-medium text-zinc-900 tabular-nums focus:outline-none"
            />
          </label>

          {!isAtTodayPeriod && (
            <button
              type="button"
              onClick={() => setSelectedDateKey(todayKey)}
              className="flex min-h-[44px] shrink-0 items-center justify-center rounded-xl border border-violet-300 bg-[#F2ECFF] px-3.5 text-xs font-semibold text-zinc-900 transition-colors hover:bg-[#e8ddff] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 whitespace-nowrap"
            >
              {viewMode === 'grid' && gridDays !== 7 ? '回今天' : '回本週'}
            </button>
          )}
        </div>
      </div>

      {/* 列表 / 格狀 切換 + 格狀天數切換 */}
      <div className="space-y-2">
        <div
          role="tablist"
          aria-label="週課表檢視方式"
          className="grid grid-cols-2 gap-1 rounded-2xl border border-violet-200/80 bg-white p-1"
        >
          <button
            type="button"
            role="tab"
            aria-selected={viewMode === 'list'}
            onClick={() => setViewMode('list')}
            className={`flex min-h-[44px] items-center justify-center rounded-xl text-sm font-medium transition-colors ${
              viewMode === 'list'
                ? 'bg-[#CDB8FF] font-semibold text-zinc-900'
                : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            列表
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={viewMode === 'grid'}
            onClick={() => setViewMode('grid')}
            className={`flex min-h-[44px] items-center justify-center rounded-xl text-sm font-medium transition-colors ${
              viewMode === 'grid'
                ? 'bg-[#CDB8FF] font-semibold text-zinc-900'
                : 'text-zinc-600 hover:text-zinc-900'
            }`}
          >
            格狀
          </button>
        </div>

        {viewMode === 'grid' && (
          <div
            role="tablist"
            aria-label="格狀圖顯示天數"
            className="grid grid-cols-3 gap-1 rounded-2xl border border-zinc-200 bg-white p-1"
          >
            {GRID_DAYS_OPTIONS.map((opt) => {
              const active = gridDays === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => {
                    void saveWeekGridDaysSetting(opt.value);
                  }}
                  className={`flex min-h-[40px] items-center justify-center rounded-xl text-xs font-medium transition-colors ${
                    active
                      ? 'bg-[#EDE6FF] font-semibold text-zinc-900'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 依單位篩選 */}
      {(organizations ?? []).length > 0 && (
        <div
          role="tablist"
          aria-label="依單位篩選"
          className="flex items-center gap-1.5 overflow-x-auto pb-0.5"
        >
          <button
            type="button"
            role="tab"
            aria-selected={selectedOrgId === 'all'}
            onClick={() => setSelectedOrgId('all')}
            className={`flex min-h-[44px] shrink-0 items-center justify-center rounded-xl border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap ${
              selectedOrgId === 'all'
                ? 'border-violet-600 bg-[#CDB8FF] font-semibold text-zinc-900'
                : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
            }`}
          >
            全部單位
          </button>
          {(organizations ?? []).map((org) => {
            const active = selectedOrgId === org.id;
            return (
              <button
                key={org.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setSelectedOrgId(org.id)}
                className={`flex min-h-[44px] shrink-0 items-center justify-center gap-2 rounded-xl border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'border-violet-600 bg-[#CDB8FF] font-semibold text-zinc-900'
                    : 'border-zinc-200 bg-white text-zinc-700 hover:bg-zinc-50'
                }`}
              >
                <span
                  aria-hidden="true"
                  style={{ backgroundColor: org.color }}
                  className="h-3 w-3 shrink-0 rounded-sm ring-1 ring-inset ring-black/15"
                />
                <span>{org.name}</span>
              </button>
            );
          })}
        </div>
      )}

      {isLoading ? (
        <div className="rounded-2xl border border-zinc-200 bg-white p-8 text-center text-sm text-zinc-500">
          載入中…
        </div>
      ) : viewMode === 'grid' ? (
        <WeekScheduleGrid
          daysCount={gridDays}
          displayDates={displayDates}
          sessions={filteredRangeSessions}
          courseMap={courseMap}
          orgMap={orgMap}
          tasksBySessionId={placement.tasksBySessionId}
          otherTasksByDate={filteredOtherTasksByDate}
          homeworksByCourseDate={homeworksByCourseDate}
          examsByCourseDate={examsByCourseDate}
          examPeriods={filteredExamPeriods}
          countdownBySessionId={countdownBySessionId}
          onSelectSession={(session) => {
            setGridSheetUnattachedDate(null);
            setGridSheetSessionId(session.id);
          }}
          onSelectExamPeriod={(period) => {
            setEditingExamPeriod(period);
            setExamFormOpen(true);
          }}
          onOpenSessionMenu={openSessionMenu}
          onSwitchToDayView={(dateKey) => {
            setSelectedDateKey(dateKey);
            void saveWeekGridDaysSetting(1);
          }}
          onOpenUnattachedDate={(dateKey) => {
            setGridSheetSessionId(null);
            setGridSheetUnattachedDate(dateKey);
          }}
        />
      ) : dayGroups.length === 0 ? (
        <div className="rounded-2xl border border-zinc-200 bg-white px-5 py-8 text-center">
          <p className="text-sm font-medium text-zinc-800">本週沒有場次</p>
          <p className="mt-1 text-xs text-zinc-500">
            {selectedOrgId !== 'all'
              ? '目前篩選的單位在本週沒有排定課程，可切回「全部單位」或切換上下週查看。'
              : '可切換上下週查看其他日期，或至「課程」頁新增場次。'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {dayGroups.map(
            ({
              date,
              dateKey,
              sessions: daySessions,
              exams: dayExams,
              homeworksDue,
              otherTasks,
              subjectExamPeriods,
            }) => {
              const isToday = dateKey === todayKey;
              return (
                <div
                  key={dateKey}
                  className={`overflow-hidden rounded-2xl border bg-white ${
                    isToday ? 'border-violet-300' : 'border-zinc-200'
                  }`}
                >
                  <div
                    className={`flex items-center justify-between border-b px-4 py-2.5 ${
                      isToday
                        ? 'border-violet-200/80 bg-[#F2ECFF]/70'
                        : 'border-zinc-100 bg-zinc-50/70'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <h2 className="text-sm font-semibold text-zinc-900 tabular-nums">
                        {formatSlashDate(dateKey)} {WEEKDAY_LABELS[date.getDay()]}
                      </h2>
                      {isToday && (
                        <span className="text-xs font-semibold text-violet-700">
                          · 今天
                        </span>
                      )}
                    </div>
                    <span className="text-xs font-medium text-zinc-500 tabular-nums">
                      {daySessions.length} 堂
                    </span>
                  </div>

                  {subjectExamPeriods.length > 0 && (
                    <div className="space-y-1 border-b border-pink-100 bg-[#FFF5F9] px-4 py-2">
                      {subjectExamPeriods.map((period) => {
                        const org = period.organizationId
                          ? orgMap.get(period.organizationId)
                          : undefined;
                        const displayTitle = getExamDisplayTitle(
                          period,
                          organizations ?? []
                        );
                        return (
                          <div
                            key={period.id}
                            className="flex items-center gap-2 text-xs font-semibold text-pink-950"
                          >
                            <CalendarRange
                              size={14}
                              className="shrink-0 text-pink-700"
                              aria-hidden="true"
                            />
                            <span className="min-w-0 flex-1 truncate">
                              今天考理化：{org ? `${org.name} ` : ''}
                              {displayTitle}
                              {period.subjectNote
                                ? `（${period.subjectNote}）`
                                : ''}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {daySessions.length > 0 && (
                    <div className="divide-y divide-zinc-100">
                      {daySessions.map((session) => {
                        const resolved = resolveSessionDisplay(
                          session,
                          courseMap,
                          orgMap
                        );
                        const isCancelled = isSessionCancelled(session);
                        const linkedCancelled = session.makeupForSessionId
                          ? sessionMap.get(session.makeupForSessionId)
                          : undefined;
                        const kindLabel =
                          session.kind === 'makeup'
                            ? linkedCancelled
                              ? `補課（補 ${formatSlashDate(linkedCancelled.date)}）`
                              : '補課'
                            : session.kind === 'extra'
                              ? '加課'
                              : null;

                        const sessionTaskEntries = !isCancelled
                          ? (placement.tasksBySessionId[session.id] ?? [])
                          : [];

                        const courseDateKey =
                          !isCancelled &&
                          !isSubstituteSession(session) &&
                          session.courseId
                            ? `${session.courseId}__${session.date}`
                            : '';
                        const sessionCourseHomeworks = courseDateKey
                          ? (homeworksByCourseDate.get(courseDateKey) ?? [])
                          : [];
                        const sessionCourseExams = courseDateKey
                          ? (examsByCourseDate.get(courseDateKey) ?? [])
                          : [];
                        const countdown = !isCancelled
                          ? countdownBySessionId[session.id]
                          : undefined;
                        const hasExtras =
                          !isCancelled &&
                          (Boolean(countdown) ||
                            sessionTaskEntries.length > 0 ||
                            sessionCourseHomeworks.length > 0 ||
                            sessionCourseExams.length > 0);

                        return (
                          <div
                            key={session.id}
                            className={isCancelled ? 'bg-zinc-50/50' : ''}
                          >
                            <div className="flex min-h-[64px] w-full items-center gap-1">
                              <button
                                type="button"
                                onClick={() => setActiveSessionId(session.id)}
                                className="min-w-0 flex-1 py-3 pl-4 pr-1 text-left transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-violet-600"
                              >
                                <div className="flex items-center gap-2">
                                  <span
                                    aria-hidden="true"
                                    style={{ backgroundColor: resolved.color }}
                                    className={`h-3.5 w-3.5 shrink-0 rounded-sm ring-1 ring-inset ring-black/15 ${
                                      isCancelled ? 'opacity-45' : ''
                                    }`}
                                  />
                                  <span
                                    className={`truncate text-base font-semibold ${
                                      isCancelled
                                        ? 'text-zinc-400 line-through'
                                        : 'text-zinc-900'
                                    }`}
                                  >
                                    {resolved.title}
                                  </span>
                                </div>

                                <div className="mt-0.5 flex flex-wrap items-center gap-1.5 pl-[22px] text-xs text-zinc-500">
                                  <span>{resolved.orgName}</span>
                                  {resolved.isSubstitute && <SubstituteBadge />}
                                  {resolved.substituteFor && (
                                    <span
                                      className={
                                        isCancelled
                                          ? 'text-zinc-400'
                                          : 'text-zinc-700'
                                      }
                                    >
                                      （代 {resolved.substituteFor}）
                                    </span>
                                  )}
                                </div>

                                <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 pl-[22px] text-xs tabular-nums">
                                  <span
                                    className={`font-medium ${
                                      isCancelled
                                        ? 'text-zinc-400 line-through'
                                        : 'text-zinc-800'
                                    }`}
                                  >
                                    {session.startTime}–{session.endTime}
                                  </span>

                                  {session.periodLabel && (
                                    <>
                                      <span
                                        aria-hidden="true"
                                        className="text-zinc-300"
                                      >
                                        ·
                                      </span>
                                      <span
                                        className={
                                          isCancelled
                                            ? 'text-zinc-400'
                                            : 'text-zinc-500'
                                        }
                                      >
                                        {session.periodLabel}
                                      </span>
                                    </>
                                  )}

                                  {isCancelled && (
                                    <>
                                      <CancelledBadge />
                                      {session.cancelReason && (
                                        <span className="text-zinc-500">
                                          {session.cancelReason}
                                        </span>
                                      )}
                                    </>
                                  )}

                                  {kindLabel && (
                                    <>
                                      <span
                                        aria-hidden="true"
                                        className="text-zinc-300"
                                      >
                                        ·
                                      </span>
                                      <span
                                        className={`font-medium ${
                                          isCancelled
                                            ? 'text-zinc-400'
                                            : 'text-violet-700'
                                        }`}
                                      >
                                        {kindLabel}
                                      </span>
                                    </>
                                  )}

                                  {session.originalDate &&
                                    session.originalStartTime && (
                                      <>
                                        <span
                                          aria-hidden="true"
                                          className="text-zinc-300"
                                        >
                                          ·
                                        </span>
                                        <span
                                          className={`font-medium ${
                                            isCancelled
                                              ? 'text-zinc-400'
                                              : 'text-violet-700'
                                          }`}
                                        >
                                          調課（原定{' '}
                                          {formatSlashDate(session.originalDate)}{' '}
                                          {session.originalStartTime}）
                                        </span>
                                      </>
                                    )}
                                </div>

                                {!isCancelled && session.progress?.trim() && (
                                  <p className="mt-1 pl-[22px] text-xs text-zinc-700">
                                    進度：{session.progress.trim()}
                                  </p>
                                )}
                              </button>

                              <SessionMenuButton
                                onClick={() => openSessionMenu(session)}
                                ariaLabel={`更多操作：${resolved.title}`}
                                className="mr-1.5"
                              />
                            </div>

                            {hasExtras && (
                              <div className="space-y-1 border-t border-zinc-100 bg-zinc-50/40 px-3 py-2 pl-8">
                                {countdown && (
                                  <div
                                    className={`flex min-h-[28px] items-center gap-2 rounded-lg px-2.5 py-1 text-xs tabular-nums ${
                                      countdown.isLast
                                        ? 'bg-[#FCE7F3] font-semibold text-pink-900'
                                        : 'bg-[#FFEDD5] font-medium text-orange-950'
                                    }`}
                                  >
                                    <CalendarRange
                                      size={14}
                                      className={`shrink-0 ${
                                        countdown.isLast
                                          ? 'text-pink-700'
                                          : 'text-orange-700'
                                      }`}
                                      aria-hidden="true"
                                    />
                                    <span className="truncate">
                                      {countdown.isLast
                                        ? `考前最後一堂 · ${countdown.title} ${formatSlashDate(
                                            countdown.targetDate
                                          )}`
                                        : `${countdown.title}倒數 ${countdown.sessionsLeft} 堂 · ${countdown.daysLeft} 天`}
                                    </span>
                                  </div>
                                )}

                                {sessionTaskEntries.map((entry) => (
                                  <TaskRowItem
                                    key={entry.task.id}
                                    task={entry.task}
                                    compact
                                    onEdit={handleEditTask}
                                  />
                                ))}

                                {sessionCourseHomeworks.map((hw) => (
                                  <div
                                    key={hw.id}
                                    className="flex min-h-[28px] items-center gap-2 px-2.5 text-xs text-emerald-900"
                                  >
                                    <BookOpen
                                      size={14}
                                      className="shrink-0 text-emerald-700"
                                      aria-hidden="true"
                                    />
                                    <span className="truncate font-medium">
                                      {hw.title}（{formatSlashDate(dateKey)} 繳交）
                                    </span>
                                  </div>
                                ))}

                                {sessionCourseExams.map((exam) => (
                                  <div
                                    key={exam.id}
                                    className="flex min-h-[28px] items-center gap-2 px-2.5 text-xs text-pink-900 tabular-nums"
                                  >
                                    <ClipboardCheck
                                      size={14}
                                      className="shrink-0 text-pink-700"
                                      aria-hidden="true"
                                    />
                                    <span className="truncate font-medium">
                                      考試：{exam.title}
                                      {exam.time ? ` · ${exam.time}` : ''}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* 當天底下：考試與作業繳交日 + 其他任務 */}
                  <div className="space-y-1.5 border-t border-zinc-100 bg-zinc-50/50 px-4 py-2.5 text-xs">
                    {otherTasks.length > 0 && (
                      <div className="space-y-0.5 rounded-xl border border-zinc-200/80 bg-white px-2 py-1">
                        <p className="px-2 pt-1 text-[11px] font-semibold text-zinc-500">
                          當日其他任務（沒掛在課堂）
                        </p>
                        {otherTasks.map((t) => (
                          <TaskRowItem
                            key={t.id}
                            task={t}
                            compact
                            onEdit={handleEditTask}
                          />
                        ))}
                      </div>
                    )}

                    {dayExams.length === 0 && homeworksDue.length === 0 ? (
                      otherTasks.length === 0 && (
                        <span className="text-zinc-400">
                          考試與作業繳交日：當日無紀錄
                        </span>
                      )
                    ) : (
                      <>
                        {dayExams.map((exam) => {
                          const course = courseMap.get(exam.courseId);
                          return (
                            <p
                              key={exam.id}
                              className="font-medium text-violet-900 tabular-nums"
                            >
                              考試：{course ? `${course.name} · ` : ''}
                              {exam.title}
                              {exam.examType ? `（${exam.examType}）` : ''}
                              {exam.time ? ` · ${exam.time}` : ''}
                            </p>
                          );
                        })}
                        {homeworksDue.map((hw) => {
                          const course = courseMap.get(hw.courseId);
                          const statusLabel =
                            HOMEWORK_STATUS_OPTIONS.find(
                              (opt) => opt.value === hw.status
                            )?.label ?? hw.status;
                          return (
                            <p key={hw.id} className="font-medium text-zinc-800">
                              作業繳交：{course ? `${course.name} · ` : ''}
                              {hw.title}（{statusLabel}）
                            </p>
                          );
                        })}
                      </>
                    )}
                  </div>
                </div>
              );
            }
          )}
        </div>
      )}

      <AddSessionFabMenu
        onSelectRegular={() => {
          setCreateMode('regular');
          setCreateModalOpen(true);
        }}
        onSelectSubstitute={() => {
          setCreateMode('substitute');
          setCreateModalOpen(true);
        }}
      />

      <SessionFormModal
        open={createModalOpen}
        session={null}
        courses={courses ?? []}
        organizations={organizations ?? []}
        defaultMode={createMode}
        defaultDate={defaultCreateDate}
        onClose={() => setCreateModalOpen(false)}
      />

      <WeekGridDetailSheet
        session={gridSheetSession}
        unattachedDate={gridSheetUnattachedDate}
        courseMap={courseMap}
        orgMap={orgMap}
        sessionTasks={
          gridSheetSession
            ? (placement.tasksBySessionId[gridSheetSession.id] ?? [])
            : []
        }
        unattachedTasks={
          gridSheetUnattachedDate
            ? (filteredOtherTasksByDate[gridSheetUnattachedDate] ?? [])
            : []
        }
        dayCourseHomeworks={gridSheetHomeworks}
        dayCourseExams={gridSheetExams}
        countdown={
          gridSheetSession && !isSessionCancelled(gridSheetSession)
            ? countdownBySessionId[gridSheetSession.id]
            : undefined
        }
        activeExamPeriods={gridSheetActiveExamPeriods}
        onClose={() => {
          setGridSheetSessionId(null);
          setGridSheetUnattachedDate(null);
        }}
        onOpenFullSession={(session) => setActiveSessionId(session.id)}
        onOpenSessionMenu={openSessionMenu}
        onAddTaskForSession={handleOpenNewTaskForSession}
        onAddTaskForDate={handleOpenNewTaskForDate}
        onEditTask={handleEditTask}
      />

      <TaskFormModal
        open={taskModalOpen}
        task={editingTask}
        courses={courses ?? []}
        sessions={sessions ?? []}
        organizations={organizations ?? []}
        defaultCourseId={taskDefaultCourseId}
        defaultSessionId={taskDefaultSessionId}
        defaultDate={taskDefaultDate}
        onClose={() => setTaskModalOpen(false)}
      />

      <SessionDetailModal
        session={activeSession}
        course={activeResolved?.course}
        organization={activeResolved?.organization}
        allCourses={courses ?? []}
        allOrganizations={organizations ?? []}
        onClose={() => setActiveSessionId(null)}
      />

      <SessionQuickActionsHost {...quickActionsProps} />

      <ExamPeriodFormModal
        open={examFormOpen}
        examPeriod={editingExamPeriod}
        organizations={organizations ?? []}
        courses={courses ?? []}
        academicYears={academicYears ?? []}
        onClose={() => setExamFormOpen(false)}
      />
    </section>
  );
}
