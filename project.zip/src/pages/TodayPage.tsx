import {
  AlertTriangle,
  ArrowRight,
  BookOpen,
  CalendarClock,
  CalendarRange,
  ClipboardCheck,
  Plus,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import { AddSessionFabMenu } from '../components/AddSessionFabMenu';
import { ExamPeriodsModal } from '../components/ExamPeriodsModal';
import { SessionDetailModal } from '../components/SessionDetailModal';
import {
  SessionFormModal,
  type SessionFormMode,
} from '../components/SessionFormModal';
import {
  CancelledBadge,
  SessionMenuButton,
  SessionQuickActionsHost,
  useSessionQuickActions,
} from '../components/SessionQuickActions';
import { SubstituteBadge } from '../components/SubstituteBadge';
import { TaskFormModal } from '../components/TaskFormModal';
import { TaskRowItem } from '../components/TaskRowItem';
import { db } from '../db/database';
import type {
  ClassSession,
  Course,
  Exam,
  Homework,
  Organization,
  TaskItem,
} from '../db/types';
import { useBackupStatus } from '../utils/backupStore';
import {
  doTimeRangesOverlap,
  formatSlashDate,
  formatSlashDateWithWeekday,
  formatTimestamp,
  toDateKey,
} from '../utils/date';
import {
  computeSessionCountdowns,
  diffDateKeys,
  getExamDisplayTitle,
  getExamPeriodStatus,
} from '../utils/examCountdown';
import {
  isSessionCancelled,
  isSubstituteSession,
  resolveSessionDisplay,
} from '../utils/sessionDisplay';
import { getEffectiveTaskDate, placeTasks } from '../utils/taskPlacement';
import { useIsKeyboardActive } from '../utils/useKeyboardAware';
import { useLiveQuery } from '../utils/useLiveQuery';

interface TodayPageProps {
  onOpenBackup?: () => void;
}

export function TodayPage({ onOpenBackup }: TodayPageProps) {
  const { isOverdue, lastBackupAt } = useBackupStatus();
  const isKeyboardActive = useIsKeyboardActive();

  const sessions = useLiveQuery(() => db.sessions.toArray(), []);
  const courses = useLiveQuery(() => db.courses.toArray(), []);
  const organizations = useLiveQuery(() => db.organizations.toArray(), []);
  const tasks = useLiveQuery(() => db.tasks.toArray(), []);
  const homeworks = useLiveQuery(() => db.homeworks.toArray(), []);
  const exams = useLiveQuery(() => db.exams.toArray(), []);
  const examPeriods = useLiveQuery(() => db.examPeriods.toArray(), []);

  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [createMode, setCreateMode] = useState<SessionFormMode>('regular');

  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskItem | null>(null);
  const [examPeriodsModalOpen, setExamPeriodsModalOpen] = useState(false);

  const { openSessionMenu, quickActionsProps } = useSessionQuickActions({
    courses: courses ?? [],
    organizations: organizations ?? [],
    onSessionDeleted: (deletedId) => {
      if (activeSessionId === deletedId) {
        setActiveSessionId(null);
      }
    },
  });

  const now = new Date();
  const todayKey = toDateKey(now);

  const courseMap = useMemo(() => {
    const map = new Map<string, Course>();
    for (const c of courses ?? []) map.set(c.id, c);
    return map;
  }, [courses]);

  const orgMap = useMemo(() => {
    const map = new Map<string, Organization>();
    for (const o of organizations ?? []) map.set(o.id, o);
    return map;
  }, [organizations]);

  const sessionMap = useMemo(() => {
    const map = new Map<string, ClassSession>();
    for (const s of sessions ?? []) map.set(s.id, s);
    return map;
  }, [sessions]);

  const placement = useMemo(
    () =>
      placeTasks({
        tasks: tasks ?? [],
        sessions: sessions ?? [],
        now,
      }),
    [tasks, sessions, todayKey, now.getHours(), now.getMinutes()]
  );

  const countdownBySessionId = useMemo(
    () =>
      computeSessionCountdowns({
        examPeriods: examPeriods ?? [],
        sessions: sessions ?? [],
        courses: courses ?? [],
        organizations: organizations ?? [],
      }),
    [examPeriods, sessions, courses, organizations]
  );

  const upcomingExamStrip = useMemo(() => {
    const limitDate = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() + 60
    );
    const limitKey = toDateKey(limitDate);
    return (examPeriods ?? [])
      .filter((p) => p.endDate >= todayKey && p.startDate <= limitKey)
      .sort((a, b) => {
        const startDiff = a.startDate.localeCompare(b.startDate);
        if (startDiff !== 0) return startDiff;
        return a.endDate.localeCompare(b.endDate);
      })
      .slice(0, 5);
  }, [examPeriods, todayKey]);

  const todaySubjectExams = useMemo(
    () =>
      (examPeriods ?? [])
        .filter((p) => p.subjectDate === todayKey)
        .sort((a, b) => a.title.localeCompare(b.title, 'zh-Hant')),
    [examPeriods, todayKey]
  );

  const homeworksByCourseDate = useMemo(() => {
    const map = new Map<string, Homework[]>();
    for (const hw of homeworks ?? []) {
      if (!hw.dueDate) continue;
      const key = `${hw.courseId}__${hw.dueDate}`;
      const arr = map.get(key) ?? [];
      arr.push(hw);
      map.set(key, arr);
    }
    return map;
  }, [homeworks]);

  const examsByCourseDate = useMemo(() => {
    const map = new Map<string, Exam[]>();
    for (const exam of exams ?? []) {
      const key = `${exam.courseId}__${exam.date}`;
      const arr = map.get(key) ?? [];
      arr.push(exam);
      map.set(key, arr);
    }
    return map;
  }, [exams]);

  const todaySessions = useMemo(() => {
    if (!sessions) return [];
    return sessions
      .filter((s) => s.date === todayKey)
      .sort((a, b) => {
        const cancelDiff =
          Number(isSessionCancelled(a)) - Number(isSessionCancelled(b));
        if (cancelDiff !== 0) return cancelDiff;
        const startDiff = a.startTime.localeCompare(b.startTime);
        if (startDiff !== 0) return startDiff;
        const endDiff = a.endTime.localeCompare(b.endTime);
        if (endDiff !== 0) return endDiff;
        return a.createdAt - b.createdAt;
      });
  }, [sessions, todayKey]);

  const overlappingIds = useMemo(() => {
    const ids = new Set<string>();
    const active = todaySessions.filter((s) => !isSessionCancelled(s));
    for (let i = 0; i < active.length; i += 1) {
      for (let j = i + 1; j < active.length; j += 1) {
        if (
          doTimeRangesOverlap(
            active[i].startTime,
            active[i].endTime,
            active[j].startTime,
            active[j].endTime
          )
        ) {
          ids.add(active[i].id);
          ids.add(active[j].id);
        }
      }
    }
    return ids;
  }, [todaySessions]);

  const nextUpcomingSession = useMemo(() => {
    if (!sessions) return null;
    const future = sessions
      .filter((s) => s.date > todayKey && !isSessionCancelled(s))
      .sort((a, b) => {
        const dateDiff = a.date.localeCompare(b.date);
        if (dateDiff !== 0) return dateDiff;
        return a.startTime.localeCompare(b.startTime);
      });
    return future[0] ?? null;
  }, [sessions, todayKey]);

  const isLoading =
    sessions === undefined ||
    courses === undefined ||
    organizations === undefined ||
    tasks === undefined ||
    homeworks === undefined ||
    exams === undefined ||
    examPeriods === undefined;

  const activeSession = activeSessionId
    ? (sessionMap.get(activeSessionId) ?? null)
    : null;
  const activeResolved = activeSession
    ? resolveSessionDisplay(activeSession, courseMap, orgMap)
    : null;

  const todayOtherTasks = placement.otherTasksByDate[todayKey] ?? [];
  const overdueTodos = placement.overdueTodos;

  const getOverdueMeta = (task: TaskItem): string => {
    const parts: string[] = [];
    if (task.courseId) {
      const course = courseMap.get(task.courseId);
      if (course) parts.push(course.name);
    }
    const effectiveDate = getEffectiveTaskDate(
      task,
      sessionMap,
      placement.nextSessionIdByCourseId
    );
    if (effectiveDate) {
      parts.push(`原定 ${formatSlashDateWithWeekday(effectiveDate)}`);
    }
    return parts.join(' · ');
  };

  const renderSessionCard = (
    session: ClassSession,
    options?: { showDate?: boolean }
  ) => {
    const resolved = resolveSessionDisplay(session, courseMap, orgMap);
    const isCancelled = isSessionCancelled(session);
    const linkedCancelled = session.makeupForSessionId
      ? sessionMap.get(session.makeupForSessionId)
      : undefined;
    const hasOverlap = overlappingIds.has(session.id) && !isCancelled;

    const kindLabel =
      session.kind === 'makeup'
        ? linkedCancelled
          ? `補課（補 ${formatSlashDate(linkedCancelled.date)}）`
          : '補課'
        : session.kind === 'extra'
          ? '加課'
          : null;

    const sessionTaskEntries = !isCancelled
      ? (placement.tasksBySessionId[session.id] ?? [])
      : [];

    const courseDateKey =
      !isCancelled && !isSubstituteSession(session) && session.courseId
        ? `${session.courseId}__${session.date}`
        : '';
    const dueHomeworks = courseDateKey
      ? (homeworksByCourseDate.get(courseDateKey) ?? [])
      : [];
    const dayExams = courseDateKey
      ? (examsByCourseDate.get(courseDateKey) ?? [])
      : [];

    const countdown = !isCancelled ? countdownBySessionId[session.id] : undefined;

    const hasExtras =
      !isCancelled &&
      (Boolean(countdown) ||
        sessionTaskEntries.length > 0 ||
        dueHomeworks.length > 0 ||
        dayExams.length > 0);

    return (
      <div
        key={session.id}
        className={`overflow-hidden rounded-2xl border transition-colors duration-150 ${
          hasOverlap
            ? 'border-amber-300 bg-amber-50/40'
            : isCancelled
              ? 'border-zinc-200/80 bg-zinc-50/60'
              : 'border-zinc-200 bg-white'
        }`}
      >
        <div className="flex min-h-[76px] w-full items-center gap-1">
          <button
            type="button"
            onClick={() => setActiveSessionId(session.id)}
            className="min-w-0 flex-1 rounded-l-2xl py-3.5 pl-4 pr-1 text-left transition-colors hover:bg-zinc-50/80 active:bg-zinc-100/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
          >
            {/* 第一行：大字顯示課程名稱／代課班級名稱並用色塊區分 */}
            <div className="flex items-center gap-2.5">
              <span
                aria-hidden="true"
                style={{ backgroundColor: resolved.color }}
                className={`h-4 w-4 shrink-0 rounded-sm ring-1 ring-inset ring-black/15 ${
                  isCancelled ? 'opacity-45' : ''
                }`}
              />
              <span
                className={`truncate text-lg font-bold leading-snug ${
                  isCancelled ? 'text-zinc-400 line-through' : 'text-zinc-900'
                }`}
              >
                {resolved.title}
              </span>
            </div>

            {/* 第二行：小字顯示單位名稱、代課標籤與代誰的課 */}
            <div className="mt-0.5 flex flex-wrap items-center gap-1.5 pl-[26px] text-xs text-zinc-500">
              <span>{resolved.orgName}</span>
              {resolved.isSubstitute && <SubstituteBadge />}
              {resolved.substituteFor && (
                <span className={isCancelled ? 'text-zinc-400' : 'text-zinc-700'}>
                  （代 {resolved.substituteFor}）
                </span>
              )}
            </div>

            {/* 時間、取消標籤、種類、調課標記 */}
            <div className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 pl-[26px] text-xs tabular-nums">
              <span
                className={`font-medium ${
                  isCancelled ? 'text-zinc-400 line-through' : 'text-zinc-800'
                }`}
              >
                {options?.showDate
                  ? `${formatSlashDateWithWeekday(session.date)} `
                  : ''}
                {session.startTime}–{session.endTime}
              </span>

              {session.periodLabel && (
                <>
                  <span aria-hidden="true" className="text-zinc-300">
                    ·
                  </span>
                  <span className={isCancelled ? 'text-zinc-400' : 'text-zinc-500'}>
                    {session.periodLabel}
                  </span>
                </>
              )}

              {isCancelled && (
                <>
                  <CancelledBadge />
                  {session.cancelReason && (
                    <span className="text-zinc-500">{session.cancelReason}</span>
                  )}
                </>
              )}

              {kindLabel && (
                <>
                  <span aria-hidden="true" className="text-zinc-300">
                    ·
                  </span>
                  <span
                    className={`font-medium ${
                      isCancelled ? 'text-zinc-400' : 'text-violet-700'
                    }`}
                  >
                    {kindLabel}
                  </span>
                </>
              )}

              {session.originalDate && session.originalStartTime && (
                <>
                  <span aria-hidden="true" className="text-zinc-300">
                    ·
                  </span>
                  <span
                    className={`font-medium ${
                      isCancelled ? 'text-zinc-400' : 'text-violet-700'
                    }`}
                  >
                    調課（原定 {formatSlashDate(session.originalDate)}{' '}
                    {session.originalStartTime}）
                  </span>
                </>
              )}
            </div>

            {!isCancelled && session.progress?.trim() && (
              <p className="mt-1.5 pl-[26px] text-xs text-zinc-700">
                進度：{session.progress.trim()}
              </p>
            )}

            {hasOverlap && (
              <p className="mt-1 flex items-center gap-1 pl-[26px] text-xs font-medium text-amber-800">
                <AlertTriangle size={13} className="shrink-0" aria-hidden="true" />
                <span>與同時段其他場次時間重疊</span>
              </p>
            )}
          </button>

          <SessionMenuButton
            onClick={() => openSessionMenu(session)}
            ariaLabel={`更多操作：${resolved.title}`}
            className="mr-1.5"
          />
        </div>

        {hasExtras && (
          <div className="space-y-1 border-t border-zinc-100 bg-zinc-50/50 px-3 py-2 pl-7">
            {countdown && (
              <div
                className={`flex min-h-[28px] items-center gap-2 rounded-lg px-2.5 py-1 text-xs tabular-nums ${
                  countdown.isLast
                    ? 'bg-[#FCE7F3] font-semibold text-pink-900'
                    : 'bg-[#FFEDD5] font-medium text-orange-950'
                }`}
              >
                <CalendarRange
                  size={14}
                  className={`shrink-0 ${
                    countdown.isLast ? 'text-pink-700' : 'text-orange-700'
                  }`}
                  aria-hidden="true"
                />
                <span className="min-w-0 flex-1 truncate">
                  {countdown.isLast
                    ? `考前最後一堂 · ${countdown.title} ${formatSlashDate(
                        countdown.targetDate
                      )}`
                    : `${countdown.title}倒數 ${countdown.sessionsLeft} 堂 · ${countdown.daysLeft} 天`}
                </span>
                {countdown.later.length > 0 && (
                  <span className="ml-auto shrink-0 text-[11px] font-semibold opacity-80">
                    ＋{countdown.later.length}
                  </span>
                )}
              </div>
            )}

            {sessionTaskEntries.map((entry) => (
              <TaskRowItem
                key={entry.task.id}
                task={entry.task}
                compact
                onEdit={(target) => {
                  setEditingTask(target);
                  setTaskModalOpen(true);
                }}
              />
            ))}

            {dueHomeworks.map((hw) => (
              <div
                key={hw.id}
                className="flex min-h-[28px] items-center gap-2 px-2.5 text-xs text-emerald-900"
              >
                <BookOpen
                  size={14}
                  className="shrink-0 text-emerald-700"
                  aria-hidden="true"
                />
                <span className="truncate font-medium">
                  {hw.title} {session.date === todayKey ? '今天繳交' : `${formatSlashDate(session.date)} 繳交`}
                </span>
              </div>
            ))}

            {dayExams.map((exam) => (
              <div
                key={exam.id}
                className="flex min-h-[28px] items-center gap-2 px-2.5 text-xs text-pink-900 tabular-nums"
              >
                <ClipboardCheck
                  size={14}
                  className="shrink-0 text-pink-700"
                  aria-hidden="true"
                />
                <span className="truncate font-medium">
                  考試：{exam.title}
                  {exam.time ? ` · ${exam.time}` : ''}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <section aria-label="今天頁面" className="space-y-4 px-4 py-4 pb-20">
      {isOverdue && (
        <div
          role="status"
          className="flex flex-col gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-amber-950 sm:flex-row sm:items-center sm:justify-between"
        >
          <div className="flex min-w-0 items-start gap-2.5">
            <AlertTriangle
              size={18}
              className="mt-0.5 shrink-0 text-amber-700"
              aria-hidden="true"
            />
            <div className="min-w-0">
              <p className="text-sm font-semibold text-amber-950">
                距離上次備份已超過 7 天
              </p>
              <p className="mt-0.5 text-xs leading-relaxed text-amber-800">
                {lastBackupAt
                  ? `上次備份：${formatTimestamp(lastBackupAt)}。建議定期匯出備份以免資料遺失。`
                  : '尚未建立任何備份檔，建議定期匯出備份以免資料遺失。'}
              </p>
            </div>
          </div>

          {onOpenBackup && (
            <button
              type="button"
              onClick={onOpenBackup}
              className="flex min-h-[44px] shrink-0 items-center justify-center gap-1 rounded-xl bg-amber-600 px-3.5 text-xs font-semibold text-white transition-colors hover:bg-amber-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-600 focus-visible:ring-offset-2 whitespace-nowrap"
            >
              <span>前往備份</span>
              <ArrowRight size={14} aria-hidden="true" />
            </button>
          )}
        </div>
      )}

      {!isLoading && upcomingExamStrip.length > 0 && (
        <div className="space-y-1.5">
          <p className="px-1 text-xs font-semibold text-zinc-500">
            接下來的考試
          </p>
          <div className="flex items-center gap-2 overflow-x-auto pb-0.5">
            {upcomingExamStrip.map((period) => {
              const org = period.organizationId
                ? orgMap.get(period.organizationId)
                : undefined;
              const status = getExamPeriodStatus(period, todayKey);
              const daysUntilStart = Math.max(
                0,
                diffDateKeys(todayKey, period.startDate)
              );
              const rightLabel =
                status === 'ongoing' ? '進行中' : `${daysUntilStart} 天`;
              const displayTitle = getExamDisplayTitle(
                period,
                organizations ?? []
              );

              return (
                <button
                  key={period.id}
                  type="button"
                  onClick={() => setExamPeriodsModalOpen(true)}
                  className="flex min-h-[40px] shrink-0 items-center gap-2 rounded-xl border border-zinc-200 bg-white px-3 py-1.5 text-left transition-colors hover:bg-zinc-50 active:bg-zinc-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600"
                >
                  <span
                    aria-hidden="true"
                    style={{ backgroundColor: org?.color ?? '#CDB8FF' }}
                    className="h-2.5 w-2.5 shrink-0 rounded-full ring-1 ring-inset ring-black/15"
                  />
                  <span className="max-w-[160px] truncate text-xs font-semibold text-zinc-900">
                    {org ? `${org.name} ${displayTitle}` : displayTitle}
                  </span>
                  <span
                    className={`shrink-0 rounded-md px-1.5 py-0.5 text-[11px] font-semibold tabular-nums ${
                      status === 'ongoing'
                        ? 'bg-[#FCE7F3] text-pink-900'
                        : 'bg-[#EDE6FF] text-violet-950'
                    }`}
                  >
                    {rightLabel}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {!isLoading && todaySubjectExams.length > 0 && (
        <div className="space-y-1.5">
          {todaySubjectExams.map((period) => {
            const org = period.organizationId
              ? orgMap.get(period.organizationId)
              : undefined;
            const displayTitle = getExamDisplayTitle(
              period,
              organizations ?? []
            );
            return (
              <div
                key={period.id}
                className="flex items-center gap-2 rounded-2xl border border-pink-200 bg-[#FFF5F9] px-3.5 py-2.5 text-xs font-semibold text-pink-950"
              >
                <CalendarRange
                  size={15}
                  className="shrink-0 text-pink-700"
                  aria-hidden="true"
                />
                <span className="min-w-0 flex-1 truncate">
                  今天考理化：{org ? `${org.name} ` : ''}
                  {displayTitle}
                  {period.subjectNote ? `（${period.subjectNote}）` : ''}
                </span>
              </div>
            );
          })}
        </div>
      )}

      {isLoading ? (
        <div className="rounded-2xl border border-zinc-200 bg-white p-8 text-center text-sm text-zinc-500">
          載入中…
        </div>
      ) : todaySessions.length === 0 ? (
        <div className="space-y-4">
          <div className="rounded-2xl border border-zinc-200 bg-white px-5 py-8 text-center">
            <CalendarClock
              size={24}
              className="mx-auto text-zinc-400"
              aria-hidden="true"
            />
            <h2 className="mt-2.5 text-base font-semibold text-zinc-900">
              今天沒有課
            </h2>
            <p className="mt-1 text-xs text-zinc-500">
              今天沒有排定的課程場次，可查看下方最近的下一堂課。
            </p>
          </div>

          <div className="space-y-2">
            <h3 className="px-1 text-xs font-semibold text-zinc-500">
              最近的下一堂
            </h3>
            {nextUpcomingSession ? (
              renderSessionCard(nextUpcomingSession, { showDate: true })
            ) : (
              <div className="rounded-2xl border border-zinc-200 bg-white px-4 py-5 text-center text-sm text-zinc-500">
                目前尚未排定後續課程場次。
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-2.5">
          <p className="px-1 text-xs font-medium text-zinc-500 tabular-nums">
            今日共 {todaySessions.length} 堂場次
          </p>
          <div className="space-y-2.5">
            {todaySessions.map((session) => renderSessionCard(session))}
          </div>
        </div>
      )}

      {/* 今天的其他任務（沒掛在課堂） */}
      {!isLoading && todayOtherTasks.length > 0 && (
        <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white">
          <div className="flex items-center justify-between border-b border-zinc-100 bg-zinc-50/70 px-4 py-2.5">
            <div className="flex items-center gap-2">
              <h2 className="text-xs font-semibold text-zinc-900">
                今天的其他任務
              </h2>
              <span className="text-[11px] text-zinc-500">沒掛在課堂</span>
            </div>
            <span className="text-xs font-medium text-zinc-500 tabular-nums">
              {todayOtherTasks.length} 筆
            </span>
          </div>
          <div className="divide-y divide-zinc-100 px-2 py-1">
            {todayOtherTasks.map((task) => (
              <TaskRowItem
                key={task.id}
                task={task}
                onEdit={(target) => {
                  setEditingTask(target);
                  setTaskModalOpen(true);
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* 逾期未完成待辦（溫和淡粉紅區塊） */}
      {!isLoading && overdueTodos.length > 0 && (
        <div className="overflow-hidden rounded-2xl border border-rose-200/90 bg-[#FFF5F7]">
          <div className="flex items-center justify-between border-b border-rose-200/70 bg-rose-100/45 px-4 py-2.5">
            <h2 className="text-xs font-semibold text-rose-900">逾期</h2>
            <span className="text-xs font-medium text-rose-700 tabular-nums">
              {overdueTodos.length} 筆待辦
            </span>
          </div>
          <div className="divide-y divide-rose-200/60 px-2 py-1">
            {overdueTodos.map((task) => (
              <TaskRowItem
                key={task.id}
                task={task}
                metaText={getOverdueMeta(task)}
                onEdit={(target) => {
                  setEditingTask(target);
                  setTaskModalOpen(true);
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* 右下角快速新增按鈕區：「＋任務」與「＋」場次按鈕 */}
      {!isKeyboardActive && (
        <div className="pointer-events-none fixed inset-x-0 bottom-[calc(var(--bottom-nav-height)+env(safe-area-inset-bottom)+1rem)] z-20">
          <div className="mx-auto flex w-full max-w-2xl justify-end px-4 pr-[5.25rem]">
            <button
              type="button"
              onClick={() => {
                setEditingTask(null);
                setTaskModalOpen(true);
              }}
              className="pointer-events-auto flex h-14 items-center gap-1.5 rounded-2xl border border-violet-300 bg-[#EDE6FF] px-4 text-sm font-semibold text-zinc-900 shadow-lg transition-transform duration-150 hover:bg-[#e1d5ff] active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-600 focus-visible:ring-offset-2 whitespace-nowrap"
            >
              <Plus size={18} strokeWidth={2.25} aria-hidden="true" />
              <span>任務</span>
            </button>
          </div>
        </div>
      )}

      <AddSessionFabMenu
        onSelectRegular={() => {
          setCreateMode('regular');
          setCreateModalOpen(true);
        }}
        onSelectSubstitute={() => {
          setCreateMode('substitute');
          setCreateModalOpen(true);
        }}
      />

      <SessionFormModal
        open={createModalOpen}
        session={null}
        courses={courses ?? []}
        organizations={organizations ?? []}
        defaultMode={createMode}
        defaultDate={todayKey}
        onClose={() => setCreateModalOpen(false)}
      />

      <TaskFormModal
        open={taskModalOpen}
        task={editingTask}
        courses={courses ?? []}
        sessions={sessions ?? []}
        organizations={organizations ?? []}
        defaultDate={todayKey}
        onClose={() => setTaskModalOpen(false)}
      />

      <SessionDetailModal
        session={activeSession}
        course={activeResolved?.course}
        organization={activeResolved?.organization}
        allCourses={courses ?? []}
        allOrganizations={organizations ?? []}
        onClose={() => setActiveSessionId(null)}
      />

      <SessionQuickActionsHost {...quickActionsProps} />

      <ExamPeriodsModal
        open={examPeriodsModalOpen}
        onClose={() => setExamPeriodsModalOpen(false)}
      />
    </section>
  );
}
