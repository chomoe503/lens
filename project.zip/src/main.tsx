import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import {startNativeBackHandler} from './utils/nativeBack.ts';
import {isNativeApp} from './utils/platform.ts';
import {initPWAInstallListener} from './utils/pwaInstallStore.ts';
import {startWidgetSync} from './utils/widgetSync.ts';

if (!isNativeApp) {
  initPWAInstallListener();
} else {
  startNativeBackHandler();
}

startWidgetSync();

createRoot(document.getElementById('root')!).render(<App />);
