/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useMemo, useState } from 'react';
import { BottomNav } from './components/BottomNav';
import { CourseDetailModal, type CourseTabId } from './components/CourseDetailModal';
import { CourseFormModal } from './components/CourseFormModal';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { OrganizationFormModal } from './components/OrganizationFormModal';
import { PWAUpdateBanner } from './components/PWAUpdateBanner';
import { SessionDetailModal } from './components/SessionDetailModal';
import { TopBar } from './components/TopBar';
import { UndoBanner } from './components/UndoBanner';
import { db } from './db/database';
import { ensureInitialData } from './db/repositories';
import type {
  AcademicYear,
  ClassSession,
  Course,
  NavTabId,
  Organization,
} from './db/types';
import { CoursesPage } from './pages/CoursesPage';
import { MorePage } from './pages/MorePage';
import { TodayPage } from './pages/TodayPage';
import { WeekSchedulePage } from './pages/WeekSchedulePage';
import { initBackupTracking, refreshBackupStatus } from './utils/backupStore';
import type { SearchResultItem } from './utils/search';
import { resolveSessionDisplay } from './utils/sessionDisplay';
import { requestPersistentStorage } from './utils/storage';
import {
  navigateToTab,
  parseTabFromLocation,
  useBackNavigationHost,
  useExitPromptVisible,
} from './utils/backNavigation';
import { useKeyboardCoordinator } from './utils/useKeyboardAware';
import { useLiveQuery } from './utils/useLiveQuery';
import { usePWAUpdate } from './utils/usePWAUpdate';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTabId>(() => parseTabFromLocation());
  const [searchOpen, setSearchOpen] = useState(false);

  const [searchSessionId, setSearchSessionId] = useState<string | null>(null);
  const [searchCourseTarget, setSearchCourseTarget] = useState<{
    courseId: string;
    initialTab: CourseTabId;
    highlightItemId?: string;
  } | null>(null);
  const [editingCourseFromSearch, setEditingCourseFromSearch] =
    useState<Course | null>(null);
  const [orgModalFromSearchOpen, setOrgModalFromSearchOpen] = useState(false);

  const { needRefresh, applyUpdate } = usePWAUpdate();
  const isKeyboardActive = useKeyboardCoordinator();
  const exitPromptVisible = useExitPromptVisible();
  useBackNavigationHost(activeTab, setActiveTab);

  const needSearchLookup =
    searchOpen || searchSessionId !== null || searchCourseTarget !== null;

  const allCourses = useLiveQuery(
    async (): Promise<Course[]> =>
      needSearchLookup ? db.courses.toArray() : [],
    [needSearchLookup]
  );
  const allOrganizations = useLiveQuery(
    async (): Promise<Organization[]> =>
      needSearchLookup ? db.organizations.toArray() : [],
    [needSearchLookup]
  );
  const allAcademicYears = useLiveQuery(
    async (): Promise<AcademicYear[]> =>
      needSearchLookup ? db.academicYears.toArray() : [],
    [needSearchLookup]
  );
  const activeSearchSession = useLiveQuery(
    async (): Promise<ClassSession | null> => {
      if (!searchSessionId) return null;
      return (await db.sessions.get(searchSessionId)) ?? null;
    },
    [searchSessionId]
  );

  useEffect(() => {
    void requestPersistentStorage();
    void ensureInitialData();
    initBackupTracking();

    const handleRefresh = () => {
      if (document.visibilityState !== 'hidden') {
        refreshBackupStatus();
      }
    };

    window.addEventListener('focus', handleRefresh);
    document.addEventListener('visibilitychange', handleRefresh);
    return () => {
      window.removeEventListener('focus', handleRefresh);
      document.removeEventListener('visibilitychange', handleRefresh);
    };
  }, []);

  const courseMap = useMemo(
    () => new Map((allCourses ?? []).map((c) => [c.id, c])),
    [allCourses]
  );
  const orgMap = useMemo(
    () => new Map((allOrganizations ?? []).map((o) => [o.id, o])),
    [allOrganizations]
  );
  const yearMap = useMemo(
    () => new Map((allAcademicYears ?? []).map((y) => [y.id, y])),
    [allAcademicYears]
  );

  const handleSelectSearchResult = (item: SearchResultItem) => {
    if (item.type === 'session') {
      setSearchSessionId(item.id);
      return;
    }
    if (item.type === 'course') {
      setSearchCourseTarget({
        courseId: item.id,
        initialTab: 'history',
      });
      return;
    }
    if (item.type === 'exam' && item.courseId) {
      setSearchCourseTarget({
        courseId: item.courseId,
        initialTab: 'exams',
        highlightItemId: item.id,
      });
      return;
    }
    if (item.type === 'homework' && item.courseId) {
      setSearchCourseTarget({
        courseId: item.courseId,
        initialTab: 'homeworks',
        highlightItemId: item.id,
      });
    }
  };

  const searchSessionResolved = activeSearchSession
    ? resolveSessionDisplay(activeSearchSession, courseMap, orgMap)
    : null;
  const searchSessionCourse = searchSessionResolved?.course;
  const searchSessionOrg = searchSessionResolved?.organization;

  const targetCourse = searchCourseTarget
    ? (courseMap.get(searchCourseTarget.courseId) ?? null)
    : null;

  const renderPage = () => {
    switch (activeTab) {
      case 'today':
        return <TodayPage onOpenBackup={() => navigateToTab('more')} />;
      case 'week':
        return <WeekSchedulePage />;
      case 'courses':
        return <CoursesPage />;
      case 'more':
        return <MorePage />;
    }
  };

  return (
    <div className="min-h-dvh bg-[var(--bg-canvas)] text-zinc-900">
      <TopBar activeTab={activeTab} onOpenSearch={() => setSearchOpen(true)} />

      <main className="mx-auto w-full max-w-2xl pb-[calc(var(--bottom-nav-height)+env(safe-area-inset-bottom)+1rem)]">
        {renderPage()}
      </main>

      <GlobalSearchModal
        open={searchOpen}
        onClose={() => {
          setSearchOpen(false);
          setSearchSessionId(null);
          setSearchCourseTarget(null);
        }}
        onSelectResult={handleSelectSearchResult}
      />

      <SessionDetailModal
        session={activeSearchSession ?? null}
        course={searchSessionCourse}
        organization={searchSessionOrg}
        allCourses={allCourses ?? []}
        allOrganizations={allOrganizations ?? []}
        onClose={() => setSearchSessionId(null)}
      />

      <CourseDetailModal
        open={targetCourse !== null}
        course={targetCourse}
        organization={
          targetCourse ? orgMap.get(targetCourse.organizationId) : undefined
        }
        academicYear={
          targetCourse ? yearMap.get(targetCourse.academicYearId) : undefined
        }
        allCourses={allCourses ?? []}
        allOrganizations={allOrganizations ?? []}
        initialTab={searchCourseTarget?.initialTab ?? 'history'}
        highlightItemId={searchCourseTarget?.highlightItemId ?? null}
        onClose={() => setSearchCourseTarget(null)}
        onEditCourse={(c) => setEditingCourseFromSearch(c)}
      />

      <CourseFormModal
        open={editingCourseFromSearch !== null}
        course={editingCourseFromSearch}
        academicYears={allAcademicYears ?? []}
        organizations={allOrganizations ?? []}
        defaultAcademicYearId={editingCourseFromSearch?.academicYearId ?? ''}
        onClose={() => setEditingCourseFromSearch(null)}
        onOpenNewOrganization={() => setOrgModalFromSearchOpen(true)}
      />

      <OrganizationFormModal
        open={orgModalFromSearchOpen}
        organization={null}
        onClose={() => setOrgModalFromSearchOpen(false)}
      />

      {exitPromptVisible && (
        <div
          role="status"
          aria-live="polite"
          className="pointer-events-none fixed inset-x-0 bottom-[calc(var(--bottom-nav-height)+env(safe-area-inset-bottom)+1rem)] z-[90] flex justify-center px-4"
        >
          <div className="rounded-xl bg-zinc-900/92 px-4 py-2.5 text-sm font-medium text-white shadow-lg">
            再按一次返回鍵離開
          </div>
        </div>
      )}

      {!isKeyboardActive && (
        <>
          <PWAUpdateBanner visible={needRefresh} onUpdate={applyUpdate} />
          <UndoBanner />
        </>
      )}
      <BottomNav
        activeTab={activeTab}
        onSelectTab={navigateToTab}
        hidden={isKeyboardActive || searchOpen}
      />
    </div>
  );
}
