import { getCurrentTaiwanAcademicYearTemplate } from '../utils/academicYear';
import { doTimeRangesOverlap } from '../utils/date';
import { createId } from '../utils/id';
import { isSessionCancelled } from '../utils/sessionDisplay';
import { db } from './database';
import type {
  AcademicYear,
  ClassSession,
  Course,
  Organization,
  Period,
  SessionBatch,
  StoredImage,
  TaskItem,
  WeekGridDays,
} from './types';

let initPromise: Promise<void> | null = null;

export interface DeletedBackupPayload {
  sessions: ClassSession[];
  batches: SessionBatch[];
  images: StoredImage[];
}

/**
 * 首次開啟（尚無任何學年時）自動建立目前民國學年度。
 * 不會建立任何範例單位或範例課程。
 */
export async function ensureInitialData(): Promise<void> {
  if (initPromise) {
    return initPromise;
  }

  initPromise = (async () => {
    const yearCount = await db.academicYears.count();
    if (yearCount > 0) {
      return;
    }

    const now = Date.now();
    const tpl = getCurrentTaiwanAcademicYearTemplate(new Date(now));
    const currentYear: AcademicYear = {
      id: createId(),
      name: tpl.name,
      startDate: tpl.startDate,
      endDate: tpl.endDate,
      archived: false,
      createdAt: now,
      updatedAt: now,
    };
    await db.academicYears.put(currentYear);
  })();

  return initPromise;
}

async function collectUniqueImageIds(
  courseIds: string[],
  sessionIds: string[],
  examIds: string[] = []
): Promise<string[]> {
  const imageIds = new Set<string>();

  if (courseIds.length > 0) {
    const courseImages = await db.images
      .where('courseId')
      .anyOf(courseIds)
      .toArray();
    for (const img of courseImages) {
      imageIds.add(img.id);
    }
  }

  if (sessionIds.length > 0) {
    const sessionImages = await db.images
      .where('sessionId')
      .anyOf(sessionIds)
      .toArray();
    for (const img of sessionImages) {
      imageIds.add(img.id);
    }
  }

  if (examIds.length > 0) {
    const examImages = await db.images
      .where('examId')
      .anyOf(examIds)
      .toArray();
    for (const img of examImages) {
      imageIds.add(img.id);
    }
  }

  return Array.from(imageIds);
}

export async function getAcademicYearDeleteSummary(academicYearId: string) {
  if (!academicYearId) {
    return { courseCount: 0, sessionCount: 0, imageCount: 0 };
  }

  const courses = await db.courses
    .where('academicYearId')
    .equals(academicYearId)
    .toArray();
  const courseIds = courses.map((c) => c.id);
  const sessions =
    courseIds.length > 0
      ? await db.sessions.where('courseId').anyOf(courseIds).toArray()
      : [];
  const exams =
    courseIds.length > 0
      ? await db.exams.where('courseId').anyOf(courseIds).toArray()
      : [];
  const sessionIds = sessions.map((s) => s.id);
  const examIds = exams.map((e) => e.id);
  const imageIds = await collectUniqueImageIds(courseIds, sessionIds, examIds);

  return {
    courseCount: courses.filter((c) => !c.isSystem).length,
    sessionCount: sessions.length,
    imageCount: imageIds.length,
  };
}

export async function deleteAcademicYearCascade(academicYearId: string): Promise<void> {
  if (!academicYearId) return;

  await db.transaction(
    'rw',
    [
      db.academicYears,
      db.courses,
      db.sessions,
      db.sessionBatches,
      db.exams,
      db.homeworks,
      db.courseNotes,
      db.images,
      db.examPeriods,
    ],
    async () => {
      const courses = await db.courses
        .where('academicYearId')
        .equals(academicYearId)
        .toArray();
      const courseIds = courses.map((c) => c.id);

      const sessions =
        courseIds.length > 0
          ? await db.sessions.where('courseId').anyOf(courseIds).toArray()
          : [];
      const exams =
        courseIds.length > 0
          ? await db.exams.where('courseId').anyOf(courseIds).toArray()
          : [];
      const sessionIds = sessions.map((s) => s.id);
      const examIds = exams.map((e) => e.id);
      const imageIds = await collectUniqueImageIds(courseIds, sessionIds, examIds);

      if (imageIds.length > 0) {
        await db.images.bulkDelete(imageIds);
      }
      if (sessionIds.length > 0) {
        await db.sessions.bulkDelete(sessionIds);
      }
      if (courseIds.length > 0) {
        const courseIdSet = new Set(courseIds);
        const allPeriods = await db.examPeriods.toArray();
        const now = Date.now();
        const updatedPeriods = allPeriods
          .filter((ep) => ep.courseIds.some((id) => courseIdSet.has(id)))
          .map((ep) => ({
            ...ep,
            courseIds: ep.courseIds.filter((id) => !courseIdSet.has(id)),
            updatedAt: now,
          }));
        if (updatedPeriods.length > 0) {
          await db.examPeriods.bulkPut(updatedPeriods);
        }

        await db.exams.where('courseId').anyOf(courseIds).delete();
        await db.homeworks.where('courseId').anyOf(courseIds).delete();
        await db.courseNotes.where('courseId').anyOf(courseIds).delete();
        await db.sessionBatches.where('courseId').anyOf(courseIds).delete();
        await db.courses.bulkDelete(courseIds);
      }

      await db.academicYears.delete(academicYearId);
    }
  );
}

export async function getOrganizationDeleteSummary(organizationId: string) {
  if (!organizationId) {
    return { courseCount: 0, sessionCount: 0, imageCount: 0, examPeriodCount: 0 };
  }

  const courses = await db.courses
    .where('organizationId')
    .equals(organizationId)
    .toArray();
  const courseIds = courses.map((c) => c.id);
  const sessions =
    courseIds.length > 0
      ? await db.sessions.where('courseId').anyOf(courseIds).toArray()
      : [];
  const exams =
    courseIds.length > 0
      ? await db.exams.where('courseId').anyOf(courseIds).toArray()
      : [];
  const sessionIds = sessions.map((s) => s.id);
  const examIds = exams.map((e) => e.id);
  const imageIds = await collectUniqueImageIds(courseIds, sessionIds, examIds);
  const examPeriodCount = await db.examPeriods
    .where('organizationId')
    .equals(organizationId)
    .count();

  return {
    courseCount: courses.length,
    sessionCount: sessions.length,
    imageCount: imageIds.length,
    examPeriodCount,
  };
}

export async function deleteOrganizationCascade(organizationId: string): Promise<void> {
  if (!organizationId) return;

  await db.transaction(
    'rw',
    [
      db.organizations,
      db.periods,
      db.courses,
      db.sessions,
      db.sessionBatches,
      db.exams,
      db.homeworks,
      db.courseNotes,
      db.images,
      db.examPeriods,
    ],
    async () => {
      const courses = await db.courses
        .where('organizationId')
        .equals(organizationId)
        .toArray();
      const courseIds = courses.map((c) => c.id);

      const sessions =
        courseIds.length > 0
          ? await db.sessions.where('courseId').anyOf(courseIds).toArray()
          : [];
      const exams =
        courseIds.length > 0
          ? await db.exams.where('courseId').anyOf(courseIds).toArray()
          : [];
      const sessionIds = sessions.map((s) => s.id);
      const examIds = exams.map((e) => e.id);
      const imageIds = await collectUniqueImageIds(courseIds, sessionIds, examIds);

      if (imageIds.length > 0) {
        await db.images.bulkDelete(imageIds);
      }
      if (sessionIds.length > 0) {
        await db.sessions.bulkDelete(sessionIds);
      }
      if (courseIds.length > 0) {
        const courseIdSet = new Set(courseIds);
        const allPeriods = await db.examPeriods.toArray();
        const now = Date.now();
        const updatedPeriods = allPeriods
          .filter(
            (ep) =>
              ep.organizationId !== organizationId &&
              ep.courseIds.some((id) => courseIdSet.has(id))
          )
          .map((ep) => ({
            ...ep,
            courseIds: ep.courseIds.filter((id) => !courseIdSet.has(id)),
            updatedAt: now,
          }));
        if (updatedPeriods.length > 0) {
          await db.examPeriods.bulkPut(updatedPeriods);
        }

        await db.exams.where('courseId').anyOf(courseIds).delete();
        await db.homeworks.where('courseId').anyOf(courseIds).delete();
        await db.courseNotes.where('courseId').anyOf(courseIds).delete();
        await db.sessionBatches.where('courseId').anyOf(courseIds).delete();
        await db.courses.bulkDelete(courseIds);
      }

      await db.examPeriods.where('organizationId').equals(organizationId).delete();
      await db.periods.where('organizationId').equals(organizationId).delete();

      const linkedSubSessions = await db.sessions
        .where('organizationId')
        .equals(organizationId)
        .toArray();
      if (linkedSubSessions.length > 0) {
        await db.sessions.bulkPut(
          linkedSubSessions.map((s) => ({
            ...s,
            organizationId: undefined,
            updatedAt: Date.now(),
          }))
        );
      }

      await db.organizations.delete(organizationId);
    }
  );
}

export async function getRemovedStudentSchoolsSummary(
  organizationId: string,
  removedSchoolIds: string[]
): Promise<{ examPeriodCount: number; courseCount: number }> {
  if (!organizationId || removedSchoolIds.length === 0) {
    return { examPeriodCount: 0, courseCount: 0 };
  }
  const removedSet = new Set(removedSchoolIds);
  const [periods, courses] = await Promise.all([
    db.examPeriods.where('organizationId').equals(organizationId).toArray(),
    db.courses.where('organizationId').equals(organizationId).toArray(),
  ]);

  const examPeriodCount = periods.filter(
    (ep) => ep.studentSchoolId && removedSet.has(ep.studentSchoolId)
  ).length;
  const courseCount = courses.filter(
    (c) =>
      Array.isArray(c.studentSchoolIds) &&
      c.studentSchoolIds.some((id) => removedSet.has(id))
  ).length;

  return { examPeriodCount, courseCount };
}

export async function saveOrganizationWithPeriods(
  organization: Organization,
  periods: Period[],
  removedSchoolIds: string[] = []
): Promise<void> {
  await db.transaction(
    'rw',
    [db.organizations, db.periods, db.examPeriods, db.courses],
    async () => {
      if (removedSchoolIds.length > 0) {
        const removedSet = new Set(removedSchoolIds);
        const now = Date.now();

        const orgExamPeriods = await db.examPeriods
          .where('organizationId')
          .equals(organization.id)
          .toArray();
        const examPeriodIdsToDelete = orgExamPeriods
          .filter((ep) => ep.studentSchoolId && removedSet.has(ep.studentSchoolId))
          .map((ep) => ep.id);
        if (examPeriodIdsToDelete.length > 0) {
          await db.examPeriods.bulkDelete(examPeriodIdsToDelete);
        }

        const orgCourses = await db.courses
          .where('organizationId')
          .equals(organization.id)
          .toArray();
        const updatedCourses = orgCourses
          .filter(
            (c) =>
              Array.isArray(c.studentSchoolIds) &&
              c.studentSchoolIds.some((id) => removedSet.has(id))
          )
          .map((c) => ({
            ...c,
            studentSchoolIds: c.studentSchoolIds!.filter(
              (id) => !removedSet.has(id)
            ),
            updatedAt: now,
          }));
        if (updatedCourses.length > 0) {
          await db.courses.bulkPut(updatedCourses);
        }
      }

      await db.organizations.put(organization);
      await db.periods
        .where('organizationId')
        .equals(organization.id)
        .delete();
      if (periods.length > 0) {
        await db.periods.bulkPut(
          periods.map((p, index) => ({
            ...p,
            organizationId: organization.id,
            sortOrder: index,
          }))
        );
      }
    }
  );
}

export async function getCourseDeleteSummary(courseId: string) {
  if (!courseId) {
    return { sessionCount: 0, imageCount: 0 };
  }

  const sessions = await db.sessions.where('courseId').equals(courseId).toArray();
  const exams = await db.exams.where('courseId').equals(courseId).toArray();
  const sessionIds = sessions.map((s) => s.id);
  const examIds = exams.map((e) => e.id);
  const imageIds = await collectUniqueImageIds([courseId], sessionIds, examIds);

  return {
    sessionCount: sessions.length,
    imageCount: imageIds.length,
  };
}

export async function deleteCourseCascade(courseId: string): Promise<void> {
  if (!courseId) return;

  const target = await db.courses.get(courseId);
  if (target?.isSystem) {
    return;
  }

  await db.transaction(
    'rw',
    [
      db.courses,
      db.sessions,
      db.sessionBatches,
      db.exams,
      db.homeworks,
      db.courseNotes,
      db.images,
      db.examPeriods,
    ],
    async () => {
      const sessions = await db.sessions.where('courseId').equals(courseId).toArray();
      const exams = await db.exams.where('courseId').equals(courseId).toArray();
      const sessionIds = sessions.map((s) => s.id);
      const examIds = exams.map((e) => e.id);
      const imageIds = await collectUniqueImageIds([courseId], sessionIds, examIds);

      if (imageIds.length > 0) {
        await db.images.bulkDelete(imageIds);
      }
      if (sessionIds.length > 0) {
        await db.sessions.bulkDelete(sessionIds);
      }

      const allPeriods = await db.examPeriods.toArray();
      const now = Date.now();
      const updatedPeriods = allPeriods
        .filter((ep) => ep.courseIds.includes(courseId))
        .map((ep) => ({
          ...ep,
          courseIds: ep.courseIds.filter((id) => id !== courseId),
          updatedAt: now,
        }));
      if (updatedPeriods.length > 0) {
        await db.examPeriods.bulkPut(updatedPeriods);
      }

      await db.exams.where('courseId').equals(courseId).delete();
      await db.homeworks.where('courseId').equals(courseId).delete();
      await db.courseNotes.where('courseId').equals(courseId).delete();
      await db.sessionBatches.where('courseId').equals(courseId).delete();
      await db.courses.delete(courseId);
    }
  );
}

export async function ensureSubstituteSystemCourseForDate(
  date: string
): Promise<Course> {
  let years = await db.academicYears.toArray();
  if (years.length === 0) {
    await ensureInitialData();
    years = await db.academicYears.toArray();
  }

  const sortedYears = [...years].sort((a, b) =>
    b.startDate.localeCompare(a.startDate)
  );
  const activeMatching = sortedYears.find(
    (y) => !y.archived && y.startDate <= date && date <= y.endDate
  );
  const anyMatching = sortedYears.find(
    (y) => y.startDate <= date && date <= y.endDate
  );
  const fallbackYear =
    sortedYears.find((y) => !y.archived) ?? sortedYears[0];

  const targetYear = activeMatching ?? anyMatching ?? fallbackYear;
  if (!targetYear) {
    throw new Error('找不到可用的學年資料，無法建立代課課程');
  }

  const yearCourses = await db.courses
    .where('academicYearId')
    .equals(targetYear.id)
    .toArray();
  const existingSystem = yearCourses.find((c) => Boolean(c.isSystem));
  if (existingSystem) {
    return existingSystem;
  }

  const now = Date.now();
  const systemCourse: Course = {
    id: createId(),
    academicYearId: targetYear.id,
    organizationId: '',
    name: '代課／臨時',
    color: '#FEF3C7',
    defaultDurationMinutes: 50,
    regularSlots: [],
    isSystem: true,
    createdAt: now,
    updatedAt: now,
  };
  await db.courses.put(systemCourse);
  return systemCourse;
}

export async function deleteExamWithImages(examId: string): Promise<void> {
  if (!examId) return;
  await db.transaction('rw', [db.exams, db.images], async () => {
    await db.images.where('examId').equals(examId).delete();
    await db.exams.delete(examId);
  });
}

export async function getLastCourseSessionTime(
  courseId: string,
  excludeSessionId?: string
): Promise<{
  startTime: string;
  endTime: string;
  periodLabel?: string;
} | null> {
  if (!courseId) return null;
  const sessions = await db.sessions.where('courseId').equals(courseId).toArray();
  const candidates = sessions.filter((s) => s.id !== excludeSessionId);
  if (candidates.length === 0) return null;

  candidates.sort((a, b) => {
    const dateDiff = b.date.localeCompare(a.date);
    if (dateDiff !== 0) return dateDiff;
    const timeDiff = b.startTime.localeCompare(a.startTime);
    if (timeDiff !== 0) return timeDiff;
    return b.createdAt - a.createdAt;
  });

  const latest = candidates[0];
  return {
    startTime: latest.startTime,
    endTime: latest.endTime,
    periodLabel: latest.periodLabel,
  };
}

export async function findOverlappingSessions(
  date: string,
  startTime: string,
  endTime: string,
  excludeSessionId?: string
): Promise<ClassSession[]> {
  if (!date || !startTime || !endTime) return [];
  const sameDay = await db.sessions.where('date').equals(date).toArray();
  return sameDay.filter(
    (s) =>
      s.id !== excludeSessionId &&
      !isSessionCancelled(s) &&
      doTimeRangesOverlap(startTime, endTime, s.startTime, s.endTime)
  );
}

export async function createBatchSessions(params: {
  course: Course;
  startDate: string;
  endDate: string;
  slotSummary: string;
  items: Array<{
    date: string;
    startTime: string;
    endTime: string;
    periodLabel?: string;
  }>;
}): Promise<{ batch: SessionBatch; createdCount: number }> {
  const now = Date.now();
  const batchId = createId();
  const batch: SessionBatch = {
    id: batchId,
    courseId: params.course.id,
    courseName: params.course.name,
    startDate: params.startDate,
    endDate: params.endDate,
    totalCount: params.items.length,
    slotSummary: params.slotSummary,
    createdAt: now,
  };

  const sessionRecords: ClassSession[] = params.items.map((item, index) => ({
    id: createId(),
    courseId: params.course.id,
    title: params.course.name,
    date: item.date,
    startTime: item.startTime,
    endTime: item.endTime,
    periodLabel: item.periodLabel,
    status: 'scheduled',
    kind: 'regular',
    batchId,
    createdAt: now + index,
    updatedAt: now + index,
  }));

  await db.transaction('rw', db.sessionBatches, db.sessions, async () => {
    await db.sessionBatches.put(batch);
    if (sessionRecords.length > 0) {
      await db.sessions.bulkPut(sessionRecords);
    }
  });

  return { batch, createdCount: sessionRecords.length };
}

export async function reclaimSessionBatch(batchId: string): Promise<{
  deletedCount: number;
  keptCount: number;
  backup: DeletedBackupPayload;
}> {
  const batch = await db.sessionBatches.get(batchId);
  const sessions = await db.sessions.where('batchId').equals(batchId).toArray();
  const sessionIds = sessions.map((s) => s.id);

  const linkedImages =
    sessionIds.length > 0
      ? await db.images.where('sessionId').anyOf(sessionIds).toArray()
      : [];
  const sessionsWithImages = new Set(
    linkedImages.map((img) => img.sessionId).filter(Boolean) as string[]
  );

  const toDelete: ClassSession[] = [];
  const toKeep: ClassSession[] = [];

  for (const s of sessions) {
    const hasRecord = Boolean(
      s.progress?.trim() ||
        s.note?.trim() ||
        s.homework?.trim() ||
        sessionsWithImages.has(s.id)
    );
    if (hasRecord) {
      toKeep.push(s);
    } else {
      toDelete.push(s);
    }
  }

  const deleteIds = toDelete.map((s) => s.id);
  const deletedBatches: SessionBatch[] = [];

  await db.transaction('rw', db.sessions, db.sessionBatches, async () => {
    if (deleteIds.length > 0) {
      await db.sessions.bulkDelete(deleteIds);
    }
    if (toKeep.length === 0 && batch) {
      await db.sessionBatches.delete(batchId);
      deletedBatches.push(batch);
    }
  });

  return {
    deletedCount: toDelete.length,
    keptCount: toKeep.length,
    backup: {
      sessions: toDelete,
      batches: deletedBatches,
      images: [],
    },
  };
}

export async function rescheduleBatchSessions(params: {
  batchId: string;
  fromDate: string;
  startTime: string;
  endTime: string;
}): Promise<number> {
  const sessions = await db.sessions
    .where('batchId')
    .equals(params.batchId)
    .toArray();
  const targets = sessions.filter((s) => s.date >= params.fromDate);
  if (targets.length === 0) return 0;

  const now = Date.now();
  await db.sessions.bulkPut(
    targets.map((s) => ({
      ...s,
      startTime: params.startTime,
      endTime: params.endTime,
      periodLabel: undefined,
      updatedAt: now,
    }))
  );

  return targets.length;
}

export async function deleteMultipleSessions(
  sessionIds: string[]
): Promise<DeletedBackupPayload> {
  if (sessionIds.length === 0) {
    return { sessions: [], batches: [], images: [] };
  }

  const sessions = (await db.sessions.bulkGet(sessionIds)).filter(
    (s): s is ClassSession => Boolean(s)
  );
  const images = await db.images.where('sessionId').anyOf(sessionIds).toArray();

  await db.transaction('rw', db.sessions, db.images, async () => {
    if (images.length > 0) {
      await db.images.bulkDelete(images.map((i) => i.id));
    }
    await db.sessions.bulkDelete(sessionIds);
  });

  return {
    sessions,
    batches: [],
    images,
  };
}

export async function restoreDeletedData(
  payload: DeletedBackupPayload
): Promise<void> {
  await db.transaction(
    'rw',
    db.sessionBatches,
    db.sessions,
    db.images,
    async () => {
      if (payload.batches.length > 0) {
        await db.sessionBatches.bulkPut(payload.batches);
      }
      if (payload.sessions.length > 0) {
        await db.sessions.bulkPut(payload.sessions);
      }
      if (payload.images.length > 0) {
        await db.images.bulkPut(payload.images);
      }
    }
  );
}

export async function toggleTaskDone(task: TaskItem): Promise<void> {
  if (task.type !== 'todo') return;
  const now = Date.now();
  const nextDone = !task.done;
  await db.tasks.update(task.id, {
    done: nextDone,
    doneAt: nextDone ? now : undefined,
    updatedAt: now,
  });
}

export const DEFAULT_SETTINGS_ID = 'default';

export async function saveWeekGridDaysSetting(
  weekGridDays: WeekGridDays
): Promise<void> {
  await db.settings.put({
    id: DEFAULT_SETTINGS_ID,
    weekGridDays,
    updatedAt: Date.now(),
  });
}

