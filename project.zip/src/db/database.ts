import Dexie, { type EntityTable } from 'dexie';
import { getCurrentTaiwanAcademicYearTemplate } from '../utils/academicYear';
import type {
  AcademicYear,
  AppSettings,
  ClassSession,
  Course,
  CourseNote,
  Exam,
  ExamPeriod,
  Homework,
  Organization,
  Period,
  SessionBatch,
  StoredImage,
  TaskItem,
} from './types';

export class CourseAssistantDB extends Dexie {
  academicYears!: EntityTable<AcademicYear, 'id'>;
  organizations!: EntityTable<Organization, 'id'>;
  periods!: EntityTable<Period, 'id'>;
  courses!: EntityTable<Course, 'id'>;
  sessions!: EntityTable<ClassSession, 'id'>;
  sessionBatches!: EntityTable<SessionBatch, 'id'>;
  exams!: EntityTable<Exam, 'id'>;
  homeworks!: EntityTable<Homework, 'id'>;
  courseNotes!: EntityTable<CourseNote, 'id'>;
  images!: EntityTable<StoredImage, 'id'>;
  tasks!: EntityTable<TaskItem, 'id'>;
  settings!: EntityTable<AppSettings, 'id'>;
  examPeriods!: EntityTable<ExamPeriod, 'id'>;

  constructor() {
    super('CourseAssistantDB');

    this.version(1).stores({
      courses: 'id, name, createdAt, updatedAt',
      sessions: 'id, date, startTime, courseId, [date+startTime], createdAt',
      images: 'id, sessionId, courseId, createdAt',
    });

    this.version(2)
      .stores({
        academicYears: 'id, name, startDate, endDate, archived, createdAt',
        organizations: 'id, name, type, createdAt',
        courses:
          'id, academicYearId, organizationId, name, [academicYearId+organizationId], createdAt, updatedAt',
        sessions: 'id, date, startTime, courseId, [date+startTime], createdAt',
        images: 'id, sessionId, courseId, createdAt',
      })
      .upgrade(async (tx) => {
        const existingCourses = await tx.table('courses').toArray();
        if (existingCourses.length === 0) {
          return;
        }

        const now = Date.now();
        const yearTable = tx.table('academicYears');
        const orgTable = tx.table('organizations');

        let defaultYear = (await yearTable.toArray())[0] as AcademicYear | undefined;
        if (!defaultYear) {
          const tpl = getCurrentTaiwanAcademicYearTemplate(new Date(now));
          defaultYear = {
            id: 'legacy-default-year',
            name: tpl.name,
            startDate: tpl.startDate,
            endDate: tpl.endDate,
            archived: false,
            createdAt: now,
            updatedAt: now,
          };
          await yearTable.put(defaultYear);
        }

        let defaultOrg = (await orgTable.toArray())[0] as Organization | undefined;
        if (!defaultOrg) {
          defaultOrg = {
            id: 'legacy-default-org',
            name: '預設單位',
            type: 'other',
            color: '#1d4ed8',
            createdAt: now,
            updatedAt: now,
          };
          await orgTable.put(defaultOrg);
        }

        for (const course of existingCourses) {
          await tx.table('courses').put({
            ...course,
            academicYearId: course.academicYearId || defaultYear.id,
            organizationId: course.organizationId || defaultOrg.id,
            color: course.color || defaultOrg.color || '#1d4ed8',
            defaultDurationMinutes:
              typeof course.defaultDurationMinutes === 'number'
                ? course.defaultDurationMinutes
                : 60,
            updatedAt: course.updatedAt || now,
          });
        }
      });

    this.version(3)
      .stores({
        academicYears: 'id, name, startDate, endDate, archived, createdAt',
        organizations: 'id, name, type, createdAt',
        periods: 'id, organizationId, startTime, [organizationId+startTime], createdAt',
        courses:
          'id, academicYearId, organizationId, name, [academicYearId+organizationId], createdAt, updatedAt',
        sessions:
          'id, date, startTime, courseId, batchId, status, kind, makeupForSessionId, [date+startTime], [courseId+date], createdAt',
        sessionBatches: 'id, courseId, createdAt',
        images: 'id, sessionId, courseId, createdAt',
      })
      .upgrade(async (tx) => {
        const existingCourses = await tx.table('courses').toArray();
        for (const course of existingCourses) {
          if (!Array.isArray(course.regularSlots)) {
            await tx.table('courses').put({
              ...course,
              regularSlots: [],
            });
          }
        }

        const existingSessions = await tx.table('sessions').toArray();
        for (const session of existingSessions) {
          await tx.table('sessions').put({
            ...session,
            status: session.status || 'scheduled',
            kind: session.kind || 'regular',
          });
        }
      });

    this.version(4)
      .stores({
        academicYears: 'id, name, startDate, endDate, archived, createdAt',
        organizations: 'id, name, type, createdAt',
        periods: 'id, organizationId, startTime, [organizationId+startTime], createdAt',
        courses:
          'id, academicYearId, organizationId, name, [academicYearId+organizationId], createdAt, updatedAt',
        sessions:
          'id, date, startTime, courseId, batchId, status, kind, makeupForSessionId, [date+startTime], [courseId+date], createdAt',
        sessionBatches: 'id, courseId, createdAt',
        images: 'id, sessionId, courseId, createdAt',
      })
      .upgrade(async (tx) => {
        const existingCourses = await tx.table('courses').toArray();
        for (const course of existingCourses) {
          if (!Array.isArray(course.regularSlots)) {
            await tx.table('courses').put({
              ...course,
              regularSlots: [],
            });
          }
        }
      });

    this.version(5).stores({
      academicYears: 'id, name, startDate, endDate, archived, createdAt',
      organizations: 'id, name, type, createdAt',
      periods: 'id, organizationId, startTime, [organizationId+startTime], createdAt',
      courses:
        'id, academicYearId, organizationId, name, [academicYearId+organizationId], createdAt, updatedAt',
      sessions:
        'id, date, startTime, courseId, batchId, status, kind, makeupForSessionId, [date+startTime], [courseId+date], createdAt',
      sessionBatches: 'id, courseId, createdAt',
      exams: 'id, courseId, date, [courseId+date], createdAt',
      homeworks:
        'id, courseId, sessionId, assignedDate, dueDate, status, [courseId+status], createdAt',
      courseNotes: 'id, courseId, pinned, updatedAt, createdAt',
      images: 'id, sessionId, courseId, examId, createdAt',
    });

    this.version(6).stores({
      academicYears: 'id, name, startDate, endDate, archived, createdAt',
      organizations: 'id, name, type, createdAt',
      periods: 'id, organizationId, startTime, [organizationId+startTime], createdAt',
      courses:
        'id, academicYearId, organizationId, name, [academicYearId+organizationId], createdAt, updatedAt',
      sessions:
        'id, date, startTime, courseId, organizationId, batchId, status, kind, makeupForSessionId, [date+startTime], [courseId+date], createdAt',
      sessionBatches: 'id, courseId, createdAt',
      exams: 'id, courseId, date, [courseId+date], createdAt',
      homeworks:
        'id, courseId, sessionId, assignedDate, dueDate, status, [courseId+status], createdAt',
      courseNotes: 'id, courseId, pinned, updatedAt, createdAt',
      images: 'id, sessionId, courseId, examId, createdAt',
    });

    this.version(7).stores({
      academicYears: 'id, name, startDate, endDate, archived, createdAt',
      organizations: 'id, name, type, createdAt',
      periods: 'id, organizationId, startTime, [organizationId+startTime], createdAt',
      courses:
        'id, academicYearId, organizationId, name, [academicYearId+organizationId], createdAt, updatedAt',
      sessions:
        'id, date, startTime, courseId, organizationId, batchId, status, kind, makeupForSessionId, [date+startTime], [courseId+date], createdAt',
      sessionBatches: 'id, courseId, createdAt',
      exams: 'id, courseId, date, [courseId+date], createdAt',
      homeworks:
        'id, courseId, sessionId, assignedDate, dueDate, status, [courseId+status], createdAt',
      courseNotes: 'id, courseId, pinned, updatedAt, createdAt',
      images: 'id, sessionId, courseId, examId, createdAt',
      tasks: 'id, type, courseId, sessionId, dueDate, done, createdAt, updatedAt',
      settings: 'id',
    });

    this.version(8).stores({
      academicYears: 'id, name, startDate, endDate, archived, createdAt',
      organizations: 'id, name, type, createdAt',
      periods: 'id, organizationId, startTime, [organizationId+startTime], createdAt',
      courses:
        'id, academicYearId, organizationId, name, [academicYearId+organizationId], createdAt, updatedAt',
      sessions:
        'id, date, startTime, courseId, organizationId, batchId, status, kind, makeupForSessionId, [date+startTime], [courseId+date], createdAt',
      sessionBatches: 'id, courseId, createdAt',
      exams: 'id, courseId, date, [courseId+date], createdAt',
      homeworks:
        'id, courseId, sessionId, assignedDate, dueDate, status, [courseId+status], createdAt',
      courseNotes: 'id, courseId, pinned, updatedAt, createdAt',
      images: 'id, sessionId, courseId, examId, createdAt',
      tasks: 'id, type, courseId, sessionId, dueDate, done, createdAt, updatedAt',
      settings: 'id',
      examPeriods: 'id, organizationId, startDate, endDate',
    });
  }
}

export const db = new CourseAssistantDB();
