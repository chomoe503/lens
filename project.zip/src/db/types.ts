export type NavTabId = 'today' | 'week' | 'courses' | 'more';

export type OrganizationType = 'school' | 'cram_school' | 'other';

export type WeekdayNumber = 0 | 1 | 2 | 3 | 4 | 5 | 6; // 0 = 週日, 1 = 週一 ... 6 = 週六

export type SessionStatus = 'scheduled' | 'completed' | 'cancelled';
export type SessionKind = 'regular' | 'makeup' | 'extra' | 'substitute';

export interface AcademicYear {
  id: string;
  name: string; // 例如：115 學年度上學期
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  archived: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface StudentSchool {
  id: string;
  name: string;
}

export interface Organization {
  id: string;
  name: string;
  type: OrganizationType;
  color: string;
  studentSchools?: StudentSchool[];
  isSample?: boolean;
  createdAt: number;
  updatedAt: number;
}

/**
 * 單位節次表（各校／單位獨立設定，選填）
 */
export interface Period {
  id: string;
  organizationId: string;
  name: string; // 例如：第1節、早自習
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  sortOrder: number;
  createdAt: number;
  updatedAt: number;
}

/**
 * 課程常用時段（僅作為產生場次的範本，修改不影響已建立場次）
 */
export interface CourseRegularSlot {
  id: string;
  weekday: WeekdayNumber;
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  periodLabel?: string; // 節次標籤（僅顯示用）
}

export interface Course {
  id: string;
  academicYearId: string;
  organizationId: string;
  name: string; // 以班級名稱為主，例如：國一A班、國二B班、高三
  subject?: string; // 選填（例如：理化），僅於課程詳情／編輯頁顯示
  color: string; // 預設沿用所屬單位顏色，可自訂
  defaultDurationMinutes: number; // 預設時長（分鐘）
  regularSlots?: CourseRegularSlot[]; // 常用時段（可多筆）
  studentSchoolIds?: string[]; // 補習班班級學生就讀學校（undefined 代表該單位所有學校）
  material?: string; // 教材
  note?: string; // 備註
  defaultLocation?: string; // 保留 v1 既有相容欄位
  isSample?: boolean;
  isSystem?: boolean; // 系統保留課程（例如「代課／臨時」，不可刪除、不出現在一般清單）
  createdAt: number;
  updatedAt: number;
}

/**
 * 課程場次（核心資料單位）：
 * 每一堂課都是獨立的一筆紀錄，永遠儲存實際起訖時間，節次標籤只用來顯示。
 */
export interface ClassSession {
  id: string;
  date: string; // YYYY-MM-DD (本機日期)
  startTime: string; // HH:mm（實際開始時間）
  endTime: string; // HH:mm（實際結束時間）
  periodLabel?: string; // 節次標籤（僅顯示用）
  courseId?: string;
  organizationId?: string; // 代課／臨時場次可另存任課單位 id（可空）
  title: string;
  substituteFor?: string; // 代課／臨時場次：代誰的課（選填）
  status: SessionStatus; // 預定 / 已上 / 停課
  kind: SessionKind; // 正常 / 補課 / 加課 / 代課
  cancelReason?: string; // 停課原因
  makeupForSessionId?: string; // 補課連結的停課場次 id
  originalDate?: string; // 改期前原定日期 YYYY-MM-DD
  originalStartTime?: string; // 改期前原定開始時間 HH:mm
  originalEndTime?: string; // 改期前原定結束時間 HH:mm
  batchId?: string; // 產生批次 id
  location?: string;
  progress?: string; // 上課進度
  note?: string;
  homework?: string; // 作業紀錄
  createdAt: number;
  updatedAt: number;
}

/**
 * 批次產生場次紀錄（用於「更多」頁檢視、整批改時間、一鍵收回整批）
 */
export interface SessionBatch {
  id: string;
  courseId: string;
  courseName: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  totalCount: number;
  slotSummary: string;
  createdAt: number;
}

export type HomeworkStatus = 'uncollected' | 'collected' | 'graded';

/**
 * 課程考試紀錄（屬於單一課程）
 */
export interface Exam {
  id: string;
  courseId: string;
  title: string; // 考試名稱
  date: string; // YYYY-MM-DD
  time?: string; // HH:mm 或時間說明
  scope?: string; // 考試範圍
  examType?: string; // 類型（小考、段考等）
  note?: string;
  createdAt: number;
  updatedAt: number;
}

/**
 * 作業紀錄（屬於單一課程，可關聯至特定派出場次）
 */
export interface Homework {
  id: string;
  courseId: string;
  sessionId?: string; // 派出此作業的場次 id（選填）
  title: string; // 作業名稱
  assignedDate: string; // 派出日 YYYY-MM-DD
  dueDate?: string; // 繳交日 YYYY-MM-DD
  status: HomeworkStatus; // 未收 / 收齊 / 已批改
  note?: string;
  createdAt: number;
  updatedAt: number;
}

/**
 * 課程專屬備註（可多筆，支援置頂）
 */
export interface CourseNote {
  id: string;
  courseId: string;
  content: string;
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
}

/**
 * 儲存於本機 IndexedDB 的圖片二進位資料，支援完全離線存取。
 */
export interface StoredImage {
  id: string;
  sessionId?: string;
  courseId?: string;
  examId?: string;
  fileName: string;
  mimeType: string;
  blob: Blob;
  thumbnailBlob?: Blob;
  createdAt: number;
}

export type TaskType = 'todo' | 'reminder';

/**
 * 任務與提醒（待辦可勾選，提醒為純文字不可勾選）
 */
export interface TaskItem {
  id: string;
  title: string;
  type: TaskType;
  courseId?: string;
  sessionId?: string;
  dueDate?: string; // YYYY-MM-DD
  dueTime?: string; // HH:mm
  done: boolean;
  doneAt?: number;
  createdAt: number;
  updatedAt: number;
}

export type WeekGridDays = 1 | 3 | 7;

/**
 * 應用程式偏好設定（儲存於本機資料庫並納入備份）
 */
export interface AppSettings {
  id: string; // 'default'
  weekGridDays: WeekGridDays;
  updatedAt: number;
}

export type ExamPeriodKind = 'midterm' | 'final' | 'mock' | 'other';

/**
 * 考試期間（各校段考、期末考、模考等）
 */
export interface ExamPeriod {
  id: string;
  organizationId?: string;
  studentSchoolId?: string; // 選填，指定單位底下的哪一間學生就讀學校
  title: string;
  kind: ExamPeriodKind;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  subjectDate?: string; // 理化考試日 YYYY-MM-DD
  subjectNote?: string; // 例如：第 3 節 10:30
  scope?: string; // 考試範圍
  note?: string;
  appliesToAll: boolean;
  courseIds: string[];
  createdAt: number;
  updatedAt: number;
}

