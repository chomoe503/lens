import JSZip from 'jszip';
import { recordBackupSuccess } from '../utils/backupStore';
import { toDateKey } from '../utils/date';
import { shareBlobAsFileNative } from '../utils/nativeFiles';
import { isNativeApp } from '../utils/platform';
import { db } from './database';

export interface TableCountSummary {
  tableName: string;
  label: string;
  count: number;
}

export interface BackupManifest {
  app: 'course-assistant';
  dbName: string;
  dbVersion: number;
  exportedAt: string;
  exportedAtMs: number;
  tables: Record<string, unknown[]>;
}

export interface ParsedBackupPackage {
  manifest: BackupManifest;
  fileName: string;
  zip: JSZip;
  previewCounts: TableCountSummary[];
  extraTableNames: string[];
}

export type ImportMode = 'overwrite' | 'merge';

export type BackupDeliveryOutcome = 'shared' | 'downloaded' | 'cancelled';

const TABLE_LABELS: Record<string, string> = {
  academicYears: '學年',
  organizations: '任課單位',
  periods: '節次表',
  courses: '課程',
  sessions: '場次',
  sessionBatches: '產生場次批次',
  exams: '考試',
  homeworks: '作業',
  courseNotes: '課程備註',
  images: '圖片',
  tasks: '任務與提醒',
  settings: '偏好設定',
  examPeriods: '考試期間',
};

const MIME_TO_EXT: Record<string, string> = {
  'image/jpeg': '.jpg',
  'image/jpg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'image/gif': '.gif',
  'image/heic': '.heic',
  'image/heif': '.heif',
  'image/svg+xml': '.svg',
  'image/avif': '.avif',
};

interface GenericBlobMarker {
  __zipBlobPath: string;
  mimeType: string;
}

function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isGenericBlobMarker(value: unknown): value is GenericBlobMarker {
  return (
    isPlainRecord(value) &&
    typeof value.__zipBlobPath === 'string' &&
    typeof value.mimeType === 'string'
  );
}

export function getTableDisplayLabel(tableName: string): string {
  return TABLE_LABELS[tableName] ?? tableName;
}

function sanitizeSegment(raw: string): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9._-]/g, '_');
  return cleaned || 'item';
}

function getImageExtension(fileName?: unknown, mimeType?: unknown): string {
  if (typeof fileName === 'string') {
    const dotIndex = fileName.lastIndexOf('.');
    if (dotIndex > 0 && dotIndex < fileName.length - 1) {
      const ext = fileName.slice(dotIndex).toLowerCase();
      if (/^\.[a-z0-9]{1,8}$/.test(ext)) {
        return ext;
      }
    }
  }
  if (typeof mimeType === 'string') {
    const mapped = MIME_TO_EXT[mimeType.toLowerCase()];
    if (mapped) return mapped;
  }
  return '.bin';
}

function makeUniquePath(basePath: string, usedPaths: Set<string>): string {
  if (!usedPaths.has(basePath)) {
    usedPaths.add(basePath);
    return basePath;
  }
  const dotIndex = basePath.lastIndexOf('.');
  const prefix = dotIndex > 0 ? basePath.slice(0, dotIndex) : basePath;
  const suffix = dotIndex > 0 ? basePath.slice(dotIndex) : '';
  let counter = 2;
  let candidate = `${prefix}_${counter}${suffix}`;
  while (usedPaths.has(candidate)) {
    counter += 1;
    candidate = `${prefix}_${counter}${suffix}`;
  }
  usedPaths.add(candidate);
  return candidate;
}

export function buildBackupFileName(date: Date = new Date()): string {
  return `課程備份-${toDateKey(date)}.zip`;
}

export function downloadBlob(blob: Blob, fileName: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  window.setTimeout(() => {
    URL.revokeObjectURL(url);
  }, 10000);
}

export async function exportDatabaseToZip(): Promise<{
  blob: Blob;
  fileName: string;
  counts: TableCountSummary[];
  exportedAtMs: number;
}> {
  const zip = new JSZip();
  const usedPaths = new Set<string>();
  const tablesPayload: Record<string, unknown[]> = {};
  const counts: TableCountSummary[] = [];

  for (const table of db.tables) {
    const rows = await table.toArray();
    const serializedRows: unknown[] = [];

    for (let index = 0; index < rows.length; index += 1) {
      const row = rows[index];
      if (!isPlainRecord(row)) {
        serializedRows.push(row);
        continue;
      }

      const cloned: Record<string, unknown> = {};

      if (table.name === 'images' && row.blob instanceof Blob) {
        const safeId = sanitizeSegment(
          typeof row.id === 'string' ? row.id : `img_${index}`
        );
        for (const [key, value] of Object.entries(row)) {
          if (key === 'blob') continue;
          if (key === 'thumbnailBlob' && value instanceof Blob) {
            const thumbPath = makeUniquePath(
              `images/thumbs/${safeId}_thumb.jpg`,
              usedPaths
            );
            const thumbBuffer = await value.arrayBuffer();
            zip.file(thumbPath, thumbBuffer, { binary: true });
            cloned._zipThumbFile = thumbPath;
            continue;
          }
          cloned[key] = value;
        }
        const ext = getImageExtension(row.fileName, row.mimeType || row.blob.type);
        const imagePath = makeUniquePath(`images/${safeId}${ext}`, usedPaths);
        const buffer = await row.blob.arrayBuffer();
        zip.file(imagePath, buffer, { binary: true });
        cloned._zipImageFile = imagePath;
      } else {
        for (const [key, value] of Object.entries(row)) {
          if (value instanceof Blob) {
            const safeId = sanitizeSegment(
              typeof row.id === 'string' ? row.id : `row_${index}`
            );
            const blobPath = makeUniquePath(
              `blobs/${sanitizeSegment(table.name)}/${safeId}_${sanitizeSegment(key)}.bin`,
              usedPaths
            );
            const buffer = await value.arrayBuffer();
            zip.file(blobPath, buffer, { binary: true });
            cloned[key] = {
              __zipBlobPath: blobPath,
              mimeType: value.type || 'application/octet-stream',
            } satisfies GenericBlobMarker;
          } else {
            cloned[key] = value;
          }
        }
      }

      serializedRows.push(cloned);
    }

    tablesPayload[table.name] = serializedRows;
    counts.push({
      tableName: table.name,
      label: getTableDisplayLabel(table.name),
      count: serializedRows.length,
    });
  }

  const nowMs = Date.now();
  const manifest: BackupManifest = {
    app: 'course-assistant',
    dbName: db.name,
    dbVersion: db.verno,
    exportedAt: new Date(nowMs).toISOString(),
    exportedAtMs: nowMs,
    tables: tablesPayload,
  };

  zip.file('data.json', JSON.stringify(manifest, null, 2));

  const blob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  return {
    blob,
    fileName: buildBackupFileName(new Date(nowMs)),
    counts,
    exportedAtMs: nowMs,
  };
}

export async function exportAndDeliverBackup(
  preferShare: boolean
): Promise<{
  outcome: BackupDeliveryOutcome;
  fileName: string;
  counts: TableCountSummary[];
}> {
  const { blob, fileName, counts, exportedAtMs } = await exportDatabaseToZip();

  if (isNativeApp) {
    const outcome = await shareBlobAsFileNative(blob, fileName);
    if (outcome === 'cancelled') {
      if (!preferShare) {
        throw new Error('已取消備份，為了安全，這次沒有覆蓋任何資料。');
      }
      return { outcome: 'cancelled', fileName, counts };
    }
    recordBackupSuccess(exportedAtMs);
    return { outcome: 'shared', fileName, counts };
  }

  if (preferShare && typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
    try {
      const file = new File([blob], fileName, { type: 'application/zip' });
      const canShareFiles =
        typeof navigator.canShare !== 'function' || navigator.canShare({ files: [file] });

      if (canShareFiles) {
        await navigator.share({
          files: [file],
          title: fileName,
        });
        recordBackupSuccess(exportedAtMs);
        return { outcome: 'shared', fileName, counts };
      }
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') {
        return { outcome: 'cancelled', fileName, counts };
      }
      // Fallback cleanly to standard download when navigator.share is blocked or unsupported in browser/iframe
    }
  }

  downloadBlob(blob, fileName);
  recordBackupSuccess(exportedAtMs);
  return { outcome: 'downloaded', fileName, counts };
}

export async function parseBackupZip(file: File): Promise<ParsedBackupPackage> {
  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(file);
  } catch {
    throw new Error('無法讀取此檔案，請確認選擇的是有效的 .zip 備份檔。');
  }

  const dataEntry = zip.file('data.json');
  if (!dataEntry) {
    throw new Error('備份檔內找不到 data.json，請確認這是由「課程助理」匯出的備份檔。');
  }

  let parsedRaw: unknown;
  try {
    const jsonText = await dataEntry.async('string');
    parsedRaw = JSON.parse(jsonText);
  } catch {
    throw new Error('備份檔內的 data.json 格式損壞，無法解析。');
  }

  if (!isPlainRecord(parsedRaw)) {
    throw new Error('備份檔內容結構不正確。');
  }

  const dbVersion = parsedRaw.dbVersion;
  if (typeof dbVersion !== 'number' || !Number.isFinite(dbVersion) || dbVersion < 1) {
    throw new Error('備份檔缺少有效的資料庫版本號（dbVersion）。');
  }

  if (dbVersion > db.verno) {
    throw new Error(
      `此備份檔的資料庫版本（v${dbVersion}）高於目前 App 版本（v${db.verno}），無法匯入。請先更新 App 後再試。`
    );
  }

  const tablesRaw = parsedRaw.tables;
  if (!isPlainRecord(tablesRaw)) {
    throw new Error('備份檔缺少資料表內容（tables）。');
  }

  const normalizedTables: Record<string, unknown[]> = {};
  for (const [tableName, rows] of Object.entries(tablesRaw)) {
    if (!Array.isArray(rows)) {
      throw new Error(`資料表「${tableName}」的格式不正確，無法匯入。`);
    }
    normalizedTables[tableName] = rows;
  }

  const exportedAt =
    typeof parsedRaw.exportedAt === 'string'
      ? parsedRaw.exportedAt
      : new Date().toISOString();
  const exportedAtMs =
    typeof parsedRaw.exportedAtMs === 'number' && Number.isFinite(parsedRaw.exportedAtMs)
      ? parsedRaw.exportedAtMs
      : Date.parse(exportedAt) || Date.now();

  const manifest: BackupManifest = {
    app: 'course-assistant',
    dbName: typeof parsedRaw.dbName === 'string' ? parsedRaw.dbName : db.name,
    dbVersion,
    exportedAt,
    exportedAtMs,
    tables: normalizedTables,
  };

  const currentTableNames = new Set(db.tables.map((t) => t.name));
  const previewCounts: TableCountSummary[] = db.tables.map((table) => ({
    tableName: table.name,
    label: getTableDisplayLabel(table.name),
    count: (normalizedTables[tableNameSafe(table.name)] ?? []).length,
  }));

  const extraTableNames = Object.keys(normalizedTables).filter(
    (name) => !currentTableNames.has(name)
  );

  return {
    manifest,
    fileName: file.name,
    zip,
    previewCounts,
    extraTableNames,
  };
}

function tableNameSafe(name: string): string {
  return name;
}

async function restoreRow(
  tableName: string,
  rawRow: unknown,
  zip: JSZip
): Promise<unknown> {
  if (!isPlainRecord(rawRow)) {
    return rawRow;
  }

  const restored: Record<string, unknown> = {};
  const zipImageFile =
    typeof rawRow._zipImageFile === 'string' ? rawRow._zipImageFile : null;
  const zipThumbFile =
    typeof rawRow._zipThumbFile === 'string' ? rawRow._zipThumbFile : null;

  for (const [key, value] of Object.entries(rawRow)) {
    if (key === '_zipImageFile' || key === '_zipThumbFile') continue;

    if (isGenericBlobMarker(value)) {
      const entry = zip.file(value.__zipBlobPath);
      if (!entry) {
        throw new Error(`備份檔缺少附件檔案：${value.__zipBlobPath}`);
      }
      const buffer = await entry.async('arraybuffer');
      restored[key] = new Blob([buffer], { type: value.mimeType });
    } else {
      restored[key] = value;
    }
  }

  if (tableName === 'images' && zipImageFile) {
    const imageEntry = zip.file(zipImageFile);
    if (!imageEntry) {
      throw new Error(`備份檔缺少圖片檔案：${zipImageFile}`);
    }
    const buffer = await imageEntry.async('arraybuffer');
    const mimeType =
      typeof rawRow.mimeType === 'string' && rawRow.mimeType
        ? rawRow.mimeType
        : 'application/octet-stream';
    restored.blob = new Blob([buffer], { type: mimeType });
  }

  if (tableName === 'images' && zipThumbFile) {
    const thumbEntry = zip.file(zipThumbFile);
    if (!thumbEntry) {
      throw new Error(`備份檔缺少縮圖檔案：${zipThumbFile}`);
    }
    const buffer = await thumbEntry.async('arraybuffer');
    restored.thumbnailBlob = new Blob([buffer], { type: 'image/jpeg' });
  }

  return restored;
}

export async function importBackupData(
  pkg: ParsedBackupPackage,
  mode: ImportMode
): Promise<TableCountSummary[]> {
  // Prepare all rows and reconstruct binary Blobs BEFORE opening the Dexie transaction
  // so async ZIP reads never prematurely auto-commit IndexedDB transactions.
  const preparedByTable = new Map<string, unknown[]>();
  const importedCounts: TableCountSummary[] = [];

  for (const table of db.tables) {
    const rawRows = pkg.manifest.tables[table.name] ?? [];
    const restoredRows: unknown[] = [];
    for (const rawRow of rawRows) {
      restoredRows.push(await restoreRow(table.name, rawRow, pkg.zip));
    }
    preparedByTable.set(table.name, restoredRows);
    importedCounts.push({
      tableName: table.name,
      label: getTableDisplayLabel(table.name),
      count: restoredRows.length,
    });
  }

  await db.transaction('rw', db.tables, async () => {
    for (const table of db.tables) {
      if (mode === 'overwrite') {
        await table.clear();
      }
      const rows = preparedByTable.get(table.name) ?? [];
      if (rows.length > 0) {
        await table.bulkPut(rows);
      }
    }
  });

  return importedCounts;
}
