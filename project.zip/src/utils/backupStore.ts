import { useSyncExternalStore } from 'react';

const LAST_BACKUP_KEY = 'course_assistant_last_backup_at';
const FIRST_USED_KEY = 'course_assistant_first_used_at';
const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

interface BackupMetaSnapshot {
  lastBackupAt: number | null;
  firstUsedAt: number;
  isOverdue: boolean;
}

const listeners = new Set<() => void>();

function readTimestamp(key: string): number | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return null;
    const parsed = Number.parseInt(raw, 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
  } catch {
    return null;
  }
}

function ensureFirstUsedAt(): number {
  const existing = readTimestamp(FIRST_USED_KEY);
  if (existing !== null) return existing;
  const now = Date.now();
  if (typeof window !== 'undefined') {
    try {
      window.localStorage.setItem(FIRST_USED_KEY, String(now));
    } catch {
      // Ignore storage quota / private mode issues
    }
  }
  return now;
}

function computeSnapshot(): BackupMetaSnapshot {
  const lastBackupAt = readTimestamp(LAST_BACKUP_KEY);
  const firstUsedAt = ensureFirstUsedAt();
  const referenceTime = lastBackupAt ?? firstUsedAt;
  const isOverdue = Date.now() - referenceTime > SEVEN_DAYS_MS;
  return { lastBackupAt, firstUsedAt, isOverdue };
}

let cachedSnapshot: BackupMetaSnapshot = computeSnapshot();

function getSnapshot(): BackupMetaSnapshot {
  return cachedSnapshot;
}

function notify() {
  cachedSnapshot = computeSnapshot();
  for (const listener of listeners) {
    listener();
  }
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function recordBackupSuccess(timestampMs: number = Date.now()): void {
  if (typeof window !== 'undefined') {
    try {
      window.localStorage.setItem(LAST_BACKUP_KEY, String(timestampMs));
    } catch {
      // Ignore localStorage failure
    }
  }
  notify();
}

export function initBackupTracking(): void {
  ensureFirstUsedAt();
  notify();
}

export function refreshBackupStatus(): void {
  notify();
}

export function useBackupStatus(): BackupMetaSnapshot {
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
}
