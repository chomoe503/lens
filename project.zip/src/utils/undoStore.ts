import { useSyncExternalStore } from 'react';
import { restoreDeletedData, type DeletedBackupPayload } from '../db/repositories';

export interface UndoEntry {
  id: string;
  message: string;
  payload?: DeletedBackupPayload;
  onUndo?: () => Promise<void>;
  remainingSeconds: number;
}

type Listener = () => void;

const UNDO_DURATION_SECONDS = 12;
const listeners = new Set<Listener>();
let currentEntry: UndoEntry | null = null;
let timerId: ReturnType<typeof setInterval> | null = null;

function notify(): void {
  listeners.forEach((l) => l());
}

function stopTimer(): void {
  if (timerId !== null) {
    clearInterval(timerId);
    timerId = null;
  }
}

function startUndoEntry(
  message: string,
  options: { payload?: DeletedBackupPayload; onUndo?: () => Promise<void> }
): void {
  stopTimer();
  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  currentEntry = {
    id,
    message,
    payload: options.payload,
    onUndo: options.onUndo,
    remainingSeconds: UNDO_DURATION_SECONDS,
  };
  notify();

  timerId = setInterval(() => {
    if (!currentEntry || currentEntry.id !== id) {
      stopTimer();
      return;
    }
    const nextSec = currentEntry.remainingSeconds - 1;
    if (nextSec <= 0) {
      currentEntry = null;
      stopTimer();
    } else {
      currentEntry = { ...currentEntry, remainingSeconds: nextSec };
    }
    notify();
  }, 1000);
}

export function pushUndoAction(
  message: string,
  payload: DeletedBackupPayload
): void {
  startUndoEntry(message, { payload });
}

export function pushUndoCustomAction(
  message: string,
  onUndo: () => Promise<void>
): void {
  startUndoEntry(message, { onUndo });
}

export function dismissUndoAction(): void {
  stopTimer();
  currentEntry = null;
  notify();
}

export async function executeUndoAction(): Promise<boolean> {
  const target = currentEntry;
  if (!target) return false;
  stopTimer();
  currentEntry = null;
  notify();
  if (target.onUndo) {
    await target.onUndo();
  } else if (target.payload) {
    await restoreDeletedData(target.payload);
  }
  return true;
}

function subscribe(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function getSnapshot(): UndoEntry | null {
  return currentEntry;
}

export function useUndoBanner() {
  const entry = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
  return {
    entry,
    undo: executeUndoAction,
    dismiss: dismissUndoAction,
  };
}
