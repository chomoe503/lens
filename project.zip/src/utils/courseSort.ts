import type { Course } from '../db/types';

const GRADE_RANK_RULES: Array<{ prefix: string; rank: number }> = [
  { prefix: '小一', rank: 1 },
  { prefix: '小二', rank: 2 },
  { prefix: '小三', rank: 3 },
  { prefix: '小四', rank: 4 },
  { prefix: '小五', rank: 5 },
  { prefix: '小六', rank: 6 },
  { prefix: '國一', rank: 7 },
  { prefix: '七年級', rank: 7 },
  { prefix: '國二', rank: 8 },
  { prefix: '八年級', rank: 8 },
  { prefix: '國三', rank: 9 },
  { prefix: '九年級', rank: 9 },
  { prefix: '高一', rank: 10 },
  { prefix: '高二', rank: 11 },
  { prefix: '高三', rank: 12 },
];

export const QUICK_GRADES = ['國一', '國二', '國三', '高一', '高二', '高三'] as const;
export const QUICK_CLASSES = ['A', 'B', 'C', 'D', 'E', 'F'] as const;

export function getCourseGradeRank(courseName: string): number {
  const trimmed = courseName.trim();
  for (const rule of GRADE_RANK_RULES) {
    if (trimmed.startsWith(rule.prefix)) {
      return rule.rank;
    }
  }
  return 99;
}

export function compareCoursesByGrade(a: Course, b: Course): number {
  const rankDiff = getCourseGradeRank(a.name) - getCourseGradeRank(b.name);
  if (rankDiff !== 0) {
    return rankDiff;
  }
  return a.name.localeCompare(b.name, 'zh-Hant-TW', { numeric: true });
}

export function parseCourseQuickParts(name: string): {
  grade: string | null;
  classLetter: string | null;
} {
  const trimmed = name.trim();
  const matchedGrade = QUICK_GRADES.find((g) => trimmed.startsWith(g)) ?? null;
  if (!matchedGrade) {
    return { grade: null, classLetter: null };
  }

  const rest = trimmed.slice(matchedGrade.length);
  const classMatch = /^([A-F])班?$/i.exec(rest);
  const classLetter = classMatch ? classMatch[1].toUpperCase() : null;
  return { grade: matchedGrade, classLetter };
}

export function composeCourseName(grade: string | null, classLetter: string | null): string {
  if (grade && classLetter) {
    return `${grade}${classLetter}班`;
  }
  if (grade) {
    return grade;
  }
  if (classLetter) {
    return `${classLetter}班`;
  }
  return '';
}
