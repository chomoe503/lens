export interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export interface PWAInstallState {
  deferredPrompt: BeforeInstallPromptEvent | null;
  hasReceivedInstallPrompt: boolean;
  isInstalled: boolean;
  isIOS: boolean;
}

type Listener = () => void;

const listeners = new Set<Listener>();
let initialized = false;

function detectStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as unknown as { standalone?: boolean }).standalone === true
  );
}

function detectIOS(): boolean {
  if (typeof window === 'undefined') return false;
  return /iphone|ipad|ipod/i.test(window.navigator.userAgent);
}

let state: PWAInstallState = {
  deferredPrompt: null,
  hasReceivedInstallPrompt: false,
  isInstalled: detectStandalone(),
  isIOS: detectIOS(),
};

function notify(): void {
  listeners.forEach((listener) => listener());
}

function setState(partial: Partial<PWAInstallState>): void {
  state = { ...state, ...partial };
  notify();
}

export function initPWAInstallListener(): void {
  if (initialized || typeof window === 'undefined') {
    return;
  }
  initialized = true;

  setState({
    isInstalled: detectStandalone(),
    isIOS: detectIOS(),
  });

  window.addEventListener('beforeinstallprompt', (e: Event) => {
    e.preventDefault();
    setState({
      deferredPrompt: e as BeforeInstallPromptEvent,
      hasReceivedInstallPrompt: true,
    });
  });

  window.addEventListener('appinstalled', () => {
    setState({
      deferredPrompt: null,
      isInstalled: true,
    });
  });

  const mediaQuery = window.matchMedia('(display-mode: standalone)');
  const handleDisplayModeChange = () => {
    setState({ isInstalled: detectStandalone() });
  };
  if (typeof mediaQuery.addEventListener === 'function') {
    mediaQuery.addEventListener('change', handleDisplayModeChange);
  }
}

export function getPWAInstallState(): PWAInstallState {
  return state;
}

export function subscribePWAInstall(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export async function triggerPWAInstall(): Promise<boolean> {
  const promptEvent = state.deferredPrompt;
  if (!promptEvent) {
    return false;
  }

  await promptEvent.prompt();
  const { outcome } = await promptEvent.userChoice;
  if (outcome === 'accepted') {
    setState({
      deferredPrompt: null,
      isInstalled: true,
    });
    return true;
  }

  setState({ deferredPrompt: null });
  return false;
}
