import type { ClassSession, TaskItem } from '../db/types';
import { timeToMinutes, toDateKey } from './date';

export type TaskPlacementOrigin = 'session' | 'course_next';

export interface PlacedTaskEntry {
  task: TaskItem;
  origin: TaskPlacementOrigin;
}

export interface PlaceTasksInput {
  tasks: TaskItem[];
  sessions: ClassSession[];
  now: Date;
}

export interface TaskPlacementResult {
  todayKey: string;
  nowMinutes: number;
  tasksBySessionId: Record<string, PlacedTaskEntry[]>;
  otherTasksByDate: Record<string, TaskItem[]>;
  overdueTodos: TaskItem[];
  unscheduledTasks: TaskItem[];
  nextSessionIdByCourseId: Record<string, string>;
  sessionIdByTaskId: Record<string, string>;
}

function getSessionEndMinutes(session: ClassSession): number {
  const start = timeToMinutes(session.startTime);
  const end = timeToMinutes(session.endTime);
  return end > start ? end : start + 45;
}

export function hasSessionEnded(
  session: Pick<ClassSession, 'date' | 'startTime' | 'endTime'>,
  now: Date
): boolean {
  const todayKey = toDateKey(now);
  if (session.date < todayKey) return true;
  if (session.date > todayKey) return false;
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  const start = timeToMinutes(session.startTime);
  const end = timeToMinutes(session.endTime);
  const effectiveEnd = end > start ? end : start + 45;
  return effectiveEnd <= nowMinutes;
}

function compareTasks(a: TaskItem, b: TaskItem): number {
  const doneDiff = Number(a.done) - Number(b.done);
  if (doneDiff !== 0) return doneDiff;

  const typeDiff = Number(a.type === 'reminder') - Number(b.type === 'reminder');
  if (typeDiff !== 0) return typeDiff;

  if (a.dueTime && b.dueTime) {
    const timeDiff = a.dueTime.localeCompare(b.dueTime);
    if (timeDiff !== 0) return timeDiff;
  } else if (a.dueTime || b.dueTime) {
    return a.dueTime ? -1 : 1;
  }

  return a.createdAt - b.createdAt;
}

function isCancelled(session: Pick<ClassSession, 'status'>): boolean {
  return session.status === 'cancelled';
}

export function getEffectiveTaskDate(
  task: TaskItem,
  sessionMap: Map<string, ClassSession>,
  nextSessionIdByCourseId: Record<string, string>
): string | undefined {
  if (task.dueDate) {
    return task.dueDate;
  }

  if (task.sessionId) {
    const direct = sessionMap.get(task.sessionId);
    if (direct && !isCancelled(direct)) {
      return direct.date;
    }
  }

  if (task.courseId) {
    const nextId = nextSessionIdByCourseId[task.courseId];
    if (nextId) {
      const nextSession = sessionMap.get(nextId);
      if (nextSession) {
        return nextSession.date;
      }
    }
  }

  return undefined;
}

/**
 * 純函式任務放置引擎（不依賴 React 與 Dexie）：
 * 1. 有 sessionId：顯示在該堂；若已取消或已刪除，視同只掛在班級（courseId）。
 * 2. 只有 courseId：顯示在該班級「今天還沒結束或之後、未取消」的下一堂；未打勾前持續跟隨。
 * 3. 都沒有或找不到下一堂：有 dueDate 則顯示在該日「其他任務」，否則只顯示於「全部任務」。
 * 4. 已打勾的待辦僅在直接掛在該場次時於時間軸保留（灰字刪除線）。
 */
export function placeTasks({
  tasks,
  sessions,
  now,
}: PlaceTasksInput): TaskPlacementResult {
  const todayKey = toDateKey(now);
  const nowMinutes = now.getHours() * 60 + now.getMinutes();

  const sessionMap = new Map<string, ClassSession>();
  for (const s of sessions) {
    sessionMap.set(s.id, s);
  }

  // 找出每個非系統課程的「下一堂（今天還沒結束或之後、未取消）」
  const nextSessionByCourseId = new Map<string, ClassSession>();
  for (const s of sessions) {
    if (!s.courseId || s.kind === 'substitute' || isCancelled(s)) continue;

    const isUpcoming =
      s.date > todayKey ||
      (s.date === todayKey && getSessionEndMinutes(s) > nowMinutes);
    if (!isUpcoming) continue;

    const existing = nextSessionByCourseId.get(s.courseId);
    if (!existing) {
      nextSessionByCourseId.set(s.courseId, s);
      continue;
    }

    const dateDiff = s.date.localeCompare(existing.date);
    if (
      dateDiff < 0 ||
      (dateDiff === 0 && s.startTime.localeCompare(existing.startTime) < 0)
    ) {
      nextSessionByCourseId.set(s.courseId, s);
    }
  }

  const nextSessionIdByCourseId: Record<string, string> = {};
  for (const [courseId, s] of nextSessionByCourseId.entries()) {
    nextSessionIdByCourseId[courseId] = s.id;
  }

  const tasksBySessionId: Record<string, PlacedTaskEntry[]> = {};
  const otherTasksByDate: Record<string, TaskItem[]> = {};
  const overdueTodos: TaskItem[] = [];
  const unscheduledTasks: TaskItem[] = [];
  const sessionIdByTaskId: Record<string, string> = {};

  for (const task of tasks) {
    const directSession = task.sessionId ? sessionMap.get(task.sessionId) : undefined;
    const isDirectSessionActive =
      Boolean(directSession) && !isCancelled(directSession!);

    // 1. 直接掛在有效場次
    if (isDirectSessionActive && directSession) {
      const list = tasksBySessionId[directSession.id] ?? [];
      list.push({ task, origin: 'session' });
      tasksBySessionId[directSession.id] = list;
      sessionIdByTaskId[task.id] = directSession.id;

      if (task.type === 'todo' && !task.done) {
        const effectiveDate = task.dueDate ?? directSession.date;
        if (effectiveDate < todayKey) {
          overdueTodos.push(task);
        }
      }
      continue;
    }

    // 已打勾的待辦若沒直接掛在有效場次，不顯示於時間軸/格狀圖/其他任務/逾期
    if (task.done) {
      continue;
    }

    // 2. 只有 courseId，或原 sessionId 已取消／已刪除（非代課場次）
    const fallbackCourseId =
      task.courseId ??
      (directSession && directSession.kind !== 'substitute'
        ? directSession.courseId
        : undefined);

    if (fallbackCourseId) {
      const nextSession = nextSessionByCourseId.get(fallbackCourseId);
      if (nextSession) {
        const list = tasksBySessionId[nextSession.id] ?? [];
        list.push({ task, origin: 'course_next' });
        tasksBySessionId[nextSession.id] = list;
        sessionIdByTaskId[task.id] = nextSession.id;

        if (task.type === 'todo' && task.dueDate && task.dueDate < todayKey) {
          overdueTodos.push(task);
        }
        continue;
      }
    }

    // 3. 沒掛到場次（或課程已無下一堂課）：有 dueDate 歸為該日「其他任務」
    if (task.dueDate) {
      const dateList = otherTasksByDate[task.dueDate] ?? [];
      dateList.push(task);
      otherTasksByDate[task.dueDate] = dateList;

      if (task.type === 'todo' && task.dueDate < todayKey) {
        overdueTodos.push(task);
      }
      continue;
    }

    // 4. 沒有日期也沒有掛到場次 -> 只出現在「全部任務」
    unscheduledTasks.push(task);
  }

  for (const sessionId of Object.keys(tasksBySessionId)) {
    tasksBySessionId[sessionId].sort((a, b) => compareTasks(a.task, b.task));
  }
  for (const dateKey of Object.keys(otherTasksByDate)) {
    otherTasksByDate[dateKey].sort(compareTasks);
  }

  overdueTodos.sort((a, b) => {
    const dateA =
      getEffectiveTaskDate(a, sessionMap, nextSessionIdByCourseId) ?? '';
    const dateB =
      getEffectiveTaskDate(b, sessionMap, nextSessionIdByCourseId) ?? '';
    const dateDiff = dateA.localeCompare(dateB);
    if (dateDiff !== 0) return dateDiff;
    return compareTasks(a, b);
  });

  unscheduledTasks.sort(compareTasks);

  return {
    todayKey,
    nowMinutes,
    tasksBySessionId,
    otherTasksByDate,
    overdueTodos,
    unscheduledTasks,
    nextSessionIdByCourseId,
    sessionIdByTaskId,
  };
}
