const MAX_MAIN_EDGE_PX = 1280;
const MAIN_JPEG_QUALITY = 0.7;

const MAX_THUMB_EDGE_PX = 320;
const THUMB_JPEG_QUALITY = 0.65;

export interface CompressedImageResult {
  blob: Blob;
  thumbnailBlob: Blob;
  fileName: string;
  mimeType: string;
}

function fitDimensions(
  srcWidth: number,
  srcHeight: number,
  maxEdge: number
): { width: number; height: number } {
  if (srcWidth <= 0 || srcHeight <= 0) {
    return { width: maxEdge, height: maxEdge };
  }
  const longest = Math.max(srcWidth, srcHeight);
  if (longest <= maxEdge) {
    return { width: srcWidth, height: srcHeight };
  }
  const scale = maxEdge / longest;
  return {
    width: Math.max(1, Math.round(srcWidth * scale)),
    height: Math.max(1, Math.round(srcHeight * scale)),
  };
}

function canvasToJpegBlob(
  canvas: HTMLCanvasElement,
  quality: number
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) {
          resolve(blob);
        } else {
          reject(new Error('圖片壓縮失敗，請嘗試其他圖片格式。'));
        }
      },
      'image/jpeg',
      quality
    );
  });
}

function drawResizedJpeg(
  source: CanvasImageSource,
  srcWidth: number,
  srcHeight: number,
  maxEdge: number,
  quality: number
): Promise<Blob> {
  const { width, height } = fitDimensions(srcWidth, srcHeight, maxEdge);
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('瀏覽器不支援畫布壓縮功能。');
  }

  // Fill white background so transparent PNG/WebP doesn't turn black in JPEG
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(source, 0, 0, width, height);

  return canvasToJpegBlob(canvas, quality);
}

function toJpegFileName(originalName: string): string {
  const dotIndex = originalName.lastIndexOf('.');
  const base = dotIndex > 0 ? originalName.slice(0, dotIndex) : originalName;
  const cleaned = base.trim() || 'photo';
  return `${cleaned}.jpg`;
}

function loadHtmlImage(file: File): Promise<{
  img: HTMLImageElement;
  cleanup: () => void;
}> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      resolve({
        img,
        cleanup: () => URL.revokeObjectURL(url),
      });
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error(`無法讀取圖片「${file.name}」`));
    };
    img.src = url;
  });
}

/**
 * 將圖片壓縮至最長邊 1280 px（JPEG 品質 0.7）並另外產生縮圖（最長邊 320 px）。
 */
export async function compressImageFile(
  file: File
): Promise<CompressedImageResult> {
  if (typeof createImageBitmap === 'function') {
    try {
      const bitmap = await createImageBitmap(file);
      try {
        const blob = await drawResizedJpeg(
          bitmap,
          bitmap.width,
          bitmap.height,
          MAX_MAIN_EDGE_PX,
          MAIN_JPEG_QUALITY
        );
        const thumbnailBlob = await drawResizedJpeg(
          bitmap,
          bitmap.width,
          bitmap.height,
          MAX_THUMB_EDGE_PX,
          THUMB_JPEG_QUALITY
        );
        return {
          blob,
          thumbnailBlob,
          fileName: toJpegFileName(file.name),
          mimeType: 'image/jpeg',
        };
      } finally {
        bitmap.close();
      }
    } catch {
      // Fallback cleanly to HTMLImageElement below
    }
  }

  const { img, cleanup } = await loadHtmlImage(file);
  try {
    const srcWidth = img.naturalWidth || img.width;
    const srcHeight = img.naturalHeight || img.height;
    const blob = await drawResizedJpeg(
      img,
      srcWidth,
      srcHeight,
      MAX_MAIN_EDGE_PX,
      MAIN_JPEG_QUALITY
    );
    const thumbnailBlob = await drawResizedJpeg(
      img,
      srcWidth,
      srcHeight,
      MAX_THUMB_EDGE_PX,
      THUMB_JPEG_QUALITY
    );
    return {
      blob,
      thumbnailBlob,
      fileName: toJpegFileName(file.name),
      mimeType: 'image/jpeg',
    };
  } finally {
    cleanup();
  }
}
