import { useEffect, useRef, useState } from 'react';
import { registerSW } from 'virtual:pwa-register';
import { isNativeApp } from './platform';

export function usePWAUpdate() {
  const [needRefresh, setNeedRefresh] = useState(false);
  const updateSWRef = useRef<((reloadPage?: boolean) => Promise<void>) | null>(null);

  useEffect(() => {
    if (isNativeApp) return;
    const updateSW = registerSW({
      immediate: true,
      onNeedRefresh() {
        setNeedRefresh(true);
      },
    });
    updateSWRef.current = updateSW;
  }, []);

  const applyUpdate = () => {
    if (updateSWRef.current) {
      void updateSWRef.current(true);
    }
  };

  return {
    needRefresh,
    applyUpdate,
  };
}
