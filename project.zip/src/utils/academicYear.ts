export interface AcademicYearTemplate {
  name: string;
  startDate: string;
  endDate: string;
}

/**
 * 依指定日期推算目前民國學年度與上下學期：
 * - 8 月至 12 月：當年度（西元年 - 1911）上學期（8/1 ~ 隔年 1/31）
 * - 1 月：前一學年度（西元年 - 1 - 1911）上學期（前一年 8/1 ~ 當年 1/31）
 * - 2 月至 7 月：前一學年度（西元年 - 1 - 1911）下學期（當年 2/1 ~ 當年 7/31）
 */
export function getCurrentTaiwanAcademicYearTemplate(
  date: Date = new Date()
): AcademicYearTemplate {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;

  if (month >= 8) {
    const rocYear = year - 1911;
    return {
      name: `${rocYear} 學年度上學期`,
      startDate: `${year}-08-01`,
      endDate: `${year + 1}-01-31`,
    };
  }

  if (month === 1) {
    const rocYear = year - 1 - 1911;
    return {
      name: `${rocYear} 學年度上學期`,
      startDate: `${year - 1}-08-01`,
      endDate: `${year}-01-31`,
    };
  }

  const rocYear = year - 1 - 1911;
  return {
    name: `${rocYear} 學年度下學期`,
    startDate: `${year}-02-01`,
    endDate: `${year}-07-31`,
  };
}
