import { Directory, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

// Multiple of 3 bytes so every base64 chunk is independently valid and can be appended.
const CHUNK_BYTES = 3 * 1024 * 1024;
const BACKUP_DIR = 'backup';

function blobSliceToBase64(slice: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error ?? new Error('讀取備份資料失敗'));
    reader.onload = () => {
      const result = String(reader.result ?? '');
      const comma = result.indexOf(',');
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.readAsDataURL(slice);
  });
}

/**
 * Android app: the WebView cannot save a blob download, so write the file into the app cache
 * (in chunks, photos can make backups large) and open the system share sheet
 * (save to Drive, LINE, Files, ...).
 */
export async function shareBlobAsFileNative(
  blob: Blob,
  fileName: string
): Promise<'shared' | 'cancelled'> {
  try {
    await Filesystem.rmdir({
      path: BACKUP_DIR,
      directory: Directory.Cache,
      recursive: true,
    });
  } catch {
    // nothing to clean up
  }

  const path = `${BACKUP_DIR}/${fileName}`;
  let offset = 0;
  let isFirst = true;

  while (isFirst || offset < blob.size) {
    const data = await blobSliceToBase64(blob.slice(offset, offset + CHUNK_BYTES));
    if (isFirst) {
      await Filesystem.writeFile({
        path,
        directory: Directory.Cache,
        data,
        recursive: true,
      });
      isFirst = false;
    } else {
      await Filesystem.appendFile({ path, directory: Directory.Cache, data });
    }
    offset += CHUNK_BYTES;
  }

  const { uri } = await Filesystem.getUri({ path, directory: Directory.Cache });

  try {
    await Share.share({
      title: fileName,
      dialogTitle: '儲存備份檔',
      url: uri,
    });
    return 'shared';
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (/cancel/i.test(message)) {
      return 'cancelled';
    }
    throw error;
  }
}
