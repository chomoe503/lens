import { useEffect, useState } from 'react';

const NON_KEYBOARD_INPUT_TYPES = new Set([
  'checkbox',
  'radio',
  'button',
  'submit',
  'reset',
  'file',
  'color',
  'range',
  'hidden',
  'image',
]);

function isTextInputElement(el: EventTarget | null): el is HTMLElement {
  if (!(el instanceof HTMLElement)) return false;
  if (el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') return true;
  if (el.tagName === 'INPUT') {
    const type = (el as HTMLInputElement).type?.toLowerCase() ?? 'text';
    return !NON_KEYBOARD_INPUT_TYPES.has(type);
  }
  return el.isContentEditable;
}

function isEditableTextEntry(el: EventTarget | null): el is HTMLElement {
  if (!(el instanceof HTMLElement)) return false;
  if (el.tagName === 'TEXTAREA') return true;
  if (el.tagName === 'INPUT') {
    const type = (el as HTMLInputElement).type?.toLowerCase() ?? 'text';
    return !NON_KEYBOARD_INPUT_TYPES.has(type);
  }
  return el.isContentEditable;
}

function scrollFocusedElementIntoView(target: HTMLElement | null) {
  if (!target || !document.contains(target)) return;
  const vv = window.visualViewport;
  const visibleTop = vv ? vv.offsetTop + 56 : 56;
  const visibleBottom = vv ? vv.offsetTop + vv.height - 24 : window.innerHeight - 24;
  const rect = target.getBoundingClientRect();

  if (rect.top < visibleTop || rect.bottom > visibleBottom) {
    target.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
}

type Listener = () => void;
const listeners = new Set<Listener>();
let currentKeyboardActive = false;

function notifyKeyboardListeners(next: boolean) {
  if (currentKeyboardActive === next) return;
  currentKeyboardActive = next;
  for (const listener of listeners) {
    listener();
  }
}

/**
 * Installs global mobile virtual-keyboard listeners once in App:
 * - Updates `--kb-inset` when visualViewport shrinks (handles iOS Safari & Android).
 * - Tracks `isKeyboardActive` so fixed bottom nav / FABs never cover focused inputs.
 * - Smoothly scrolls focused inputs into the visible area above the keyboard.
 */
export function useKeyboardCoordinator(): boolean {
  const [keyboardActive, setKeyboardActive] = useState(currentKeyboardActive);

  useEffect(() => {
    const syncState = () => setKeyboardActive(currentKeyboardActive);
    listeners.add(syncState);

    let focusTimer1: number | null = null;
    let focusTimer2: number | null = null;
    let blurTimer: number | null = null;

    const clearTimers = () => {
      if (focusTimer1 !== null) window.clearTimeout(focusTimer1);
      if (focusTimer2 !== null) window.clearTimeout(focusTimer2);
      if (blurTimer !== null) window.clearTimeout(blurTimer);
      focusTimer1 = null;
      focusTimer2 = null;
      blurTimer = null;
    };

    const updateViewportMetrics = () => {
      const vv = window.visualViewport;
      const activeEl = document.activeElement;
      const inputFocused = isEditableTextEntry(activeEl);
      const isCoarsePointer =
        typeof window.matchMedia === 'function' &&
        window.matchMedia('(pointer: coarse)').matches;

      let viewportShrunk = false;
      let kbInsetPx = 0;

      if (vv) {
        const diff = window.innerHeight - vv.height - vv.offsetTop;
        if (window.innerHeight - vv.height > 110) {
          viewportShrunk = true;
          kbInsetPx = Math.max(0, Math.round(diff));
        }
      }

      document.documentElement.style.setProperty('--kb-inset', `${kbInsetPx}px`);
      notifyKeyboardListeners(viewportShrunk || (isCoarsePointer && inputFocused));

      if (viewportShrunk && isTextInputElement(activeEl)) {
        scrollFocusedElementIntoView(activeEl);
      }
    };

    const handleFocusIn = (e: FocusEvent) => {
      if (blurTimer !== null) {
        window.clearTimeout(blurTimer);
        blurTimer = null;
      }

      const target = e.target;
      if (!isTextInputElement(target)) {
        updateViewportMetrics();
        return;
      }

      updateViewportMetrics();

      if (focusTimer1 !== null) window.clearTimeout(focusTimer1);
      if (focusTimer2 !== null) window.clearTimeout(focusTimer2);

      focusTimer1 = window.setTimeout(() => {
        scrollFocusedElementIntoView(target);
      }, 150);
      focusTimer2 = window.setTimeout(() => {
        updateViewportMetrics();
        scrollFocusedElementIntoView(target);
      }, 360);
    };

    const handleFocusOut = () => {
      if (blurTimer !== null) window.clearTimeout(blurTimer);
      blurTimer = window.setTimeout(() => {
        updateViewportMetrics();
      }, 120);
    };

    document.addEventListener('focusin', handleFocusIn, true);
    document.addEventListener('focusout', handleFocusOut, true);
    window.visualViewport?.addEventListener('resize', updateViewportMetrics);
    window.visualViewport?.addEventListener('scroll', updateViewportMetrics);
    window.addEventListener('resize', updateViewportMetrics);

    updateViewportMetrics();

    return () => {
      clearTimers();
      listeners.delete(syncState);
      document.removeEventListener('focusin', handleFocusIn, true);
      document.removeEventListener('focusout', handleFocusOut, true);
      window.visualViewport?.removeEventListener('resize', updateViewportMetrics);
      window.visualViewport?.removeEventListener('scroll', updateViewportMetrics);
      window.removeEventListener('resize', updateViewportMetrics);
      document.documentElement.style.setProperty('--kb-inset', '0px');
    };
  }, []);

  return keyboardActive;
}

export function useIsKeyboardActive(): boolean {
  const [active, setActive] = useState(currentKeyboardActive);

  useEffect(() => {
    const sync = () => setActive(currentKeyboardActive);
    listeners.add(sync);
    setActive(currentKeyboardActive);
    return () => {
      listeners.delete(sync);
    };
  }, []);

  return active;
}
