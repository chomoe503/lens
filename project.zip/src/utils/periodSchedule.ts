import type { Period } from '../db/types';
import { doTimeRangesOverlap, minutesToTime, timeToMinutes } from './date';
import { createId } from './id';

export interface QuickGeneratePeriodsParams {
  organizationId: string;
  startTime: string;
  periodDuration: number;
  breakDuration: number;
  count: number;
  lunchEnabled: boolean;
  lunchAfterPeriod: number;
  lunchDuration: number;
}

export function generatePeriodsSchedule(
  params: QuickGeneratePeriodsParams
): { periods: Period[]; overflowsMidnight: boolean } {
  const now = Date.now();
  const safeCount = Math.max(1, Math.min(20, Math.round(params.count)));
  const safePeriodDuration = Math.max(1, Math.min(360, Math.round(params.periodDuration)));
  const safeBreakDuration = Math.max(0, Math.min(180, Math.round(params.breakDuration)));
  const safeLunchDuration = Math.max(0, Math.min(240, Math.round(params.lunchDuration)));
  const startMins = timeToMinutes(params.startTime || '08:30');

  let cursor = startMins;
  let overflowsMidnight = false;
  const periods: Period[] = [];

  for (let i = 1; i <= safeCount; i++) {
    const pStart = cursor;
    const pEnd = pStart + safePeriodDuration;

    if (pStart > 23 * 60 + 59 || pEnd > 23 * 60 + 59) {
      overflowsMidnight = true;
    }

    periods.push({
      id: createId(),
      organizationId: params.organizationId,
      name: `第${i}節`,
      startTime: minutesToTime(pStart),
      endTime: minutesToTime(pEnd),
      sortOrder: i - 1,
      createdAt: now + i,
      updatedAt: now + i,
    });

    if (i < safeCount) {
      const gap =
        params.lunchEnabled && i === params.lunchAfterPeriod
          ? safeLunchDuration
          : safeBreakDuration;
      cursor = pEnd + gap;
    }
  }

  return { periods, overflowsMidnight };
}

export function shiftTimeMinutes(hhmm: string, deltaMinutes: number): string {
  return minutesToTime(timeToMinutes(hhmm) + deltaMinutes);
}

export function canShiftTimeMinutes(hhmm: string, deltaMinutes: number): boolean {
  if (!/^\d{2}:\d{2}$/.test(hhmm)) return false;
  const next = timeToMinutes(hhmm) + deltaMinutes;
  return next >= 0 && next <= 23 * 60 + 59;
}

export function validatePeriodsList(periods: Period[]): Map<string, string> {
  const errors = new Map<string, string>();

  for (let i = 0; i < periods.length; i++) {
    const p = periods[i];
    if (!p.name.trim()) {
      errors.set(p.id, '請輸入節次名稱');
      continue;
    }
    if (!p.startTime || !p.endTime || p.startTime >= p.endTime) {
      errors.set(p.id, '結束時間必須晚於開始時間');
      continue;
    }

    for (let j = 0; j < periods.length; j++) {
      if (i === j) continue;
      const other = periods[j];
      if (!other.startTime || !other.endTime || other.startTime >= other.endTime) {
        continue;
      }
      if (doTimeRangesOverlap(p.startTime, p.endTime, other.startTime, other.endTime)) {
        errors.set(
          p.id,
          `與「${other.name.trim() || `第${j + 1}節`}」（${other.startTime}–${other.endTime}）時間重疊`
        );
        break;
      }
    }
  }

  return errors;
}

export function getNextPeriodName(periods: Period[]): string {
  const nextIndex = periods.length + 1;
  return `第${nextIndex}節`;
}
