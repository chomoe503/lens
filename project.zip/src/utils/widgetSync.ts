import { App as CapacitorApp } from '@capacitor/app';
import { registerPlugin } from '@capacitor/core';
import { db } from '../db/database';
import { isNativeApp } from './platform';
import { buildWidgetSnapshot } from './widgetSnapshot';

/**
 * Android 桌面小工具同步：資料有變動（或回到前景）時，把「接下來 14 天的課、進度、待辦」
 * 整理成一份快照送到原生端；原生端存起來並重畫桌面小工具。網頁版不會做任何事。
 */

interface WidgetBridgePlugin {
  setSnapshot(options: { json: string }): Promise<void>;
}

const WidgetBridge = registerPlugin<WidgetBridgePlugin>('WidgetBridge');

let started = false;
let lastJson = '';
let timer: number | undefined;

async function pushSnapshot(): Promise<void> {
  try {
    const [sessions, courses, organizations, tasks, examPeriods] = await Promise.all([
      db.sessions.toArray(),
      db.courses.toArray(),
      db.organizations.toArray(),
      db.tasks.toArray(),
      db.examPeriods.toArray(),
    ]);
    const snapshot = buildWidgetSnapshot({
      sessions,
      courses,
      organizations,
      tasks,
      examPeriods,
      now: new Date(),
    });
    const json = JSON.stringify(snapshot);
    if (json === lastJson) return;
    await WidgetBridge.setSnapshot({ json });
    lastJson = json;
  } catch (error) {
    // 小工具只是附加功能，失敗不影響 App 本身；下次再試
    console.warn('Widget sync failed:', error);
    lastJson = '';
  }
}

function schedulePush(delayMs = 800): void {
  if (timer !== undefined) {
    window.clearTimeout(timer);
  }
  timer = window.setTimeout(() => {
    timer = undefined;
    void pushSnapshot();
  }, delayMs);
}

export function startWidgetSync(): void {
  if (!isNativeApp || started) return;
  started = true;

  const onChange = () => {
    schedulePush();
  };
  for (const table of [db.sessions, db.courses, db.organizations, db.tasks, db.examPeriods]) {
    table.hook('creating', () => {
      onChange();
    });
    table.hook('updating', () => {
      onChange();
    });
    table.hook('deleting', () => {
      onChange();
    });
  }

  void CapacitorApp.addListener('appStateChange', ({ isActive }) => {
    if (isActive) schedulePush(300);
  });
  // 以防萬一（例如整批還原備份時不會觸發 hook）：App 開著時每 10 分鐘對一次，內容沒變就不會送出
  window.setInterval(() => {
    void pushSnapshot();
  }, 10 * 60 * 1000);

  schedulePush(1500);
}
