import { liveQuery } from 'dexie';
import { useEffect, useState } from 'react';

export function useLiveQuery<T>(
  querier: () => Promise<T> | T,
  deps: readonly unknown[] = []
): T | undefined {
  const [value, setValue] = useState<T | undefined>(undefined);

  useEffect(() => {
    let active = true;
    const observable = liveQuery(querier);
    const subscription = observable.subscribe({
      next: (result) => {
        if (active) {
          setValue(result);
        }
      },
      error: (err) => {
        console.error('Dexie liveQuery error:', err);
      },
    });

    return () => {
      active = false;
      subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return value;
}
