import type { ClassSession, Course, Organization } from '../db/types';
import { timeToMinutes } from './date';

export function isSubstituteSession(session: ClassSession): boolean {
  return session.kind === 'substitute';
}

/**
 * 集中判斷場次是否已取消。
 * 既有資料中的 scheduled 與 completed 一律視為正常，僅 cancelled 視為已取消。
 */
export function isSessionCancelled(
  session: Pick<ClassSession, 'status'>
): boolean {
  return session.status === 'cancelled';
}

export function resolveSessionOrgId(
  session: ClassSession,
  courseMap: Map<string, Course>
): string | undefined {
  if (session.kind === 'substitute') {
    return session.organizationId || undefined;
  }
  if (session.organizationId) {
    return session.organizationId;
  }
  const course = session.courseId ? courseMap.get(session.courseId) : undefined;
  return course?.organizationId || undefined;
}

export interface ResolvedSessionDisplay {
  isSubstitute: boolean;
  course?: Course;
  organization?: Organization;
  title: string;
  orgName: string;
  color: string;
  substituteFor?: string;
}

export function resolveSessionDisplay(
  session: ClassSession,
  courseMap: Map<string, Course>,
  orgMap: Map<string, Organization>
): ResolvedSessionDisplay {
  const isSubstitute = session.kind === 'substitute';
  const course = session.courseId ? courseMap.get(session.courseId) : undefined;
  const orgId = resolveSessionOrgId(session, courseMap);
  const organization = orgId ? orgMap.get(orgId) : undefined;

  const title = isSubstitute ? session.title : (course?.name ?? session.title);
  const orgName = organization?.name ?? '未指定單位';
  const color = isSubstitute
    ? (organization?.color ?? '#FDE68A')
    : (course?.color ?? organization?.color ?? '#CDB8FF');
  const substituteFor = isSubstitute
    ? session.substituteFor?.trim() || undefined
    : undefined;

  return {
    isSubstitute,
    course,
    organization,
    title,
    orgName,
    color,
    substituteFor,
  };
}

export function getSessionDurationMinutes(session: ClassSession): number {
  if (!session.startTime || !session.endTime || session.startTime >= session.endTime) {
    return 0;
  }
  return Math.max(0, timeToMinutes(session.endTime) - timeToMinutes(session.startTime));
}

export function formatDurationSummary(totalMinutes: number): string {
  const safe = Math.max(0, Math.round(totalMinutes));
  if (safe === 0) return '0 小時';
  const hours = Math.floor(safe / 60);
  const mins = safe % 60;
  if (hours === 0) return `${mins} 分鐘`;
  if (mins === 0) return `${hours} 小時`;
  return `${hours} 小時 ${mins} 分`;
}
