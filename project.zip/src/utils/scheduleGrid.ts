import type { ClassSession } from '../db/types';
import { timeToMinutes } from './date';

export interface GridPositionedSession {
  session: ClassSession;
  startMinutes: number;
  endMinutes: number;
  laneIndex: number;
  laneCount: number;
}

/**
 * 判斷十六進位色碼是否屬於亮色，決定方塊上文字應使用深色或白色以維持高對比。
 */
export function isLightHexColor(hexColor: string): boolean {
  const cleaned = hexColor.trim().replace(/^#/, '');
  let r = 205;
  let g = 184;
  let b = 255;

  if (cleaned.length === 3) {
    r = Number.parseInt(cleaned[0] + cleaned[0], 16);
    g = Number.parseInt(cleaned[1] + cleaned[1], 16);
    b = Number.parseInt(cleaned[2] + cleaned[2], 16);
  } else if (cleaned.length === 6) {
    r = Number.parseInt(cleaned.slice(0, 2), 16);
    g = Number.parseInt(cleaned.slice(2, 4), 16);
    b = Number.parseInt(cleaned.slice(4, 6), 16);
  }

  if (Number.isNaN(r) || Number.isNaN(g) || Number.isNaN(b)) {
    return true;
  }

  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.58;
}

export function computeWeekGridHours(sessions: ClassSession[]): {
  startHour: number;
  endHour: number;
} {
  let minMinute = 8 * 60;
  let maxMinute = 22 * 60;

  for (const s of sessions) {
    const start = timeToMinutes(s.startTime);
    const rawEnd = timeToMinutes(s.endTime);
    const end = rawEnd > start ? rawEnd : start + 45;
    if (start < minMinute) minMinute = start;
    if (end > maxMinute) maxMinute = end;
  }

  const startHour = Math.max(0, Math.floor(minMinute / 60));
  const endHour = Math.min(24, Math.max(startHour + 1, Math.ceil(maxMinute / 60)));

  return { startHour, endHour };
}

/**
 * 將單日內的場次依時間重疊群組分配水平欄位（lane），確保重疊時段並排顯示不互相遮擋。
 */
export function layoutDaySessionsForGrid(
  daySessions: ClassSession[]
): GridPositionedSession[] {
  if (daySessions.length === 0) return [];

  const sorted = [...daySessions].sort((a, b) => {
    const startDiff = timeToMinutes(a.startTime) - timeToMinutes(b.startTime);
    if (startDiff !== 0) return startDiff;
    return timeToMinutes(a.endTime) - timeToMinutes(b.endTime);
  });

  const normalized = sorted.map((session) => {
    const startMinutes = timeToMinutes(session.startTime);
    const rawEnd = timeToMinutes(session.endTime);
    const endMinutes = rawEnd > startMinutes ? rawEnd : startMinutes + 30;
    return { session, startMinutes, endMinutes };
  });

  // Partition into overlap-connected clusters
  const clusters: Array<typeof normalized> = [];
  let currentCluster: typeof normalized = [];
  let clusterMaxEnd = -1;

  for (const item of normalized) {
    if (currentCluster.length === 0 || item.startMinutes < clusterMaxEnd) {
      currentCluster.push(item);
      if (item.endMinutes > clusterMaxEnd) {
        clusterMaxEnd = item.endMinutes;
      }
    } else {
      clusters.push(currentCluster);
      currentCluster = [item];
      clusterMaxEnd = item.endMinutes;
    }
  }
  if (currentCluster.length > 0) {
    clusters.push(currentCluster);
  }

  const result: GridPositionedSession[] = [];

  for (const cluster of clusters) {
    const laneEndTimes: number[] = [];
    const assigned: Array<{
      item: (typeof normalized)[number];
      laneIndex: number;
    }> = [];

    for (const item of cluster) {
      let laneIndex = laneEndTimes.findIndex((endMin) => endMin <= item.startMinutes);
      if (laneIndex === -1) {
        laneIndex = laneEndTimes.length;
        laneEndTimes.push(item.endMinutes);
      } else {
        laneEndTimes[laneIndex] = item.endMinutes;
      }
      assigned.push({ item, laneIndex });
    }

    const laneCount = Math.max(1, laneEndTimes.length);
    for (const entry of assigned) {
      result.push({
        session: entry.item.session,
        startMinutes: entry.item.startMinutes,
        endMinutes: entry.item.endMinutes,
        laneIndex: entry.laneIndex,
        laneCount,
      });
    }
  }

  return result;
}
