import { useSyncExternalStore } from 'react';
import {
  getPWAInstallState,
  subscribePWAInstall,
  triggerPWAInstall,
} from './pwaInstallStore';

export function usePWAInstall() {
  const state = useSyncExternalStore(
    subscribePWAInstall,
    getPWAInstallState,
    getPWAInstallState
  );

  return {
    isInstallable: state.deferredPrompt !== null,
    hasReceivedInstallPrompt: state.hasReceivedInstallPrompt,
    isInstalled: state.isInstalled,
    isIOS: state.isIOS,
    install: triggerPWAInstall,
  };
}
