import { Capacitor } from '@capacitor/core';

/**
 * true when running inside the Android app (Capacitor), false in a normal browser / PWA.
 * Web-only features (service worker, install prompt, persistent-storage request) are skipped in the app.
 */
export const isNativeApp: boolean = (() => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
})();
