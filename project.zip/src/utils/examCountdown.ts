import type {
  ClassSession,
  Course,
  ExamPeriod,
  ExamPeriodKind,
  Organization,
} from '../db/types';
import { hasSessionEnded } from './taskPlacement';

export const COUNTDOWN_MAX_SESSIONS = 5;
export const COUNTDOWN_MAX_DAYS = 21;
export const COUNTDOWN_MAX_LATER = 5;

export const EXAM_KIND_LABELS: Record<ExamPeriodKind, string> = {
  midterm: '段考',
  final: '期末考',
  mock: '模考',
  other: '其他',
};

export interface SessionCountdownBrief {
  examPeriodId: string;
  title: string;
  sessionsLeft: number;
  isLast: boolean;
  daysLeft: number;
  targetDate: string;
}

export interface SessionCountdown {
  examPeriodId: string;
  title: string;
  kind: ExamPeriodKind;
  organizationId?: string;
  sessionsLeft: number;
  isLast: boolean;
  daysLeft: number;
  targetDate: string;
  later: SessionCountdownBrief[];
}

export interface CourseCountdownRow {
  courseId: string;
  sessionsLeft: number;
  nextSessionDate?: string;
}

export type ExamPeriodStatus = 'ongoing' | 'upcoming' | 'ended';

function isValidRegularCourse(course: Course): boolean {
  return !course.isSystem;
}

function isCountableSession(session: ClassSession): boolean {
  return (
    session.status !== 'cancelled' &&
    session.kind !== 'substitute' &&
    Boolean(session.courseId)
  );
}

export function diffDateKeys(fromDateKey: string, toDateKeyStr: string): number {
  const [fy, fm, fd] = fromDateKey.split('-').map((n) => Number.parseInt(n, 10));
  const [ty, tm, td] = toDateKeyStr.split('-').map((n) => Number.parseInt(n, 10));
  const fromUtc = Date.UTC(fy || 1970, (fm || 1) - 1, fd || 1);
  const toUtc = Date.UTC(ty || 1970, (tm || 1) - 1, td || 1);
  return Math.round((toUtc - fromUtc) / 86400000);
}

export function getExamTargetDate(
  period: Pick<ExamPeriod, 'startDate' | 'subjectDate'>
): string {
  const trimmedSubject = period.subjectDate?.trim();
  return trimmedSubject || period.startDate;
}

export function getExamPeriodStatus(
  period: Pick<ExamPeriod, 'startDate' | 'endDate'>,
  todayKey: string
): ExamPeriodStatus {
  if (period.endDate < todayKey) return 'ended';
  if (period.startDate <= todayKey && todayKey <= period.endDate) return 'ongoing';
  return 'upcoming';
}

export function getExamDisplayTitle(
  period: Pick<ExamPeriod, 'title' | 'organizationId' | 'studentSchoolId'>,
  organizations: Organization[]
): string {
  if (period.organizationId && period.studentSchoolId) {
    const org = organizations.find((o) => o.id === period.organizationId);
    const school = org?.studentSchools?.find(
      (s) => s.id === period.studentSchoolId
    );
    if (school) {
      return `${school.name} ${period.title}`;
    }
  }
  return period.title;
}

export function resolveExamCourseIds(
  period: Pick<
    ExamPeriod,
    'organizationId' | 'appliesToAll' | 'courseIds' | 'studentSchoolId'
  >,
  courses: Course[]
): Set<string> {
  const validCourses = courses.filter(isValidRegularCourse);

  if (period.organizationId && period.appliesToAll) {
    const result = new Set<string>();
    for (const c of validCourses) {
      if (c.organizationId !== period.organizationId) continue;
      if (period.studentSchoolId) {
        if (
          c.studentSchoolIds === undefined ||
          c.studentSchoolIds.includes(period.studentSchoolId)
        ) {
          result.add(c.id);
        }
      } else {
        result.add(c.id);
      }
    }
    return result;
  }

  const validCourseIdSet = new Set(validCourses.map((c) => c.id));
  const result = new Set<string>();
  for (const id of period.courseIds) {
    if (validCourseIdSet.has(id)) {
      result.add(id);
    }
  }
  return result;
}

function countSessionsBeforeExam(
  session: ClassSession,
  courseSessions: ClassSession[],
  targetDate: string
): number {
  let sessionsLeft = 0;
  for (const candidate of courseSessions) {
    if (candidate.date >= targetDate) break;
    if (
      candidate.date > session.date ||
      (candidate.date === session.date && candidate.startTime >= session.startTime)
    ) {
      sessionsLeft += 1;
    }
  }
  return sessionsLeft;
}

export function computeSessionCountdowns({
  examPeriods,
  sessions,
  courses,
  organizations,
}: {
  examPeriods: ExamPeriod[];
  sessions: ClassSession[];
  courses: Course[];
  organizations: Organization[];
}): Record<string, SessionCountdown> {
  const result: Record<string, SessionCountdown> = {};
  if (examPeriods.length === 0 || sessions.length === 0) {
    return result;
  }

  const periodsPrepared = examPeriods
    .map((period) => ({
      period,
      displayTitle: getExamDisplayTitle(period, organizations),
      targetDate: getExamTargetDate(period),
      courseIdSet: resolveExamCourseIds(period, courses),
    }))
    .filter((entry) => entry.courseIdSet.size > 0 && Boolean(entry.targetDate))
    .sort((a, b) => {
      const targetDiff = a.targetDate.localeCompare(b.targetDate);
      if (targetDiff !== 0) return targetDiff;
      const startDiff = a.period.startDate.localeCompare(b.period.startDate);
      if (startDiff !== 0) return startDiff;
      return a.period.createdAt - b.period.createdAt;
    });

  if (periodsPrepared.length === 0) {
    return result;
  }

  // Group countable sessions by courseId and sort ascending by date + startTime
  const sessionsByCourse = new Map<string, ClassSession[]>();
  for (const s of sessions) {
    if (!isCountableSession(s) || !s.courseId) continue;
    const arr = sessionsByCourse.get(s.courseId) ?? [];
    arr.push(s);
    sessionsByCourse.set(s.courseId, arr);
  }

  for (const list of sessionsByCourse.values()) {
    list.sort((a, b) => {
      const dateDiff = a.date.localeCompare(b.date);
      if (dateDiff !== 0) return dateDiff;
      const startDiff = a.startTime.localeCompare(b.startTime);
      if (startDiff !== 0) return startDiff;
      return a.createdAt - b.createdAt;
    });
  }

  for (const [courseId, courseSessions] of sessionsByCourse.entries()) {
    const applicablePeriods = periodsPrepared.filter((p) =>
      p.courseIdSet.has(courseId)
    );
    if (applicablePeriods.length === 0) continue;

    for (const s of courseSessions) {
      const futurePeriods = applicablePeriods.filter(
        (p) => p.targetDate > s.date
      );
      if (futurePeriods.length === 0) continue;

      const nearest = futurePeriods[0];
      const sessionsLeft = countSessionsBeforeExam(
        s,
        courseSessions,
        nearest.targetDate
      );
      if (sessionsLeft <= 0) continue;

      const daysLeft = diffDateKeys(s.date, nearest.targetDate);
      if (
        sessionsLeft > COUNTDOWN_MAX_SESSIONS &&
        daysLeft > COUNTDOWN_MAX_DAYS
      ) {
        continue;
      }

      const later: SessionCountdownBrief[] = [];
      for (let i = 1; i < futurePeriods.length; i += 1) {
        if (later.length >= COUNTDOWN_MAX_LATER) break;
        const other = futurePeriods[i];
        const otherSessionsLeft = countSessionsBeforeExam(
          s,
          courseSessions,
          other.targetDate
        );
        if (otherSessionsLeft <= 0) continue;

        const otherDaysLeft = diffDateKeys(s.date, other.targetDate);
        if (
          otherSessionsLeft <= COUNTDOWN_MAX_SESSIONS ||
          otherDaysLeft <= COUNTDOWN_MAX_DAYS
        ) {
          later.push({
            examPeriodId: other.period.id,
            title: other.displayTitle,
            sessionsLeft: otherSessionsLeft,
            isLast: otherSessionsLeft === 1,
            daysLeft: otherDaysLeft,
            targetDate: other.targetDate,
          });
        }
      }

      result[s.id] = {
        examPeriodId: nearest.period.id,
        title: nearest.displayTitle,
        kind: nearest.period.kind,
        organizationId: nearest.period.organizationId,
        sessionsLeft,
        isLast: sessionsLeft === 1,
        daysLeft,
        targetDate: nearest.targetDate,
        later,
      };
    }
  }

  return result;
}

export function computeCourseCountdownRows({
  period,
  sessions,
  courses,
  now,
}: {
  period: ExamPeriod;
  sessions: ClassSession[];
  courses: Course[];
  now: Date;
}): CourseCountdownRow[] {
  const targetDate = getExamTargetDate(period);
  const courseIdSet = resolveExamCourseIds(period, courses);
  if (courseIdSet.size === 0) return [];

  const courseNameMap = new Map<string, string>();
  for (const c of courses) {
    courseNameMap.set(c.id, c.name);
  }

  const upcomingByCourse = new Map<string, ClassSession[]>();
  for (const id of courseIdSet) {
    upcomingByCourse.set(id, []);
  }

  for (const s of sessions) {
    if (!isCountableSession(s) || !s.courseId) continue;
    if (!courseIdSet.has(s.courseId)) continue;
    if (s.date >= targetDate) continue;
    if (hasSessionEnded(s, now)) continue;
    upcomingByCourse.get(s.courseId)?.push(s);
  }

  const rows: CourseCountdownRow[] = [];
  for (const [courseId, list] of upcomingByCourse.entries()) {
    list.sort((a, b) => {
      const dateDiff = a.date.localeCompare(b.date);
      if (dateDiff !== 0) return dateDiff;
      return a.startTime.localeCompare(b.startTime);
    });
    rows.push({
      courseId,
      sessionsLeft: list.length,
      nextSessionDate: list[0]?.date,
    });
  }

  rows.sort((a, b) => {
    const countDiff = a.sessionsLeft - b.sessionsLeft;
    if (countDiff !== 0) return countDiff;
    const nameA = courseNameMap.get(a.courseId) ?? '';
    const nameB = courseNameMap.get(b.courseId) ?? '';
    return nameA.localeCompare(nameB, 'zh-Hant');
  });

  return rows;
}
