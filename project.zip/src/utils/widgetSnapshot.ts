import type {
  ClassSession,
  Course,
  ExamPeriod,
  Organization,
  TaskItem,
} from '../db/types';
import { toDateKey } from './date';
import { computeSessionCountdowns } from './examCountdown';
import { isSessionCancelled, resolveSessionDisplay } from './sessionDisplay';
import { placeTasks } from './taskPlacement';

/**
 * 桌面小工具的資料快照（純函式，不依賴 React 與 Dexie）。
 * 原生端只負責顯示：這裡先把「班級名稱、單位、上次進度、每堂課的待辦」全部算好。
 */

export const WIDGET_WINDOW_DAYS = 14;
const MAX_ITEMS_PER_SESSION = 6;
const MAX_OTHERS = 30;

export interface WidgetItemDto {
  title: string;
  kind: 'todo' | 'reminder';
  /** true：直接掛在這一堂；false：掛在班級、因為這是下一堂才顯示在這裡 */
  direct: boolean;
}

/** 這一堂距離下一次考試（同班級）還剩幾堂：與 App 內的「倒數 N 堂」同一套規則 */
export interface WidgetCountdownDto {
  title: string;
  /** 含這一堂在內，考前還有幾堂 */
  sessionsLeft: number;
  isLast: boolean;
  daysLeft: number;
}

export interface WidgetSessionDto {
  id: string;
  /** 代課／臨時場次為空字串 */
  courseId: string;
  date: string; // YYYY-MM-DD
  start: string; // HH:mm
  end: string; // HH:mm
  title: string;
  org: string;
  color: string;
  lastProgress: string;
  /** 上次進度是哪一天那堂課記的 YYYY-MM-DD，沒有進度時為空字串 */
  lastProgressDate: string;
  items: WidgetItemDto[];
  /** 沒有要倒數的考試時省略 */
  countdown?: WidgetCountdownDto;
}

export interface WidgetOtherDto {
  title: string;
  kind: 'todo' | 'reminder';
  date: string; // YYYY-MM-DD
}

export interface WidgetSnapshot {
  version: 1;
  sessions: WidgetSessionDto[];
  others: WidgetOtherDto[];
}

export interface BuildWidgetSnapshotInput {
  sessions: ClassSession[];
  courses: Course[];
  organizations: Organization[];
  tasks: TaskItem[];
  examPeriods: ExamPeriod[];
  now: Date;
}

function clip(text: string | undefined, max: number): string {
  const flat = (text ?? '').replace(/\s+/g, ' ').trim();
  return flat.length > max ? `${flat.slice(0, max - 1)}…` : flat;
}

function addDaysKey(base: Date, days: number): string {
  return toDateKey(
    new Date(base.getFullYear(), base.getMonth(), base.getDate() + days)
  );
}

function sessionStart(session: ClassSession): Date {
  const [y, m, d] = session.date.split('-').map(Number);
  const [hh, mm] = session.startTime.split(':').map(Number);
  return new Date(y || 1970, (m || 1) - 1, d || 1, hh || 0, mm || 0, 0, 0);
}

function compareSessions(a: ClassSession, b: ClassSession): number {
  return (
    a.date.localeCompare(b.date) || a.startTime.localeCompare(b.startTime)
  );
}

export function buildWidgetSnapshot({
  sessions,
  courses,
  organizations,
  tasks,
  examPeriods,
  now,
}: BuildWidgetSnapshotInput): WidgetSnapshot {
  const courseMap = new Map(courses.map((c) => [c.id, c]));
  const orgMap = new Map(organizations.map((o) => [o.id, o]));
  const todayKey = toDateKey(now);
  const endKey = addDaysKey(now, WIDGET_WINDOW_DAYS);

  const sorted = sessions.slice().sort(compareSessions);
  const countdowns = computeSessionCountdowns({
    examPeriods,
    sessions,
    courses,
    organizations,
  });

  // 每一堂「之前」同班級最近一筆有填寫的上課進度
  const lastProgressBefore = new Map<string, { text: string; date: string }>();
  const runningProgress = new Map<string, { text: string; date: string }>();
  for (const s of sorted) {
    if (!s.courseId || s.kind === 'substitute' || isSessionCancelled(s)) continue;
    lastProgressBefore.set(
      s.id,
      runningProgress.get(s.courseId) ?? { text: '', date: '' }
    );
    const progress = s.progress?.trim();
    if (progress) runningProgress.set(s.courseId, { text: progress, date: s.date });
  }

  const openTasks = tasks.filter((t) => !t.done);
  const windowSessions = sorted.filter(
    (s) => !isSessionCancelled(s) && s.date >= todayKey && s.date <= endKey
  );

  const placedTaskIds = new Set<string>();
  const sessionDtos: WidgetSessionDto[] = windowSessions.map((s) => {
    // 以「這堂開始的那一刻」為基準放置任務，小工具之後隨時間切換到這一堂時內容才會正確
    const placement = placeTasks({
      tasks: openTasks,
      sessions,
      now: sessionStart(s),
    });
    const entries = placement.tasksBySessionId[s.id] ?? [];
    const items: WidgetItemDto[] = [];
    for (const entry of entries) {
      placedTaskIds.add(entry.task.id);
      if (items.length >= MAX_ITEMS_PER_SESSION) continue;
      items.push({
        title: clip(entry.task.title, 40),
        kind: entry.task.type === 'reminder' ? 'reminder' : 'todo',
        direct: entry.origin === 'session',
      });
    }

    const display = resolveSessionDisplay(s, courseMap, orgMap);
    const cd = countdowns[s.id];
    return {
      id: s.id,
      courseId: s.kind === 'substitute' ? '' : (s.courseId ?? ''),
      date: s.date,
      start: s.startTime,
      end: s.endTime,
      title: clip(display.title, 30),
      org: clip(display.orgName, 20),
      color: display.color,
      lastProgress: clip(lastProgressBefore.get(s.id)?.text, 100),
      lastProgressDate: lastProgressBefore.get(s.id)?.date ?? '',
      items,
      ...(cd
        ? {
            countdown: {
              title: clip(cd.title, 20),
              sessionsLeft: cd.sessionsLeft,
              isLast: cd.isLast,
              daysLeft: cd.daysLeft,
            },
          }
        : {}),
    };
  });

  // 沒掛在任何一堂課的任務（其他任務、逾期）
  const sessionDateById = new Map(sessions.map((s) => [s.id, s.date]));
  const base = placeTasks({ tasks: openTasks, sessions, now });
  const others: WidgetOtherDto[] = [];
  const otherIds = new Set<string>();
  const pushOther = (task: TaskItem, date: string | undefined) => {
    if (!date || date > endKey || otherIds.has(task.id)) return;
    otherIds.add(task.id);
    others.push({
      title: clip(task.title, 40),
      kind: task.type === 'reminder' ? 'reminder' : 'todo',
      date,
    });
  };

  for (const [date, list] of Object.entries(base.otherTasksByDate)) {
    for (const task of list) pushOther(task, date);
  }
  for (const task of base.overdueTodos) {
    if (placedTaskIds.has(task.id)) continue;
    const date =
      task.dueDate ??
      (task.sessionId ? sessionDateById.get(task.sessionId) : undefined);
    pushOther(task, date);
  }
  others.sort(
    (a, b) => a.date.localeCompare(b.date) || a.title.localeCompare(b.title)
  );

  return {
    version: 1,
    sessions: sessionDtos,
    others: others.slice(0, MAX_OTHERS),
  };
}
