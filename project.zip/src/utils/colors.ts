import type { OrganizationType } from '../db/types';

export const ORGANIZATION_TYPE_LABELS: Record<OrganizationType, string> = {
  school: '學校',
  cram_school: '補習班',
  other: '其他',
};

export const ORG_COLOR_PALETTE = [
  { hex: '#FFB8D1', label: '櫻花粉' },
  { hex: '#FFA3B1', label: '莓果紅' },
  { hex: '#FFA99C', label: '珊瑚' },
  { hex: '#FFBFA3', label: '蜜桃' },
  { hex: '#FFCE9E', label: '杏橘' },
  { hex: '#FFE49A', label: '奶油黃' },
  { hex: '#F3F29E', label: '檸檬' },
  { hex: '#D5F29E', label: '青檸' },
  { hex: '#B8EBB0', label: '抹茶綠' },
  { hex: '#A3EDC4', label: '薄荷' },
  { hex: '#A0EBDC', label: '海沫' },
  { hex: '#A0E4F2', label: '冰藍' },
  { hex: '#A9D6FF', label: '天空藍' },
  { hex: '#B5C4FF', label: '長春藍' },
  { hex: '#CDB8FF', label: '薰衣草' },
  { hex: '#EBB6F2', label: '蘭花紫' },
] as const;

export const DEFAULT_ORG_COLOR = '#CDB8FF';

export function isLightHexColor(hex: string): boolean {
  const clean = hex.replace('#', '').trim();
  if (clean.length !== 6) return true;
  const r = Number.parseInt(clean.slice(0, 2), 16);
  const g = Number.parseInt(clean.slice(2, 4), 16);
  const b = Number.parseInt(clean.slice(4, 6), 16);
  if ([r, g, b].some(Number.isNaN)) return true;
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.62;
}
