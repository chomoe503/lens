import { useEffect, useRef, useSyncExternalStore } from 'react';
import type { NavTabId } from '../db/types';

export interface BackLayerOptions {
  active: boolean;
  zLayer: number;
  onBack: () => void;
}

interface InternalBackLayer {
  id: number;
  zLayer: number;
  seq: number;
  getOnBack: () => () => void;
}

interface HistoryPayload {
  __caApp: true;
  __caRole: 'exit-base' | 'guard' | 'layer';
  __caDepth: number;
  tab: NavTabId;
}

const VALID_TABS: ReadonlySet<NavTabId> = new Set([
  'today',
  'week',
  'courses',
  'more',
]);

const EXIT_PROMPT_DURATION_MS = 2000;

let nextLayerId = 1;
let nextLayerSeq = 1;
const registeredLayers = new Map<number, InternalBackLayer>();
const layerListeners = new Set<() => void>();

let currentTab: NavTabId = 'today';
let tabUpdater: ((tab: NavTabId) => void) | null = null;
let initialized = false;

let lastObservedDepth = -1;
let ignorePopCount = 0;
let pendingGoTargetDepth: number | null = null;

let exitArmed = false;
let exitTimer: number | null = null;
const exitPromptListeners = new Set<() => void>();

function notifyExitPromptListeners() {
  for (const listener of exitPromptListeners) {
    listener();
  }
}

function notifyLayerListeners() {
  for (const listener of layerListeners) {
    listener();
  }
}

function subscribeLayers(listener: () => void): () => void {
  layerListeners.add(listener);
  return () => {
    layerListeners.delete(listener);
  };
}

function getLayersSnapshot(): number {
  return registeredLayers.size;
}

function subscribeExitPrompt(listener: () => void): () => void {
  exitPromptListeners.add(listener);
  return () => {
    exitPromptListeners.delete(listener);
  };
}

function getExitPromptSnapshot(): boolean {
  return exitArmed;
}

export function useExitPromptVisible(): boolean {
  return useSyncExternalStore(
    subscribeExitPrompt,
    getExitPromptSnapshot,
    () => false
  );
}

export function parseTabFromLocation(): NavTabId {
  if (typeof window === 'undefined') return 'today';
  const raw = window.location.hash.replace(/^#\/?/, '').trim();
  if (VALID_TABS.has(raw as NavTabId)) {
    return raw as NavTabId;
  }
  return 'today';
}

function buildTabHash(tab: NavTabId): string {
  return `#${tab}`;
}

function readDepthFromState(state: unknown): number {
  if (typeof state === 'object' && state !== null) {
    const candidate = state as { __caApp?: unknown; __caDepth?: unknown };
    if (
      candidate.__caApp === true &&
      typeof candidate.__caDepth === 'number'
    ) {
      return candidate.__caDepth;
    }
  }
  return -1;
}

function pushHistoryEntry(role: 'guard' | 'layer', depth: number, tab: NavTabId) {
  if (typeof window === 'undefined') return;
  const payload: HistoryPayload = {
    __caApp: true,
    __caRole: role,
    __caDepth: depth,
    tab,
  };
  window.history.pushState(payload, '', buildTabHash(tab));
  lastObservedDepth = depth;
}

function replaceHistoryEntry(
  role: 'exit-base' | 'guard',
  depth: number,
  tab: NavTabId
) {
  if (typeof window === 'undefined') return;
  const payload: HistoryPayload = {
    __caApp: true,
    __caRole: role,
    __caDepth: depth,
    tab,
  };
  window.history.replaceState(payload, '', buildTabHash(tab));
  lastObservedDepth = depth;
}

function clearExitArmed(restoreGuard: boolean) {
  if (exitTimer !== null) {
    window.clearTimeout(exitTimer);
    exitTimer = null;
  }
  if (exitArmed) {
    exitArmed = false;
    notifyExitPromptListeners();
  }
  if (restoreGuard && initialized && lastObservedDepth < 0) {
    pushHistoryEntry('guard', 0, currentTab);
  }
}

function armExitPrompt() {
  if (exitTimer !== null) {
    window.clearTimeout(exitTimer);
  }
  exitArmed = true;
  notifyExitPromptListeners();

  exitTimer = window.setTimeout(() => {
    exitTimer = null;
    exitArmed = false;
    notifyExitPromptListeners();
    if (initialized && lastObservedDepth < 0 && registeredLayers.size === 0) {
      pushHistoryEntry('guard', 0, currentTab);
    }
  }, EXIT_PROMPT_DURATION_MS);
}

function getSortedLayers(): InternalBackLayer[] {
  return Array.from(registeredLayers.values()).sort((a, b) => {
    if (a.zLayer !== b.zLayer) return a.zLayer - b.zLayer;
    return a.seq - b.seq;
  });
}

function syncHistoryDepth() {
  if (!initialized || typeof window === 'undefined') return;
  if (pendingGoTargetDepth !== null) return;

  const targetDepth = registeredLayers.size;

  // On 'today' while waiting for second back press within 2 seconds, stay on exit-base (-1).
  if (exitArmed && targetDepth === 0 && currentTab === 'today') {
    return;
  }

  if (exitArmed && targetDepth > 0) {
    clearExitArmed(false);
  }

  const stateDepth = readDepthFromState(window.history.state);
  lastObservedDepth = stateDepth;

  if (stateDepth < targetDepth) {
    for (let d = stateDepth + 1; d <= targetDepth; d += 1) {
      pushHistoryEntry(d === 0 ? 'guard' : 'layer', d, currentTab);
    }
  } else if (stateDepth > targetDepth) {
    const delta = stateDepth - targetDepth;
    ignorePopCount += 1;
    pendingGoTargetDepth = targetDepth;
    window.history.go(-delta);
  }
}

export function navigateToTab(tab: NavTabId) {
  currentTab = tab;
  tabUpdater?.(tab);

  if (!initialized || typeof window === 'undefined') {
    return;
  }

  clearExitArmed(false);

  const stateDepth = readDepthFromState(window.history.state);
  lastObservedDepth = stateDepth;

  if (stateDepth < 0) {
    pushHistoryEntry('guard', 0, tab);
  } else {
    replaceHistoryEntry('guard', stateDepth, tab);
  }
}

export function useBackNavigationHost(
  activeTab: NavTabId,
  onTabChange: (tab: NavTabId) => void
) {
  const layerCount = useSyncExternalStore(
    subscribeLayers,
    getLayersSnapshot,
    () => 0
  );

  currentTab = activeTab;
  tabUpdater = onTabChange;

  useEffect(() => {
    if (typeof window === 'undefined') return undefined;

    const initialTab = parseTabFromLocation();
    currentTab = initialTab;
    onTabChange(initialTab);

    const existingDepth = readDepthFromState(window.history.state);
    if (existingDepth < 0) {
      replaceHistoryEntry('exit-base', -1, initialTab);
      pushHistoryEntry('guard', 0, initialTab);
    } else {
      replaceHistoryEntry('guard', 0, initialTab);
    }

    initialized = true;

    const handlePopState = (event: PopStateEvent) => {
      const nextDepth = readDepthFromState(event.state);
      const prevDepth = lastObservedDepth;
      lastObservedDepth = nextDepth;

      if (ignorePopCount > 0) {
        ignorePopCount -= 1;
        if (pendingGoTargetDepth !== null && nextDepth <= pendingGoTargetDepth) {
          pendingGoTargetDepth = null;
        }
        window.setTimeout(syncHistoryDepth, 40);
        return;
      }

      if (nextDepth >= prevDepth) {
        syncHistoryDepth();
        return;
      }

      // Priority 1 & 2: Close topmost open overlay/detail/menu/dialog/lightbox.
      const layers = getSortedLayers();
      if (layers.length > 0) {
        const top = layers[layers.length - 1];
        top.getOnBack()();
        window.setTimeout(syncHistoryDepth, 40);
        return;
      }

      // Priority 3: On week/courses/more tab -> return to today tab.
      if (currentTab !== 'today') {
        currentTab = 'today';
        onTabChange('today');
        pushHistoryEntry('guard', 0, 'today');
        return;
      }

      // Priority 4: On today tab -> double back within 2 seconds exits.
      if (!exitArmed) {
        armExitPrompt();
      }
    };

    const handleUserGesture = () => {
      if (!exitArmed && pendingGoTargetDepth === null) {
        syncHistoryDepth();
      }
    };

    window.addEventListener('popstate', handlePopState);
    window.addEventListener('pointerdown', handleUserGesture, true);
    window.addEventListener('keydown', handleUserGesture, true);

    return () => {
      initialized = false;
      clearExitArmed(false);
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('pointerdown', handleUserGesture, true);
      window.removeEventListener('keydown', handleUserGesture, true);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    syncHistoryDepth();
  }, [layerCount, activeTab]);
}

export function useBackLayer({ active, zLayer, onBack }: BackLayerOptions) {
  const idRef = useRef<number | null>(null);
  if (idRef.current === null) {
    idRef.current = nextLayerId++;
  }
  const onBackRef = useRef(onBack);
  onBackRef.current = onBack;

  useEffect(() => {
    const id = idRef.current;
    if (id === null || !active) {
      return undefined;
    }

    registeredLayers.set(id, {
      id,
      zLayer,
      seq: nextLayerSeq++,
      getOnBack: () => onBackRef.current,
    });
    notifyLayerListeners();

    return () => {
      if (registeredLayers.delete(id)) {
        notifyLayerListeners();
      }
    };
  }, [active, zLayer]);
}
