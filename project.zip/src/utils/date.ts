import type { WeekdayNumber } from '../db/types';

export const WEEKDAY_LABELS = [
  '週日',
  '週一',
  '週二',
  '週三',
  '週四',
  '週五',
  '週六',
] as const;

export const WEEKDAY_ORDER_MON_FIRST: WeekdayNumber[] = [1, 2, 3, 4, 5, 6, 0];

export function toDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function parseDateKey(dateKey: string): Date {
  const [y, m, d] = dateKey.split('-').map((n) => Number.parseInt(n, 10));
  return new Date(y, (m || 1) - 1, d || 1);
}

export function formatMonthDayWeekday(date: Date): string {
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const weekday = WEEKDAY_LABELS[date.getDay()];
  return `${month}月${day}日 ${weekday}`;
}

export function formatFullChineseDate(date: Date): string {
  const year = date.getFullYear();
  return `${year}年${formatMonthDayWeekday(date)}`;
}

export function formatSlashDate(dateKey: string): string {
  const parts = dateKey.split('-');
  if (parts.length !== 3) return dateKey;
  const month = Number.parseInt(parts[1], 10);
  const day = Number.parseInt(parts[2], 10);
  return `${month}/${day}`;
}

export function formatSlashDateWithWeekday(dateKey: string): string {
  const date = parseDateKey(dateKey);
  const weekday = WEEKDAY_LABELS[date.getDay()].replace('週', '');
  return `${formatSlashDate(dateKey)}（${weekday}）`;
}

export function formatTimestamp(ts: number): string {
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${y}/${m}/${day} ${hh}:${mm}`;
}

export function getWeekDates(anchorDate: Date): Date[] {
  const start = new Date(
    anchorDate.getFullYear(),
    anchorDate.getMonth(),
    anchorDate.getDate()
  );
  const dayOfWeek = start.getDay();
  const offsetToMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
  start.setDate(start.getDate() + offsetToMonday);

  return Array.from({ length: 7 }, (_, index) => {
    const next = new Date(start);
    next.setDate(start.getDate() + index);
    return next;
  });
}

export function timeToMinutes(hhmm: string): number {
  const [hStr, mStr] = hhmm.split(':');
  const h = Number.parseInt(hStr || '0', 10);
  const m = Number.parseInt(mStr || '0', 10);
  if (Number.isNaN(h) || Number.isNaN(m)) return 0;
  return h * 60 + m;
}

export function minutesToTime(totalMinutes: number): string {
  const clamped = Math.max(0, Math.min(23 * 60 + 59, totalMinutes));
  const h = Math.floor(clamped / 60);
  const m = clamped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export function addMinutesToTime(hhmm: string, deltaMinutes: number): string {
  return minutesToTime(timeToMinutes(hhmm) + deltaMinutes);
}

export function doTimeRangesOverlap(
  startA: string,
  endA: string,
  startB: string,
  endB: string
): boolean {
  const s1 = timeToMinutes(startA);
  const e1 = timeToMinutes(endA);
  const s2 = timeToMinutes(startB);
  const e2 = timeToMinutes(endB);
  if (e1 <= s1 || e2 <= s2) return false;
  return s1 < e2 && s2 < e1;
}

export function enumerateDateKeysInRange(
  startDate: string,
  endDate: string
): string[] {
  if (!startDate || !endDate || startDate > endDate) {
    return [];
  }
  const result: string[] = [];
  const cursor = parseDateKey(startDate);
  const end = parseDateKey(endDate);
  // Guard against accidental multi-decade typos (max ~730 days)
  let guard = 0;
  while (cursor <= end && guard < 800) {
    result.push(toDateKey(cursor));
    cursor.setDate(cursor.getDate() + 1);
    guard += 1;
  }
  return result;
}
