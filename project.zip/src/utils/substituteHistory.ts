import type { ClassSession } from '../db/types';

const RECENT_TITLES_KEY = 'course_assistant_recent_substitute_titles';
const RECENT_TEACHERS_KEY = 'course_assistant_recent_substitute_teachers';
const MAX_RECENT = 10;

function readStringList(key: string): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((item): item is string => typeof item === 'string')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, MAX_RECENT);
  } catch {
    return [];
  }
}

function pushToMruList(key: string, value: string): void {
  const trimmed = value.trim();
  if (!trimmed || typeof window === 'undefined') return;
  try {
    const existing = readStringList(key);
    const next = [trimmed, ...existing.filter((item) => item !== trimmed)].slice(
      0,
      MAX_RECENT
    );
    window.localStorage.setItem(key, JSON.stringify(next));
  } catch {
    // Ignore localStorage quota / private browsing errors
  }
}

export function recordSubstituteShortcuts(
  title: string,
  substituteFor?: string
): void {
  pushToMruList(RECENT_TITLES_KEY, title);
  if (substituteFor?.trim()) {
    pushToMruList(RECENT_TEACHERS_KEY, substituteFor);
  }
}

export function getSubstituteShortcuts(
  allSessions: ClassSession[]
): {
  recentTitles: string[];
  recentTeachers: string[];
} {
  const titleSet = new Set<string>(readStringList(RECENT_TITLES_KEY));
  const teacherSet = new Set<string>(readStringList(RECENT_TEACHERS_KEY));

  if (titleSet.size < MAX_RECENT || teacherSet.size < MAX_RECENT) {
    const subSessions = allSessions
      .filter((s) => s.kind === 'substitute')
      .sort((a, b) => b.updatedAt - a.updatedAt);

    for (const s of subSessions) {
      if (titleSet.size < MAX_RECENT && s.title?.trim()) {
        titleSet.add(s.title.trim());
      }
      if (teacherSet.size < MAX_RECENT && s.substituteFor?.trim()) {
        teacherSet.add(s.substituteFor.trim());
      }
      if (titleSet.size >= MAX_RECENT && teacherSet.size >= MAX_RECENT) {
        break;
      }
    }
  }

  return {
    recentTitles: Array.from(titleSet).slice(0, MAX_RECENT),
    recentTeachers: Array.from(teacherSet).slice(0, MAX_RECENT),
  };
}
