import { App as CapacitorApp } from '@capacitor/app';
import { isNativeApp } from './platform';

let started = false;

/**
 * Android app only. The web app (backNavigation.ts) walks the browser history to close layers, return to
 * the today tab and show "再按一次返回鍵離開". Capacitor consumes the hardware back button without
 * doing anything when there is no history left, so here: go back while there is history, otherwise leave.
 */
export function startNativeBackHandler(): void {
  if (!isNativeApp || started) return;
  started = true;
  void CapacitorApp.addListener('backButton', ({ canGoBack }) => {
    if (canGoBack) {
      window.history.back();
      return;
    }
    void CapacitorApp.exitApp();
  });
}
