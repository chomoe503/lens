import type {
  AcademicYear,
  ClassSession,
  Course,
  Exam,
  Homework,
  Organization,
} from '../db/types';
import { toDateKey } from './date';
import { isSessionCancelled, resolveSessionDisplay } from './sessionDisplay';

export type SearchResultType = 'course' | 'session' | 'exam' | 'homework';
export type SearchCategoryFilter = 'all' | SearchResultType;
export type SearchSortOrder = 'desc' | 'asc';

export interface SearchResultItem {
  key: string;
  type: SearchResultType;
  id: string;
  courseId?: string;
  title: string;
  subtitle: string;
  matchedFields: Array<{ label: string; text: string }>;
  sortDate: string;
  sortTime: string;
  updatedAt: number;
  color: string;
  statusLabel?: string;
  isSubstitute?: boolean;
  orgName?: string;
  substituteFor?: string;
  course?: Course;
  session?: ClassSession;
  exam?: Exam;
  homework?: Homework;
}

export interface SearchDataset {
  courses: Course[];
  organizations: Organization[];
  academicYears: AcademicYear[];
  sessions: ClassSession[];
  exams: Exam[];
  homeworks: Homework[];
}

function tokenizeQuery(rawQuery: string): string[] {
  return rawQuery
    .trim()
    .toLowerCase()
    .split(/\s+/)
    .filter((token) => token.length > 0);
}

function matchesAllTokens(tokens: string[], fields: Array<string | undefined>): boolean {
  if (tokens.length === 0) return false;
  const combined = fields
    .filter((f): f is string => Boolean(f && f.trim()))
    .join('\n')
    .toLowerCase();
  if (!combined) return false;
  return tokens.every((token) => combined.includes(token));
}

function getHomeworkStatusText(status: Homework['status']): string {
  if (status === 'graded') return '已批改';
  if (status === 'collected') return '收齊';
  return '未收';
}

export function runOfflineSearch(
  query: string,
  dataset: SearchDataset,
  options?: {
    category?: SearchCategoryFilter;
    sortOrder?: SearchSortOrder;
  }
): SearchResultItem[] {
  const tokens = tokenizeQuery(query);
  if (tokens.length === 0) return [];

  const category = options?.category ?? 'all';
  const sortOrder = options?.sortOrder ?? 'desc';

  const orgMap = new Map(dataset.organizations.map((o) => [o.id, o]));
  const yearMap = new Map(dataset.academicYears.map((y) => [y.id, y]));
  const courseMap = new Map(dataset.courses.map((c) => [c.id, c]));

  const latestCourseSessionDate = new Map<string, string>();
  for (const s of dataset.sessions) {
    if (isSessionCancelled(s) || !s.courseId) continue;
    const prev = latestCourseSessionDate.get(s.courseId);
    if (!prev || s.date > prev) {
      latestCourseSessionDate.set(s.courseId, s.date);
    }
  }

  const results: SearchResultItem[] = [];

  // 1. 課程名稱
  if (category === 'all' || category === 'course') {
    for (const course of dataset.courses) {
      if (course.isSystem) continue;
      const org = orgMap.get(course.organizationId);
      const year = yearMap.get(course.academicYearId);
      if (
        matchesAllTokens(tokens, [course.name])
      ) {
        const latestDate =
          latestCourseSessionDate.get(course.id) ??
          year?.startDate ??
          toDateKey(new Date(course.updatedAt));
        const matchedFields: Array<{ label: string; text: string }> = [];
        if (course.subject?.trim()) {
          matchedFields.push({ label: '科目', text: course.subject.trim() });
        }
        if (course.note?.trim()) {
          matchedFields.push({ label: '課程備註', text: course.note.trim() });
        }

        results.push({
          key: `course:${course.id}`,
          type: 'course',
          id: course.id,
          courseId: course.id,
          title: course.name,
          subtitle: [org?.name ?? '未指定單位', year?.name]
            .filter(Boolean)
            .join(' · '),
          matchedFields,
          sortDate: latestDate,
          sortTime: '00:00',
          updatedAt: course.updatedAt,
          color: course.color || org?.color || '#CDB8FF',
          course,
        });
      }
    }
  }

  // 2. 場次的進度與備註（代課場次同時搜尋班級／課名與代誰的課；不含已取消場次）
  if (category === 'all' || category === 'session') {
    for (const session of dataset.sessions) {
      if (isSessionCancelled(session)) continue;
      const resolved = resolveSessionDisplay(session, courseMap, orgMap);
      const searchableFields = resolved.isSubstitute
        ? [
            session.title,
            session.substituteFor,
            session.progress,
            session.note,
            session.homework,
          ]
        : [session.progress, session.note, session.homework];

      if (matchesAllTokens(tokens, searchableFields)) {
        const matchedFields: Array<{ label: string; text: string }> = [];
        if (session.progress?.trim()) {
          matchedFields.push({ label: '進度', text: session.progress.trim() });
        }
        if (session.note?.trim()) {
          matchedFields.push({ label: '備註', text: session.note.trim() });
        }
        if (session.homework?.trim()) {
          matchedFields.push({ label: '作業備忘', text: session.homework.trim() });
        }

        results.push({
          key: `session:${session.id}`,
          type: 'session',
          id: session.id,
          courseId: resolved.course?.id,
          title: resolved.title,
          subtitle: `${resolved.orgName} · ${session.startTime}–${session.endTime}`,
          matchedFields,
          sortDate: session.date,
          sortTime: session.startTime,
          updatedAt: session.updatedAt,
          color: resolved.color,
          isSubstitute: resolved.isSubstitute,
          orgName: resolved.orgName,
          substituteFor: resolved.substituteFor,
          course: resolved.course,
          session,
        });
      }
    }
  }

  // 3. 考試的名稱與備註（含範圍）
  if (category === 'all' || category === 'exam') {
    for (const exam of dataset.exams) {
      const course = courseMap.get(exam.courseId);
      const org = course ? orgMap.get(course.organizationId) : undefined;
      if (matchesAllTokens(tokens, [exam.title, exam.note, exam.scope])) {
        const matchedFields: Array<{ label: string; text: string }> = [];
        if (exam.scope?.trim()) {
          matchedFields.push({ label: '範圍', text: exam.scope.trim() });
        }
        if (exam.note?.trim()) {
          matchedFields.push({ label: '備註', text: exam.note.trim() });
        }

        results.push({
          key: `exam:${exam.id}`,
          type: 'exam',
          id: exam.id,
          courseId: exam.courseId,
          title: exam.title,
          subtitle: [
            course?.name ?? '課程',
            org?.name,
            exam.examType,
            exam.time,
          ]
            .filter(Boolean)
            .join(' · '),
          matchedFields,
          sortDate: exam.date,
          sortTime: exam.time && /^\d{2}:\d{2}/.test(exam.time) ? exam.time.slice(0, 5) : '00:00',
          updatedAt: exam.updatedAt,
          color: course?.color ?? org?.color ?? '#CDB8FF',
          course,
          exam,
        });
      }
    }
  }

  // 4. 作業的名稱與備註
  if (category === 'all' || category === 'homework') {
    for (const hw of dataset.homeworks) {
      const course = courseMap.get(hw.courseId);
      const org = course ? orgMap.get(course.organizationId) : undefined;
      if (matchesAllTokens(tokens, [hw.title, hw.note])) {
        const matchedFields: Array<{ label: string; text: string }> = [];
        if (hw.note?.trim()) {
          matchedFields.push({ label: '備註', text: hw.note.trim() });
        }

        results.push({
          key: `homework:${hw.id}`,
          type: 'homework',
          id: hw.id,
          courseId: hw.courseId,
          title: hw.title,
          subtitle: [course?.name ?? '課程', org?.name]
            .filter(Boolean)
            .join(' · '),
          matchedFields,
          sortDate: hw.dueDate || hw.assignedDate,
          sortTime: '00:00',
          updatedAt: hw.updatedAt,
          color: course?.color ?? org?.color ?? '#CDB8FF',
          statusLabel: getHomeworkStatusText(hw.status),
          course,
          homework: hw,
        });
      }
    }
  }

  results.sort((a, b) => {
    const dir = sortOrder === 'desc' ? -1 : 1;
    const dateDiff = a.sortDate.localeCompare(b.sortDate);
    if (dateDiff !== 0) return dateDiff * dir;
    const timeDiff = a.sortTime.localeCompare(b.sortTime);
    if (timeDiff !== 0) return timeDiff * dir;
    return (a.updatedAt - b.updatedAt) * dir;
  });

  return results;
}
