package com.classplan.assistant;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Data model and display logic for the home-screen widgets.
 * Deliberately free of Android classes so it can be unit-tested on a plain JVM.
 */
final class WidgetModel {
    private WidgetModel() {}

    static final int ROW_CLASS = 0;
    static final int ROW_SECTION = 1;
    static final int ROW_TODO = 2;

    private static final String[] WEEKDAYS = {"日", "一", "二", "三", "四", "五", "六"};
    private static final long DEFAULT_SESSION_MS = 45L * 60L * 1000L;

    static final class Item {
        final String title;
        final boolean reminder;
        /** true: attached to this exact session; false: attached to the class and shown on its next session */
        final boolean direct;

        Item(String title, boolean reminder, boolean direct) {
            this.title = title;
            this.reminder = reminder;
            this.direct = direct;
        }
    }

    static final class Session {
        String id = "";
        String courseId = "";
        String date = "";
        String start = "";
        String end = "";
        String title = "";
        String org = "";
        int color = 0xFFCDB8FF;
        String lastProgress = "";
        String lastProgressDate = "";
        /** exam countdown; countdownLeft == 0 means there is none */
        String countdownTitle = "";
        int countdownLeft;
        int countdownDays;
        boolean countdownLast;
        long startMs;
        long endMs;
        boolean firstUpcomingOfCourse;
        final List<Item> items = new ArrayList<>();
    }

    static final class Other {
        String title = "";
        boolean reminder;
        String date = "";
    }

    static final class Snapshot {
        final List<Session> sessions = new ArrayList<>();
        final List<Other> others = new ArrayList<>();
    }

    static final class Row {
        int type;
        // class row
        String time = "";
        String title = "";
        String sub = "";
        String items = "";
        String progress = "";
        String countdown = "";
        boolean countdownLast;
        int color;
        boolean ended;
        boolean current;
        // section / todo rows
        String text = "";
        boolean overdue;
    }

    // ---------------------------------------------------------------- time helpers

    static long toMillis(String date, String time) {
        try {
            String[] d = date.split("-");
            String[] t = time.split(":");
            Calendar c = Calendar.getInstance();
            c.clear();
            c.set(
                    Integer.parseInt(d[0].trim()),
                    Integer.parseInt(d[1].trim()) - 1,
                    Integer.parseInt(d[2].trim()),
                    Integer.parseInt(t[0].trim()),
                    Integer.parseInt(t[1].trim()),
                    0);
            return c.getTimeInMillis();
        } catch (RuntimeException e) {
            return -1L;
        }
    }

    static String dateKey(long ms) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        return String.format(
                Locale.US,
                "%04d-%02d-%02d",
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH) + 1,
                c.get(Calendar.DAY_OF_MONTH));
    }

    static String tomorrowKey(long ms) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        c.add(Calendar.DAY_OF_MONTH, 1);
        return dateKey(c.getTimeInMillis());
    }

    static String weekdayLabel(long ms) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        return "週" + WEEKDAYS[c.get(Calendar.DAY_OF_WEEK) - 1];
    }

    static String monthDay(String date) {
        try {
            String[] d = date.split("-");
            return Integer.parseInt(d[1].trim()) + "/" + Integer.parseInt(d[2].trim());
        } catch (RuntimeException e) {
            return date;
        }
    }

    /** "今天" / "明天" / "週三 11/25" */
    static String relativeDay(String date, long now) {
        if (date.equals(dateKey(now))) {
            return "今天";
        }
        if (date.equals(tomorrowKey(now))) {
            return "明天";
        }
        long noon = toMillis(date, "12:00");
        if (noon < 0) {
            return date;
        }
        return weekdayLabel(noon) + " " + monthDay(date);
    }

    static int parseColor(String hex, int fallback) {
        if (hex == null) {
            return fallback;
        }
        String h = hex.trim();
        if (h.length() == 7 && h.charAt(0) == '#') {
            try {
                return (int) (0xFF000000L | Long.parseLong(h.substring(1), 16));
            } catch (NumberFormatException e) {
                return fallback;
            }
        }
        return fallback;
    }

    // ---------------------------------------------------------------- snapshot preparation

    /** Fills startMs/endMs; an end that is not after the start counts as a 45-minute class. */
    static void finishSession(Session s) {
        s.startMs = toMillis(s.date, s.start);
        long end = toMillis(s.date, s.end);
        if (s.startMs > 0 && end <= s.startMs) {
            end = s.startMs + DEFAULT_SESSION_MS;
        }
        s.endMs = end;
    }

    /**
     * Class-level todos are shown only on the next not-yet-finished session of that class
     * (same rule as the app), so remember which session that is.
     */
    static void prepare(Snapshot snap, long now) {
        Set<String> claimed = new HashSet<>();
        for (Session s : snap.sessions) {
            s.firstUpcomingOfCourse = false;
            if (s.endMs > now && !s.courseId.isEmpty() && claimed.add(s.courseId)) {
                s.firstUpcomingOfCourse = true;
            }
        }
    }

    static Session findCurrentOrNext(Snapshot snap, long now) {
        for (Session s : snap.sessions) {
            if (s.endMs > now) {
                return s;
            }
        }
        return null;
    }

    static List<Item> visibleItems(Session s, long now) {
        List<Item> out = new ArrayList<>();
        boolean ended = s.endMs <= now;
        boolean showClassLevel = !ended && (s.courseId.isEmpty() || s.firstUpcomingOfCourse);
        for (Item item : s.items) {
            if (item.direct || showClassLevel) {
                out.add(item);
            }
        }
        return out;
    }

    /** Next moment the widgets should be redrawn: a class starting/ending, or midnight. */
    static long nextBoundary(Snapshot snap, long now) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        c.add(Calendar.DAY_OF_MONTH, 1);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long best = c.getTimeInMillis();
        for (Session s : snap.sessions) {
            if (s.startMs > now && s.startMs < best) {
                best = s.startMs;
            }
            if (s.endMs > now && s.endMs < best) {
                best = s.endMs;
            }
        }
        return best;
    }

    // ---------------------------------------------------------------- text for the widgets

    static String timeRange(Session s) {
        return s.start + "–" + s.end;
    }

    /** Start above end, for the narrow time column of the "today" widget. */
    static String timeStacked(Session s) {
        return s.start + "\n" + s.end;
    }

    static String nextLabel(Session s, long now) {
        if (now >= s.startMs) {
            return "上課中 · " + timeRange(s);
        }
        return "下一堂 · " + relativeDay(s.date, now) + " " + timeRange(s);
    }

    /** Small caption above the progress text: "上次進度 · 11/18" (which day it was recorded). */
    static String progressCaption(Session s) {
        if (s.lastProgress.isEmpty() || s.lastProgressDate.isEmpty()) {
            return "上次進度";
        }
        return "上次進度 · " + monthDay(s.lastProgressDate);
    }

    static String progressBody(Session s) {
        return s.lastProgress.isEmpty() ? "還沒有記錄" : s.lastProgress;
    }

    static boolean hasCountdown(Session s) {
        return s.countdownLeft > 0;
    }

    /**
     * "第二次段考 · 倒數 3 堂" / "第二次段考 · 考前最後一堂"; withDays adds " · 14 天" for the roomier widget.
     * Empty when this class has no exam to count down to.
     */
    static String countdownText(Session s, boolean withDays) {
        if (!hasCountdown(s)) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        if (!s.countdownTitle.isEmpty()) {
            sb.append(s.countdownTitle).append(" · ");
        }
        if (s.countdownLast) {
            sb.append("考前最後一堂");
        } else {
            sb.append("倒數 ").append(s.countdownLeft).append(" 堂");
        }
        if (withDays && s.countdownDays > 0) {
            sb.append(" · ").append(s.countdownDays).append(" 天");
        }
        return sb.toString();
    }

    static String itemPrefix(boolean reminder) {
        return reminder ? "🔔 " : "☐ ";
    }

    /** One item per line, for the "next class" widget. */
    static String itemsMultiline(List<Item> items, int max) {
        StringBuilder sb = new StringBuilder();
        int shown = 0;
        for (Item item : items) {
            if (shown >= max) {
                break;
            }
            if (shown > 0) {
                sb.append('\n');
            }
            sb.append(itemPrefix(item.reminder)).append(item.title);
            shown++;
        }
        if (items.size() > shown) {
            sb.append("\n…還有 ").append(items.size() - shown).append(" 項");
        }
        return sb.toString();
    }

    /** All on one line, for rows of the "today" widget. */
    static String itemsInline(List<Item> items) {
        StringBuilder sb = new StringBuilder();
        for (Item item : items) {
            if (sb.length() > 0) {
                sb.append("  ");
            }
            sb.append(itemPrefix(item.reminder)).append(item.title);
        }
        return sb.toString();
    }

    static int countToday(Snapshot snap, long now) {
        String today = dateKey(now);
        int n = 0;
        for (Session s : snap.sessions) {
            if (s.date.equals(today)) {
                n++;
            }
        }
        return n;
    }

    static String headerText(Snapshot snap, long now) {
        int n = countToday(snap, now);
        return monthDay(dateKey(now)) + " " + weekdayLabel(now) + " · "
                + (n == 0 ? "沒有課" : n + " 堂課");
    }

    static List<Row> buildTodayRows(Snapshot snap, long now) {
        List<Row> rows = new ArrayList<>();
        String today = dateKey(now);

        for (Session s : snap.sessions) {
            if (!s.date.equals(today)) {
                continue;
            }
            Row r = new Row();
            r.type = ROW_CLASS;
            r.time = timeStacked(s);
            r.title = s.title;
            r.sub = s.org;
            r.progress = s.lastProgress.isEmpty() ? "" : "上次：" + s.lastProgress;
            r.countdown = countdownText(s, false);
            r.countdownLast = s.countdownLast;
            r.items = itemsInline(visibleItems(s, now));
            r.color = s.color;
            r.ended = s.endMs <= now;
            r.current = s.startMs <= now && now < s.endMs;
            rows.add(r);
        }

        List<Row> others = new ArrayList<>();
        for (Other o : snap.others) {
            boolean overdue = !o.reminder && o.date.compareTo(today) < 0;
            boolean showToday = o.date.equals(today);
            if (!overdue && !showToday) {
                continue;
            }
            Row r = new Row();
            r.type = ROW_TODO;
            r.overdue = overdue;
            r.text = (overdue ? "逾期 · " : "") + itemPrefix(o.reminder) + o.title;
            others.add(r);
        }
        if (!others.isEmpty()) {
            Row header = new Row();
            header.type = ROW_SECTION;
            header.text = "今天的其他待辦";
            rows.add(header);
            int cap = Math.min(others.size(), 8);
            rows.addAll(others.subList(0, cap));
        }
        return rows;
    }
}
