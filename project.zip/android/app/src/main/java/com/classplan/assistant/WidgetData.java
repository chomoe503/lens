package com.classplan.assistant;

import android.content.Context;
import java.util.Collections;
import java.util.Comparator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Stores the snapshot the web app pushes (SharedPreferences) and parses it into the widget model. */
final class WidgetData {
    private static final String PREFS = "classplan_widget";
    private static final String KEY_SNAPSHOT = "snapshot";

    private WidgetData() {}

    static void save(Context context, String json) {
        context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_SNAPSHOT, json)
                .apply();
    }

    static WidgetModel.Snapshot load(Context context) {
        String json = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_SNAPSHOT, null);
        return parse(json);
    }

    static WidgetModel.Snapshot parse(String json) {
        WidgetModel.Snapshot snap = new WidgetModel.Snapshot();
        if (json == null || json.isEmpty()) {
            return snap;
        }
        try {
            JSONObject root = new JSONObject(json);

            JSONArray sessions = root.optJSONArray("sessions");
            if (sessions != null) {
                for (int i = 0; i < sessions.length(); i++) {
                    JSONObject o = sessions.optJSONObject(i);
                    if (o == null) {
                        continue;
                    }
                    WidgetModel.Session s = new WidgetModel.Session();
                    s.id = o.optString("id", "");
                    s.courseId = o.optString("courseId", "");
                    s.date = o.optString("date", "");
                    s.start = o.optString("start", "");
                    s.end = o.optString("end", "");
                    s.title = o.optString("title", "");
                    s.org = o.optString("org", "");
                    s.color = WidgetModel.parseColor(o.optString("color", ""), s.color);
                    s.lastProgress = o.optString("lastProgress", "");
                    s.lastProgressDate = o.optString("lastProgressDate", "");
                    JSONObject cd = o.optJSONObject("countdown");
                    if (cd != null) {
                        s.countdownTitle = cd.optString("title", "");
                        s.countdownLeft = cd.optInt("sessionsLeft", 0);
                        s.countdownDays = cd.optInt("daysLeft", 0);
                        s.countdownLast = cd.optBoolean("isLast", false);
                    }
                    JSONArray items = o.optJSONArray("items");
                    if (items != null) {
                        for (int j = 0; j < items.length(); j++) {
                            JSONObject it = items.optJSONObject(j);
                            if (it == null) {
                                continue;
                            }
                            s.items.add(new WidgetModel.Item(
                                    it.optString("title", ""),
                                    "reminder".equals(it.optString("kind", "todo")),
                                    it.optBoolean("direct", true)));
                        }
                    }
                    WidgetModel.finishSession(s);
                    if (s.startMs > 0) {
                        snap.sessions.add(s);
                    }
                }
            }

            JSONArray others = root.optJSONArray("others");
            if (others != null) {
                for (int i = 0; i < others.length(); i++) {
                    JSONObject o = others.optJSONObject(i);
                    if (o == null) {
                        continue;
                    }
                    WidgetModel.Other other = new WidgetModel.Other();
                    other.title = o.optString("title", "");
                    other.reminder = "reminder".equals(o.optString("kind", "todo"));
                    other.date = o.optString("date", "");
                    if (!other.date.isEmpty()) {
                        snap.others.add(other);
                    }
                }
            }
        } catch (JSONException e) {
            // A broken snapshot just means empty widgets until the app pushes a new one.
            snap.sessions.clear();
            snap.others.clear();
        }

        Collections.sort(snap.sessions, new Comparator<WidgetModel.Session>() {
            @Override
            public int compare(WidgetModel.Session a, WidgetModel.Session b) {
                return Long.compare(a.startMs, b.startMs);
            }
        });
        return snap;
    }
}
