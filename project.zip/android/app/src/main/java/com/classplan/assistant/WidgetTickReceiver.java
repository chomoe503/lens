package com.classplan.assistant;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Redraws the widgets at class boundaries and after reboot, app update or a clock / time-zone change.
 */
public class WidgetTickReceiver extends BroadcastReceiver {
    static final String ACTION_TICK = "com.classplan.assistant.WIDGET_TICK";

    @Override
    public void onReceive(Context context, Intent intent) {
        WidgetUpdater.updateAll(context);
    }
}
