package com.classplan.assistant;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.view.View;
import android.widget.RemoteViews;

/** "下一堂課" widget: current or next class, last progress, and its todos. */
public class NextClassWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        WidgetUpdater.updateAll(context);
    }

    @Override
    public void onEnabled(Context context) {
        WidgetUpdater.updateAll(context);
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        WidgetUpdater.updateAll(context);
    }

    @Override
    public void onDisabled(Context context) {
        WidgetUpdater.updateAll(context);
    }

    static RemoteViews build(Context context, WidgetModel.Snapshot snap, long now) {
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_next_class);
        v.setOnClickPendingIntent(R.id.nc_root, WidgetUpdater.launchApp(context));

        WidgetModel.Session s = WidgetModel.findCurrentOrNext(snap, now);
        if (s == null) {
            v.setInt(R.id.nc_bar, "setBackgroundColor", 0xFFD9D3E6);
            v.setTextViewText(R.id.nc_label, "課程助理");
            v.setTextViewText(R.id.nc_title, "近期沒有課");
            v.setTextViewText(R.id.nc_org, "點一下打開 App");
            v.setViewVisibility(R.id.nc_org, View.VISIBLE);
            v.setViewVisibility(R.id.nc_countdown, View.GONE);
            v.setViewVisibility(R.id.nc_progress_caption, View.GONE);
            v.setViewVisibility(R.id.nc_progress, View.GONE);
            v.setViewVisibility(R.id.nc_items, View.GONE);
            return v;
        }

        v.setInt(R.id.nc_bar, "setBackgroundColor", s.color);
        v.setTextViewText(R.id.nc_label, WidgetModel.nextLabel(s, now));
        v.setTextViewText(R.id.nc_title, s.title);

        if (s.org.isEmpty()) {
            v.setViewVisibility(R.id.nc_org, View.GONE);
        } else {
            v.setTextViewText(R.id.nc_org, s.org);
            v.setViewVisibility(R.id.nc_org, View.VISIBLE);
        }

        String countdown = WidgetModel.countdownText(s, true);
        if (countdown.isEmpty()) {
            v.setViewVisibility(R.id.nc_countdown, View.GONE);
        } else {
            v.setTextViewText(R.id.nc_countdown, countdown);
            v.setTextColor(R.id.nc_countdown, s.countdownLast ? 0xFFB4506E : 0xFFB45309);
            v.setViewVisibility(R.id.nc_countdown, View.VISIBLE);
        }

        v.setTextViewText(R.id.nc_progress_caption, WidgetModel.progressCaption(s));
        v.setViewVisibility(R.id.nc_progress_caption, View.VISIBLE);
        v.setTextViewText(R.id.nc_progress, WidgetModel.progressBody(s));
        v.setTextColor(R.id.nc_progress, s.lastProgress.isEmpty() ? 0xFF9A94A8 : 0xFF2B2540);
        v.setViewVisibility(R.id.nc_progress, View.VISIBLE);

        String items = WidgetModel.itemsMultiline(WidgetModel.visibleItems(s, now), 3);
        if (items.isEmpty()) {
            v.setViewVisibility(R.id.nc_items, View.GONE);
        } else {
            v.setTextViewText(R.id.nc_items, items);
            v.setViewVisibility(R.id.nc_items, View.VISIBLE);
        }
        return v;
    }
}
