package com.classplan.assistant;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/** Redraws every placed widget and arms the alarm for the next redraw (class start/end, midnight). */
final class WidgetUpdater {
    private static final String TAG = "ClassplanWidget";

    private WidgetUpdater() {}

    static void updateAll(Context context) {
        Context app = context.getApplicationContext();
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(app);
            int[] nextIds = mgr.getAppWidgetIds(new ComponentName(app, NextClassWidgetProvider.class));
            int[] todayIds = mgr.getAppWidgetIds(new ComponentName(app, TodayWidgetProvider.class));
            if (nextIds.length + todayIds.length == 0) {
                cancelTick(app);
                return;
            }

            long now = System.currentTimeMillis();
            WidgetModel.Snapshot snap = WidgetData.load(app);
            WidgetModel.prepare(snap, now);

            for (int id : nextIds) {
                mgr.updateAppWidget(id, NextClassWidgetProvider.build(app, snap, now));
            }
            for (int id : todayIds) {
                mgr.updateAppWidget(id, TodayWidgetProvider.build(app, id, snap, now));
            }
            if (todayIds.length > 0) {
                mgr.notifyAppWidgetViewDataChanged(todayIds, R.id.today_list);
            }

            scheduleTick(app, WidgetModel.nextBoundary(snap, now));
        } catch (RuntimeException e) {
            Log.w(TAG, "Widget update failed", e);
        }
    }

    private static PendingIntent tickIntent(Context app) {
        Intent intent = new Intent(app, WidgetTickReceiver.class);
        intent.setAction(WidgetTickReceiver.ACTION_TICK);
        return PendingIntent.getBroadcast(
                app, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void scheduleTick(Context app, long boundaryMs) {
        AlarmManager am = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (am == null) {
            return;
        }
        // Inexact alarm: needs no special permission. The system's own 30-minute update is the fallback.
        am.setAndAllowWhileIdle(AlarmManager.RTC, boundaryMs + 1000L, tickIntent(app));
    }

    private static void cancelTick(Context app) {
        AlarmManager am = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            am.cancel(tickIntent(app));
        }
    }

    /** Opens the app (used by taps on the header / the whole "next class" widget). */
    static PendingIntent launchApp(Context context) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        return PendingIntent.getActivity(
                context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Template for taps on list rows (needs to be mutable on Android 12+ so the row's fill-in intent can merge). */
    static PendingIntent launchAppTemplate(Context context) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            flags |= PendingIntent.FLAG_MUTABLE;
        }
        return PendingIntent.getActivity(context, 1, intent, flags);
    }
}
