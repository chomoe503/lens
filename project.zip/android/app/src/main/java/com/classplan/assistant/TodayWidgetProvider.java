package com.classplan.assistant;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

/** "今天課表" widget: scrolling list of today's classes (time, progress, todos) plus other todos. */
public class TodayWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        WidgetUpdater.updateAll(context);
    }

    @Override
    public void onEnabled(Context context) {
        WidgetUpdater.updateAll(context);
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        WidgetUpdater.updateAll(context);
    }

    @Override
    public void onDisabled(Context context) {
        WidgetUpdater.updateAll(context);
    }

    static RemoteViews build(Context context, int appWidgetId, WidgetModel.Snapshot snap, long now) {
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_today);

        Intent serviceIntent = new Intent(context, TodayWidgetService.class);
        serviceIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        // Unique data per widget so each one gets its own adapter.
        serviceIntent.setData(Uri.parse(serviceIntent.toUri(Intent.URI_INTENT_SCHEME)));
        v.setRemoteAdapter(R.id.today_list, serviceIntent);
        v.setEmptyView(R.id.today_list, R.id.today_empty);

        v.setTextViewText(R.id.today_header, WidgetModel.headerText(snap, now));
        v.setOnClickPendingIntent(R.id.today_header, WidgetUpdater.launchApp(context));
        v.setOnClickPendingIntent(R.id.today_empty, WidgetUpdater.launchApp(context));
        v.setPendingIntentTemplate(R.id.today_list, WidgetUpdater.launchAppTemplate(context));
        return v;
    }
}
