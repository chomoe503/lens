package com.classplan.assistant;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;
import java.util.ArrayList;
import java.util.List;

/** Supplies the rows of the "今天課表" widget list. */
public class TodayWidgetService extends RemoteViewsService {

    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    private static final class Factory implements RemoteViewsService.RemoteViewsFactory {
        private static final int TEXT = 0xFF2B2540;
        private static final int TEXT_SECONDARY = 0xFF6B6580;
        private static final int TEXT_ITEMS = 0xFF4A4560;
        private static final int ACCENT = 0xFF6D4AFF;
        private static final int ENDED_TITLE = 0xFF9A94A8;
        private static final int ENDED_SUB = 0xFFB3AEC0;
        private static final int OVERDUE = 0xFFB4506E;
        private static final int COUNTDOWN = 0xFFB45309;

        private final Context context;
        private List<WidgetModel.Row> rows = new ArrayList<>();

        Factory(Context context) {
            this.context = context;
        }

        @Override
        public void onCreate() {
            // Rows are built in onDataSetChanged.
        }

        @Override
        public void onDataSetChanged() {
            long now = System.currentTimeMillis();
            WidgetModel.Snapshot snap = WidgetData.load(context);
            WidgetModel.prepare(snap, now);
            rows = WidgetModel.buildTodayRows(snap, now);
        }

        @Override
        public void onDestroy() {
            rows.clear();
        }

        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public RemoteViews getViewAt(int position) {
            if (position < 0 || position >= rows.size()) {
                return null;
            }
            WidgetModel.Row r = rows.get(position);
            String pkg = context.getPackageName();
            RemoteViews v;

            if (r.type == WidgetModel.ROW_SECTION) {
                v = new RemoteViews(pkg, R.layout.widget_today_section);
                v.setTextViewText(R.id.sec_text, r.text);
                v.setOnClickFillInIntent(R.id.sec_root, new Intent());
                return v;
            }

            if (r.type == WidgetModel.ROW_TODO) {
                v = new RemoteViews(pkg, R.layout.widget_today_todo);
                v.setTextViewText(R.id.todo_text, r.text);
                v.setTextColor(R.id.todo_text, r.overdue ? OVERDUE : TEXT);
                v.setOnClickFillInIntent(R.id.todo_root, new Intent());
                return v;
            }

            v = new RemoteViews(pkg, R.layout.widget_today_row);
            v.setInt(R.id.row_bar, "setBackgroundColor", r.color);
            v.setTextViewText(R.id.row_time, r.time);
            v.setTextColor(R.id.row_time, r.current ? ACCENT : (r.ended ? ENDED_SUB : TEXT_SECONDARY));
            v.setTextViewText(R.id.row_title, r.title);
            v.setTextColor(R.id.row_title, r.ended ? ENDED_TITLE : TEXT);

            if (r.sub.isEmpty()) {
                v.setViewVisibility(R.id.row_sub, View.GONE);
            } else {
                v.setTextViewText(R.id.row_sub, r.sub);
                v.setTextColor(R.id.row_sub, r.ended ? ENDED_SUB : TEXT_SECONDARY);
                v.setViewVisibility(R.id.row_sub, View.VISIBLE);
            }

            if (r.countdown.isEmpty()) {
                v.setViewVisibility(R.id.row_countdown, View.GONE);
            } else {
                v.setTextViewText(R.id.row_countdown, r.countdown);
                v.setTextColor(
                        R.id.row_countdown,
                        r.ended ? ENDED_SUB : (r.countdownLast ? OVERDUE : COUNTDOWN));
                v.setViewVisibility(R.id.row_countdown, View.VISIBLE);
            }

            if (r.progress.isEmpty()) {
                v.setViewVisibility(R.id.row_progress, View.GONE);
            } else {
                v.setTextViewText(R.id.row_progress, r.progress);
                v.setTextColor(R.id.row_progress, r.ended ? ENDED_SUB : TEXT);
                v.setViewVisibility(R.id.row_progress, View.VISIBLE);
            }

            if (r.items.isEmpty()) {
                v.setViewVisibility(R.id.row_items, View.GONE);
            } else {
                v.setTextViewText(R.id.row_items, r.items);
                v.setTextColor(R.id.row_items, r.ended ? ENDED_SUB : TEXT_ITEMS);
                v.setViewVisibility(R.id.row_items, View.VISIBLE);
            }

            v.setOnClickFillInIntent(R.id.row_root, new Intent());
            return v;
        }

        @Override
        public RemoteViews getLoadingView() {
            return null;
        }

        @Override
        public int getViewTypeCount() {
            return 3;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }
    }
}
