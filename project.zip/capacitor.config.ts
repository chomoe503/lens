import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.classplan.assistant',
  appName: '課程助理',
  webDir: 'dist',
  backgroundColor: '#faf8fc',
  plugins: {
    SystemBars: {
      // The app UI is light only: always use dark status/navigation bar icons.
      style: 'LIGHT',
    },
  },
};

export default config;
